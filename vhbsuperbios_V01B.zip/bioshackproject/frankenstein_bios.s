# =============================================================================
# Project Frankenstein: Clean-Room Compliant Super BIOS Bootstrap
#
# LEGAL NOTICE:
#   This file contains 100% original MIPS assembly code. It does NOT
#   contain, reference, or link to any copyrighted Sony, Nintendo, or
#   other proprietary firmware code. No proprietary BIOS dumps are
#   merged into the output. The resulting binary is built entirely
#   from this source file.
#
# Architecture:
#   - MIPS R3000A ISA (publicly documented instruction set)
#   - SFX-100 cartridge bus probe (hypothetical expansion)
#   - Multi-region initialization (NA/JP/EU) via public hardware registers
#   - PSX2 IOP bridge stubs for extended I/O
#
# Memory Map (publicly documented hardware addresses):
#   0xBFC00000 - BIOS ROM base (512KB)
#   0x1F000000 - Hardware registers (CPU control)
#   0x1F801000 - Memory control registers (public datasheet)
#   0x1F400000 - SFX-100 expansion bus (hypothetical)
#   0x80100000 - RAM payload entry (Frankenstein ROM)
#   0xB8000000 - Kanji ROM mapping (JP region, public spec)
#
# Configurable RAM Size (P2):
#   The RAM_SIZE register value at 0x1F801060 is patched by the build
#   script to support 2MB (0x00000B88), 8MB (0x00000B88 | 0x0800),
#   or 16MB (0x00000B88 | 0x1000) configurations.
#   Default: 8MB for Frankenstein builds.
#
# Descriptor Pre-init (P2):
#   Before jumping to the Frankenstein payload, the BIOS writes a safe
#   default descriptor base (0x80100000) to 0x800F2228 and 0x800D9A40.
#   This prevents the DW7 EXE from reading garbage descriptor pointers
#   if HBD parsing over-allocates and the bump pointer exceeds RAM.
#
# Crash Handler (P4):
#   General exception vector at 0xBFC00180 dumps registers to
#   0x801FFF00 (debug area at top of 2MB RAM) for post-mortem analysis.
#
# Build:
#   python build_frankenstein_bios.py
#   (Uses cybergrime/mips/assembler.py — no external toolchain needed)
# =============================================================================

.set noreorder
.global _start
.org 0xbfc00000

# =============================================================================
# Boot Entry Point
# =============================================================================
_start:
    # Step 1: Safe Hardware State Initialization
    # CP0 Status Register: kernel mode, disable interrupts, BEV=1
    li      $t0, 0x00400000         # Kernel mode, clear interrupts
    mtc0    $t0, 12                 # Write to Status Register (CP0 $12)
    nop                             # CP0 write hazard
    mtc0    $zero, 13               # Clear Cause Register (CP0 $13)
    nop

    # Step 2: Initialize Open Memory Controllers via Standard Bus Mapping
    lui     $t1, 0x1f80             # Base I/O address (public hardware register)
    ori     $t2, $t1, 0x1000        # Memory Control Register offset
    li      $t3, 0x00070707         # Generic open-bus timing parameters
    sw      $t3, 0($t2)
    nop

    # Step 3: Configure RAM Size Register (P2: configurable)
    # Default: 8MB (0x00000B88 | 0x0800 = 0x00000F88)
    # The build script patches this immediate for 2MB/8MB/16MB configs.
    # RAM_SIZE_PATCH_MARKER — bios_tool.py replaces this value
    li      $t3, 0x00000F88         # 8MB RAM configuration (default)
    sw      $t3, 0x1060($t1)        # RAM_SIZE register at 0x1F801060
    nop

    # Step 4: Clear RAM (first 64KB sanity check region)
    li      $t0, 0x00000000         # Start of RAM (KUSEG)
    li      $t1, 0x0000FFFF         # End of clear region (64KB)
clear_ram_loop:
    sw      $zero, 0($t0)
    addiu   $t0, $t0, 4
    sltu    $t2, $t0, $t1
    bne     $t2, $zero, clear_ram_loop
    nop

    # Step 5: Probe SFX-100 / SNES-CD Cartridge Bus Interface
    jal     Probe_SFX100_Bus
    nop
    bne     $v0, $zero, sfx_boot_mode
    nop

    # Default: Standard Boot Path
    jal     Init_Region_Profile     # Determine NA/JP/EU via hardware config
    nop
    jal     Preinit_Descriptors    # P2: Write safe descriptor defaults
    nop
    j       Launch_Frankenstein_Rom
    nop

sfx_boot_mode:
    # Initialize SNES-CD / SFX-100 shared memory registers
    jal     Init_SFX100_Bridge
    nop
    jal     Preinit_Descriptors    # P2: Write safe descriptor defaults
    nop
    j       Launch_Frankenstein_Rom
    nop

# =============================================================================
# P2: Descriptor Pre-Initialization
# =============================================================================
# Write safe default descriptor base (0x80100000) to the two locations
# that the DW7 EXE reads during HBD parsing:
#   0x800F2228 — published descriptor base (read by descriptor walk 0x80075430)
#   0x800D9A40 — descriptor table base (read by descriptor publish 0x8007AD44)
# If the EXE's malloc over-allocates and the clamp trampoline (P1) fires,
# these pre-init values ensure the descriptor walk has valid data to read
# instead of garbage from uninitialized BSS.
Preinit_Descriptors:
    lui     $t0, 0x8010             # Safe descriptor base = 0x80100000
    # Write to 0x800F2228 (published descriptor base)
    lui     $t1, 0x800F
    ori     $t1, $t1, 0x2228
    sw      $t0, 0($t1)            # *0x800F2228 = 0x80100000
    nop
    # Write to 0x800D9A40 (descriptor table base)
    lui     $t1, 0x800D
    ori     $t1, $t1, 0x9A40
    sw      $t0, 0($t1)            # *0x800D9A40 = 0x80100000
    nop
    # Write 0 to 0x800F2238 (descriptor index — start at 0)
    lui     $t1, 0x800F
    ori     $t1, $t1, 0x2238
    sw      $zero, 0($t1)          # *0x800F2238 = 0
    nop
    jr      $ra
    nop

# =============================================================================
# Frankenstein ROM Launch
# =============================================================================
Launch_Frankenstein_Rom:
    # Direct handshake to Frankenstein Application Layer
    lui     $k0, 0x8010             # Target RAM Vector
    ori     $k0, $k0, 0x0000
    jr      $k0                     # Jump to Frankenstein payload
    nop

# =============================================================================
# SFX-100 Cartridge Bus Probe
# =============================================================================
Probe_SFX100_Bus:
    # Hardware handshake probe for the unreleased expansion slot
    lui     $t4, 0x1f40             # Hypothetical SFX expansion register space
    lw      $v0, 0($t4)            # Read expansion ID register
    nop                             # Load delay slot
    lui     $t5, 0x5346             # 'SF' magic word check (0x53460000)
    bne     $v0, $t5, probe_fail
    nop
    li      $v0, 1                  # Success: SFX-100 hardware present
    jr      $ra
    nop

probe_fail:
    li      $v0, 0                  # Standard mode fallback
    jr      $ra
    nop

# =============================================================================
# Region Profile Initialization
# =============================================================================
Init_Region_Profile:
    # Read region from hardware configuration area (public register spec)
    # Region codes: 0=JP, 1=NA, 2=AUS, 3=UK, 4=EU, 5=Korea, 6=HK, 7=TW, 8=RUS

    lui     $t0, 0x1f80             # Hardware register base
    lbu     $t1, 0x1060($t0)        # Read region byte from RAM_SIZE config
    nop

    # Branch to region-specific init
    beq     $t1, $zero, region_jp   # Region 0 = Japan
    nop
    li      $t2, 1
    beq     $t1, $t2, region_na     # Region 1 = North America
    nop
    li      $t2, 4
    beq     $t1, $t2, region_eu     # Region 4 = Europe
    nop
    j       region_default          # Unknown region — use NA defaults
    nop

region_jp:
    # Japan: Kanji ROM mapping at 0xB8000000 (public hardware spec)
    lui     $t3, 0xB800             # Kanji ROM base
    li      $t4, 0x00000001         # Enable Kanji ROM
    sw      $t4, 0($t3)
    nop
    # Set NTSC timing (60Hz VSync)
    li      $t5, 0x00000000         # NTSC mode
    j       region_done
    nop

region_na:
    # North America: NTSC timing / CD Audio Sync
    li      $t5, 0x00000000         # NTSC mode
    j       region_done
    nop

region_eu:
    # Europe: PAL interlace / 50Hz VSync handlers
    li      $t5, 0x00000001         # PAL mode
    j       region_done
    nop

region_default:
    # Default to NA/NTSC
    li      $t5, 0x00000000

region_done:
    # Store region mode in a global config location
    lui     $t6, 0x8010             # RAM config area
    ori     $t6, $t6, 0xFFC0       # Offset 0xFFC0 (config page)
    sw      $t5, 0($t6)            # Store region mode
    nop

    jr      $ra
    nop

# =============================================================================
# SFX-100 Bridge Initialization
# =============================================================================
Init_SFX100_Bridge:
    # Map 65816 co-processor communication buffers
    lui     $t0, 0x1f40             # SFX expansion space
    nop

    # Initialize communication buffer descriptors
    li      $t1, 0x00000001         # Enable bridge
    sw      $t1, 0x0100($t0)       # Bridge control register
    nop

    # Set up 65816 I/O buffer at expansion RAM
    lui     $t2, 0x1f41             # Expansion RAM base
    li      $t3, 0x0000FFFF         # Buffer size mask
    sw      $t3, 0($t2)            # Initialize buffer header
    nop

    # Enable SFX-100 interrupt routing
    li      $t4, 0x00000002         # IRQ enable for cartridge bus
    sw      $t4, 0x0200($t0)       # IRQ mask register
    nop

    jr      $ra
    nop

# =============================================================================
# P4: General Exception Handler (at 0xBFC00180)
# =============================================================================
# PSX exception vector for TLB/refill/general exceptions.
# Dumps registers to debug area at 0x801FFF00 (top of 2MB RAM).
# This is a minimal crash logger — it writes register state and
# the exception cause to a known RAM location for post-mortem analysis.
.org 0xbfc00180
exception_handler:
    # Save all registers to debug area at 0x801FFF00
    lui     $k0, 0x801F             # Debug area base = 0x801F0000
    ori     $k0, $k0, 0xFF00        # Offset 0xFF00 = 0x801FFF00
    # Save $at through $t7 (registers 1-15)
    sw      $at, 0x00($k0)          # [0x00] = $at (reg 1)
    sw      $v0, 0x04($k0)          # [0x04] = $v0 (reg 2)
    sw      $v1, 0x08($k0)          # [0x08] = $v1 (reg 3)
    sw      $a0, 0x0C($k0)          # [0x0C] = $a0 (reg 4)
    sw      $a1, 0x10($k0)          # [0x10] = $a1 (reg 5)
    sw      $a2, 0x14($k0)          # [0x14] = $a2 (reg 6)
    sw      $a3, 0x18($k0)          # [0x18] = $a3 (reg 7)
    sw      $t0, 0x1C($k0)          # [0x1C] = $t0 (reg 8)
    sw      $t1, 0x20($k0)          # [0x20] = $t1 (reg 9)
    sw      $t2, 0x24($k0)          # [0x24] = $t2 (reg 10)
    sw      $t3, 0x28($k0)          # [0x28] = $t3 (reg 11)
    sw      $t4, 0x2C($k0)          # [0x2C] = $t4 (reg 12)
    sw      $t5, 0x30($k0)          # [0x30] = $t5 (reg 13)
    sw      $t6, 0x34($k0)          # [0x34] = $t6 (reg 14)
    sw      $t7, 0x38($k0)          # [0x38] = $t7 (reg 15)
    # Save COP0 registers (EPC, Cause, BadVAddr)
    mfc0    $t0, 14                 # EPC (exception PC)
    nop
    sw      $t0, 0x3C($k0)          # [0x3C] = EPC
    mfc0    $t0, 13                 # Cause
    nop
    sw      $t0, 0x40($k0)          # [0x40] = Cause
    mfc0    $t0, 8                  # BadVAddr
    nop
    sw      $t0, 0x44($k0)          # [0x44] = BadVAddr
    mfc0    $t0, 12                 # Status
    nop
    sw      $t0, 0x48($k0)          # [0x48] = Status
    # Write crash magic: 0xDEADCAFE
    lui     $t0, 0xDEAD
    ori     $t0, $t0, 0xCAFE
    sw      $t0, 0x4C($k0)          # [0x4C] = crash magic
    # Halt: infinite loop (watchdog or debugger can break here)
    j       exception_halt
    nop
exception_halt:
    j       exception_halt
    nop

# =============================================================================
# Open-Source Signature Block (NOT a proprietary identifier)
# =============================================================================
.org 0xbfc07FE0
# 32-byte open-source signature at end of 512KB BIOS image
# Identifies this as a Frankenstein-PSX clean-room build
# Format: "FRANK-PSX\0" + "OPEN-BIOS\0\0\0\0\0\0\0"
# These are injected by build_frankenstein_bios.py

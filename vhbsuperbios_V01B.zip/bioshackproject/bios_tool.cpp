// =============================================================================
// bios_tool.cpp — Project Frankenstein: Clean-Room BIOS Binary Utility
//
// High-performance C++ tool for binary post-processing of the clean-room BIOS:
//   - Pad raw machine code to 512KB BIOS image
//   - Inject open-source signatures (FRANK-PSX / OPEN-BIOS)
//   - Compute SHA-256 checksum
//   - Verify clean-room compliance (zero proprietary code)
//
// Build:
//   g++ -O2 -std=c++17 -o bios_tool bios_tool.cpp
//
// Usage:
//   bios_tool pack   <input.bin> <output.bin> [--region NA|JP|EU]
//   bios_tool verify <input.bin>
//   bios_tool checksum <input.bin>
// =============================================================================

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <fstream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>

// ============================================================================
// Constants
// ============================================================================

static constexpr size_t BIOS_SIZE = 524288;       // 512KB
static constexpr size_t SIG_OFFSET = 0x7FE0;      // Signature block offset

// Open-source signatures (NOT proprietary identifiers)
static const uint8_t SIG_FRANK_PSX[16] = {
    'F','R','A','N','K','-','P','S','X',0,0,0,0,0,0,0
};
static const uint8_t SIG_OPEN_BIOS[16] = {
    'O','P','E','N','-','B','I','O','S',0,0,0,0,0,0,0
};

// ============================================================================
// SHA-256 (minimal implementation — no external deps)
// ============================================================================

class SHA256 {
public:
    SHA256() { reset(); }

    void reset() {
        state[0] = 0x6a09e667; state[1] = 0xbb67ae85;
        state[2] = 0x3c6ef372; state[3] = 0xa54ff53a;
        state[4] = 0x510e527f; state[5] = 0x9b05688c;
        state[6] = 0x1f83d9ab; state[7] = 0x5be0cd19;
        bitlen = 0;
        datalen = 0;
    }

    void update(const uint8_t* data, size_t len) {
        for (size_t i = 0; i < len; i++) {
            buffer[datalen++] = data[i];
            if (datalen == 64) {
                transform(buffer);
                bitlen += 512;
                datalen = 0;
            }
        }
    }

    std::string final() {
        // Pad
        uint32_t i = datalen;
        if (datalen < 56) {
            buffer[i++] = 0x80;
            while (i < 56) buffer[i++] = 0x00;
        } else {
            buffer[i++] = 0x80;
            while (i < 64) buffer[i++] = 0x00;
            transform(buffer);
            memset(buffer, 0, 56);
        }
        bitlen += datalen * 8;
        for (i = 0; i < 8; i++)
            buffer[63 - i] = (bitlen >> (i * 8)) & 0xFF;
        transform(buffer);

        std::ostringstream oss;
        for (i = 0; i < 8; i++) {
            oss << std::hex << std::setfill('0') << std::setw(2)
                << ((state[i] >> 24) & 0xFF)
                << ((state[i] >> 16) & 0xFF)
                << ((state[i] >> 8) & 0xFF)
                << (state[i] & 0xFF);
        }
        return oss.str();
    }

private:
    uint8_t buffer[64];
    uint32_t state[8];
    uint64_t bitlen;
    uint32_t datalen;

    static constexpr uint32_t K[64] = {
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };

    static uint32_t rotr(uint32_t x, uint32_t n) { return (x >> n) | (x << (32 - n)); }

    void transform(const uint8_t* block) {
        uint32_t W[64];
        for (int i = 0; i < 16; i++)
            W[i] = (block[i*4]<<24)|(block[i*4+1]<<16)|(block[i*4+2]<<8)|block[i*4+3];
        for (int i = 16; i < 64; i++)
            W[i] = rotr(W[i-15],7) ^ rotr(W[i-15],18) ^ (W[i-15]>>3)
                 + rotr(W[i-2],17) ^ rotr(W[i-2],19) ^ (W[i-2]>>10) + W[i-7] + W[i-16];

        uint32_t a=state[0],b=state[1],c=state[2],d=state[3];
        uint32_t e=state[4],f=state[5],g=state[6],h=state[7];

        for (int i = 0; i < 64; i++) {
            uint32_t S1 = rotr(e,6) ^ rotr(e,11) ^ rotr(e,25);
            uint32_t ch = (e & f) ^ (~e & g);
            uint32_t t1 = h + S1 + ch + K[i] + W[i];
            uint32_t S0 = rotr(a,2) ^ rotr(a,13) ^ rotr(a,22);
            uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            uint32_t t2 = S0 + maj;
            h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        state[0]+=a; state[1]+=b; state[2]+=c; state[3]+=d;
        state[4]+=e; state[5]+=f; state[6]+=g; state[7]+=h;
    }
};

// ============================================================================
// File I/O helpers
// ============================================================================

static std::vector<uint8_t> read_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) {
        fprintf(stderr, "ERROR: Cannot read %s\n", path.c_str());
        exit(1);
    }
    size_t size = f.tellg();
    f.seekg(0);
    std::vector<uint8_t> data(size);
    f.read(reinterpret_cast<char*>(data.data()), size);
    return data;
}

static void write_file(const std::string& path, const std::vector<uint8_t>& data) {
    std::ofstream f(path, std::ios::binary);
    if (!f) {
        fprintf(stderr, "ERROR: Cannot write %s\n", path.c_str());
        exit(1);
    }
    f.write(reinterpret_cast<const char*>(data.data()), data.size());
}

// ============================================================================
// Commands
// ============================================================================

static int cmd_pack(const std::string& input, const std::string& output,
                     const std::string& region) {
    fprintf(stderr, "[bios_tool] Packing %s -> %s (region=%s)\n",
            input.c_str(), output.c_str(), region.c_str());

    auto raw = read_file(input);
    if (raw.size() > BIOS_SIZE) {
        fprintf(stderr, "ERROR: Input (%zu bytes) exceeds BIOS size (%zu)\n",
                raw.size(), BIOS_SIZE);
        return 1;
    }

    // Zero-fill to 512KB
    std::vector<uint8_t> bios(BIOS_SIZE, 0);
    memcpy(bios.data(), raw.data(), raw.size());

    fprintf(stderr, "  Code: %zu bytes at 0x0000\n", raw.size());
    fprintf(stderr, "  Zero-fill: %zu bytes (no proprietary code)\n",
            BIOS_SIZE - raw.size());

    // Inject signatures at 0x7FE0
    memcpy(bios.data() + SIG_OFFSET, SIG_FRANK_PSX, 16);
    memcpy(bios.data() + SIG_OFFSET + 16, SIG_OPEN_BIOS, 16);

    fprintf(stderr, "  Signature at 0x%04zX: FRANK-PSX\n", SIG_OFFSET);
    fprintf(stderr, "  Tag at 0x%04zX: OPEN-BIOS\n", SIG_OFFSET + 16);

    // Compute SHA-256
    SHA256 sha;
    sha.update(bios.data(), bios.size());
    std::string hash = sha.final();

    write_file(output, bios);
    fprintf(stderr, "  Size: %zu bytes\n", bios.size());
    fprintf(stderr, "  SHA-256: %s\n", hash.c_str());
    fprintf(stderr, "[bios_tool] DONE\n");

    return 0;
}

static int cmd_verify(const std::string& input) {
    fprintf(stderr, "[bios_tool] Verifying %s\n", input.c_str());

    auto data = read_file(input);
    int passed = 0, total = 0;

    // Check 1: Size
    total++;
    if (data.size() == BIOS_SIZE) {
        printf("  [PASS] Size: %zu bytes == %zu\n", data.size(), BIOS_SIZE);
        passed++;
    } else {
        printf("  [FAIL] Size: %zu != %zu\n", data.size(), BIOS_SIZE);
    }

    // Check 2: Entry point is valid MIPS (LUI opcode 0x0F or COP0 0x10)
    total++;
    if (data.size() >= 4) {
        uint32_t entry = data[0] | (data[1]<<8) | (data[2]<<16) | (data[3]<<24);
        uint32_t op = (entry >> 26) & 0x3F;
        if (op == 0x0F) {
            printf("  [PASS] Entry opcode: 0x%02X (LUI)\n", op);
            passed++;
        } else if (op == 0x10) {
            printf("  [PASS] Entry opcode: 0x%02X (COP0)\n", op);
            passed++;
        } else {
            printf("  [WARN] Entry opcode: 0x%02X (unexpected)\n", op);
        }
    }

    // Check 3: FRANK-PSX signature
    total++;
    if (memcmp(data.data() + SIG_OFFSET, SIG_FRANK_PSX, 8) == 0) {
        printf("  [PASS] Open-source signature: FRANK-PSX\n");
        passed++;
    } else {
        printf("  [FAIL] No FRANK-PSX signature at 0x%04zX\n", SIG_OFFSET);
    }

    // Check 4: OPEN-BIOS tag
    total++;
    if (memcmp(data.data() + SIG_OFFSET + 16, SIG_OPEN_BIOS, 8) == 0) {
        printf("  [PASS] Open-BIOS tag present\n");
        passed++;
    } else {
        printf("  [FAIL] No OPEN-BIOS tag at 0x%04zX\n", SIG_OFFSET + 16);
    }

    // Check 5: Clean-room — no proprietary strings
    total++;
    bool has_scpy = false;
    for (size_t i = 0; i + 4 <= data.size(); i++) {
        if (memcmp(data.data() + i, "SCPH", 4) == 0 ||
            memcmp(data.data() + i, "Sony", 4) == 0 ||
            memcmp(data.data() + i, "SONY", 4) == 0) {
            has_scpy = true;
            break;
        }
    }
    if (!has_scpy) {
        printf("  [PASS] No proprietary strings (SCPH/Sony) found\n");
        passed++;
    } else {
        printf("  [FAIL] Proprietary strings found — clean-room violation\n");
    }

    // Check 6: Kernel area is zero-filled (no proprietary code)
    total++;
    size_t code_end = 0;
    for (size_t i = 0; i + 4 <= SIG_OFFSET; i += 4) {
        uint32_t w = data[i] | (data[i+1]<<8) | (data[i+2]<<16) | (data[i+3]<<24);
        if (w != 0) code_end = i + 4;
    }
    bool all_zero = true;
    for (size_t i = code_end; i < SIG_OFFSET; i++) {
        if (data[i] != 0) { all_zero = false; break; }
    }
    if (all_zero) {
        printf("  [PASS] Clean-room: 0x%04zX-0x%04zX = %zu bytes of zeros\n",
               code_end, SIG_OFFSET, SIG_OFFSET - code_end);
        passed++;
    } else {
        printf("  [FAIL] Non-zero data in kernel area — possible proprietary code\n");
    }

    printf("\n  Result: %d/%d checks passed\n", passed, total);
    return (passed == total) ? 0 : 1;
}

static int cmd_checksum(const std::string& input) {
    auto data = read_file(input);
    SHA256 sha;
    sha.update(data.data(), data.size());
    printf("%s\n", sha.final().c_str());
    return 0;
}

// ============================================================================
// Main
// ============================================================================

static void usage() {
    fprintf(stderr, "Usage:\n");
    fprintf(stderr, "  bios_tool pack    <input.bin> <output.bin> [--region NA|JP|EU]\n");
    fprintf(stderr, "  bios_tool verify  <input.bin>\n");
    fprintf(stderr, "  bios_tool checksum <input.bin>\n");
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        usage();
        return 1;
    }

    std::string cmd = argv[1];

    if (cmd == "pack") {
        if (argc < 4) { usage(); return 1; }
        std::string region = "NA";
        if (argc >= 6 && std::string(argv[4]) == "--region") {
            region = argv[5];
        }
        return cmd_pack(argv[2], argv[3], region);
    } else if (cmd == "verify") {
        return cmd_verify(argv[2]);
    } else if (cmd == "checksum") {
        return cmd_checksum(argv[2]);
    }

    usage();
    return 1;
}

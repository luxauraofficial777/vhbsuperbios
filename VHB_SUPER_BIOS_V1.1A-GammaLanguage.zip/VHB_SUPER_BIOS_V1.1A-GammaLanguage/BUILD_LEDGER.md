# BUILD LEDGER — VHB Super BIOS V1.01A + CyberGrime (VHB Environment)

**Governing ruleset:** `study/AGENT_DRIFT_RULESET_RAG_MANDATE_Aug3_2026.md` (M4, M9)
**Canonical plan:** `study/SURGICAL_COMPLETION_VHB_CYBERGRIME_Aug3_2026.md`
**Scope:** This ledger covers the VHB_SUPER_BIOS_V1.00A directory only. The separate `DQLOSTTRANSLATION/cybergrime/` environment has its own ledger.

---

## Gate Definitions

### VHB BIOS Gates (B0–B5)

| Gate | Test | Pass criteria |
|------|------|-------------|
| B0 | `build_frankenstein_bios.py --verify-only` | 6/6 clean-room checks (7/7 for V1.01A with Gamma sig) |
| B1 | `vhb_test --bios FRANKENSTEIN.BIOS --max-instr 2000000` | Past CDROM_Init, no crash |
| B2 | BIOS + DW7 disc in `psx_core` | Reaches EXE entry 0x8008E284 |
| B3 | BIOS + DW7 disc in CyberGrime | Reaches EXE entry; telemetry parity vs B2 |
| B4 | BIOS + DQ4 build in DuckStation | Passes DQ4 G2–G3 with FRANKENSTEIN.BIOS — **HARD PREREQUISITE for --gamma** |
| B5 | Service coverage | Documented matrix: every BIOS service called is present or delegated |
| B6 | Gamma script execution (V1.01A) | `--gamma-test` runs all 5 v1.1C opcodes without error |
| B7 | CP0 on-demand mapping (V1.01A) | `--cp0-snapshot` produces valid CP0 register values via live getters |
| B8 | DMA dispatch via FFI (V1.01A) | `--dma-dispatch 2` triggers GPU DMA, controller fires IRQ on completion |

### CyberGrime Harness Gates (H0–H5)

| Gate | Test | Pass criteria |
|------|------|-------------|
| H0 | `build_agent.bat clean` | 0 errors; exe hash recorded |
| H1 | `regression_runner.py quick_smoke` | 3/3 pass against CURRENT discs |
| H2 | `full_regression` | All disc + unit tests pass |
| H3 | CD-ROM conformance | R1.1–R1.8 checklist closed |
| H4 | DQ4 gate alignment | CyberGrime verdict matches DuckStation |
| H5 | CI | One command runs H0–H2 + B0 |

---

## Ledger Entries

| Date | Artifact | Gate | Result | Evidence |
|------|----------|------|--------|---------|
| Aug 3, 2026 | FRANKENSTEIN.BIOS (512KB) | B0 | **PASS** | 6/6 clean-room verification checks (size, entry opcode, FRANK-PSX sig, OPEN-BIOS tag, no proprietary strings, clean kernel area) |
| Aug 3, 2026 | vhb_test.exe + FRANKENSTEIN.BIOS | B1 | **PASS** | 2M instructions, past CDROM_Init YES, 5 CD commands, 10 GPU writes, no crash, idle loop at 0xBFC0027C |
| Aug 3, 2026 | vhb_core.cpp | Compile | **PASS** | Compiles clean with MSVC 19.44 |
| Aug 3, 2026 | vhb_api.cpp | Compile | **FAIL** | 100+ compile errors (enum drift, missing interfaces) — quarantined to `_future_multibit/` per D-A |
| Aug 3, 2026 | cpu_w65c816.cpp | Compile | **FAIL** | Header syntax errors — quarantined to `_future_multibit/` per D-A |
| Aug 4, 2026 | FRANKENSTEIN.BIOS in DuckStation | B4 | **FAIL** | Black screen, FPS=0, CPU=5%, no progress. SCPH-1001 is the working BIOS for DQ4. |
| Aug 4, 2026 | Phase 0 reconcile | — | **DONE** | D-A quarantine (10 dirs/files moved to `_future_multibit/`), D-B boundary (psx_core scoped), README rewritten to truth, CyberGrime_ROADMAP marked SUPERSEDED, 31 stale logs archived |
| Aug 4, 2026 | FRANKENSTEIN.BIOS | B0 | **PASS** (re-verified live) | 6/6 clean-room checks; image forensics: v0.2 sig @0x7FE0, code region 0x0000–0x2100 (8,448 B), 4,978 non-zero bytes. Audit: `study/AUDIT_VHB_CYBERGRIME_REPAIR_UPGRADE_Aug4_2026.md` |
| Aug 4, 2026 | vhb_test.exe + FRANKENSTEIN.BIOS | B1 | **PASS** (reproduced live) | 2M instrs, past CDROM_Init YES, 5 CD commands, 10 GPU writes, no crash, idle 0xBFC0027C |
| Aug 4, 2026 | `cybergrime\build_agent.bat clean` | H0 | **PASS** | BUILD SUCCESS; `psx_agent_runner.exe` 25,153,536 B, sha256[16]=`81E056DE0BAA0D5E` (replaced stale 648,192 B bare build). BASE_DIR fix confirmed in source. |
| Aug 4, 2026 | `regression_runner.py quick_smoke` | H1 | **FAIL → PASS (3/3)** | Initial FAIL: (1) JSON trailing comma in test_definitions.json; (2) telemetry schema mismatch (harness `VBlank_Count` vs evaluator `vblank_count`) auto-failed every emulator test; (3) `min_vblank: 10` @5M instrs physically impossible (~564K instr/vblank → max 8.86). FIX-1/2/3 applied; final 3/3 PASS; `test_results.db` live. |
| Aug 4, 2026 | `regression_runner.py bios_only` | B2 | **PASS** (first record on Jul-30 image) | 5M instrs, 8 vblanks, pc 0x8009674C, no crash. Identical 5M PC to CyberGrime dw7_boot = informal B3 parity. Caveat: `exe_entry_pc` assertion unimplemented in evaluate_pass (C7). |
| Aug 4, 2026 | `cybergrime_ci.bat` | CI | **FIXED** | Line 34 repointed from `bioshackproject\` to VHB root paths. B0_only run: PASS (1/1, exit 0). R0.1 complete. |
| Aug 4, 2026 | Root hygiene (R0.2) | — | **DONE** | 17 `test_*.json` → `configs/`; 2 `.obj` intermediates → `build/`. Root clutter eliminated. |
| Aug 4, 2026 | README_VHB.md + README_SUPER_BIOS.md | Docs | **DONE** | R1.1/R1.2: Rewritten to match product reality (v0.2 kernel, ~8,448 bytes, correct signatures `VHB-SUPER-BIOS-v0.2` + `OpenBIOS`@0x0078, correct paths, service inventory, gate status table). Legal section preserved verbatim. |
| Aug 4, 2026 | SERVICE_INVENTORY.md | Docs | **CREATED** | R1.3: Full service inventory from label scan of frankenstein_bios.s — 50+ services across 10 subsystems + HBD boot logic documented. |
| Aug 5, 2026 | FRANKENSTEIN.BIOS v0.3 (512KB) | B0 | **PASS** | 6/6 clean-room checks. SHA-256: `d9a41be6ef0d6c56cc47e2a7d75c38a5c5ed3fc0ddd32ad0e93532168c6e9a20`. 40,588 bytes code (10,147 instructions). 3 fixes applied: (1) CP0 Status IM0 unmask 0x00040401→0x00040501, (2) unified exception dispatch in VBlank_Handler via Cause register IP0/IP2 check, (3) copy size 384→512. RAM size patched to 2MB (0x00000B88). |
| Aug 5, 2026 | FRANKENSTEIN.BIOS v0.3 | B1 | **PENDING** | Awaiting vhb_test execution |
| Aug 5, 2026 | FRANKENSTEIN.BIOS v0.3 | B4 | **PENDING** | Awaiting DuckStation test |
| Aug 5, 2026 | FRANKENSTEIN.BIOS v0.4 (512KB) | B0 | **PASS** | 6/6 clean-room checks. SHA-256: `c89e2c218d953020daf855f43be99a8036811a43aed10d60faad70247f15243b` (corrected — bios_tool SHA-256 operator precedence bug fixed Aug 4). 40,608 bytes code (10,152 instructions). 6 fixes applied: (1) VBlank_Handler IP2 Cause bit 12 + ISTAT dispatch, (2) BEV exception handler IP2 Cause bit 12 + ISTAT dispatch, (3) A0 table CD functions at 4B-4F, (4) B0 table CD functions at 4B-4F, (5) GPU_Init display range command bytes 0x0C→0x06/0x07, (6) version signature v0.4. RAM size patched to 2MB (0x00000B88). |
| Aug 5, 2026 | FRANKENSTEIN.BIOS v0.4 | B1 | **PENDING** | Awaiting vhb_test execution |
| Aug 5, 2026 | FRANKENSTEIN.BIOS v0.4 | B4 | **PENDING** | Awaiting DuckStation test |

---

## Phase 0 Gate (from surgical plan)

**Gate:** H0 + B0 recorded in BUILD_LEDGER.md

- **B0: PASS** (recorded above)
- **H0: PASS** (Aug 4 — BASE_DIR confirmed correct; clean rebuild BUILD SUCCESS, exe hash pinned above). **Phase 0 gate CLOSED.**

---

## V1.01A GammaLanguage v1.1C Blueprint Entries

| Date | Artifact | Gate | Result | Evidence |
|------|----------|------|--------|----------|
| Aug 10, 2026 | `BLUEPRINT_V1.01A_GammaLanguage_v1.1C.md` | — | **CREATED** | Full upgrade blueprint: 5 phases, 17 implementation steps, 6 new files, 12 modified files, ~6h effort estimate |
| Aug 10, 2026 | `COUNTER_REFLECTION_V1.01A.md` | — | **RECEIVED** | First counter reflection: 4 issues (memory collision 0x80010000, CP0 stale polling, DMA I_STAT race, endianness/pointer size) |
| Aug 10, 2026 | `COUNTER_REFLECTION_V1.01A_SECOND_REPORT.md` | — | **RECEIVED** | Second counter reflection: 3 additional issues (DMA reg misalignment, RustFFIExport static_assert, RegisterBank race condition) |
| Aug 10, 2026 | `A2A_Gamma.h` — `PSXHwRegMap` | — | **FIXED** | DMA CH1: 0x1F8010A0→0x1F801090 (MDEC out), CH2: 0x1F8010B0→0x1F8010A0 (GPU) |
| Aug 10, 2026 | `A2A_Gamma.h` — `RustFFIExport` | — | **FIXED** | `DataPtr` changed from `const void*` to `uint64_t`; `static_assert` updated 80→96 bytes |
| Aug 10, 2026 | `A2A_Gamma.h` — `RegisterBank` | — | **FIXED** | Added `std::atomic_flag` spinlock with `lock()`/`unlock()` methods; `#include <atomic>` added |
| Aug 10, 2026 | `BLUEPRINT_V1.01A_GammaLanguage_v1.1C.md` | — | **AMENDED** | All 7 counter reflection fixes applied: RAM→0x80000200, on-demand CP0 getters, removed I_STAT from DMA trampoline, B4 hard prerequisite, Rust FFI u64 parity, config JSON updated, gate chain restructured |
| Aug 11, 2026 | `README_VHB.md` | Docs | **UPDATED** | V1.01A: version, gate status (B6-B8), GammaLanguage section, counter reflection fixes, 7/7 verification, subsystem table |
| Aug 11, 2026 | `README_SUPER_BIOS.md` | Docs | **UPDATED** | V1.01A: version, 7/7 verification, Gamma constants, GammaLanguage integration section |
| Aug 11, 2026 | `SERVICE_INVENTORY.md` | Docs | **UPDATED** | V1.01A: GammaLanguage services, Rust FFI PEAK table, CP0 on-demand map, DMA channel table, RustFFIExport struct layout |
| Aug 11, 2026 | `BUILD_LEDGER.md` | Docs | **UPDATED** | V1.01A: gate definitions B6-B8, blueprint + counter reflection entries, fix records |

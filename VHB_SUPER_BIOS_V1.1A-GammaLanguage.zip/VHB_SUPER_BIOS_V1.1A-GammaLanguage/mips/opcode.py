"""MIPS I opcode tables and register helpers."""

REG_NAMES = [
    "zero", "at", "v0", "v1", "a0", "a1", "a2", "a3",
    "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
    "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
    "t8", "t9", "k0", "k1", "gp", "sp", "fp", "ra",
]

REG_BY_NAME = {name: idx for idx, name in enumerate(REG_NAMES)}


def reg_index(name: str) -> int:
    """Return register index from name or integer string."""
    name = name.strip().lstrip("$").lower()
    if name in REG_BY_NAME:
        return REG_BY_NAME[name]
    try:
        idx = int(name, 0)
        if 0 <= idx < 32:
            return idx
    except ValueError:
        pass
    raise ValueError(f"Unknown register: {name}")


def reg_name(idx: int) -> str:
    if 0 <= idx < 32:
        return REG_NAMES[idx]
    raise ValueError(f"Invalid register index: {idx}")


# Primary opcodes (bits 31-26)
OP_SPECIAL = 0x00
OP_REGIMM = 0x01
OP_J = 0x02
OP_JAL = 0x03
OP_BEQ = 0x04
OP_BNE = 0x05
OP_BLEZ = 0x06
OP_BGTZ = 0x07
OP_ADDI = 0x08
OP_ADDIU = 0x09
OP_SLTI = 0x0A
OP_SLTIU = 0x0B
OP_ANDI = 0x0C
OP_ORI = 0x0D
OP_XORI = 0x0E
OP_LUI = 0x0F
OP_LB = 0x20
OP_LH = 0x21
OP_LWL = 0x22
OP_LW = 0x23
OP_LBU = 0x24
OP_LHU = 0x25
OP_LWR = 0x26
OP_SB = 0x28
OP_SH = 0x29
OP_SWL = 0x2A
OP_SW = 0x2B

# SPECIAL function codes (bits 5-0)
FN_SLL = 0x00
FN_SRL = 0x02
FN_SRA = 0x03
FN_SLLV = 0x04
FN_SRLV = 0x06
FN_SRAV = 0x07
FN_JR = 0x08
FN_JALR = 0x09
FN_SYSCALL = 0x0C
FN_BREAK = 0x0D
FN_MFHI = 0x10
FN_MTHI = 0x11
FN_MFLO = 0x12
FN_MTLO = 0x13
FN_MULT = 0x18
FN_MULTU = 0x19
FN_DIV = 0x1A
FN_DIVU = 0x1B
FN_ADD = 0x20
FN_ADDU = 0x21
FN_SUB = 0x22
FN_SUBU = 0x23
FN_AND = 0x24
FN_OR = 0x25
FN_XOR = 0x26
FN_NOR = 0x27
FN_SLT = 0x2A
FN_SLTU = 0x2B

# REGIMM rt codes (bits 20-16)
RT_BLTZ = 0x00
RT_BGEZ = 0x01
RT_BLTZAL = 0x10
RT_BGEZAL = 0x11

OPCODES = {
    "j": ("J", OP_J),
    "jal": ("J", OP_JAL),
    "beq": ("B", OP_BEQ),
    "bne": ("B", OP_BNE),
    "blez": ("Bz", OP_BLEZ),
    "bgtz": ("Bz", OP_BGTZ),
    "addi": ("Is", OP_ADDI),
    "addiu": ("Is", OP_ADDIU),
    "slti": ("Is", OP_SLTI),
    "sltiu": ("Is", OP_SLTIU),
    "andi": ("Iu", OP_ANDI),
    "ori": ("Iu", OP_ORI),
    "xori": ("Iu", OP_XORI),
    "lui": ("Lui", OP_LUI),
    "lb": ("I", OP_LB),
    "lh": ("I", OP_LH),
    "lw": ("I", OP_LW),
    "lbu": ("I", OP_LBU),
    "lhu": ("I", OP_LHU),
    "sb": ("I", OP_SB),
    "sh": ("I", OP_SH),
    "sw": ("I", OP_SW),
    "lwl": ("I", OP_LWL),
    "lwr": ("I", OP_LWR),
    "swl": ("I", OP_SWL),
}

SPECIAL_FUNCS = {
    "sll": ("R_sa", FN_SLL),
    "srl": ("R_sa", FN_SRL),
    "sra": ("R_sa", FN_SRA),
    "sllv": ("R", FN_SLLV),
    "srlv": ("R", FN_SRLV),
    "srav": ("R", FN_SRAV),
    "jr": ("R_j", FN_JR),
    "jalr": ("R_j", FN_JALR),
    "mfhi": ("R_dst", FN_MFHI),
    "mthi": ("R_src", FN_MTHI),
    "mflo": ("R_dst", FN_MFLO),
    "mtlo": ("R_src", FN_MTLO),
    "mult": ("R_mul", FN_MULT),
    "multu": ("R_mul", FN_MULTU),
    "div": ("R_mul", FN_DIV),
    "divu": ("R_mul", FN_DIVU),
    "add": ("R", FN_ADD),
    "addu": ("R", FN_ADDU),
    "sub": ("R", FN_SUB),
    "subu": ("R", FN_SUBU),
    "and": ("R", FN_AND),
    "or": ("R", FN_OR),
    "xor": ("R", FN_XOR),
    "nor": ("R", FN_NOR),
    "slt": ("R", FN_SLT),
    "sltu": ("R", FN_SLTU),
    "syscall": ("R_none", FN_SYSCALL),
    "break": ("R_none", FN_BREAK),
}

REGIMM_FUNCS = {
    "bltz": ("Bz_l", RT_BLTZ),
    "bgez": ("Bz_l", RT_BGEZ),
    "bltzal": ("Bz_l", RT_BLTZAL),
    "bgezal": ("Bz_l", RT_BGEZAL),
}

# COP0 (opcode 0x10)
OP_COP0 = 0x10

# COP0 rs field codes (bits 25-21)
COP0_MFC0 = 0x00  # mfc0 rt, rd
COP0_MTC0 = 0x04  # mtc0 rt, rd
COP0_CFC0 = 0x02  # cfc0 rt, rd
COP0_CTC0 = 0x06  # ctc0 rt, rd

# CP0 register names (for disassembly / reference)
CP0_REG_NAMES = {
    0: "Index", 1: "Random", 2: "EntryLo0", 3: "EntryLo1",
    4: "Context", 5: "PageMask", 6: "Wired", 7: "BadVAddr",
    8: "Count", 9: "EntryHi", 10: "Compare", 11: "SR",
    12: "Status", 13: "Cause", 14: "EPC", 15: "PRId",
    16: "Config",
}

CP0_REG_BY_NAME = {v.lower(): k for k, v in CP0_REG_NAMES.items()}

# Add numeric aliases (Status=12, Cause=13, EPC=14, etc.)
for _i in range(32):
    CP0_REG_BY_NAME[str(_i)] = _i

COP0_FUNCS = {
    "mtc0": ("COP0_m", COP0_MTC0),
    "mfc0": ("COP0_m", COP0_MFC0),
    "ctc0": ("COP0_m", COP0_CTC0),
    "cfc0": ("COP0_m", COP0_CFC0),
}


def cp0_reg_index(name: str) -> int:
    """Return CP0 register index from name or integer string."""
    name = name.strip().lstrip("$").lower()
    if name in CP0_REG_BY_NAME:
        return CP0_REG_BY_NAME[name]
    try:
        idx = int(name, 0)
        if 0 <= idx < 32:
            return idx
    except ValueError:
        pass
    raise ValueError(f"Unknown CP0 register: {name}")

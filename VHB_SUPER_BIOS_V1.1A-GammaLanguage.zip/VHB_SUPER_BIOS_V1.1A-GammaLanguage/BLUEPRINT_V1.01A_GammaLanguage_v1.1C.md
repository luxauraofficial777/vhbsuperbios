# VHB Super BIOS V1.01A — GammaLanguage v1.1C Integration Blueprint

**Date:** August 11, 2026  
**Author:** Cascade (Pair-Programming Agent)  
**Status:** Blueprint — Approved for Implementation  
**Scope:** VHB_SUPER_BIOS_V1.00A → V1.01A upgrade with GammaLanguage v1.1C

---

## 1. Executive Summary

This blueprint specifies the upgrade of the VHB Super BIOS from V1.00A to V1.01A, integrating GammaLanguage v1.1C (Rust FFI Zero-Copy + Peak Performance) into all layers of the VHB stack: the clean-room BIOS image (`frankenstein_bios.s`), the C++ hypervisor core (`vhb_core.h`/`vhb_core.cpp`), the launcher (`vhb_launch.cpp`), the build orchestrator (`build_frankenstein_bios.py`), and the CyberGrime harness environment.

The upgrade adds five new capabilities:

1. **Rust FFI Zero-Copy Memory Offsets** — `&RUST_OFFSET` sigil for zero-copy PSX hardware register access
2. **PEAK Subsystem FFI Dispatch** — `RUST_FFI_CALL` opcode for PEAK-1..5 function pointer dispatch
3. **Alignment Bounds** — `@ALIGN_BOUND` for `repr(C)` parity between MIPS and Rust types
4. **CyberGrime CP0 Register Mapping** — `CP0_REG_MAP` opcode mapping MIPS R3000A CP0 registers into Gamma `RegisterBank`
5. **PSXMatrix DMA Hardware Register Dispatch** — `PSX_DMA_DISPATCH` opcode for DMA channel control via Rust FFI

---

## 2. Current State Analysis (V1.00A)

### 2.1 BIOS Image (`frankenstein_bios.s`)

| Property | Value |
|----------|-------|
| Version | v0.5 (assembly header), v0.4 (build ledger) |
| Size | 512KB (524,288 bytes) |
| Code region | 0x0000–0x2100 (8,448 bytes, ~2,112 instructions) |
| Kernel services | 50+ across 10 subsystems |
| Signature | `VHB-SUPER-BIOS-v0.2` at offset 0x7FE0 |
| Clean-room | 6/6 verification checks PASS |
| HBD boot logic | Present (Find_HBD, skip_hbd_load) |

### 2.2 C++ Hypervisor Core (`vhb_core.h` / `vhb_core.cpp`)

| Component | Status |
|-----------|--------|
| SoftMMU (64MB pool) | Implemented, C++ side only |
| VectorDispatcher | Implemented (A0/B0/C0 + custom vectors) |
| VirtualFileSystem | Implemented (mount/open/read) |
| RomImageInfo | PS-X EXE + ISO 9660 parsing |
| TargetProfile | 11 target systems (PSX primary) |
| GammaLanguage | **NOT INTEGRATED** |
| Rust FFI | **NOT INTEGRATED** |
| CP0 mapping | **NOT INTEGRATED** |
| DMA dispatch | **NOT INTEGRATED** |

### 2.3 Gate Status

| Gate | Test | Result |
|------|------|--------|
| B0 | Clean-room verification (6/6) | **PASS** |
| B1 | vhb_test 2M instructions | **PASS** |
| B2 | BIOS + DW7 disc, 5M instrs | **PASS** |
| B3 | CyberGrime parity vs B2 | **PASS** (informal) |
| B4 | DuckStation boot | **FAIL** (black screen) |
| B5 | Service coverage matrix | **OPEN** |

### 2.4 Key Gaps

- **B4 blocker:** No commercial-emulator boot — semantic mismatch with DuckStation expectations
- **No GammaLanguage:** VHB Core has no A2A-DSL parser, evaluator, or bytecode VM
- **No Rust FFI:** No zero-copy memory bridge to PSX hardware registers
- **No CP0 mapping:** CP0 state not exposed to speculative execution layer
- **No DMA dispatch:** DMA channels not controllable via FFI
- **No alignment guarantees:** No `repr(C)` parity between MIPS assembly structs and C++/Rust types
- **Soft-MMU is C++ only:** BIOS image has no MMU services

---

## 3. Target Architecture (V1.01A)

### 3.1 Layer Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    VHB Super BIOS V1.01A                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────┐  │
│  │  BIOS Image      │  │  VHB Core (C++)  │  │  Rust FFI    │  │
│  │  (MIPS R3000A)   │  │  Hypervisor      │  │  Bridge      │  │
│  │                  │  │                  │  │              │  │
│  │  - CP0 init      │  │  - SoftMMU       │  │  - PEAK-1..5 │  │
│  │  - CP0_REG_MAP ◄─┼──┼── CP0Map struct  │  │  dispatch    │  │
│  │  - DMA dispatch  │  │  - GammaEvaluator│◄─┤  - repr(C)   │  │
│  │  - PSX hw regs   │  │  - RegisterBank  │  │  parity      │  │
│  │  - Gamma sigils  │  │  - FFIExports[4] │  │  - zero-copy │  │
│  │  - A0/B0/C0 tbl  │  │  - PSXHwRegMap   │  │  offsets     │  │
│  │  - VBlank handler│  │  - VectorDispatch│  │              │  │
│  │                  │  │  - VFS           │  │  - SpecScope │  │
│  └──────────────────┘  └──────────────────┘  └──────────────┘  │
│         │                       │                     │         │
│         └───────────────────────┼─────────────────────┘         │
│                                 │                               │
│                    ┌────────────┴────────────┐                  │
│                    │  GammaLanguage v1.1C    │                  │
│                    │  A2A_Gamma.h (inline)   │                  │
│                    │  - Lexer + Parser       │                  │
│                    │  - AST Evaluator        │                  │
│                    │  - Bytecode VM (DTC)    │                  │
│                    │  - 5 new v1.1C opcodes  │                  │
│                    └─────────────────────────┘                  │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 3.2 New Components

| Component | Location | Language | Purpose |
|-----------|----------|----------|---------|
| `A2A_Gamma.h` | `gamma/A2A_Gamma.h` | C++ (inline header) | GammaLanguage parser, evaluator, bytecode VM |
| `gamma_ffi.rs` | `rust/gamma_ffi.rs` | Rust | FFI bridge with `repr(C)` parity types |
| `gamma_ffi.h` | `gamma/gamma_ffi.h` | C++ | Rust FFI C-ABI bindings |
| `gamma_bridge.py` | (existing, updated) | Python | Python bridge for build-time Gamma scripts |
| `vhb_gamma_config.json` | `configs/vhb_gamma_config.json` | JSON | GammaLanguage feature configuration |

### 3.3 Modified Components

| Component | File | Changes |
|-----------|------|---------|
| BIOS assembly | `frankenstein_bios.s` | CP0 register export stubs, DMA dispatch trampoline, Gamma sigil scan |
| VHB Core header | `vhb_core.h` | GammaEvaluator member, FFI dispatch table, CP0Map, PSXHwRegMap |
| VHB Core impl | `vhb_core.cpp` | Gamma script execution, FFI init, CP0 snapshot, DMA dispatch |
| VHB Launcher | `vhb_launch.cpp` | `--gamma` flag, `--gamma-script PATH` option |
| Build orchestrator | `build_frankenstein_bios.py` | Version bump, Gamma sigil verification, Rust crate build |
| bios_tool | `bios_tool.cpp` | Version signature update, Gamma feature flag in header |
| Service inventory | `SERVICE_INVENTORY.md` | New Gamma/FFI/CP0/DMA services documented |
| Build ledger | `BUILD_LEDGER.md` | V1.01A gate entries |
| README | `README_VHB.md` / `README_SUPER_BIOS.md` | V1.01A documentation |

---

## 4. Implementation Plan

### Phase 1: GammaLanguage Core Integration (C++ Side)

**Goal:** Embed `A2A_Gamma.h` into VHB Core as the speculative execution and FFI dispatch engine.

#### 4.1.1 — Copy A2A_Gamma.h into VHB

- Create `gamma/` directory under VHB root
- Copy `A2A_Gamma.h` from `Modern_X64/tools/Liminal_Lore_V1.1B/liminal_lore_vw_deck/gamma/A2A_Gamma.h`
- This is the v1.1C inline header with all 5 new opcodes, types, lexer, and evaluator

#### 4.1.2 — Extend `vhb_core.h`

```cpp
// New includes
#include "gamma/A2A_Gamma.h"

// New structs (mirror GammaLanguage v1.1C types)
struct VHBCP0Snapshot {
    uint32_t Status;
    uint32_t Cause;
    uint32_t EPC;
    uint32_t BadVAddr;
    uint32_t Count;
    uint32_t Compare;
    uint32_t EntryHi;
    uint32_t Index;
};

struct VHBPSXHwRegs {
    uint32_t DMA_CH1_MADR;
    uint32_t DMA_CH1_BCR;
    uint32_t DMA_CH1_CHCR;
    uint32_t DMA_CH2_MADR;
    uint32_t DMA_CH2_BCR;
    uint32_t DMA_CH2_CHCR;
    uint32_t GPU_GP0;
    uint32_t GPU_GP1;
    uint32_t I_STAT;
    uint32_t I_MASK;
};

// Extend SuperBIOSHypervisor class
class SuperBIOSHypervisor {
    // ... existing members ...
    
    // GammaLanguage v1.1C members
    RegisterBank gamma_regs;
    ASTArena<256> gamma_arena;
    BytecodeArena<512> gamma_bytecode;
    Evaluator gamma_evaluator;
    
    // CP0 and PSX hw reg state (on-demand, not VBlank-polled)
    VHBCP0Snapshot cp0_snapshot;  // Initial boot snapshot only
    VHBPSXHwRegs psx_hw_regs;     // Live hardware register shadow
    
    // FFI dispatch table
    RustFFIDispatchTable ffi_dispatch;
    
public:
    // New methods
    bool execute_gamma_script(const std::string& script);
    VHBCP0Snapshot get_cp0_live() const;  // On-demand CP0 read (replaces snapshot_cp0)
    void dispatch_dma(uint8_t channel);
    void init_ffi_dispatch();
    const VHBPSXHwRegs& get_psx_hw_regs() const;
};
```

#### 4.1.3 — Extend `vhb_core.cpp`

- **`execute_gamma_script()`** — Parse Gamma DSL script → AST → evaluate → compile to bytecode → execute via DTC
- **`snapshot_cp0()`** — **REMOVED** — Per Counter Reflection Report #1, VBlank polling produces stale `Count`/`Compare` data. Instead, `CP0_REG_MAP` uses **on-demand getters** that read live CP0 state directly from the hypervisor's MIPS CPU context when the Gamma evaluator accesses `gamma_regs.CP0Map` fields
- **`get_cp0_live()`** — NEW: On-demand CP0 register read from emulated MIPS state. Called by `CP0_REG_MAP` opcode handler instead of reading stale RAM snapshot. Returns fresh `Count`, `Compare`, `Status`, etc. at evaluation time
- **`dispatch_dma()`** — Set up DMA channel registers in `psx_hw_regs`, trigger `PSX_DMA_DISPATCH` opcode in Gamma evaluator. **Does NOT manually fire I_STAT** — lets the emulator's DMA controller trigger the interrupt naturally when the block transfer completes
- **`init_ffi_dispatch()`** — Initialize `ffi_dispatch` function pointers (PEAK-1..5 stubs for C++ side, real Rust FFI when crate is linked)

#### 4.1.4 — Extend `vhb_launch.cpp`

- Add `--gamma` flag: enable GammaLanguage processing
- Add `--gamma-script PATH` option: load and execute a `.gamma` script file
- Add `--gamma-test` option: run built-in v1.1C test script
- Add `--cp0-snapshot` option: dump CP0 register snapshot
- Add `--dma-dispatch CH` option: dispatch DMA channel via Gamma FFI

### Phase 2: BIOS Assembly Extensions (MIPS Side)

**Goal:** Add MIPS assembly stubs in `frankenstein_bios.s` for CP0 register export and DMA dispatch trampolines.

#### 4.2.1 — CP0 Register Export Stubs

```mips
# CP0 Register Export — called during boot to snapshot CP0 state
# into a known RAM location for Gamma evaluator access
Export_CP0_State:
    mfc0    $t0, 12           # Status
    sw      $t0, CP0_STATUS_ADDR
    mfc0    $t0, 13           # Cause
    sw      $t0, CP0_CAUSE_ADDR
    mfc0    $t0, 14           # EPC
    sw      $t0, CP0_EPC_ADDR
    mfc0    $t0, 8            # BadVAddr
    sw      $t0, CP0_BADVADDR_ADDR
    mfc0    $t0, 9            # Count
    sw      $t0, CP0_COUNT_ADDR
    mfc0    $t0, 11           # Compare
    sw      $t0, CP0_COMPARE_ADDR
    jr      $ra
    nop
```

- **RAM addresses:** Allocate 32 bytes at `0x80000200` (kernel reserved area, below EXE load address) for CP0 snapshot struct. **NOT `0x80010000`** — that address is the default PS-X EXE load address and would corrupt game code
- **Call site:** After CP0 init, before GPU init — gives Gamma evaluator early CP0 state
- **VBlank hook:** **REMOVED** — Per Counter Reflection Report, VBlank polling produces stale `Count`/`Compare` data. CP0 state is read on-demand via C++ hypervisor getters

#### 4.2.2 — DMA Dispatch Trampoline

```mips
# DMA Dispatch Trampoline — callable from Gamma evaluator via FFI
# Sets up DMA channel registers and triggers transfer
DMA_Dispatch:
    # $a0 = channel (0-6)
    # $a1 = MADR (memory address)
    # $a2 = BCR (block count + size)
    # $a3 = CHCR (control flags)
    lui     $t0, 0x1f80
    sll     $t1, $a0, 4       # channel * 16
    addu    $t0, $t0, $t1     # 0x1F801000 + channel*16 + 0x80
    sw      $a1, 0x80($t0)    # MADR
    sw      $a2, 0x84($t0)    # BCR
    sw      $a3, 0x88($t0)    # CHCR (triggers transfer)
    # NOTE: Do NOT manually set I_STAT — let the DMA controller
    # fire the interrupt naturally when the block transfer completes.
    # Manual I_STAT writes cause race conditions (Counter Reflection Report #1).
    jr      $ra
    nop
```

- **Address:** Appended after existing kernel code, before signature area
- **Size:** ~14 instructions (56 bytes) — reduced after removing I_STAT write
- **Integration:** Called via `RUST_FFI_CALL` → PEAK-4 HW interrupt dispatch path

#### 4.2.3 — Gamma Sigil Scan (Boot-Time)

Add a minimal boot-time scanner that checks for Gamma sigil markers in the SYSTEM.CNF boot line:

```mips
# Scan SYSTEM.CNF for Gamma directives (e.g., "GAMMA=1")
# If found, set flag at GAMMA_ENABLED_ADDR
Check_Gamma_Flag:
    # ... parse SYSTEM.CNF for "GAMMA=" prefix ...
    # If found, set byte at 0x80000220 to 1
    jr      $ra
    nop
```

- **Size:** ~30 instructions (120 bytes)
- **Purpose:** Allows disc-side Gamma scripts to be auto-loaded at boot

#### 4.2.4 — Version Signature Update

- Update signature from `VHB-SUPER-BIOS-v0.2` to `VHB-SUPER-BIOS-v1.01A`
- Update assembly header comment from `v0.5` to `v1.01A`
- Update `RAM_SIZE_PATCH_MARKER` area to include Gamma flag byte

### Phase 3: Rust FFI Bridge

**Goal:** Create a Rust crate that provides `repr(C)` parity types and PEAK-1..5 dispatch functions.

#### 4.3.1 — `rust/gamma_ffi.rs`

```rust
// repr(C) parity types matching A2A_Gamma.h
// Fixed: DataPtr uses u64 for fixed-width parity with C++ uint64_t on x64
#[repr(C, align(16))]
pub struct RustFFIExport {
    pub data_ptr: u64,          // 8 bytes fixed-width (was *const u8)
    pub data_size: u32,
    pub element_size: u32,
    pub repr: RustReprType,
    pub flags: u8,
    pub _pad: [u8; 2],
    pub offset_addr: u32,
    pub struct_name: [u8; 32],
    pub field_name: [u8; 32],
}
// Size: 96 bytes on x64 (was incorrectly 80 in original blueprint)

#[repr(C)]
pub struct CyberGrimeCP0Map {
    pub status: u32,
    pub cause: u32,
    pub epc: u32,
    pub bad_vaddr: u32,
    pub count: u32,
    pub compare: u32,
    pub entry_hi: u32,
    pub index: u32,
}

#[repr(C)]
pub struct PSXHwRegMap {
    pub dma_ch1_madr: u32,
    pub dma_ch1_bcr: u32,
    pub dma_ch1_chcr: u32,
    pub dma_ch2_madr: u32,
    pub dma_ch2_bcr: u32,
    pub dma_ch2_chcr: u32,
    pub gpu_gp0: u32,
    pub gpu_gp1: u32,
    pub i_stat: u32,
    pub i_mask: u32,
}

// PEAK-1..5 dispatch functions
#[no_mangle]
pub extern "C" fn peak1_export_bytecode(...) -> i32 { ... }

#[no_mangle]
pub extern "C" fn peak2_qvec_simd(...) -> i32 { ... }

#[no_mangle]
pub extern "C" fn peak3_spec_scope_enter(...) -> i32 { ... }

#[no_mangle]
pub extern "C" fn peak4_hw_int_dispatch(...) -> i32 { ... }

#[no_mangle]
pub extern "C" fn peak5_ring_iter_next(...) -> i32 { ... }
```

#### 4.3.2 — `rust/Cargo.toml`

```toml
[package]
name = "gamma_ffi"
version = "1.1.0"
edition = "2021"

[lib]
crate-type = ["cdylib", "staticlib"]
```

#### 4.3.3 — `gamma/gamma_ffi.h` (C-ABI Bindings)

```cpp
#pragma once
#include <cstdint>

// Rust FFI C-ABI declarations
extern "C" {
    int32_t peak1_export_bytecode(void* bytecode, uint32_t size);
    int32_t peak2_qvec_simd(void* vec_a, void* vec_b, uint32_t count);
    int32_t peak3_spec_scope_enter(uint32_t scope_id);
    int32_t peak4_hw_int_dispatch(uint32_t vector, uint32_t* registers);
    int32_t peak5_ring_iter_next(uint32_t ring_id, uint32_t* out_value);
}
```

#### 4.3.4 — Build Integration

- Add Rust build step to `build_frankenstein_bios.py`:
  - Check for `cargo` in PATH
  - If found: `cargo build --release` in `rust/` directory
  - Link `gamma_ffi.lib` (or `.a`) into VHB Core build
  - If not found: use C++ stub implementations (function pointers set to no-op lambdas)

### Phase 4: Build Pipeline Updates

#### 4.4.1 — `build_frankenstein_bios.py` Changes

- Version bump: `v0.5` → `v1.01A`
- New `--gamma` flag: enables Gamma feature set in BIOS build
- New `--rust-ffi` flag: builds and links Rust FFI crate
- New verification checks (7/7 for V1.01A):
  - Check 7: Gamma signature at offset 0x7FF0 (`GAMMA-v1.1C`)
- Updated `--verify-only` to check 7/7 instead of 6/6
- New `--gamma-script PATH` option: embed a Gamma script into BIOS image at offset 0x7F00

#### 4.4.2 — `bios_tool.cpp` Changes

- Update version string to `VHB-SUPER-BIOS-v1.01A`
- Add Gamma signature injection at offset 0x7FF0
- Add `--gamma-features` flag to list enabled Gamma features
- Update clean-room verification to 7/7 checks

#### 4.4.3 — `configs/vhb_gamma_config.json`

```json
{
    "gamma_language_version": "v1.1C",
    "gamma_features": [
        "&RUST_OFFSET",
        "@ALIGN_BOUND",
        "RUST_FFI_CALL",
        "CP0_REG_MAP",
        "PSX_DMA_DISPATCH"
    ],
    "ffi_dispatch_table": {
        "peak1_export_bytecode": true,
        "peak2_qvec_simd": true,
        "peak3_spec_scope_enter": true,
        "peak4_hw_int_dispatch": true,
        "peak5_ring_iter_next": true
    },
    "cp0_register_map": {
        "enabled": true,
        "snapshot_address": "0x80000200",
        "vblank_refresh": false,
        "on_demand_getters": true
    },
    "psx_dma_dispatch": {
        "enabled": true,
        "channels": [0, 1, 2, 3, 4, 5, 6],
        "interrupt_on_complete": false,
        "controller_driven_irq": true
    },
    "alignment_bound": 16,
    "rust_ffi_crate": "gamma_ffi",
    "rust_ffi_version": "1.1.0"
}
```

### Phase 5: Documentation Updates

#### 4.5.1 — `README_VHB.md`

- Update version to V1.01A throughout
- Add "GammaLanguage v1.1C Integration" section
- Update architecture diagram to show Gamma/Rust FFI layers
- Update subsystem table with new Gamma/FFI/CP0/DMA rows
- Update gate status table with new B6-B8 gates
- Update file inventory with new files
- Update build instructions with `--gamma` and `--rust-ffi` flags

#### 4.5.2 — `README_SUPER_BIOS.md`

- Update version to v1.01A
- Update architecture diagram with Gamma layer
- Update verification table to 7/7 checks
- Update key constants with Gamma-related addresses
- Update DuckStation deployment section with Gamma boot sequence

#### 4.5.3 — `SERVICE_INVENTORY.md`

- Add new sections:
  - **GammaLanguage Services:** `execute_gamma_script`, `snapshot_cp0`, `dispatch_dma`, `init_ffi_dispatch`
  - **Rust FFI Services:** PEAK-1..5 dispatch functions
  - **CP0 Register Map:** `Export_CP0_State`, `VHBCP0Snapshot` struct
  - **DMA Dispatch:** `DMA_Dispatch` trampoline, `VHBPSXHwRegs` struct

#### 4.5.4 — `BUILD_LEDGER.md`

- Add V1.01A gate entries (B0 re-verify with 7/7, B6, B7, B8)
- Record all file changes
- Record SHA-256 of new BIOS image

#### 4.5.5 — `cybergrime/README.md` + `cybergrime/INTEGRATION_MANIFEST.md`

- Update GammaLanguage integration section to reference VHB V1.01A
- Add VHB-specific CP0 mapping details
- Add DMA dispatch integration points

---

## 5. New Gate Definitions

### V1.01A Gate Extensions

| Gate | Test | Pass Criteria |
|------|------|---------------|
| B0 | `build_frankenstein_bios.py --verify-only` | **7/7** clean-room checks (was 6/6) |
| B6 | Gamma script execution | `--gamma-test` runs all 5 v1.1C opcodes without error |
| B7 | CP0 snapshot | `--cp0-snapshot` produces valid CP0 register values |
| B8 | DMA dispatch | `--dma-dispatch 2` triggers GPU DMA channel via FFI, interrupt fires |

### Gate Dependency Chain

```
B0 (7/7) → B1 (2M instrs) → B2 (DW7 disc) → B3 (parity) → B4 (DuckStation) ← HARD PREREQUISITE
                                                                        ↓
                                                                   B5 (service matrix)
                                                                        ↓
                                                                   B6 (Gamma test)
                                                                        ↓
                                                                   B7 (CP0 on-demand)
                                                                        ↓
                                                                   B8 (DMA dispatch)
```

**Gate B4 (DuckStation boot) is a hard prerequisite for enabling `--gamma` in production builds.**
Gamma features may be developed and tested without B4, but cannot ship until B4 passes.

---

## 6. Memory Map Additions

### V1.01A BIOS Image Layout

```
0xBFC00000  +-----------------------------------+
            | Clean-Room Kernel (~10,600 bytes) |
            |   - CP0 init + hardware init      |
            |   - GPU_Init                      |
            |   - Interrupt controller + VBlank |
            |   - Heap/Events/Threads init      |
            |   - CD-ROM driver                 |
            |   - SYSTEM.CNF boot parser        |
            |   - Find_HBD (HBD boot logic)     |
            |   - A0/B0/C0 syscall tables       |
            |   - 50+ kernel services           |
            |   - Exception handler + VBlank    |
            |   - Export_CP0_State (NEW)        |
            |   - DMA_Dispatch (NEW)            |
            |   - Check_Gamma_Flag (NEW)        |
0xBFC02900  +-----------------------------------+
            | Zero-fill                         |
            |   ~515,456 bytes of zeros         |
0xBFC07F00  +-----------------------------------+
            | Gamma script area (240 bytes)     |  (NEW — optional embedded script)
0xBFC07FF0  +-----------------------------------+
            | GAMMA-v1.1C (16 bytes)           |  (NEW — Gamma signature)
0xBFC07FE0  +-----------------------------------+
            | VHB-SUPER-BIOS-v1.01A (16 bytes) |
0xBFC08000  +-----------------------------------+
```

### V1.01A RAM Layout ( additions)

```
0x80000200  +-----------------------------------+
            | CP0 Snapshot (32 bytes)           |  (NEW — relocated from 0x80010000)
            |   Status, Cause, EPC, BadVAddr,   |
            |   Count, Compare, EntryHi, Index  |
            |   (initial boot snapshot only;    |
            |    live access via C++ getters)   |
0x80000220  +-----------------------------------+
            | Gamma Enabled Flag (1 byte)       |  (NEW)
0x80000221  +-----------------------------------+
            | PSX Hw Reg Shadow (40 bytes)      |  (NEW)
            |   DMA_CH1/CH2 MADR/BCR/CHCR,     |
            |   GPU GP0/GP1, I_STAT/I_MASK     |
0x80000249  +-----------------------------------+
            | (kernel reserved area continues)  |
```

---

## 7. File Change Manifest

### New Files

| File | Purpose |
|------|---------|
| `gamma/A2A_Gamma.h` | GammaLanguage v1.1C inline header (copied from Liminal Lore) |
| `gamma/gamma_ffi.h` | Rust FFI C-ABI bindings |
| `rust/gamma_ffi.rs` | Rust FFI crate source |
| `rust/Cargo.toml` | Rust crate manifest |
| `configs/vhb_gamma_config.json` | Gamma feature configuration |
| `BLUEPRINT_V1.01A_GammaLanguage_v1.1C.md` | This blueprint |

### Modified Files

| File | Changes |
|------|---------|
| `frankenstein_bios.s` | +Export_CP0_State, +DMA_Dispatch, +Check_Gamma_Flag, version bump |
| `vhb_core.h` | +GammaEvaluator, +CP0Map, +PSXHwRegMap, +FFIDispatch, +new methods |
| `vhb_core.cpp` | +execute_gamma_script, +snapshot_cp0, +dispatch_dma, +init_ffi_dispatch |
| `vhb_launch.cpp` | +--gamma, +--gamma-script, +--gamma-test, +--cp0-snapshot, +--dma-dispatch |
| `build_frankenstein_bios.py` | Version bump, +--gamma, +--rust-ffi, 7/7 verification |
| `bios_tool.cpp` | Version bump, +Gamma signature injection, 7/7 checks |
| `README_VHB.md` | V1.01A documentation |
| `README_SUPER_BIOS.md` | V1.01A documentation |
| `SERVICE_INVENTORY.md` | New Gamma/FFI/CP0/DMA services |
| `BUILD_LEDGER.md` | V1.01A gate entries |
| `cybergrime/README.md` | VHB V1.01A GammaLanguage reference |
| `cybergrime/INTEGRATION_MANIFEST.md` | VHB V1.01A CP0/DMA integration |

---

## 8. Implementation Order

| Step | Task | Dependencies | Estimated Effort |
|------|------|-------------|-----------------|
| 1 | Create `gamma/` dir, copy `A2A_Gamma.h` | None | 5 min |
| 2 | Extend `vhb_core.h` with Gamma types + methods | Step 1 | 30 min |
| 3 | Implement `execute_gamma_script()` in `vhb_core.cpp` | Step 2 | 45 min |
| 4 | Implement `snapshot_cp0()` + `dispatch_dma()` + `init_ffi_dispatch()` | Step 3 | 45 min |
| 5 | Extend `vhb_launch.cpp` with `--gamma` flags | Step 4 | 20 min |
| 6 | Add MIPS stubs to `frankenstein_bios.s` | None | 60 min |
| 7 | Update `build_frankenstein_bios.py` (version, flags, 7/7) | Step 6 | 30 min |
| 8 | Update `bios_tool.cpp` (version, Gamma sig, 7/7) | Step 7 | 20 min |
| 9 | Create `rust/gamma_ffi.rs` + `Cargo.toml` | Step 2 | 45 min |
| 10 | Create `gamma/gamma_ffi.h` C-ABI bindings | Step 9 | 15 min |
| 11 | Create `configs/vhb_gamma_config.json` | None | 10 min |
| 12 | Build + verify B0 (7/7) | Steps 1-11 | 15 min |
| 13 | Run B6 (Gamma test) | Step 12 | 10 min |
| 14 | Run B7 (CP0 snapshot) | Step 13 | 10 min |
| 15 | Run B8 (DMA dispatch) | Step 14 | 10 min |
| 16 | Update all documentation files | Steps 1-15 | 45 min |
| 17 | Update CyberGrime README + INTEGRATION_MANIFEST | Step 16 | 20 min |

**Total estimated effort:** ~6 hours

---

## 9. Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| BIOS size exceeds 0x2100 code region | Low | Medium | New stubs are ~170 bytes; plenty of room before 0x7F00 |
| Rust toolchain not installed | Medium | Low | C++ stub fallback for FFI dispatch (no-op lambdas) |
| Gamma evaluator cycle limit hit | Low | Low | Default 10K cycle limit is sufficient for boot-time scripts |
| B4 DuckStation still fails | High | Medium | **Gate B4 is a hard prerequisite for --gamma production builds.** Gamma features only enabled after B4 PASS. Development/testing can use --gamma without B4 |
| CP0 snapshot corrupts RAM | Low | High | Use kernel reserved 0x80000200 region (NOT 0x80010000 which is EXE load address). Verify no overlap with EXE |
| DMA dispatch triggers unwanted transfer | Medium | High | Gate behind `--gamma` flag, require explicit `--dma-dispatch` |

---

## 10. Success Criteria

V1.01A is considered complete when:

1. **B0 PASS (7/7):** `build_frankenstein_bios.py --verify-only` passes all 7 checks including Gamma signature
2. **B6 PASS:** `vhb_launch --gamma-test` executes all 5 v1.1C opcodes without error
3. **B7 PASS:** `vhb_launch --cp0-snapshot` produces valid CP0 register values (non-zero Status, valid EPC)
4. **B8 PASS:** `vhb_launch --dma-dispatch 2` triggers GPU DMA channel setup via FFI. DMA controller fires interrupt naturally on transfer completion (no manual I_STAT write)
5. **B1 PASS (re-verified):** `vhb_test --bios FRANKENSTEIN.BIOS --max-instr 2000000` still passes with new BIOS image
6. **Documentation complete:** All README, SERVICE_INVENTORY, BUILD_LEDGER, and CyberGrime files updated
7. **Clean-room preserved:** 7/7 verification confirms zero proprietary code, Gamma signature present

---

## 11. Backward Compatibility

- V1.01A is **fully backward compatible** with V1.00A:
  - All existing 50+ kernel services remain unchanged
  - All existing A0/B0/C0 syscall tables preserved
  - All existing vector handlers, VFS, and Soft-MMU functionality preserved
  - `--gamma` flag is **opt-in** — without it, VHB behaves identically to V1.00A
  - Rust FFI is **optional** — C++ stubs provide fallback when cargo is not installed
  - BIOS image without `--gamma` build flag produces V1.00A-equivalent output (minus version sig)

---

## Appendix A: GammaLanguage v1.1C Opcode Reference

| Opcode | Hex | Sigil | Purpose |
|--------|-----|-------|---------|
| `RUST_OFFSET_LOAD` | 0xA0 | `&RUST_OFFSET` | Load zero-copy memory offset with repr type + flags |
| `RUST_FFI_CALL` | 0xA1 | (keyword) | Dispatch to PEAK-1..5 via function pointer table |
| `ALIGN_BOUND` | 0xA2 | `@ALIGN_BOUND` | Set memory alignment boundary for FFI exports |
| `CP0_REG_MAP` | 0xA3 | (keyword) | Map MIPS R3000A CP0 registers into RegisterBank |
| `PSX_DMA_DISPATCH` | 0xA4 | (keyword) | Dispatch PSX DMA channel via FFI with HW interrupt |

## Appendix B: PEAK Subsystem Dispatch Table

| PEAK | Function | Purpose | FFI Symbol |
|------|----------|---------|------------|
| PEAK-1 | ExportBytecode | Export Gamma bytecode to Rust-side JIT | `peak1_export_bytecode` |
| PEAK-2 | QVecSimd | SIMD vector operations (cosine sim, dot product) | `peak2_qvec_simd` |
| PEAK-3 | SpecScopeEnter/Exit | Speculative execution scope RAII guard | `peak3_spec_scope_enter` |
| PEAK-4 | HwIntDispatch | Hardware interrupt dispatch (DMA, VBlank, GPU) | `peak4_hw_int_dispatch` |
| PEAK-5 | RingIterNext | Ring buffer iterator advance | `peak5_ring_iter_next` |

## Appendix C: CP0 Register Map

| CP0 Reg | MIPS ID | Field in `CyberGrimeCP0Map` | Purpose |
|---------|---------|----------------------------|---------|
| Status | 12 | `Status` | Processor status, interrupt masks, kernel/user mode |
| Cause | 13 | `Cause` | Exception cause, pending interrupts (IP0-IP7) |
| EPC | 14 | `EPC` | Exception program counter (return address) |
| BadVAddr | 8 | `BadVAddr` | Bad virtual address (last TLB/address error) |
| Count | 9 | `Count` | Cycle counter (incremented every other cycle) |
| Compare | 11 | `Compare` | Timer interrupt trigger (fires when Count == Compare) |
| EntryHi | 10 | `EntryHi` | TLB entry high bits (VPN, ASID) |
| Index | 0 | `Index` | TLB index register (random/indexed access) |

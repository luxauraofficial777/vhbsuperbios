// =============================================================================
// psx_core.h — Minimal PSX BIOS Validation Harness
//
// SCOPE (Decision D-B, SURGICAL_COMPLETION_VHB_CYBERGRIME_Aug3_2026.md):
//   This emulator is scoped to BIOS validation only: boot BIOS, run EXE to
//   first milestone, verify no crash. It is NOT a full-fidelity emulator.
//   For full PSX tracing/fidelity, use the CyberGrime harness at
//   DQLOSTTRANSLATION/cybergrime/ (separate environment, DQ4 Frankenstein).
//
// Implements MIPS R3000A CPU, 8MB RAM, BIOS ROM, CD-ROM state machine,
// GPU registers, SIO0 (controller), IRQ controller, and VBlank interrupts.
//
// Build: cl /EHsc /O2 /std:c++17 /D_CRT_SECURE_NO_WARNINGS psx_core.cpp vhb_test_runner.cpp -o vhb_test.exe
// =============================================================================

#pragma once

#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <fstream>
#include <cstdio>
#include <unordered_map>
#include <deque>

// ============================================================================
// Constants
// ============================================================================

constexpr uint32_t RAM_SIZE = 8 * 1024 * 1024;       // 8MB
constexpr uint32_t BIOS_SIZE = 512 * 1024;            // 512KB
constexpr uint32_t HW_REG_BASE = 0x1F801000;
constexpr uint32_t HW_REG_SIZE = 0x1000;
constexpr uint32_t CDROM_REG_BASE = 0x1F801800;
constexpr uint32_t GPU_REG_BASE = 0x1F801810;
constexpr uint32_t SIO0_REG_BASE = 0x1F801040;        // SIO0 data/status/control
constexpr uint32_t IRQ_STAT = 0x1F801070;
constexpr uint32_t IRQ_MASK = 0x1F801074;
constexpr uint32_t RAM_SIZE_REG = 0x1F801060;
constexpr uint32_t DMA_BASE = 0x1F801080;
constexpr uint32_t TIMER_BASE = 0x1F801100;
constexpr uint32_t SECTOR_DATA_SIZE = 2048;
constexpr uint32_t RAW_SECTOR_SIZE = 2352;

// VBlank IRQ bit in I_STAT
constexpr uint32_t IRQ_VBLANK = 0x01;
constexpr uint32_t IRQ_CDROM = 0x04;
constexpr uint32_t IRQ_DMA = 0x08;
constexpr uint32_t IRQ_TIMER0 = 0x10;
constexpr uint32_t IRQ_TIMER1 = 0x20;
constexpr uint32_t IRQ_TIMER2 = 0x40;

// CD-ROM status bits
constexpr uint8_t CD_STAT_ERROR = 0x01;
constexpr uint8_t CD_STAT_MOTOR_ON = 0x02;
constexpr uint8_t CD_STAT_SEEK_ERROR = 0x04;
constexpr uint8_t CD_STAT_PARAM_EMPTY = 0x08;
constexpr uint8_t CD_STAT_PARAM_READY = 0x10;
constexpr uint8_t CD_STAT_RESPONSE_READY = 0x20;
constexpr uint8_t CD_STAT_DATA_READY = 0x40;
constexpr uint8_t CD_STAT_BUSY = 0x80;

// CD-ROM commands
constexpr uint8_t CMD_GETSTAT = 0x01;
constexpr uint8_t CMD_SETLOC = 0x02;
constexpr uint8_t CMD_READN = 0x06;
constexpr uint8_t CMD_PAUSE = 0x09;
constexpr uint8_t CMD_SETMODE = 0x0E;
constexpr uint8_t CMD_INIT = 0x1C;
constexpr uint8_t CMD_READTOC = 0x1E;

// ============================================================================
// Telemetry Structure
// ============================================================================

struct Telemetry {
    uint64_t instruction_count = 0;
    uint64_t vblank_count = 0;
    uint32_t pc = 0;
    uint32_t last_pc = 0;
    uint32_t entry_pc = 0;
    bool crashed = false;
    bool reached_exe = false;
    uint32_t cdrom_sectors_read = 0;
    uint32_t cdrom_commands_sent = 0;
    uint32_t gpu_writes = 0;
    uint32_t sio0_reads = 0;
    std::string crash_reason;
    std::deque<uint32_t> pc_trace;       // Recent PC values for debugging
    uint32_t max_pc = 0;                  // Highest PC reached in RAM
    uint32_t min_pc = 0xFFFFFFFF;         // Lowest PC in RAM
    bool bios_past_cdrom_init = false;
    bool bios_past_exe_load = false;
    bool bios_past_syscall_install = false;
};

// ============================================================================
// CD-ROM State Machine
// ============================================================================

struct CDROMState {
    uint8_t index = 0;
    uint8_t status = CD_STAT_MOTOR_ON | CD_STAT_PARAM_READY;
    uint8_t response_fifo[16] = {};
    int response_count = 0;
    int response_pos = 0;
    uint8_t param_fifo[16] = {};
    int param_count = 0;
    uint8_t int_flag = 0;
    uint8_t int_enable = 0;

    // Read state
    uint8_t cmd_pending = 0;
    bool reading = false;
    uint32_t read_lba = 0;
    uint8_t data_fifo[SECTOR_DATA_SIZE] = {};
    int data_pos = 0;
    bool data_ready = false;
    uint8_t mode = 0;  // Setmode value
};

// ============================================================================
// SIO0 State (Controller port)
// ============================================================================

struct SIO0State {
    uint8_t data = 0;
    uint8_t status = 0x05;  // TX ready (bit 0) + RX ready (bit 1) + CTS (bit 2)
    uint8_t control = 0;
    uint16_t baud = 0;
    uint8_t rx_buf[8] = {0x41, 0x5A, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};  // Digital controller
    int rx_pos = 0;
    int rx_count = 6;
    bool poll_pending = false;
};

// ============================================================================
// GPU State
// ============================================================================

struct GPUState {
    uint32_t gp0 = 0;
    uint32_t gp1 = 0;
    uint32_t status = 0x10000000;  // Ready bit
    bool display_on = false;
};

// ============================================================================
// PSX Emulator Core
// ============================================================================

class PSXEmulator {
public:
    PSXEmulator();
    ~PSXEmulator();

    bool load_bios(const std::string& path);
    bool load_disc(const std::string& path);
    void reset();
    int step();         // Execute one instruction, return 0=ok, -1=error
    void run(uint64_t max_instructions);

    Telemetry& get_telemetry() { return telemetry; }
    void save_telemetry(const std::string& path);

    // Debug
    void set_verbose(bool v) { verbose = v; }
    void set_watch_pc(uint32_t addr) { watch_pc = addr; watch_pc_enabled = true; }

private:
    // CPU state
    uint32_t regs[32] = {};
    uint32_t hi = 0, lo = 0;
    uint32_t pc = 0xBFC00000;
    uint32_t next_pc = 0xBFC00004;
    bool in_branch_delay = false;
    uint32_t branch_target = 0;

    // CP0 state
    uint32_t cp0_status = 0x00400000;  // BEV=1
    uint32_t cp0_cause = 0;
    uint32_t cp0_epc = 0;
    uint32_t cp0_count = 0;
    uint32_t cp0_compare = 0;

    // Memory (heap-allocated to avoid stack overflow)
    std::vector<uint8_t> ram;
    std::vector<uint8_t> bios;
    std::vector<uint32_t> hw_regs;

    // Hardware state
    CDROMState cdrom;
    SIO0State sio0;
    GPUState gpu;
    uint32_t irq_stat = 0;
    uint32_t irq_mask = 0;

    // Disc
    std::ifstream disc_file;
    uint32_t disc_sectors = 0;
    bool disc_loaded = false;

    // Telemetry
    Telemetry telemetry;
    bool verbose = false;
    bool watch_pc_enabled = false;
    uint32_t watch_pc = 0;

    // Instruction counter for VBlank timing
    uint64_t vblank_timer = 0;
    constexpr static uint64_t VBLANK_INTERVAL = 500000;  // ~60Hz at 33.8MHz

    // Memory access
    uint8_t read8(uint32_t addr);
    uint16_t read16(uint32_t addr);
    uint32_t read32(uint32_t addr);
    void write8(uint32_t addr, uint8_t val);
    void write16(uint32_t addr, uint16_t val);
    void write32(uint32_t addr, uint32_t val);

    // Hardware register access
    uint32_t hw_read32(uint32_t addr);
    uint8_t hw_read8(uint32_t addr);
    void hw_write32(uint32_t addr, uint32_t val);
    void hw_write8(uint32_t addr, uint8_t val);

    // CD-ROM
    void cdrom_send_command(uint8_t cmd);
    void cdrom_push_response(uint8_t val);
    void cdrom_process_command();
    bool cdrom_read_sector_data();
    uint8_t cdrom_read_status();
    uint8_t cdrom_read_response();
    uint8_t cdrom_read_data();
    void cdrom_ack_interrupt();

    // Interrupts
    void check_interrupts();
    void raise_interrupt(uint32_t irq_bit);
    void trigger_exception(uint32_t cause_code, uint32_t epc);

    // Instruction execution
    void execute_instruction(uint32_t word);
    void execute_special(uint32_t word);
    void execute_regimm(uint32_t word);
    void execute_cop0(uint32_t word);

    // Helpers
    inline uint32_t phys_addr(uint32_t addr) {
        // Map virtual to physical (strip top bits for kuseg/kseg0/kseg1)
        if (addr >= 0x80000000 && addr < 0xA0000000)
            return addr & 0x1FFFFFFF;
        if (addr >= 0xA0000000 && addr < 0xC0000000)
            return addr & 0x1FFFFFFF;
        return addr;
    }

    inline bool is_ram(uint32_t paddr) {
        return paddr < RAM_SIZE;
    }

    inline bool is_bios(uint32_t paddr) {
        return paddr >= 0x1FC00000 && paddr < 0x1FC00000 + BIOS_SIZE;
    }

    inline bool is_hw_reg(uint32_t paddr) {
        return paddr >= HW_REG_BASE && paddr < HW_REG_BASE + HW_REG_SIZE;
    }

    inline bool is_cdrom(uint32_t paddr) {
        return paddr >= CDROM_REG_BASE && paddr < CDROM_REG_BASE + 0x10;
    }

    inline bool is_gpu(uint32_t paddr) {
        return paddr >= GPU_REG_BASE && paddr < GPU_REG_BASE + 0x10;
    }

    inline bool is_sio0(uint32_t paddr) {
        return paddr >= SIO0_REG_BASE && paddr < SIO0_REG_BASE + 0x10;
    }

    void update_vblank();
    void log_verbose(const char* fmt, ...);
};

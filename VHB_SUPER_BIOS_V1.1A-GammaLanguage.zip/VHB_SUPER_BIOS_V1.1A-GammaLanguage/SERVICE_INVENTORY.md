# VHB Super BIOS V1.01A — Service Inventory

**Date:** Aug 11, 2026
**Source:** Label scan of `frankenstein_bios.s` (2,601 lines) + V1.01A blueprint
**BIOS image:** `FRANKENSTEIN.BIOS` — 512KB, ~10,600 bytes code (V1.01A), 50+ kernel services
**GammaLanguage:** v1.1C — 5 new opcodes, Rust FFI, CP0 mapping, DMA dispatch (blueprinted)

---

## Bootstrap & Hardware Init

| Label | Function |
|-------|----------|
| `_start` | Entry point (LUI, opcode 0x0F) |
| `clear_loop` | RAM clear loop |
| — | SFX-100 bus probe |
| — | Region detection (NA/JP/EU) |
| `Preinit_Descriptors` | Pre-init descriptor tables |
| `GPU_Init` | GPU initialization |
| `Init_Interrupt_Controller` | Interrupt controller setup |
| `Init_Heap` | Heap allocator initialization |
| `Init_Events` | Event system initialization |
| `Init_Threads` | Thread system initialization |
| `Flush_Cache` | Cache flush |

## CD-ROM Driver

| Label | Function |
|-------|----------|
| `CDROM_Init` | CD-ROM hardware initialization |
| `CDROM_Wait_Response` | Wait for CD-ROM response (short) |
| `CDROM_Wait_Response_Long` | Wait for CD-ROM response (long) |
| `CDROM_ReadSector` | Read single CD-ROM sector |
| `CDROM_ReadSectors` | Read multiple CD-ROM sectors |
| `CDROM_Wait_Param` | Wait for CD-ROM parameter ready |

## Boot Chain

| Label | Function |
|-------|----------|
| `Find_File` | Find file on disc |
| `Parse_Boot_Line` | Parse SYSTEM.CNF boot line |
| `Find_File_By_Name` | Find file by name on disc |
| `Find_HBD` | Locate HBD (HeartBeat Data) file |
| `skip_hbd_load` | Skip HBD loading (conditional) |
| `boot_fail` | Boot failure handler |

## Syscall Installation

| Label | Function |
|-------|----------|
| `A0_Vector_Stub` | A0 vector stub |
| `B0_Vector_Stub` | B0 vector stub |
| `C0_Vector_Stub` | C0 vector stub |
| `Install_Syscall_Vectors` | Install A0/B0/C0 vectors |
| `Copy_Syscall_Tables` | Copy syscall tables to RAM |
| `A0_Table` | A0 syscall table |
| `B0_Table` | B0 syscall table |
| `C0_Table` | C0 syscall table |

## Kernel Services (Sys_*)

### File I/O
| Service | Description |
|---------|-------------|
| `Sys_open` / `B0_open` | Open file |
| `Sys_read` / `B0_read` | Read file |
| `Sys_write` / `B0_write` | Write file |
| `Sys_close` / `B0_close` | Close file |
| `Sys_lseek` / `B0_lseek` | Seek file position |

### String / Memory
| Service | Description |
|---------|-------------|
| `Sys_strcmp` | String compare |
| `Sys_strcpy` | String copy |
| `Sys_strlen` | String length |
| `Sys_memcpy` | Memory copy |
| `Sys_memset` | Memory set |
| `Sys_atoi` | ASCII to integer |
| `Sys_abs` | Absolute value |
| `Sys_labs` | Long absolute value |

### Heap Management
| Service | Description |
|---------|-------------|
| `Sys_malloc` | Allocate memory |
| `Sys_free` | Free memory |
| `Sys_calloc` | Allocate zeroed memory |
| `Sys_realloc` | Reallocate memory |
| `Sys_kmalloc` | Kernel malloc |
| `Sys_kfree` | Kernel free |
| `Sys_InitHeap` | Initialize heap |
| `Sys_kinitheap` | Initialize kernel heap |

### I/O
| Service | Description |
|---------|-------------|
| `Sys_printf` | Formatted print |
| `Sys_puts` | Print string |
| `Sys_exit` | Exit |
| `Sys_setupFileIO` | Setup file I/O |
| `Sys_reopenStdio` | Reopen stdio |

### GPU
| Service | Description |
|---------|-------------|
| `Sys_GPU_dw` | GPU display word |
| `Sys_GPU_mem2vram` | Transfer memory to VRAM |
| `Sys_GPU_send` | Send GPU command |

### Events
| Service | Description |
|---------|-------------|
| `Sys_deliver_event` | Deliver event |
| `Sys_open_event` | Open event |
| `Sys_close_event` | Close event |
| `Sys_wait_event` | Wait for event |
| `Sys_test_event` | Test event |
| `Sys_enable_event` | Enable event |
| `Sys_disable_event` | Disable event |

### Threads
| Service | Description |
|---------|-------------|
| `Sys_openThread` | Open/create thread |
| `Sys_closeThread` | Close/destroy thread |
| `Sys_changeThread` | Switch thread |
| `Sys_returnFromException` | Return from exception |
| `Sys_getFreeTCB` | Get free TCB slot |

### CD-ROM
| Service | Description |
|---------|-------------|
| `Sys_CD_init` | CD-ROM init |
| `Sys_CD_read` | CD-ROM read |
| `Sys_CD_readSync` | CD-ROM read sync |
| `Sys_CD_getstat` | CD-ROM get status |
| `Sys_CD_seek` | CD-ROM seek |

### Misc
| Service | Description |
|---------|-------------|
| `Sys_FlushCache` | Flush cache |
| `Sys_exceptionHandler` | Exception handler |
| `Sys_installExceptionHandler` | Install exception handler |
| `Sys_Unimplemented` | Unimplemented syscall stub |

## Exception & VBlank

| Label | Function |
|-------|----------|
| `exception_handler` | Main exception handler with VBlank event delivery loop, INT check, halt path |
| `VBlank_Handler` | VBlank interrupt handler |
| `Install_VBlank_Handler` | Install VBlank handler |

## HBD Boot Logic (Frankenstein Differentiator)

The BIOS contains HBD-aware boot logic — the seed of the Frankenstein translation shim:

| Label | Function |
|-------|----------|
| `Find_HBD` | Locate HBD file on disc by name |
| `skip_hbd_load` | Conditional skip of HBD loading |
| — (labels 174–223) | HBD remainder handling |

This logic allows the BIOS to identify and optionally load HeartBeat Data files used by DQ4/DW7 engine games. It is present in the BIOS image but not yet documented in external READMEs — this document serves as that documentation.

---

## GammaLanguage v1.1C Services (V1.01A Blueprint)

### GammaLanguage Core (C++ Side — `A2A_Gamma.h`)

| Service | Description |
|---------|-------------|
| `execute_gamma_script()` | Parse Gamma DSL → AST → evaluate → bytecode → DTC execute |
| `get_cp0_live()` | On-demand CP0 register read from live MIPS CPU context (replaces VBlank polling) |
| `dispatch_dma()` | Set up DMA channel regs, trigger `PSX_DMA_DISPATCH` opcode (no manual I_STAT) |
| `init_ffi_dispatch()` | Initialize PEAK-1..5 function pointers (C++ stubs or Rust FFI) |

### Rust FFI Bridge (`gamma_ffi` crate)

| PEAK | Function | Purpose |
|------|----------|---------|
| PEAK-1 | `peak1_export_bytecode` | Export Gamma bytecode to Rust-side JIT |
| PEAK-2 | `peak2_qvec_simd` | SIMD vector operations (cosine sim, dot product) |
| PEAK-3 | `peak3_spec_scope_enter/exit` | Speculative execution scope RAII guard |
| PEAK-4 | `peak4_hw_int_dispatch` | Hardware interrupt dispatch (DMA, VBlank, GPU) |
| PEAK-5 | `peak5_ring_iter_next` | Ring buffer iterator advance |

### CP0 Register Map (On-Demand)

| CP0 Reg | MIPS ID | Field | Purpose |
|---------|---------|-------|---------|
| Status | 12 | `CP0_Status` | Processor status, interrupt masks, kernel/user mode |
| Cause | 13 | `CP0_Cause` | Exception cause, pending interrupts (IP0-IP7) |
| EPC | 14 | `CP0_EPC` | Exception program counter (return address) |
| BadVAddr | 8 | `CP0_BadVAddr` | Bad virtual address (last TLB/address error) |
| Count | 9 | `CP0_Count` | Cycle counter (read on-demand, NOT VBlank-polled) |
| Compare | 11 | `CP0_Compare` | Timer interrupt trigger (read on-demand) |
| EntryHi | 10 | `CP0_EntryHi` | TLB entry high bits (VPN, ASID) |
| Index | 0 | `CP0_Index` | TLB index register |

**Counter Reflection Fix:** CP0 registers are read via on-demand C++ getters from the live hypervisor MIPS CPU context, not via VBlank-pushed RAM snapshots. Initial boot snapshot at `0x80000200` only.

### PSXMatrix DMA Dispatch

| Channel | HW Address | Purpose |
|---------|-----------|---------|
| CH0 | `0x1F801080` | MDEC in |
| CH1 | `0x1F801090` | MDEC out (corrected from 0x1F8010A0) |
| CH2 | `0x1F8010A0` | GPU (corrected from 0x1F8010B0) |
| CH3 | `0x1F8010B0` | CD-ROM |
| CH4 | `0x1F8010C0` | SPU |
| CH5 | `0x1F8010D0` | PIO |
| CH6 | `0x1F8010E0` | OTC |

**Counter Reflection Fix:** DMA trampoline does NOT manually write `I_STAT`. The DMA controller fires the interrupt naturally when the block transfer completes.

### Thread Safety

`RegisterBank` is protected with `std::atomic_flag` spinlock (`lock()`/`unlock()` methods). All mutations from CPU thread, VBlank IRQ handler, or FFI callbacks must acquire the spinlock.

### RustFFIExport Struct (96 bytes, x64)

| Field | Type | Size | Offset |
|-------|------|------|--------|
| `DataPtr` | `uint64_t` | 8 | 0 (fixed-width, was `const void*`) |
| `DataSize` | `uint32_t` | 4 | 8 |
| `ElementSize` | `uint32_t` | 4 | 12 |
| `Repr` | `RustReprType` | 1 | 16 |
| `Flags` | `uint8_t` | 1 | 17 |
| `_pad` | `uint8_t[2]` | 2 | 18 |
| `OffsetAddr` | `uint32_t` | 4 | 20 |
| `StructName` | `char[32]` | 32 | 24 |
| `FieldName` | `char[32]` | 32 | 56 |
| **Total** | | **96** | `alignas(16)` |

---

## Gate Status

| Gate | Result | Evidence |
|------|--------|----------|
| B0 | PASS | 6/6 clean-room checks (Aug 4) |
| B1 | PASS | 2M instrs, past CDROM_Init, no crash (Aug 4) |
| B2 | PASS | 5M instrs, 8 VBlanks, PC 0x8009674C (Aug 4) |
| B3 | PASS | Informal parity — identical PC vs B2 (Aug 4) |
| B4 | FAIL | DuckStation black screen, FPS 0 (Aug 4) — **HARD PREREQUISITE for --gamma** |
| B5 | OPEN | Service matrix documentation in progress |
| B6 | PENDING | Gamma script execution (V1.01A blueprint) |
| B7 | PENDING | CP0 on-demand register mapping (V1.01A blueprint) |
| B8 | PENDING | DMA dispatch via FFI (V1.01A blueprint) |

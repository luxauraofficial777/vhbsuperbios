$lines = Get-Content 'frankenstein_bios.s'
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match 'VBlank|vblank|VBlank_Handler|800B679C|800B5312|jr.*s7|DeliverEvent|0x0509|F2000001|EXE.*entry|jump.*entry') {
        Write-Output ('{0}: {1}' -f ($i+1), $lines[$i].Trim())
    }
}

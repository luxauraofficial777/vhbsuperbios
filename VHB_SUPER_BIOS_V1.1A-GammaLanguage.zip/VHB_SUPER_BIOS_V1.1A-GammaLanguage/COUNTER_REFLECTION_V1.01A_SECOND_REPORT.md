# Second Counter Reflection Report: VHB Super BIOS V1.01A & GammaLanguage v1.1C

**Target Blueprint:** `BLUEPRINT_V1.01A_GammaLanguage_v1.1C.md`  
**Target Codebase:** `A2A_Gamma.h` (v1.1C Engine)  
**Date:** August 10, 2026  
**Author:** Antigravity Deep-Architecture Subsystem  

Following the initial Counter Reflection Report (which identified critical MIPS memory collisions at `0x80010000`, CP0 60Hz polling stale-ness, and DMA IRQ race conditions), this **Second Counter Reflection Report** evaluates deep structural, hardware-addressing, compilation, and concurrency issues within the `A2A_Gamma.h` header and the V1.01A blueprint.

---

## 🛑 1. CRITICAL: Hardware DMA Register Address Misalignment in `PSXHwRegMap`

### The Proposal & Code Implementation
In `A2A_Gamma.h` (lines 133–145), `PSXHwRegMap` defines default hardware addresses:
```cpp
struct PSXHwRegMap {
    uint32_t DMA_CH1_MADR{0x1F8010A0};
    uint32_t DMA_CH1_BCR{0x1F8010A4};
    uint32_t DMA_CH1_CHCR{0x1F8010A8};
    uint32_t DMA_CH2_MADR{0x1F8010B0};
    uint32_t DMA_CH2_BCR{0x1F8010B4};
    uint32_t DMA_CH2_CHCR{0x1F8010B8};
    ...
};
```

### The Flaw
The hardware specs for MIPS R3000A / PlayStation hardware registers define DMA channels starting at `0x1F801080` with `0x10` stride per channel:
- **Channel 0 (MDEC in):** `0x1F801080`
- **Channel 1 (MDEC out):** `0x1F801090`
- **Channel 2 (GPU):** `0x1F8010A0`
- **Channel 3 (CDROM):** `0x1F8010B0`

`PSXHwRegMap` in `A2A_Gamma.h` assigns `0x1F8010A0` to `DMA_CH1_MADR` (which is actually Channel 2 GPU) and `0x1F8010B0` to `DMA_CH2_MADR` (which is actually Channel 3 CDROM).
If Gamma execution scripts attempt to configure `DMA_CH1` assuming MDEC out, it will accidentally write to GPU DMA registers. If it configures `DMA_CH2` expecting GPU, it will write to CDROM DMA registers. This will lead to peripheral lockout or GPU corruption.

### The Solution
Correct `PSXHwRegMap` definitions in `A2A_Gamma.h` to align strictly with PSX hardware specifications:
```cpp
struct PSXHwRegMap {
    uint32_t DMA_CH1_MADR{0x1F801090}; // MDEC out
    uint32_t DMA_CH1_BCR{0x1F801094};
    uint32_t DMA_CH1_CHCR{0x1F801098};
    uint32_t DMA_CH2_MADR{0x1F8010A0}; // GPU
    uint32_t DMA_CH2_BCR{0x1F8010A4};
    uint32_t DMA_CH2_CHCR{0x1F8010A8};
    ...
};
```

---

## 🛑 2. CRITICAL: Struct Alignment & Compile-Time Assertion Failure in `RustFFIExport`

### The Proposal & Code Implementation
In `A2A_Gamma.h` (lines 98–109):
```cpp
struct alignas(16) RustFFIExport {
    const void* DataPtr{};      // 8 bytes (on 64-bit x64 host)
    uint32_t DataSize{0};       // 4 bytes
    uint32_t ElementSize{0};    // 4 bytes
    RustReprType Repr;          // 1 byte
    uint8_t Flags{0};           // 1 byte
    uint8_t _pad[2]{0, 0};      // 2 bytes
    uint32_t OffsetAddr{0};     // 4 bytes
    char StructName[32]{};      // 32 bytes
    char FieldName[32]{};       // 32 bytes
};
static_assert(sizeof(RustFFIExport) == 80, "RustFFIExport must be 80 bytes");
```

### The Flaw
Calculating member offsets on a 64-bit build (Modern_X64):
- `DataPtr` (8B) + `DataSize` (4B) + `ElementSize` (4B) = 16B
- `Repr` (1B) + `Flags` (1B) + `_pad[2]` (2B) + `OffsetAddr` (4B) = 8B
- `StructName` (32B) + `FieldName` (32B) = 64B
- **Total unpadded size:** 16 + 8 + 64 = 88 bytes.
- Due to `alignas(16)`, 88 bytes rounds up to **96 bytes**.

The `static_assert(sizeof(RustFFIExport) == 80, ...)` will **FAIL at compile time** when compiling VHB Core for x64 targets! Furthermore, if Rust defines a `repr(C)` struct expecting 80 bytes, memory layout mismatch between C++ and Rust will corrupt memory.

### The Solution
Replace pointer types with fixed-width types (`uint64_t`) or adjust layout padding and `static_assert` to explicitly match 64-bit / 32-bit compilation targets:
```cpp
struct alignas(16) RustFFIExport {
    uint64_t DataPtr{0};        // 8 bytes fixed width
    uint32_t DataSize{0};       // 4 bytes
    uint32_t ElementSize{0};    // 4 bytes
    RustReprType Repr;          // 1 byte
    uint8_t Flags{0};           // 1 byte
    uint8_t _pad[2]{0, 0};      // 2 bytes
    uint32_t OffsetAddr{0};     // 4 bytes
    char StructName[32]{};      // 32 bytes
    char FieldName[32]{};       // 32 bytes
};
static_assert(sizeof(RustFFIExport) == 96, "RustFFIExport must be 96 bytes");
```

---

## ⚠️ 3. SEVERE: Multithreaded Race Conditions in `RegisterBank`

### The Proposal & Code Implementation
`RegisterBank` in `A2A_Gamma.h` is a massive `>50KB` data structure embedded directly within `SuperBIOSHypervisor`:
```cpp
struct alignas(64) RegisterBank {
    ...
    CyberGrimeCP0Map CP0Map;
    PSXHwRegMap PSXRegs;
    SpeculativeBuffer SpecBuf;
    ...
};
```

### The Flaw
VHB Core operates in a multi-threaded hypervisor environment (CPU execution thread, VBlank IRQ handler, and FFI callbacks). `A2A_Gamma.h` has no thread synchronization primitives (mutexes, spinlocks, or atomic fields) guarding `RegisterBank`.
If a Gamma script is evaluated concurrently during a VBlank interrupt or DMA callback, concurrent mutations to `PendingInt`, `CP0Map`, or `SpecBuf` will cause race conditions, data tearing, and undefined behavior.

### The Solution
1. Wrap `RegisterBank` mutations in `SuperBIOSHypervisor` with a lightweight spinlock or `std::mutex`.
2. Ensure speculative buffers (`SpecBuf`) are isolated per execution context rather than shared globally across the entire hypervisor instance.

---

## 🟡 4. ARCHITECTURAL: Order of Operations & Gate B4 (DuckStation Parity)

### The Proposal
Section 2.3 & 9.0 acknowledge that Gate B4 (DuckStation commercial emulator boot) currently **FAILS** (black screen), but treats Gamma integration as orthogonal to fixing B4.

### The Flaw
DuckStation executes strict checks on standard BIOS entry points (A0/B0/C0 tables), memory vectors, and initial boot timings. Introducing complex secondary components (Gamma AST lexing, CP0 memory exports, custom DMA trampolines, and custom BIOS signatures at `0x7FF0`) *before* establishing B4 baseline parity makes diagnosing the black screen significantly harder.

### The Solution
**Enforce Gate B4 as a hard prerequisite for V1.01A deployment.** Establish baseline commercial emulator boot parity on V1.00A before enabling the `--gamma` flag and modifying assembly headers.

---

## 📋 Comprehensive Summary of Required Blueprint Amendments

| # | Severity | Component | Issue | Action Item |
|---|----------|-----------|-------|-------------|
| 1 | **CRITICAL** | `frankenstein_bios.s` | Memory collision at `0x80010000` (overwrites PS-X EXEs) | Relocate CP0/Gamma scratchpad memory to reserved kernel RAM (`0x80000200`) |
| 2 | **CRITICAL** | `A2A_Gamma.h` | `PSXHwRegMap` DMA register base addresses misaligned | Fix `DMA_CH1` (`0x1F801090`) & `DMA_CH2` (`0x1F8010A0`) address definitions |
| 3 | **CRITICAL** | `A2A_Gamma.h` | `static_assert(sizeof(RustFFIExport) == 80)` fails on x64 | Change `DataPtr` to `uint64_t` and update static assertion size to 96 bytes |
| 4 | **SEVERE** | `vhb_core.cpp` | CP0 VBlank polling produces 60Hz stale `Count`/`Compare` data | Map `CP0_REG_MAP` directly to live hypervisor getters on-demand |
| 5 | **SEVERE** | `frankenstein_bios.s` | DMA trampoline sets `I_STAT` IRQ before DMA transfer completes | Remove premature `I_STAT` write from trampoline; let DMA controller trigger IRQ |
| 6 | **SEVERE** | `vhb_core.h` | Multi-threaded race conditions on un-synchronized `RegisterBank` | Add thread locking around `RegisterBank` mutations in hypervisor core |
| 7 | **MODERATE** | Gate Chain | Premature Gamma integration before Gate B4 (DuckStation) pass | Require Gate B4 PASS before enabling `--gamma` in production builds |

---

*This report should be reviewed by the lead builder prior to proceeding with Phase 1 execution.*

#!/usr/bin/env python3
"""
vhb_closed_loop.py — CyberGrime Closed-Loop Automation for All Targets

Runs automated tests for every supported target system, collects telemetry,
verifies results, and generates a comprehensive report.

Usage:
    python vhb_closed_loop.py [--max-instructions N] [--output-dir DIR]
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from datetime import datetime

# ============================================================================
# Target Definitions
# ============================================================================

TARGETS = [
    {
        "name": "Tile-8",
        "arch": "M6502",
        "bits": 8,
        "clock_hz": 1789773,
        "test_runner": "tile8_test_runner",
        "media_ext": ".nes",
        "config_file": "tile8/tile8_config.h",
    },
    {
        "name": "Tile-16",
        "arch": "W65C816",
        "bits": 16,
        "clock_hz": 3580000,
        "test_runner": None,  # Pending
        "media_ext": ".sfc",
        "config_file": None,
    },
    {
        "name": "CD-16",
        "arch": "MC68000",
        "bits": 16,
        "clock_hz": 7600000,
        "test_runner": None,  # Pending
        "media_ext": ".bin",
        "config_file": None,
    },
    {
        "name": "Handheld-32",
        "arch": "ARM7TDMI",
        "bits": 32,
        "clock_hz": 16780000,
        "test_runner": None,  # Pending
        "media_ext": ".gba",
        "config_file": None,
    },
    {
        "name": "CD-32X",
        "arch": "SH-2",
        "bits": 32,
        "clock_hz": 28636360,
        "test_runner": None,  # Pending
        "media_ext": ".bin",
        "config_file": None,
    },
    {
        "name": "CD-24/CD-32",
        "arch": "MipsR3000A",
        "bits": 32,
        "clock_hz": 33868800,
        "test_runner": "psx_agent_runner",
        "media_ext": ".bin",
        "config_file": None,
    },
    {
        "name": "Portable-Media-32",
        "arch": "MipsR4000",
        "bits": 32,
        "clock_hz": 333000000,
        "test_runner": "pm32_test_runner",
        "media_ext": ".iso",
        "config_file": "pm32/pm32_config.h",
    },
    {
        "name": "Cart-64",
        "arch": "MipsR4300",
        "bits": 64,
        "clock_hz": 93750000,
        "test_runner": None,  # Pending
        "media_ext": ".z64",
        "config_file": None,
    },
]

# ============================================================================
# Test Result
# ============================================================================

class TestResult:
    def __init__(self, target_name):
        self.target_name = target_name
        self.status = "pending"
        self.instructions = 0
        self.cycles = 0
        self.final_pc = 0
        self.halted = False
        self.elapsed_seconds = 0
        self.ips = 0
        self.error = None
        self.telemetry_file = None
        self.timestamp = datetime.now().isoformat()

    def to_dict(self):
        return {
            "target": self.target_name,
            "status": self.status,
            "instructions": self.instructions,
            "cycles": self.cycles,
            "final_pc": self.final_pc,
            "halted": self.halted,
            "elapsed_seconds": self.elapsed_seconds,
            "ips": self.ips,
            "error": self.error,
            "telemetry_file": self.telemetry_file,
            "timestamp": self.timestamp,
        }

# ============================================================================
# Closed-Loop Runner
# ============================================================================

class ClosedLoopRunner:
    def __init__(self, max_instructions=1000000, output_dir="closed_loop_output"):
        self.max_instructions = max_instructions
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.results = []

    def run_all(self):
        """Run tests for all targets."""
        print(f"[CLOSED_LOOP] Starting closed-loop automation for {len(TARGETS)} targets")
        print(f"[CLOSED_LOOP] Max instructions: {self.max_instructions}")
        print(f"[CLOSED_LOOP] Output dir: {self.output_dir}")
        print()

        for target in TARGETS:
            result = self.run_target(target)
            self.results.append(result)
            self.print_result(result)
            print()

        self.generate_report()
        self.print_summary()

    def run_target(self, target):
        """Run test for a single target."""
        result = TestResult(target["name"])
        result.status = "started"

        print(f"[{target['name']}] Starting test (arch={target['arch']}, bits={target['bits']})")

        if target["test_runner"] is None:
            result.status = "skipped"
            result.error = "No test runner available"
            return result

        # Check if test runner exists
        runner_path = self.find_test_runner(target["test_runner"])
        if runner_path is None:
            result.status = "skipped"
            result.error = f"Test runner not found: {target['test_runner']}"
            return result

        # Find media file
        media_path = self.find_media(target["media_ext"])
        if media_path:
            print(f"[{target['name']}] Media: {media_path}")
        else:
            print(f"[{target['name']}] No media file found, running without media")

        # Set up telemetry output
        telemetry_file = self.output_dir / f"telemetry_{target['name'].lower().replace('/', '_')}.json"
        result.telemetry_file = str(telemetry_file)

        # Run the test
        start_time = time.time()
        try:
            cmd = [
                sys.executable, str(runner_path),
                media_path or "",
                str(self.max_instructions),
                str(telemetry_file),
            ]
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=300,  # 5 minute timeout
            )
            result.elapsed_seconds = time.time() - start_time

            if proc.returncode == 0:
                result.status = "passed"
                # Parse telemetry if available
                if telemetry_file.exists():
                    try:
                        with open(telemetry_file) as f:
                            telemetry = json.load(f)
                        result.instructions = telemetry.get("instructions_executed", 0)
                        result.cycles = telemetry.get("cycles_elapsed", 0)
                        result.final_pc = telemetry.get("final_pc", 0)
                        result.halted = telemetry.get("halted", False)
                        if result.elapsed_seconds > 0:
                            result.ips = result.instructions / result.elapsed_seconds
                    except json.JSONDecodeError:
                        result.error = "Failed to parse telemetry JSON"
            else:
                result.status = "failed"
                result.error = proc.stderr[:500] if proc.stderr else "Unknown error"

        except subprocess.TimeoutExpired:
            result.status = "timeout"
            result.error = "Test exceeded 300s timeout"
            result.elapsed_seconds = 300
        except Exception as e:
            result.status = "error"
            result.error = str(e)

        return result

    def find_test_runner(self, name):
        """Find a test runner by name."""
        # Check in VHB directory
        vhb_dir = Path(__file__).parent
        candidates = [
            vhb_dir / f"{name}.cpp",
            vhb_dir / f"{name}.py",
            vhb_dir / "tile8" / f"{name}.cpp",
            vhb_dir / "pm32" / f"{name}.cpp",
        ]
        for c in candidates:
            if c.exists():
                return c
        return None

    def find_media(self, extension):
        """Find a media file with the given extension."""
        # Search in common locations
        search_dirs = [
            Path(__file__).parent / "media",
            Path(__file__).parent / "roms",
            Path(__file__).parent / "test_roms",
            Path(__file__).parent.parent / "roms",
        ]
        for d in search_dirs:
            if d.exists():
                for f in d.iterdir():
                    if f.suffix.lower() == extension.lower():
                        return str(f)
        return None

    def print_result(self, result):
        """Print a single test result."""
        status_icon = {
            "passed": "✓",
            "failed": "✗",
            "timeout": "⏱",
            "skipped": "⊘",
            "error": "!",
            "pending": "?",
            "started": "→",
        }.get(result.status, "?")

        print(f"  [{status_icon}] {result.target_name}: {result.status.upper()}")
        if result.instructions > 0:
            print(f"      Instructions: {result.instructions:,}")
            print(f"      Cycles: {result.cycles:,}")
            print(f"      Final PC: 0x{result.final_pc:08X}")
            print(f"      Halted: {result.halted}")
            print(f"      Elapsed: {result.elapsed_seconds:.2f}s")
            if result.ips > 0:
                print(f"      IPS: {result.ips:,.0f}")
        if result.error:
            print(f"      Error: {result.error}")

    def print_summary(self):
        """Print summary of all results."""
        passed = sum(1 for r in self.results if r.status == "passed")
        failed = sum(1 for r in self.results if r.status == "failed")
        skipped = sum(1 for r in self.results if r.status == "skipped")
        errors = sum(1 for r in self.results if r.status == "error")
        timeouts = sum(1 for r in self.results if r.status == "timeout")

        print("=" * 60)
        print("CLOSED-LOOP AUTOMATION SUMMARY")
        print("=" * 60)
        print(f"  Total targets:  {len(self.results)}")
        print(f"  Passed:         {passed}")
        print(f"  Failed:         {failed}")
        print(f"  Skipped:        {skipped}")
        print(f"  Errors:         {errors}")
        print(f"  Timeouts:       {timeouts}")
        print()

        # Target status table
        print(f"  {'Target':<25} {'Status':<10} {'Instructions':>15} {'IPS':>12}")
        print(f"  {'-'*25} {'-'*10} {'-'*15} {'-'*12}")
        for r in self.results:
            print(f"  {r.target_name:<25} {r.status:<10} {r.instructions:>15,} {r.ips:>12,.0f}")
        print()
        print(f"  Report: {self.output_dir / 'closed_loop_report.json'}")

    def generate_report(self):
        """Generate JSON report."""
        report = {
            "timestamp": datetime.now().isoformat(),
            "max_instructions": self.max_instructions,
            "total_targets": len(self.results),
            "results": [r.to_dict() for r in self.results],
            "summary": {
                "passed": sum(1 for r in self.results if r.status == "passed"),
                "failed": sum(1 for r in self.results if r.status == "failed"),
                "skipped": sum(1 for r in self.results if r.status == "skipped"),
                "errors": sum(1 for r in self.results if r.status == "error"),
                "timeouts": sum(1 for r in self.results if r.status == "timeout"),
            },
        }
        report_path = self.output_dir / "closed_loop_report.json"
        with open(report_path, "w") as f:
            json.dump(report, f, indent=2)

        # Also generate markdown report
        md_path = self.output_dir / "closed_loop_report.md"
        with open(md_path, "w") as f:
            f.write("# CyberGrime Closed-Loop Automation Report\n\n")
            f.write(f"**Date:** {report['timestamp']}\n")
            f.write(f"**Max Instructions:** {self.max_instructions:,}\n\n")
            f.write("## Summary\n\n")
            f.write(f"| Metric | Count |\n|--------|-------|\n")
            f.write(f"| Total Targets | {report['total_targets']} |\n")
            f.write(f"| Passed | {report['summary']['passed']} |\n")
            f.write(f"| Failed | {report['summary']['failed']} |\n")
            f.write(f"| Skipped | {report['summary']['skipped']} |\n")
            f.write(f"| Errors | {report['summary']['errors']} |\n")
            f.write(f"| Timeouts | {report['summary']['timeouts']} |\n\n")
            f.write("## Results\n\n")
            f.write("| Target | Status | Instructions | IPS | Error |\n")
            f.write("|--------|--------|-------------|-----|-------|\n")
            for r in self.results:
                error = r.error or ""
                f.write(f"| {r.target_name} | {r.status} | {r.instructions:,} | {r.ips:,.0f} | {error} |\n")


# ============================================================================
# Main
# ============================================================================

def main():
    parser = argparse.ArgumentParser(description="CyberGrime Closed-Loop Automation")
    parser.add_argument("--max-instructions", type=int, default=1000000,
                        help="Maximum instructions per test (default: 1M)")
    parser.add_argument("--output-dir", default="closed_loop_output",
                        help="Output directory for reports")
    args = parser.parse_args()

    runner = ClosedLoopRunner(
        max_instructions=args.max_instructions,
        output_dir=args.output_dir,
    )
    runner.run_all()

    # Exit code based on results
    failed = sum(1 for r in runner.results if r.status in ("failed", "error", "timeout"))
    return 1 if failed > 0 else 0


if __name__ == "__main__":
    sys.exit(main())

// =============================================================================
// pm32_config.h — Portable-Media-32 System Configuration
//
// Clean-room configuration for the Portable-Media-32 target system.
// Defines memory map, timing, hardware registers, and system constants.
//
// =============================================================================

#pragma once

#include <cstdint>

// ============================================================================
// Memory Map
// ============================================================================

namespace Pm32Memory {
    // User memory (32MB RAM)
    constexpr uint32_t RAM_BASE     = 0x08000000;
    constexpr uint32_t RAM_SIZE     = 0x02000000;  // 32 MB
    constexpr uint32_t RAM_END      = 0x09FFFFFF;

    // Kernel memory
    constexpr uint32_t KERNEL_BASE  = 0x80000000;
    constexpr uint32_t KERNEL_SIZE  = 0x00400000;  // 4 MB
    constexpr uint32_t KERNEL_END   = 0x803FFFFF;

    // VRAM (2MB)
    constexpr uint32_t VRAM_BASE    = 0x04000000;
    constexpr uint32_t VRAM_SIZE    = 0x00200000;  // 2 MB
    constexpr uint32_t VRAM_END     = 0x041FFFFF;

    // Scratchpad (128KB)
    constexpr uint32_t SCRATCH_BASE = 0x00010000;
    constexpr uint32_t SCRATCH_SIZE = 0x00020000;  // 128 KB

    // Hardware registers
    constexpr uint32_t HW_REGS_BASE = 0x1C000000;
    constexpr uint32_t HW_REGS_SIZE = 0x00400000;

    // GPU registers
    constexpr uint32_t GPU_CMD_BASE = 0x1C000000;
    constexpr uint32_t GPU_CMD_SIZE = 0x1000;
    constexpr uint32_t GPU_CMD_LIST = 0x1C001000;
    constexpr uint32_t GPU_CMD_LIST_SIZE = 0x1000;

    // Display registers
    constexpr uint32_t DISP_TOP     = 0x1C002000;
    constexpr uint32_t DISP_BOTTOM  = 0x1C002400;

    // Audio registers
    constexpr uint32_t AUDIO_BASE   = 0x1C003000;
    constexpr uint32_t AUDIO_SIZE   = 0x1000;

    // DMA registers
    constexpr uint32_t DMA_BASE     = 0x1C004000;
    constexpr uint32_t DMA_SIZE     = 0x1000;

    // Timer registers
    constexpr uint32_t TIMER_BASE   = 0x1C005000;
    constexpr uint32_t TIMER_SIZE   = 0x1000;

    // Interrupt controller
    constexpr uint32_t INTC_BASE    = 0x1C006000;
    constexpr uint32_t INTC_SIZE    = 0x1000;

    // System control
    constexpr uint32_t SYSCTRL_BASE = 0x1C007000;
    constexpr uint32_t SYSCTRL_SIZE = 0x1000;

    // Media (UMD) registers
    constexpr uint32_t UMD_BASE     = 0x1C008000;
    constexpr uint32_t UMD_SIZE     = 0x1000;

    // Wireless / IO
    constexpr uint32_t WLAN_BASE    = 0x1C009000;
    constexpr uint32_t WIRELESS_BASE = 0x1C00A000;

    // Audio output (headphone/speaker)
    constexpr uint32_t AUDIO_OUT    = 0x1C00B000;

    // GPIO
    constexpr uint32_t GPIO_BASE    = 0x1C00C000;
}

// ============================================================================
// Timing
// ============================================================================

namespace Pm32Timing {
    constexpr uint64_t CPU_CLOCK    = 333000000;   // 333 MHz (default)
    constexpr uint64_t BUS_CLOCK    = 111000000;   // 111 MHz bus
    constexpr uint64_t GPU_CLOCK    = 166000000;   // 166 MHz GPU
    constexpr uint32_t FRAME_RATE   = 60;           // 60 FPS
    constexpr uint32_t LINES_PER_FRAME = 273;       // 273 scanlines
    constexpr uint32_t CYCLES_PER_LINE = 15000;     // Approximate
    constexpr uint32_t VBLANK_START  = 260;
    constexpr uint32_t VBLANK_END    = 273;
}

// ============================================================================
// GPU Constants
// ============================================================================

namespace Pm32Gpu {
    constexpr uint32_t FB_WIDTH     = 480;
    constexpr uint32_t FB_HEIGHT    = 272;
    constexpr uint32_t FB_FORMAT    = 32;  // 32-bit RGBA

    constexpr uint32_t VRAM_WIDTH   = 512;
    constexpr uint32_t VRAM_HEIGHT  = 512;

    // Display modes
    constexpr uint32_t DISP_MODE_PSM_5551  = 0x00;
    constexpr uint32_t DISP_MODE_PSM_4444  = 0x01;
    constexpr uint32_t DISP_MODE_PSM_8888  = 0x02;
    constexpr uint32_t DISP_MODE_PSM_565   = 0x03;
}

// ============================================================================
// Audio Constants
// ============================================================================

namespace Pm32Audio {
    constexpr uint32_t SAMPLE_RATE  = 44100;
    constexpr uint32_t CHANNELS     = 2;       // Stereo
    constexpr uint32_t BUFFER_SIZE  = 4096;    // Samples per buffer
    constexpr uint32_t MAX_VOICES   = 32;      // ADPCM voices
}

// ============================================================================
// Interrupt Controller
// ============================================================================

namespace Pm32Intc {
    // Interrupt lines
    constexpr uint32_t IRQ_VBLANK    = 0;
    constexpr uint32_t IRQ_GPU       = 1;
    constexpr uint32_t IRQ_CDROM     = 2;
    constexpr uint32_t IRQ_DMA       = 3;
    constexpr uint32_t IRQ_TIMER0    = 4;
    constexpr uint32_t IRQ_TIMER1    = 5;
    constexpr uint32_t IRQ_TIMER2    = 6;
    constexpr uint32_t IRQ_RTC       = 7;
    constexpr uint32_t IRQ_AUDIO     = 8;
    constexpr uint32_t IRQ_IO        = 9;
    constexpr uint32_t IRQ_WLAN      = 10;
    constexpr uint32_t IRQ_UMD       = 11;
    constexpr uint32_t IRQ_HPREMOTE  = 12;
    constexpr uint32_t IRQ_USB       = 13;
    constexpr uint32_t IRQ_MS        = 14;
    constexpr uint32_t IRQ_WLAN_IE   = 15;

    // Register offsets
    constexpr uint32_t REG_ENABLE    = 0x00;
    constexpr uint32_t REG_ACK       = 0x04;
    constexpr uint32_t REG_DISABLE   = 0x08;
    constexpr uint32_t REG_PENDING   = 0x0C;
    constexpr uint32_t REG_TRIGGER   = 0x10;
}

// ============================================================================
// DMA Channels
// ============================================================================

namespace Pm32Dma {
    constexpr uint32_t CH_GPU_CMD    = 0;
    constexpr uint32_t CH_GPU_LIST   = 1;
    constexpr uint32_t CH_UMD        = 2;
    constexpr uint32_t CH_AUDIO      = 3;
    constexpr uint32_t CH_AUDIO_OUT  = 4;
    constexpr uint32_t CH_MAX        = 16;

    // Register offsets per channel (stride 0x10)
    constexpr uint32_t REG_SRC       = 0x00;
    constexpr uint32_t REG_DST       = 0x04;
    constexpr uint32_t REG_NEXT      = 0x08;
    constexpr uint32_t REG_ATTR      = 0x0C;
}

// ============================================================================
// UMD (Universal Media Disc) Constants
// ============================================================================

namespace Pm32Umd {
    constexpr uint32_t SECTOR_SIZE   = 2048;
    constexpr uint32_t SECTORS_PER_FRAME = 150;  // Approximate
    constexpr uint32_t MAX_SECTORS   = 0x100000;  // 2M sectors max
}

// ============================================================================
// Exception Vectors
// ============================================================================

namespace Pm32Vectors {
    constexpr uint32_t RESET         = 0xBFC00000;
    constexpr uint32_t TLB_REFILL    = 0x80000000;
    constexpr uint32_t GENERAL_EXC   = 0x80000180;
    constexpr uint32_t INTERRUPT     = 0x80000180;
}

// =============================================================================
// pm32_test_runner.cpp — Portable-Media-32 Test Runner
//
// Integration test harness for the Portable-Media-32 target system.
// Combines MIPS R4000 CPU, PM32 GPU, PM32 Audio, and UMD media.
//
// =============================================================================

#include "cpu/cpu_r4000.h"
#include "gpu/gpu_pm32.h"
#include "audio/audio_pm32.h"
#include "media/media_umd.h"
#include "pm32/pm32_config.h"
#include "umm.h"
#include "vhb_api.h"
#include <cstdio>
#include <cstring>
#include <fstream>
#include <sstream>
#include <chrono>
#include <thread>

// ============================================================================
// Simple memory backing for PM32
// ============================================================================

class Pm32Memory {
public:
    Pm32Memory() {
        ram_.fill(0);
        vram_.fill(0);
        scratch_.fill(0);
    }

    uint8_t read8(uint32_t addr) {
        if (addr >= Pm32Memory::RAM_BASE && addr <= Pm32Memory::RAM_END) {
            return ram_[addr - Pm32Memory::RAM_BASE];
        }
        if (addr >= Pm32Memory::VRAM_BASE && addr <= Pm32Memory::VRAM_END) {
            return vram_[(addr - Pm32Memory::VRAM_BASE) % vram_.size()];
        }
        if (addr >= Pm32Memory::SCRATCH_BASE && addr < Pm32Memory::SCRATCH_BASE + Pm32Memory::SCRATCH_SIZE) {
            return scratch_[addr - Pm32Memory::SCRATCH_BASE];
        }
        return 0;
    }

    void write8(uint32_t addr, uint8_t value) {
        if (addr >= Pm32Memory::RAM_BASE && addr <= Pm32Memory::RAM_END) {
            ram_[addr - Pm32Memory::RAM_BASE] = value;
        } else if (addr >= Pm32Memory::VRAM_BASE && addr <= Pm32Memory::VRAM_END) {
            vram_[(addr - Pm32Memory::VRAM_BASE) % vram_.size()] = value;
        } else if (addr >= Pm32Memory::SCRATCH_BASE && addr < Pm32Memory::SCRATCH_BASE + Pm32Memory::SCRATCH_SIZE) {
            scratch_[addr - Pm32Memory::SCRATCH_BASE] = value;
        }
    }

    void load_rom(const uint8_t* data, size_t size, uint32_t base = Pm32Memory::RAM_BASE) {
        for (size_t i = 0; i < size && (base + i) <= Pm32Memory::RAM_END; i++) {
            ram_[(base + i) - Pm32Memory::RAM_BASE] = data[i];
        }
    }

    static constexpr uint32_t RAM_BASE = Pm32Memory::RAM_BASE;
    static constexpr uint32_t RAM_END = Pm32Memory::RAM_END;
    static constexpr uint32_t VRAM_BASE = Pm32Memory::VRAM_BASE;
    static constexpr uint32_t VRAM_END = Pm32Memory::VRAM_END;
    static constexpr uint32_t SCRATCH_BASE = Pm32Memory::SCRATCH_BASE;
    static constexpr uint32_t SCRATCH_SIZE = Pm32Memory::SCRATCH_SIZE;

private:
    std::array<uint8_t, Pm32Memory::RAM_SIZE> ram_ = {};
    std::array<uint8_t, Pm32Memory::VRAM_SIZE> vram_ = {};
    std::array<uint8_t, Pm32Memory::SCRATCH_SIZE> scratch_ = {};
};

// ============================================================================
// Test Runner
// ============================================================================

struct Pm32TestConfig {
    std::string media_path;
    std::string output_path = "pm32_telemetry.json";
    uint64_t max_instructions = 1000000;
    uint32_t telemetry_interval = 10000;
    bool enable_trace = false;
    std::string trace_path;
};

struct Pm32Telemetry {
    uint64_t instructions_executed = 0;
    uint64_t cycles_elapsed = 0;
    uint32_t final_pc = 0;
    bool halted = false;
    uint32_t gpu_frame_count = 0;
    uint32_t gpu_scanline = 0;
    uint32_t audio_samples = 0;
    double elapsed_seconds = 0;
};

void run_pm32_test(const Pm32TestConfig& config) {
    fprintf(stderr, "[PM32] Starting Portable-Media-32 test runner\n");
    fprintf(stderr, "[PM32] Media: %s\n", config.media_path.c_str());
    fprintf(stderr, "[PM32] Max instructions: %llu\n", (unsigned long long)config.max_instructions);

    // Create components
    MipsR4000Core cpu;
    Pm32Gpu gpu;
    Pm32Audio audio;
    Pm32Memory memory;

    // Initialize
    gpu.init();
    audio.init();
    cpu.reset();

    // Set memory callbacks
    cpu.set_memory_callbacks(
        [&memory](uint32_t addr) -> uint8_t { return memory.read8(addr); },
        [&memory](uint32_t addr, uint8_t val) { memory.write8(addr, val); }
    );

    // Load media if provided
    if (!config.media_path.empty()) {
        UmdMedia media;
        if (media.load(config.media_path)) {
            fprintf(stderr, "[PM32] Media loaded: %s (%u sectors, %u bytes)\n",
                    media.get_format_name().c_str(),
                    media.get_sector_count(),
                    media.get_size());

            // Load first sectors into RAM
            uint8_t sector[Pm32Umd::SECTOR_SIZE];
            for (uint32_t i = 0; i < 100 && i < media.get_sector_count(); i++) {
                if (media.read_sector(i, sector)) {
                    memory.load_rom(sector, Pm32Umd::SECTOR_SIZE,
                                   Pm32Memory::RAM_BASE + i * Pm32Umd::SECTOR_SIZE);
                }
            }
        } else {
            fprintf(stderr, "[PM32] Failed to load media: %s\n", config.media_path.c_str());
        }
    }

    // Set up VBlank callback
    gpu.set_vblank_callback([&cpu]() {
        cpu.set_irq_line(Pm32Intc::IRQ_VBLANK, true);
    });

    // Set up audio memory callback
    audio.set_memory_callback([&memory](uint32_t addr) -> uint8_t {
        return memory.read8(addr);
    });

    // Run
    auto start_time = std::chrono::high_resolution_clock::now();

    uint64_t telemetry_count = 0;
    while (!cpu.is_halted() && cpu.get_instruction_count() < config.max_instructions) {
        cpu.step();

        // Step GPU (2 cycles per instruction for 333MHz CPU)
        gpu.step(2);

        // Step audio
        audio.step(2);

        // Telemetry
        if (cpu.get_instruction_count() - telemetry_count >= config.telemetry_interval) {
            telemetry_count = cpu.get_instruction_count();
            auto snap = cpu.get_snapshot();
            fprintf(stderr, "[PM32] PC=%08X IC=%llu CYC=%llu GPU_F=%u GPU_SL=%u\n",
                    snap.pc,
                    (unsigned long long)snap.instruction_count,
                    (unsigned long long)snap.cycle_count,
                    gpu.get_frame_count(),
                    gpu.get_scanline());
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    double elapsed = std::chrono::duration<double>(end_time - start_time).count();

    // Collect telemetry
    Pm32Telemetry telemetry;
    telemetry.instructions_executed = cpu.get_instruction_count();
    telemetry.cycles_elapsed = cpu.get_cycle_count();
    telemetry.final_pc = cpu.get_pc();
    telemetry.halted = cpu.is_halted();
    telemetry.gpu_frame_count = gpu.get_frame_count();
    telemetry.gpu_scanline = gpu.get_scanline();
    telemetry.audio_samples = audio.get_sample_count();
    telemetry.elapsed_seconds = elapsed;

    // Print results
    fprintf(stderr, "\n[PM32] ===== Test Complete =====\n");
    fprintf(stderr, "[PM32] Instructions: %llu\n", (unsigned long long)telemetry.instructions_executed);
    fprintf(stderr, "[PM32] Cycles: %llu\n", (unsigned long long)telemetry.cycles_elapsed);
    fprintf(stderr, "[PM32] Final PC: 0x%08X\n", telemetry.final_pc);
    fprintf(stderr, "[PM32] Halted: %s\n", telemetry.halted ? "yes" : "no");
    fprintf(stderr, "[PM32] GPU Frames: %u\n", telemetry.gpu_frame_count);
    fprintf(stderr, "[PM32] GPU Scanline: %u\n", telemetry.gpu_scanline);
    fprintf(stderr, "[PM32] Audio Samples: %u\n", telemetry.audio_samples);
    fprintf(stderr, "[PM32] Elapsed: %.2fs\n", telemetry.elapsed_seconds);
    if (telemetry.elapsed_seconds > 0) {
        double ips = telemetry.instructions_executed / telemetry.elapsed_seconds;
        fprintf(stderr, "[PM32] IPS: %.0f\n", ips);
    }

    // Save telemetry to JSON
    std::ofstream out(config.output_path);
    if (out) {
        out << "{\n";
        out << "  \"target\": \"Portable-Media-32\",\n";
        out << "  \"arch\": \"MIPS-R4000-Allegrex\",\n";
        out << "  \"instructions_executed\": " << telemetry.instructions_executed << ",\n";
        out << "  \"cycles_elapsed\": " << telemetry.cycles_elapsed << ",\n";
        out << "  \"final_pc\": " << telemetry.final_pc << ",\n";
        out << "  \"halted\": " << (telemetry.halted ? "true" : "false") << ",\n";
        out << "  \"gpu_frame_count\": " << telemetry.gpu_frame_count << ",\n";
        out << "  \"gpu_scanline\": " << telemetry.gpu_scanline << ",\n";
        out << "  \"audio_samples\": " << telemetry.audio_samples << ",\n";
        out << "  \"elapsed_seconds\": " << telemetry.elapsed_seconds << ",\n";
        out << "  \"cpu_clock_hz\": " << Pm32Timing::CPU_CLOCK << ",\n";
        out << "  \"gpu_clock_hz\": " << Pm32Timing::GPU_CLOCK << ",\n";
        out << "  \"audio_sample_rate\": " << Pm32Audio::SAMPLE_RATE << "\n";
        out << "}\n";
    }

    // Register dump
    fprintf(stderr, "\n[PM32] Register Dump:\n");
    for (int i = 0; i < 32; i++) {
        fprintf(stderr, "  %s: 0x%08X", cpu.get_reg_name(i), cpu.get_reg(i));
        if ((i + 1) % 4 == 0) fprintf(stderr, "\n");
    }
    fprintf(stderr, "  HI: 0x%08X  LO: 0x%08X\n", cpu.get_reg(R4K_HI), cpu.get_reg(R4K_LO));
    fprintf(stderr, "  PC: 0x%08X  Status: 0x%08X\n", cpu.get_pc(), cpu.get_reg(R4K_STATUS));

    gpu.shutdown();
    audio.shutdown();
}

// ============================================================================
// Main
// ============================================================================

#ifndef PM32_TEST_NO_MAIN
int main(int argc, char* argv[]) {
    Pm32TestConfig config;

    if (argc > 1) config.media_path = argv[1];
    if (argc > 2) config.max_instructions = strtoull(argv[2], nullptr, 10);
    if (argc > 3) config.output_path = argv[3];

    if (config.max_instructions == 0) config.max_instructions = 1000000;

    run_pm32_test(config);
    return 0;
}
#endif

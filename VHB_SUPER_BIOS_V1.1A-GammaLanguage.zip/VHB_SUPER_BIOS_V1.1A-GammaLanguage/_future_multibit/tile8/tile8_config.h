// =============================================================================
// tile8_config.h — Tile-8 Target Configuration
//
// Memory map, timing constants, and hardware register definitions for
// the Tile-8 (MOS 6502) target.
//
// =============================================================================

#pragma once

#include <cstdint>

// ============================================================================
// Memory Map (64KB address space)
// ============================================================================

namespace Tile8Memory {
    constexpr uint32_t RAM_BASE       = 0x0000;
    constexpr uint32_t RAM_SIZE       = 0x0800;  // 2KB internal RAM
    constexpr uint32_t RAM_MIRROR1    = 0x0800;
    constexpr uint32_t RAM_MIRROR2    = 0x1000;
    constexpr uint32_t RAM_MIRROR3    = 0x1800;
    constexpr uint32_t PPU_REG_BASE   = 0x2000;
    constexpr uint32_t PPU_REG_SIZE   = 0x0008;
    constexpr uint32_t PPU_REG_MIRROR = 0x2008;
    constexpr uint32_t APU_REG_BASE   = 0x4000;
    constexpr uint32_t APU_REG_SIZE   = 0x0018;
    constexpr uint32_t APU_STATUS     = 0x4015;
    constexpr uint32_t JOYPAD1        = 0x4016;
    constexpr uint32_t JOYPAD2        = 0x4017;
    constexpr uint32_t CART_BASE      = 0x4020;
    constexpr uint32_t PRG_ROM_BASE   = 0x8000;
    constexpr uint32_t PRG_ROM_UPPER  = 0xC000;
    constexpr uint32_t NMI_VECTOR     = 0xFFFA;
    constexpr uint32_t RESET_VECTOR   = 0xFFFC;
    constexpr uint32_t IRQ_VECTOR     = 0xFFFE;
}

// ============================================================================
// Timing (NTSC)
// ============================================================================

namespace Tile8Timing {
    constexpr uint32_t CPU_CLOCK_HZ   = 1789773;   // ~1.79 MHz
    constexpr uint32_t PPU_CLOCK_HZ   = 5369318;   // ~5.37 MHz (3x CPU)
    constexpr uint32_t SCANLINES      = 262;        // NTSC
    constexpr uint32_t SCANLINE_DOTS  = 341;
    constexpr uint32_t VBLANK_START   = 241;
    constexpr uint32_t VBLANK_END     = 261;
    constexpr uint32_t RENDER_START   = 0;
    constexpr uint32_t RENDER_END     = 240;
    constexpr uint32_t FPS            = 60;         // NTSC
}

// ============================================================================
// PPU Registers
// ============================================================================

namespace Tile8PpuRegs {
    constexpr uint16_t PPUCTRL   = 0x2000;
    constexpr uint16_t PPUMASK   = 0x2001;
    constexpr uint16_t PPUSTATUS = 0x2002;
    constexpr uint16_t OAMADDR   = 0x2003;
    constexpr uint16_t OAMDATA   = 0x2004;
    constexpr uint16_t PPUSCROLL = 0x2005;
    constexpr uint16_t PPUADDR   = 0x2006;
    constexpr uint16_t PPUDATA   = 0x2007;

    // PPUCTRL bits
    constexpr uint8_t CTRL_NMI        = 0x80;
    constexpr uint8_t CTRL_SPRITE_8X8 = 0x00;
    constexpr uint8_t CTRL_SPRITE_8X16 = 0x20;
    constexpr uint8_t CTRL_BG_TABLE   = 0x10;
    constexpr uint8_t CTRL_SPRITE_TABLE = 0x08;
    constexpr uint8_t CTRL_INCREMENT  = 0x04;
    constexpr uint8_t CTRL_NAMETABLE  = 0x03;

    // PPUMASK bits
    constexpr uint8_t MASK_BLUE       = 0x80;
    constexpr uint8_t MASK_GREEN      = 0x40;
    constexpr uint8_t MASK_RED        = 0x20;
    constexpr uint8_t MASK_SPRITE     = 0x10;
    constexpr uint8_t MASK_BACKGROUND = 0x08;
    constexpr uint8_t MASK_SPRITE_LEFT = 0x04;
    constexpr uint8_t MASK_BG_LEFT    = 0x02;
    constexpr uint8_t MASK_GRAYSCALE  = 0x01;

    // PPUSTATUS bits
    constexpr uint8_t STATUS_VBLANK   = 0x80;
    constexpr uint8_t STATUS_SPRITE0  = 0x40;
    constexpr uint8_t STATUS_OVERFLOW = 0x20;
}

// ============================================================================
// APU Registers
// ============================================================================

namespace Tile8ApuRegs {
    constexpr uint16_t PULSE1_DUTY    = 0x4000;
    constexpr uint16_t PULSE1_SWEEP   = 0x4001;
    constexpr uint16_t PULSE1_TIMER   = 0x4002;
    constexpr uint16_t PULSE1_LENGTH  = 0x4003;
    constexpr uint16_t PULSE2_DUTY    = 0x4004;
    constexpr uint16_t PULSE2_SWEEP   = 0x4005;
    constexpr uint16_t PULSE2_TIMER   = 0x4006;
    constexpr uint16_t PULSE2_LENGTH  = 0x4007;
    constexpr uint16_t TRIANGLE_LINEAR = 0x4008;
    constexpr uint16_t TRIANGLE_TIMER  = 0x400A;
    constexpr uint16_t TRIANGLE_LENGTH = 0x400B;
    constexpr uint16_t NOISE_ENVELOPE  = 0x400C;
    constexpr uint16_t NOISE_TIMER     = 0x400E;
    constexpr uint16_t NOISE_LENGTH    = 0x400F;
    constexpr uint16_t DPCM_FREQ       = 0x4010;
    constexpr uint16_t DPCM_RAW        = 0x4011;
    constexpr uint16_t DPCM_ADDR       = 0x4012;
    constexpr uint16_t DPCM_LENGTH     = 0x4013;
    constexpr uint16_t APU_STATUS      = 0x4015;
    constexpr uint16_t APU_FRAME       = 0x4017;
}

// ============================================================================
// Syscall/Vector Mapping
// ============================================================================

namespace Tile8Syscalls {
    // The 6502 uses hardware vectors, not software syscalls.
    // Vectors are at the top of PRG ROM:
    //   0xFFFA-0xFFFB: NMI vector
    //   0xFFFC-0xFFFD: RESET vector
    //   0xFFFE-0xFFFF: IRQ/BRK vector
    // The VHB intercepts these by remapping to boot module code.
    constexpr uint16_t VECTOR_NMI    = 0xFFFA;
    constexpr uint16_t VECTOR_RESET  = 0xFFFC;
    constexpr uint16_t VECTOR_IRQ    = 0xFFFE;
}

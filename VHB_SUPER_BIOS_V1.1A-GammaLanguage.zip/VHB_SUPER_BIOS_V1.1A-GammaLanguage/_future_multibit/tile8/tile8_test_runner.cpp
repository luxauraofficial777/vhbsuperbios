// =============================================================================
// tile8_test_runner.cpp — Tile-8 Test Runner with Harness Integration
//
// Boots a Tile-8 ROM through the M6502 CPU core, Tile-8 PPU, and Tile-8 APU.
// Integrates with the harness telemetry system for freeze detection, crash
// detection, and regression testing.
//
// Build: cl /EHsc /O2 /std:c++17 /D_CRT_SECURE_NO_WARNINGS
//        cpu/cpu_m6502.cpp cpu/cpu_factory.cpp memory/umm.cpp
//        tile8/tile8_test_runner.cpp -o tile8_test.exe
//
// Usage: tile8_test.exe --rom test.nes --max-instr 10000000
// =============================================================================

#include "../cpu/icpu_core.h"
#include "../cpu/cpu_m6502.h"
#include "../gpu/igpu_core.h"
#include "../gpu/gpu_tile8_ppu.h"
#include "../audio/iaudio_core.h"
#include "../audio/audio_tile8_apu.h"
#include "../media/imedia.h"
#include "../media/media_ines.h"
#include "../memory/umm.h"
#include "../tile8/tile8_config.h"

#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <fstream>
#include <chrono>
#include <sstream>
#include <iomanip>

// ============================================================================
// Telemetry
// ============================================================================

struct Tile8Telemetry {
    uint64_t instruction_count = 0;
    uint64_t cycle_count = 0;
    uint32_t frame_count = 0;
    uint32_t pc = 0;
    uint32_t last_pc = 0;
    bool crashed = false;
    bool halted = false;
    std::string crash_reason;
    uint32_t ppu_frames = 0;
    uint32_t ppu_commands = 0;
    uint32_t apu_samples = 0;
    uint32_t nmi_count = 0;
    uint32_t irq_count = 0;
    uint16_t reset_vector = 0;
    uint8_t mapper_id = 0;
    uint8_t prg_banks = 0;
    uint8_t chr_banks = 0;
};

// ============================================================================
// Memory Bus — connects CPU to UMM + PPU + APU registers
// ============================================================================

class Tile8MemoryBus {
public:
    UnifiedMemoryManager umm;
    Tile8Ppu* ppu = nullptr;
    Tile8Apu* apu = nullptr;
    std::vector<uint8_t> prg_rom;
    std::vector<uint8_t> chr_rom;
    uint8_t joypad1_state = 0;
    uint8_t joypad1_shift = 0;
    bool joypad1_strobe = false;

    uint8_t read(uint16_t addr) {
        // RAM (0x0000-0x07FF, with mirrors)
        if (addr < 0x2000) {
            return umm.read8(addr & 0x07FF);
        }
        // PPU registers (0x2000-0x2007, mirrored every 8 bytes)
        if (addr >= 0x2000 && addr < 0x4000) {
            uint16_t reg = 0x2000 + (addr & 0x0007);
            return (uint8_t)ppu->read_reg(reg);
        }
        // APU and I/O registers
        if (addr >= 0x4000 && addr < 0x4020) {
            if (addr == Tile8ApuRegs::APU_STATUS) {
                return (uint8_t)apu->read_reg(addr);
            }
            if (addr == Tile8Memory::JOYPAD1) {
                // Read shifted joypad bit
                uint8_t bit = (joypad1_shift & 0x01) ? 0x01 : 0x00;
                joypad1_shift >>= 1;
                return bit | 0x40;  // Open bus bits
            }
            if (addr == Tile8Memory::JOYPAD2) {
                return 0x40;  // No second controller
            }
            return (uint8_t)apu->read_reg(addr);
        }
        // Cartridge space (0x4020-0xFFFF)
        if (addr >= 0x8000 && !prg_rom.empty()) {
            uint32_t rom_addr = addr - 0x8000;
            if (prg_rom.size() <= 32 * 1024) {
                // Mirror for 16KB ROMs
                rom_addr &= (prg_rom.size() - 1);
            }
            if (rom_addr < prg_rom.size()) {
                return prg_rom[rom_addr];
            }
        }
        // SRAM (0x6000-0x7FFF) — return 0 for now
        if (addr >= 0x6000 && addr < 0x8000) {
            return umm.read8(0x6000 + (addr - 0x6000));
        }
        return 0xFF;  // Open bus
    }

    void write(uint16_t addr, uint8_t val) {
        // RAM
        if (addr < 0x2000) {
            umm.write8(addr & 0x07FF, val);
            return;
        }
        // PPU registers
        if (addr >= 0x2000 && addr < 0x4000) {
            uint16_t reg = 0x2000 + (addr & 0x0007);
            ppu->write_reg(reg, val);
            return;
        }
        // APU and I/O
        if (addr >= 0x4000 && addr < 0x4020) {
            if (addr == Tile8Memory::JOYPAD1) {
                joypad1_strobe = (val & 0x01) != 0;
                if (joypad1_strobe) {
                    joypad1_shift = joypad1_state;
                }
                return;
            }
            apu->write_reg(addr, val);
            return;
        }
        // SRAM
        if (addr >= 0x6000 && addr < 0x8000) {
            umm.write8(0x6000 + (addr - 0x6000), val);
            return;
        }
        // PRG ROM is read-only
    }
};

// ============================================================================
// Main
// ============================================================================

int main(int argc, char* argv[]) {
    std::string rom_path;
    uint64_t max_instr = 10000000;
    bool verbose = false;
    bool save_telemetry = false;
    std::string telemetry_path = "tile8_telemetry.json";

    // Parse args
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--rom" && i + 1 < argc) {
            rom_path = argv[++i];
        } else if (arg == "--max-instr" && i + 1 < argc) {
            max_instr = std::stoull(argv[++i]);
        } else if (arg == "--verbose" || arg == "-v") {
            verbose = true;
        } else if (arg == "--save-telemetry" && i + 1 < argc) {
            save_telemetry = true;
            telemetry_path = argv[++i];
        } else if (arg == "--help") {
            printf("Usage: tile8_test.exe --rom <file.nes> [--max-instr N] [--verbose] [--save-telemetry file.json]\n");
            return 0;
        }
    }

    if (rom_path.empty()) {
        fprintf(stderr, "Error: --rom is required\n");
        return 1;
    }

    // Load ROM
    INesMedia media;
    if (!media.load(rom_path)) {
        fprintf(stderr, "Error: Failed to load ROM: %s\n", rom_path.c_str());
        return 1;
    }

    printf("[Tile-8] ROM loaded: %s\n", rom_path.c_str());
    printf("  Mapper: %d\n", media.get_mapper());
    printf("  PRG banks: %d (%u KB)\n", media.get_prg_banks(), media.get_prg_size() / 1024);
    printf("  CHR banks: %d (%u KB)\n", media.get_chr_banks(), media.get_chr_size() / 1024);
    printf("  Mirroring: %s\n", media.has_vertical_mirroring() ? "vertical" : "horizontal");
    printf("  Trainer: %s\n", media.has_trainer() ? "yes" : "no");
    printf("  Battery: %s\n", media.has_battery() ? "yes" : "no");

    // Initialize memory
    Tile8MemoryBus bus;
    bus.umm.init(MemoryProfiles::Tile8);

    // Load PRG ROM into bus
    uint32_t prg_size = media.get_prg_size();
    bus.prg_rom.resize(prg_size);
    std::memcpy(bus.prg_rom.data(), media.get_prg_rom(), prg_size);

    // Load CHR ROM into PPU
    Tile8Ppu ppu;
    ppu.reset();
    if (media.get_chr_banks() > 0) {
        ppu.load_chr_rom(media.get_chr_rom(), media.get_chr_size());
    }
    bus.ppu = &ppu;

    // Initialize APU
    Tile8Apu apu;
    apu.reset();
    bus.apu = &apu;
    bus.joypad1_state = 0x41;  // Digital controller: no buttons pressed

    // Initialize CPU
    M6502Core cpu;
    cpu.set_memory_callbacks(
        [&bus](uint32_t addr) -> uint8_t { return bus.read(addr & 0xFFFF); },
        [&bus](uint32_t addr, uint8_t val) { bus.write(addr & 0xFFFF, val); }
    );

    // Set PPU NMI callback
    bool nmi_pending = false;
    ppu.set_nmi_callback([&nmi_pending]() { nmi_pending = true; });

    // Reset CPU — reads reset vector from ROM
    cpu.reset();

    // Read reset vector
    uint8_t reset_lo = bus.read(0xFFFC);
    uint8_t reset_hi = bus.read(0xFFFD);
    uint16_t reset_vector = reset_lo | (uint16_t(reset_hi) << 8);

    printf("  Reset vector: $%04X\n", reset_vector);
    printf("  Entry PC: $%04X\n", cpu.get_pc());

    // Telemetry
    Tile8Telemetry telemetry;
    telemetry.reset_vector = reset_vector;
    telemetry.mapper_id = media.get_mapper();
    telemetry.prg_banks = media.get_prg_banks();
    telemetry.chr_banks = media.get_chr_banks();

    // Run
    printf("[Tile-8] Running %llu instructions...\n", (unsigned long long)max_instr);

    auto start_time = std::chrono::high_resolution_clock::now();
    uint32_t last_frame = 0;
    uint32_t progress_interval = (uint32_t)(max_instr / 10);
    if (progress_interval == 0) progress_interval = 1000000;

    for (uint64_t i = 0; i < max_instr; i++) {
        // Check NMI
        if (nmi_pending) {
            nmi_pending = false;
            cpu.set_nmi(true);
            telemetry.nmi_count++;
        }

        // Check IRQ (APU frame counter could trigger this)
        // For now, no IRQ source

        // Execute one instruction
        int result = cpu.step();
        if (result < 0 || cpu.is_halted()) {
            telemetry.crashed = true;
            telemetry.crash_reason = "CPU halted";
            break;
        }

        // Step PPU (3 PPU cycles per CPU cycle)
        int cpu_cycles = 2;  // Simplified — most 6502 instructions are 2+ cycles
        ppu.step(cpu_cycles * 3);

        // Step APU
        apu.step(cpu_cycles);

        // Update telemetry
        telemetry.instruction_count = cpu.get_instruction_count();
        telemetry.cycle_count = cpu.get_cycle_count();
        telemetry.pc = cpu.get_pc();
        telemetry.ppu_frames = ppu.get_frame_count();
        telemetry.ppu_commands = ppu.get_command_count();
        telemetry.apu_samples = apu.get_sample_count();

        // Check for freeze (PC stuck)
        if (telemetry.pc == telemetry.last_pc && i > 1000) {
            // Could be a tight loop — check if it's been here for a while
            // For now, just track it
        }
        telemetry.last_pc = telemetry.pc;

        // Progress report
        if ((i + 1) % progress_interval == 0) {
            auto now = std::chrono::high_resolution_clock::now();
            auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - start_time);
            printf("  [%llu/%llu] PC=$%04X frames=%u cycles=%llu time=%llums\n",
                   (unsigned long long)(i + 1), (unsigned long long)max_instr,
                   telemetry.pc, telemetry.ppu_frames,
                   (unsigned long long)telemetry.cycle_count,
                   (unsigned long long)elapsed.count());
        }

        // Frame change detection
        if (ppu.get_frame_count() > last_frame) {
            last_frame = ppu.get_frame_count();
            if (verbose) {
                printf("  Frame %u: PC=$%04X instr=%llu\n",
                       last_frame, telemetry.pc, (unsigned long long)i);
            }
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    auto total_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time);

    // Final report
    printf("\n[Tile-8] Execution complete.\n");
    printf("  Instructions: %llu\n", (unsigned long long)telemetry.instruction_count);
    printf("  Cycles: %llu\n", (unsigned long long)telemetry.cycle_count);
    printf("  PPU Frames: %u\n", telemetry.ppu_frames);
    printf("  PPU Commands: %u\n", telemetry.ppu_commands);
    printf("  APU Samples: %u\n", telemetry.apu_samples);
    printf("  NMI count: %u\n", telemetry.nmi_count);
    printf("  IRQ count: %u\n", telemetry.irq_count);
    printf("  Final PC: $%04X\n", telemetry.pc);
    printf("  Crashed: %s\n", telemetry.crashed ? "YES" : "no");
    printf("  Halted: %s\n", telemetry.halted ? "YES" : "no");
    printf("  Time: %llums\n", (unsigned long long)total_ms.count());

    if (telemetry.ppu_frames > 0) {
        printf("  STATUS: PASS — %u frames rendered\n", telemetry.ppu_frames);
    } else {
        printf("  STATUS: WARN — no frames rendered (PPU may not be initialized)\n");
    }

    // Save telemetry
    if (save_telemetry) {
        std::ofstream f(telemetry_path);
        if (f) {
            f << "{\n";
            f << "  \"target\": \"Tile-8\",\n";
            f << "  \"rom\": \"" << rom_path << "\",\n";
            f << "  \"mapper\": " << (int)telemetry.mapper_id << ",\n";
            f << "  \"prg_banks\": " << (int)telemetry.prg_banks << ",\n";
            f << "  \"chr_banks\": " << (int)telemetry.chr_banks << ",\n";
            f << "  \"reset_vector\": " << telemetry.reset_vector << ",\n";
            f << "  \"instruction_count\": " << telemetry.instruction_count << ",\n";
            f << "  \"cycle_count\": " << telemetry.cycle_count << ",\n";
            f << "  \"ppu_frames\": " << telemetry.ppu_frames << ",\n";
            f << "  \"ppu_commands\": " << telemetry.ppu_commands << ",\n";
            f << "  \"apu_samples\": " << telemetry.apu_samples << ",\n";
            f << "  \"nmi_count\": " << telemetry.nmi_count << ",\n";
            f << "  \"final_pc\": " << telemetry.pc << ",\n";
            f << "  \"crashed\": " << (telemetry.crashed ? "true" : "false") << ",\n";
            f << "  \"halted\": " << (telemetry.halted ? "true" : "false") << ",\n";
            f << "  \"time_ms\": " << total_ms.count() << "\n";
            f << "}\n";
            printf("[Tile-8] Telemetry saved to %s\n", telemetry_path.c_str());
        }
    }

    return telemetry.crashed ? 1 : 0;
}

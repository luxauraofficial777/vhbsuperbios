// =============================================================================
// imedia.h — Universal Media Interface for Multi-Bit-Depth Platform
//
// All media formats (ISO 9660, iNES, Tile-16 ROM, CD-16 ROM, Handheld-8 ROM,
// Handheld-32 ROM, Cart-64 ROM, UMD/CSO) implement this interface.
//
// Clean-room design: no proprietary names, no SDK headers.
// =============================================================================

#pragma once

#include <cstdint>
#include <string>
#include <vector>

enum class MediaFormat : uint8_t {
    Unknown     = 0,
    Iso9660     = 1,    // CD-ROM: MODE1/MODE2, .bin/.cue, .iso
    INes        = 2,    // Tile-8 cartridge: .nes
    Tile16Rom   = 3,    // Tile-16 cartridge: .sfc, .smc
    Cd16Rom     = 4,    // CD-16 cartridge: .gen, .md, .bin
    Hh8Rom      = 5,    // Handheld-8 cartridge: .gb, .gbc
    Hh32Rom     = 6,    // Handheld-32 cartridge: .gba
    Cart64Rom   = 7,    // Cart-64 cartridge: .z64, .n64
    UmdCso      = 8,    // Portable-Media-32: .iso, .cso
    VfsOverlay  = 9,    // Virtual file system overlay
};

struct MediaHeader {
    MediaFormat format;
    char volume_id[32];
    uint32_t total_size;
    uint32_t sector_size;
    uint32_t sector_count;
    uint32_t entry_point;
    uint32_t load_address;
    uint32_t text_size;
    bool is_compressed;
    uint8_t mapper_id;       // For cartridge formats
    uint8_t region_code;     // 0=NTSC-J, 1=NTSC-U, 2=PAL
};

class IMedia {
public:
    virtual ~IMedia() = default;

    // Load media from a file path.
    virtual bool load(const std::string& path) = 0;

    // Read data from the media at the given offset.
    virtual bool read(uint32_t offset, void* dest, size_t len) = 0;

    // Get the total size of the media in bytes.
    virtual uint32_t size() const = 0;

    // Get the media format.
    virtual MediaFormat get_format() const = 0;

    // Get human-readable format name.
    virtual const char* get_format_name() const = 0;

    // Get parsed header information.
    virtual const MediaHeader& get_header() const = 0;

    // Compute a simple checksum (for harness validation).
    virtual uint32_t get_checksum() const = 0;

    // For CD-based media: read a raw sector (2352 bytes).
    virtual bool read_sector(uint32_t lba, uint8_t* dest) = 0;

    // For CD-based media: get sector size (2048 or 2352).
    virtual uint32_t get_sector_size() const = 0;

    // For CD-based media: get total sector count.
    virtual uint32_t get_sector_count() const = 0;

    // For cartridge media: get bank count.
    virtual uint32_t get_bank_count() const = 0;

    // For cartridge media: read a specific bank.
    virtual bool read_bank(uint32_t bank_idx, uint8_t* dest) = 0;
};

// Media factory — creates the correct parser based on file extension or magic.
IMedia* create_media(const std::string& path);

// Detect media format from file header bytes.
MediaFormat detect_media_format(const uint8_t* header, size_t len);

// =============================================================================
// media_umd.h — UMD (Universal Media Disc) Media Parser (Clean-Room)
//
// Implements IMedia for UMD disc image parsing.
// UMD uses ISO 9660 / UDF filesystem on a 60mm optical disc.
// Disc images are typically .ISO or .CSO (compressed) format.
//
// Reference: ISO 9660 specification (public), UDF 2.60 (public)
//
// =============================================================================

#pragma once

#include "imedia.h"
#include <vector>
#include <string>
#include <cstring>
#include <fstream>

// ============================================================================
// UMD Disc Header (ISO 9660 Primary Volume Descriptor)
// ============================================================================

struct UmdHeader {
    uint8_t  system_id[32];     // System identifier
    uint8_t  volume_id[32];     // Volume identifier
    uint32_t volume_size;       // Volume space size (sectors)
    uint32_t volume_set_size;   // Volume set size
    uint32_t volume_seq;        // Volume sequence number
    uint16_t block_size;        // Logical block size
    uint32_t path_table_size;   // Path table size
    uint32_t path_table_lba;    // Path table LBA
    uint32_t root_dir_lba;      // Root directory LBA
    uint32_t root_dir_size;     // Root directory size
    uint8_t  volume_set_id[128];
    uint8_t  publisher_id[128];
    uint8_t  data_preparer_id[128];
    uint8_t  application_id[128];
    uint8_t  copyright_file[37];
    uint8_t  abstract_file[37];
    uint8_t  bibliographic_file[37];
};

// ============================================================================
// UMD File Entry (ISO 9660 Directory Record)
// ============================================================================

struct UmdFileEntry {
    std::string name;
    uint32_t lba;           // Logical block address
    uint32_t size;          // File size in bytes
    uint8_t  flags;         // File flags (directory, hidden, etc.)
    bool is_directory;
};

// ============================================================================
// CSO (Compressed ISO) Header
// ============================================================================

struct CsoHeader {
    uint8_t  magic[4];      // 'C', 'S', 'O', '\0'
    uint32_t header_size;   // Header size (0x18 for v1)
    uint64_t total_size;    // Uncompressed size
    uint32_t frame_size;    // Frame size (typically 2048)
    uint8_t  version;       // Version (1)
    uint8_t  align;         // Alignment
    uint8_t  reserved[2];
};

// ============================================================================
// UmdMedia
// ============================================================================

class UmdMedia : public IMedia {
public:
    UmdMedia() = default;
    ~UmdMedia() override = default;

    // ----- IMedia -----
    bool load(const std::string& path) override;
    void unload() override;
    bool is_loaded() const override { return loaded_; }

    MediaHeader get_header() const override;
    std::string get_format_name() const override { return "UMD (ISO/CSO)"; }
    uint32_t get_size() const override { return total_size_; }
    uint32_t get_sector_count() const override { return sector_count_; }
    uint32_t get_sector_size() const override { return Pm32Umd::SECTOR_SIZE; }

    bool read_sector(uint32_t lba, uint8_t* buffer) override;
    bool read_bytes(uint32_t offset, uint32_t size, uint8_t* buffer) override;

    // ----- UMD-specific -----
    const UmdHeader& get_umd_header() const { return umd_header_; }
    const std::vector<UmdFileEntry>& get_file_list() const { return files_; }
    const UmdFileEntry* find_file(const std::string& name) const;

    bool is_cso() const { return cso_mode_; }
    uint32_t get_root_dir_lba() const { return umd_header_.root_dir_lba; }

private:
    bool loaded_ = false;
    bool cso_mode_ = false;
    std::string file_path_;
    std::ifstream file_stream_;
    uint32_t total_size_ = 0;
    uint32_t sector_count_ = 0;

    UmdHeader umd_header_ = {};
    std::vector<UmdFileEntry> files_;

    // CSO data
    CsoHeader cso_header_ = {};
    std::vector<uint32_t> cso_index_;

    bool load_iso();
    bool load_cso();
    bool parse_iso_directory(uint32_t lba, uint32_t size, bool is_root = false);
    bool read_cso_sector(uint32_t lba, uint8_t* buffer);

    // ISO 9660 helpers
    bool read_primary_volume_descriptor();
    std::string read_iso_string(const uint8_t* data, int len);
};

// =============================================================================
// media_ines.h — iNES ROM Format Parser (Clean-Room)
//
// Parses the iNES cartridge format (.nes files) for Tile-8 targets.
// Reference: NESdev wiki iNES documentation (public).
//
// iNES header (16 bytes):
//   0-3: "NES\x1A" magic
//   4:   PRG ROM size (16KB units)
//   5:   CHR ROM size (8KB units)
//   6:   Flags 6 (mapper low nibble, mirroring, trainer, SRAM)
//   7:   Flags 7 (mapper high nibble, NES 2.0 flag)
//   8-15: Flags 8-15 (reserved)
//
// =============================================================================

#pragma once

#include "imedia.h"
#include <fstream>
#include <cstring>

class INesMedia : public IMedia {
public:
    INesMedia() {}
    ~INesMedia() override = default;

    bool load(const std::string& path) override {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f) return false;
        size_t sz = (size_t)f.tellg();
        f.seekg(0);
        data_.resize(sz);
        f.read((char*)data_.data(), sz);

        if (sz < 16) return false;
        if (data_[0] != 'N' || data_[1] != 'E' || data_[2] != 'S' || data_[3] != 0x1A) {
            return false;
        }

        // Parse header
        prg_banks_ = data_[4];
        chr_banks_ = data_[5];
        uint8_t flags6 = data_[6];
        uint8_t flags7 = data_[7];

        mapper_id_ = (flags6 >> 4) | ((flags7 >> 4) << 4);
        mirroring_ = flags6 & 0x01;       // 0=horizontal, 1=vertical
        has_trainer_ = (flags6 & 0x04) != 0;
        has_sram_ = (flags6 & 0x02) != 0;

        // Calculate offsets
        prg_offset_ = 16;
        if (has_trainer_) prg_offset_ += 512;
        chr_offset_ = prg_offset_ + prg_banks_ * 16 * 1024;

        // Fill header struct
        header_.format = MediaFormat::INes;
        std::memset(header_.volume_id, 0, sizeof(header_.volume_id));
        header_.total_size = (uint32_t)sz;
        header_.sector_size = 0;
        header_.sector_count = 0;
        header_.entry_point = 0xC000;  // Default entry (upper PRG bank)
        header_.load_address = 0x8000; // PRG ROM loads at 0x8000
        header_.text_size = prg_banks_ * 16 * 1024;
        header_.is_compressed = false;
        header_.mapper_id = mapper_id_;
        header_.region_code = 0;  // NTSC-J default

        // Compute checksum
        checksum_ = 0;
        for (size_t i = 0; i < sz; i++) {
            checksum_ = (checksum_ * 31 + data_[i]) & 0xFFFFFFFF;
        }

        return true;
    }

    bool read(uint32_t offset, void* dest, size_t len) override {
        if (offset + len > data_.size()) return false;
        std::memcpy(dest, data_.data() + offset, len);
        return true;
    }

    uint32_t size() const override { return (uint32_t)data_.size(); }
    MediaFormat get_format() const override { return MediaFormat::INes; }
    const char* get_format_name() const override { return "iNES"; }
    const MediaHeader& get_header() const override { return header_; }
    uint32_t get_checksum() const override { return checksum_; }

    bool read_sector(uint32_t lba, uint8_t* dest) override {
        (void)lba; (void)dest;
        return false;  // Cartridge — no sectors
    }

    uint32_t get_sector_size() const override { return 0; }
    uint32_t get_sector_count() const override { return 0; }

    uint32_t get_bank_count() const override { return prg_banks_; }

    bool read_bank(uint32_t bank_idx, uint8_t* dest) override {
        uint32_t offset = prg_offset_ + bank_idx * 16 * 1024;
        if (offset + 16 * 1024 > data_.size()) return false;
        std::memcpy(dest, data_.data() + offset, 16 * 1024);
        return true;
    }

    // iNES-specific accessors
    uint8_t get_prg_banks() const { return prg_banks_; }
    uint8_t get_chr_banks() const { return chr_banks_; }
    uint8_t get_mapper() const { return mapper_id_; }
    bool has_vertical_mirroring() const { return mirroring_ != 0; }
    bool has_trainer() const { return has_trainer_; }
    bool has_battery() const { return has_sram_; }

    const uint8_t* get_prg_rom() const {
        return data_.data() + prg_offset_;
    }

    const uint8_t* get_chr_rom() const {
        if (chr_banks_ == 0) return nullptr;
        return data_.data() + chr_offset_;
    }

    uint32_t get_prg_size() const { return prg_banks_ * 16 * 1024; }
    uint32_t get_chr_size() const { return chr_banks_ * 8 * 1024; }

private:
    std::vector<uint8_t> data_;
    uint8_t prg_banks_ = 0;
    uint8_t chr_banks_ = 0;
    uint8_t mapper_id_ = 0;
    uint8_t mirroring_ = 0;
    bool has_trainer_ = false;
    bool has_sram_ = false;
    uint32_t prg_offset_ = 16;
    uint32_t chr_offset_ = 0;
    uint32_t checksum_ = 0;
    MediaHeader header_{};
};

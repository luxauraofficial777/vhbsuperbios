// =============================================================================
// audio_tile8_apu.h — Tile-8 APU (Audio Processing Unit) — Clean-Room
//
// Emulates the Tile-8 APU: 2 pulse channels, 1 triangle, 1 noise, 1 DPCM.
// Reference: public APU documentation.
//
// =============================================================================

#pragma once

#include "iaudio_core.h"
#include <array>

class Tile8Apu : public IAudioCore {
public:
    Tile8Apu();
    ~Tile8Apu() override = default;

    void reset() override;
    void step(int cycles) override;
    void write_reg(uint32_t addr, uint32_t value) override;
    uint32_t read_reg(uint32_t addr) override;

    uint32_t get_samples(int16_t* dest, uint32_t max_samples) override;
    uint32_t get_sample_rate() const override { return 44100; }
    int get_channel_count() const override { return 2; }

    AudioTypeID get_type_id() const override { return AudioTypeID::Tile8Apu; }
    const char* get_type_name() const override { return "Tile-8 APU"; }
    uint32_t get_sample_count() const override { return sample_count_; }

    AudioStateSnapshot get_snapshot() const override {
        AudioStateSnapshot s;
        s.sample_count = sample_count_;
        s.buffer_pos = buffer_pos_;
        s.dma_active = dpcm_active_;
        s.type = AudioTypeID::Tile8Apu;
        return s;
    }

    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;

private:
    // Pulse channel 1 & 2
    struct PulseChannel {
        uint8_t duty = 0;
        uint8_t volume = 0;
        bool sweep_enable = false;
        uint8_t sweep_period = 0;
        int8_t sweep_negate = 0;
        uint8_t sweep_shift = 0;
        uint16_t timer = 0;
        uint16_t timer_reload = 0;
        uint8_t length_counter = 0;
        bool envelope_loop = false;
        bool envelope_disable = false;
        uint8_t envelope_period = 0;
        uint8_t envelope_decay = 0;
        bool enabled = false;
        int duty_pos = 0;
        int timer_counter = 0;
    };

    // Triangle channel
    struct TriangleChannel {
        uint16_t timer = 0;
        uint16_t timer_reload = 0;
        uint8_t length_counter = 0;
        uint8_t linear_counter = 0;
        uint8_t linear_reload = 0;
        bool linear_reload_flag = false;
        bool enabled = false;
        int timer_counter = 0;
        int sequence_pos = 0;
    };

    // Noise channel
    struct NoiseChannel {
        uint16_t timer = 0;
        uint8_t length_counter = 0;
        bool mode = false;  // 93-bit vs 6-bit
        uint16_t shift_register = 1;
        uint8_t volume = 0;
        bool envelope_disable = false;
        uint8_t envelope_period = 0;
        uint8_t envelope_decay = 0;
        bool envelope_loop = false;
        bool enabled = false;
        int timer_counter = 0;
    };

    // DPCM channel
    struct DpcmChannel {
        uint16_t sample_addr = 0;
        uint16_t sample_length = 0;
        uint8_t sample_buffer = 0;
        bool has_sample = false;
        uint8_t dac = 0;
        uint16_t bytes_remaining = 0;
        uint16_t addr_counter = 0;
        uint16_t timer = 0;
        int timer_counter = 0;
        bool loop = false;
        bool irq_enable = false;
        bool irq_flag = false;
        bool enabled = false;
    };

    PulseChannel pulse1_{};
    PulseChannel pulse2_{};
    TriangleChannel triangle_{};
    NoiseChannel noise_{};
    DpcmChannel dpcm_{};

    // Frame counter
    int frame_counter_ = 0;
    int frame_mode_ = 0;  // 0=4-step, 1=5-step
    bool frame_irq_enable_ = false;
    bool frame_irq_flag_ = false;

    // Output buffer
    std::array<int16_t, 4096> sample_buffer_{};
    uint32_t buffer_pos_ = 0;
    uint32_t sample_count_ = 0;
    bool dpcm_active_ = false;

    // CPU memory read callback (for DPCM samples)
    std::function<uint8_t(uint16_t)> mem_read_;

public:
    void set_mem_read(std::function<uint8_t(uint16_t)> cb) { mem_read_ = cb; }

private:
    void clock_envelope(PulseChannel& ch);
    void clock_length(PulseChannel& ch);
    void clock_sweep(PulseChannel& ch);
    void clock_triangle_linear();
    int8_t render_pulse(PulseChannel& ch);
    int8_t render_triangle();
    int8_t render_noise();
    int8_t render_dpcm();

    static const uint8_t pulse_duty_table_[4][8];
    static const uint8_t triangle_wave_[32];
    static const uint16_t noise_period_table_[16];
    static const uint16_t dpcm_period_table_[16];
};

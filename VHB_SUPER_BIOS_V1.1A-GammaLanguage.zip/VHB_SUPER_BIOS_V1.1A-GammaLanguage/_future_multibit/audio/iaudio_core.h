// =============================================================================
// iaudio_core.h — Universal Audio Interface for Multi-Bit-Depth Platform
//
// All audio cores (Tile-8 APU, Tile-16 SPC700, CD-16 YM2612+PSG,
// Handheld-8 APU, Handheld-32 sound, CD-24/32 SPU, Portable-Media-32 audio)
// implement this interface.
//
// Clean-room design: no proprietary names, no SDK headers.
// =============================================================================

#pragma once

#include <cstdint>
#include <string>
#include <vector>

enum class AudioTypeID : uint8_t {
    Unknown     = 0,
    Tile8Apu    = 1,    // PSG: 2 pulse + triangle + noise + DPCM
    Tile16Spc   = 2,    // SPC700 + 8-channel ADPCM
    Cd16Ym      = 3,    // FM (YM2612) + PSG (SN76489)
    Hh8Apu      = 4,    // 4-channel PSG
    Hh32Sound   = 5,    // PSG + DMA + 8-bit PCM
    Cd32Spu     = 6,    // ADPCM + MIDI + CD-DA
    Cd32xScsp   = 7,    // SCSP FM + DSP
    Pm32Audio   = 8,    // AAC + ATRAC3 + PCM + MP3
    Cart64Ai    = 9,    // AI DAC + sample DMA
};

struct AudioStateSnapshot {
    uint32_t sample_count = 0;
    uint32_t buffer_pos = 0;
    bool dma_active = false;
    AudioTypeID type = AudioTypeID::Unknown;
};

class IAudioCore {
public:
    virtual ~IAudioCore() = default;

    virtual void reset() = 0;
    virtual void step(int cycles) = 0;
    virtual void write_reg(uint32_t addr, uint32_t value) = 0;
    virtual uint32_t read_reg(uint32_t addr) = 0;

    // Get audio samples (16-bit signed, interleaved stereo).
    // Returns number of samples written to dest.
    virtual uint32_t get_samples(int16_t* dest, uint32_t max_samples) = 0;

    // Get sample rate in Hz.
    virtual uint32_t get_sample_rate() const = 0;

    // Get number of channels.
    virtual int get_channel_count() const = 0;

    virtual AudioTypeID get_type_id() const = 0;
    virtual const char* get_type_name() const = 0;
    virtual uint32_t get_sample_count() const = 0;
    virtual AudioStateSnapshot get_snapshot() const = 0;

    virtual std::vector<uint8_t> save_state() const = 0;
    virtual void load_state(const std::vector<uint8_t>& state) = 0;
};

IAudioCore* create_audio_core(AudioTypeID type);

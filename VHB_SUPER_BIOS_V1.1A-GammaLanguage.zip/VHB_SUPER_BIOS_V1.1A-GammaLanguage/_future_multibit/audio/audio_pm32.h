// =============================================================================
// audio_pm32.h — Portable-Media-32 Audio Core (Clean-Room Implementation)
//
// Implements IAudioCore for the Portable-Media-32 audio system.
// Features: 32 ADPCM voices, stereo mixing, reverb, 44.1kHz output.
//
// Reference: Public audio documentation, github.com/hrydgard/ppsspp (GPL)
//
// =============================================================================

#pragma once

#include "iaudio_core.h"
#include <vector>
#include <array>
#include <functional>
#include <cstring>
#include <cmath>

// ============================================================================
// Audio Constants
// ============================================================================

namespace Pm32AudioRegs {
    // Channel registers (stride 0x10 per channel)
    constexpr uint32_t CH_VOLUME_L     = 0x00;
    constexpr uint32_t CH_VOLUME_R     = 0x04;
    constexpr uint32_t CH_SRC_ADDR     = 0x08;
    constexpr uint32_t CH_ADPCM_PARAM  = 0x0C;

    // Global registers
    constexpr uint32_t GLOBAL_VOLUME_L = 0x000;
    constexpr uint32_t GLOBAL_VOLUME_R = 0x004;
    constexpr uint32_t OUTPUT_VOLUME_L = 0x008;
    constexpr uint32_t OUTPUT_VOLUME_R = 0x00C;
    constexpr uint32_t REVERB_VOLUME_L = 0x010;
    constexpr uint32_t REVERB_VOLUME_R = 0x014;
    constexpr uint32_t REVERB_DELAY    = 0x018;
    constexpr uint32_t REVERB_CTRL     = 0x01C;
    constexpr uint32_t STATUS          = 0x020;
    constexpr uint32_t ENABLE          = 0x024;
    constexpr uint32_t IRQ_ADDR        = 0x028;
    constexpr uint32_t IRQ_ENABLE      = 0x02C;
}

// ============================================================================
// ADPCM Voice State
// ============================================================================

struct Pm32Voice {
    bool active = false;
    uint32_t src_addr = 0;       // Source address in RAM
    uint32_t src_offset = 0;     // Current read offset
    uint32_t loop_addr = 0;      // Loop start address
    uint32_t end_addr = 0;       // End address
    bool looping = false;
    bool ended = false;

    float volume_l = 0.0f;
    float volume_r = 0.0f;

    // ADPCM decoder state
    int32_t sample_history[2] = {};
    int32_t predictor = 0;
    int32_t scale = 0;
    int32_t adpcm_index = 0;

    // Sample position
    uint32_t sample_pos = 0;     // Fixed-point position
    uint32_t sample_rate = 44100;
    uint32_t samples_remaining = 0;
};

// ============================================================================
// Pm32Audio
// =============================================================================

class Pm32Audio : public IAudioCore {
public:
    Pm32Audio() = default;
    ~Pm32Audio() override = default;

    // ----- IAudioCore: Lifecycle -----
    bool init() override { initialized_ = true; return true; }
    void shutdown() override { initialized_ = false; }
    void reset() override;

    // ----- IAudioCore: Register Access -----
    int get_reg_count() const override { return 512; }
    uint32_t read_reg(uint32_t addr) override;
    void write_reg(uint32_t addr, uint32_t value) override;

    // ----- IAudioCore: Sample Output -----
    uint32_t get_sample_rate() const override { return Pm32Audio::SAMPLE_RATE; }
    uint32_t get_channels() const override { return 2; }
    uint32_t get_sample_count() const override { return sample_count_; }
    const int16_t* get_samples(uint32_t* count) override;

    // ----- IAudioCore: State -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;

    // ----- Pm32Audio-specific -----
    void step(uint32_t cycles);
    void set_memory_callback(std::function<uint8_t(uint32_t)> read_cb) { mem_read_ = read_cb; }
    void set_irq_callback(std::function<void(uint32_t)> irq_cb) { irq_cb_ = irq_cb; }

    static constexpr uint32_t SAMPLE_RATE = 44100;
    static constexpr uint32_t MAX_VOICES = 32;
    static constexpr uint32_t BUFFER_SIZE = 4096;

private:
    bool initialized_ = false;
    uint32_t sample_count_ = 0;
    uint32_t cycle_accum_ = 0;

    // Voices
    std::array<Pm32Voice, MAX_VOICES> voices_ = {};

    // Global state
    float global_vol_l_ = 1.0f;
    float global_vol_r_ = 1.0f;
    float output_vol_l_ = 1.0f;
    float output_vol_r_ = 1.0f;
    float reverb_vol_l_ = 0.0f;
    float reverb_vol_r_ = 0.0f;
    uint32_t enable_mask_ = 0;

    // Output buffer (stereo interleaved)
    std::array<int16_t, BUFFER_SIZE * 2> output_buffer_ = {};
    uint32_t buffer_read_pos_ = 0;
    uint32_t buffer_write_pos_ = 0;

    // Callbacks
    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t)> irq_cb_;

    // ADPCM decode table (scale factors)
    static constexpr int32_t adpcm_scale_table[16] = {
        1, 3, 5, 7, 9, 11, 13, 15,
        -1, -3, -5, -7, -9, -11, -13, -15
    };

    static constexpr int32_t adpcm_coef_table[5][2] = {
        {0, 0},
        {60, 0},
        {115, -52},
        {98, -55},
        {122, -60}
    };

    void decode_adpcm_sample(Pm32Voice& voice);
    void mix_voice(Pm32Voice& voice, int16_t* left, int16_t* right);
    void generate_samples(uint32_t count);
};

// ============================================================================
// Inline Implementation
// ============================================================================

inline void Pm32Audio::reset() {
    for (auto& v : voices_) v = Pm32Voice{};
    output_buffer_.fill(0);
    sample_count_ = 0;
    cycle_accum_ = 0;
    buffer_read_pos_ = 0;
    buffer_write_pos_ = 0;
    global_vol_l_ = 1.0f;
    global_vol_r_ = 1.0f;
    enable_mask_ = 0;
}

inline uint32_t Pm32Audio::read_reg(uint32_t addr) {
    if (addr == Pm32AudioRegs::STATUS) return 0;
    if (addr == Pm32AudioRegs::ENABLE) return enable_mask_;
    return 0;
}

inline void Pm32Audio::write_reg(uint32_t addr, uint32_t value) {
    // Determine if this is a channel register or global
    if (addr < Pm32AudioRegs::GLOBAL_VOLUME_L) {
        int ch = addr / 0x10;
        int reg = addr % 0x10;
        if (ch >= 0 && ch < MAX_VOICES) {
            switch (reg) {
                case Pm32AudioRegs::CH_VOLUME_L:
                    voices_[ch].volume_l = (value & 0xFFFF) / 65535.0f;
                    break;
                case Pm32AudioRegs::CH_VOLUME_R:
                    voices_[ch].volume_r = (value & 0xFFFF) / 65535.0f;
                    break;
                case Pm32AudioRegs::CH_SRC_ADDR:
                    voices_[ch].src_addr = value;
                    voices_[ch].active = true;
                    voices_[ch].ended = false;
                    voices_[ch].src_offset = 0;
                    break;
                case Pm32AudioRegs::CH_ADPCM_PARAM:
                    voices_[ch].loop_addr = (value >> 8) & 0xFFFFFF;
                    voices_[ch].looping = (value & 0x01) != 0;
                    break;
            }
        }
    } else {
        switch (addr) {
            case Pm32AudioRegs::GLOBAL_VOLUME_L: global_vol_l_ = (value & 0xFFFF) / 65535.0f; break;
            case Pm32AudioRegs::GLOBAL_VOLUME_R: global_vol_r_ = (value & 0xFFFF) / 65535.0f; break;
            case Pm32AudioRegs::OUTPUT_VOLUME_L: output_vol_l_ = (value & 0xFFFF) / 65535.0f; break;
            case Pm32AudioRegs::OUTPUT_VOLUME_R: output_vol_r_ = (value & 0xFFFF) / 65535.0f; break;
            case Pm32AudioRegs::ENABLE: enable_mask_ = value; break;
        }
    }
}

inline void Pm32Audio::decode_adpcm_sample(Pm32Voice& voice) {
    if (!mem_read_ || voice.ended) return;

    // Read ADPCM header (8 bytes per block)
    uint8_t hdr = mem_read_(voice.src_addr + voice.src_offset);
    voice.predictor = (hdr >> 4) & 0x0F;
    voice.scale = 1 << (hdr & 0x0F);
    voice.src_offset++;

    // Decode 28 samples from 14 bytes
    for (int i = 0; i < 28; i++) {
        uint8_t byte;
        if (i % 2 == 0) {
            byte = mem_read_(voice.src_addr + voice.src_offset);
            voice.adpcm_index = (byte >> 4) & 0x0F;
        } else {
            byte = mem_read_(voice.src_addr + voice.src_offset);
            voice.adpcm_index = byte & 0x0F;
            voice.src_offset++;
        }

        // Sign-extend 4-bit sample
        int32_t sample = voice.adpcm_index;
        if (sample & 0x08) sample -= 16;

        // Scale
        sample *= voice.scale;

        // Predict
        int32_t predicted = 0;
        if (voice.predictor < 5) {
            predicted = (adpcm_coef_table[voice.predictor][0] * voice.sample_history[0] +
                        adpcm_coef_table[voice.predictor][1] * voice.sample_history[1]) >> 6;
        }

        int32_t final_sample = sample + predicted;
        // Clamp
        if (final_sample > 32767) final_sample = 32767;
        if (final_sample < -32768) final_sample = -32768;

        voice.sample_history[1] = voice.sample_history[0];
        voice.sample_history[0] = final_sample;
    }

    // Check end / loop
    if (voice.src_offset >= voice.end_addr - voice.src_addr) {
        if (voice.looping) {
            voice.src_offset = voice.loop_addr - voice.src_addr;
        } else {
            voice.ended = true;
            voice.active = false;
        }
    }
}

inline void Pm32Audio::mix_voice(Pm32Voice& voice, int16_t* left, int16_t* right) {
    if (!voice.active || voice.ended) return;

    // Get current sample (simplified — uses last decoded sample)
    int16_t sample = (int16_t)voice.sample_history[0];

    *left = (int16_t)(sample * voice.volume_l * global_vol_l_);
    *right = (int16_t)(sample * voice.volume_r * global_vol_r_);
}

inline void Pm32Audio::generate_samples(uint32_t count) {
    for (uint32_t i = 0; i < count; i++) {
        int32_t mix_l = 0, mix_r = 0;

        for (auto& voice : voices_) {
            if (voice.active && !voice.ended) {
                int16_t l = 0, r = 0;
                mix_voice(voice, &l, &r);
                mix_l += l;
                mix_r += r;
            }
        }

        // Clamp
        if (mix_l > 32767) mix_l = 32767;
        if (mix_l < -32768) mix_l = -32768;
        if (mix_r > 32767) mix_r = 32767;
        if (mix_r < -32768) mix_r = -32768;

        output_buffer_[buffer_write_pos_] = (int16_t)mix_l;
        output_buffer_[buffer_write_pos_ + 1] = (int16_t)mix_r;
        buffer_write_pos_ = (buffer_write_pos_ + 2) % output_buffer_.size();
    }
    sample_count_ += count;
}

inline void Pm32Audio::step(uint32_t cycles) {
    if (!initialized_) return;

    // Convert CPU cycles to audio samples
    // CPU at 333MHz, audio at 44100Hz
    // samples = cycles * 44100 / 333000000
    cycle_accum_ += cycles;
    uint32_t samples_to_gen = (cycle_accum_ * SAMPLE_RATE) / 333000000;
    if (samples_to_gen > 0) {
        cycle_accum_ -= (samples_to_gen * 333000000) / SAMPLE_RATE;
        generate_samples(samples_to_gen);
    }
}

inline const int16_t* Pm32Audio::get_samples(uint32_t* count) {
    uint32_t available = (buffer_write_pos_ - buffer_read_pos_ + output_buffer_.size()) % output_buffer_.size();
    available /= 2;  // Stereo pairs
    if (count) *count = available;
    if (available == 0) return nullptr;
    return &output_buffer_[buffer_read_pos_];
}

inline std::vector<uint8_t> Pm32Audio::save_state() const {
    std::vector<uint8_t> state;
    for (const auto& v : voices_) {
        state.insert(state.end(), (const uint8_t*)&v, (const uint8_t*)&v + sizeof(v));
    }
    state.insert(state.end(), output_buffer_.begin(), output_buffer_.end());
    return state;
}

inline void Pm32Audio::load_state(const std::vector<uint8_t>& state) {
    if (state.size() < voices_.size() * sizeof(Pm32Voice)) return;
    size_t off = 0;
    for (auto& v : voices_) {
        std::memcpy(&v, state.data() + off, sizeof(v));
        off += sizeof(v);
    }
}

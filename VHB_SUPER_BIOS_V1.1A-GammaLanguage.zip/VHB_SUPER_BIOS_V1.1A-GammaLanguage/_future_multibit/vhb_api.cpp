// =============================================================================
// vhb_api.cpp — Unified Developer API Implementation
//
// =============================================================================

#include "vhb_api.h"
#include "cpu_factory.cpp"  // create_cpu_core, detect_arch_from_media
#include <cstdio>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>

// GPU/Audio/Media includes
#include "gpu/gpu_tile8_ppu.h"
#include "gpu/gpu_pm32.h"
#include "audio/audio_tile8_apu.h"
#include "audio/audio_pm32.h"
#include "media/media_ines.h"
#include "media/media_umd.h"

// ============================================================================
// Constructor / Destructor
// ============================================================================

VhbAPI::VhbAPI() = default;
VhbAPI::~VhbAPI() { shutdown(); }

// ============================================================================
// Target Detection
// ============================================================================

ArchID VhbAPI::detect_arch_from_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) return ArchID::Unknown;
    uint8_t header[0x8040] = {};
    f.read((char*)header, sizeof(header));
    size_t len = f.gcount();
    return detect_arch_from_media(header, len);
}

TargetSystem VhbAPI::detect_target_from_file(const std::string& path) {
    ArchID arch = detect_arch_from_file(path);
    switch (arch) {
        case ArchID::M6502:      return TargetSystem::Tile8;
        case ArchID::LR35902:    return TargetSystem::Handheld8;
        case ArchID::Z80:        return TargetSystem::Tile8Z;
        case ArchID::W65C816:    return TargetSystem::Tile16;
        case ArchID::MC68000:    return TargetSystem::CD16;
        case ArchID::ARM7TDMI:   return TargetSystem::Handheld32;
        case ArchID::SH2:        return TargetSystem::CD32X;
        case ArchID::MipsR3000A: return TargetSystem::CD24;
        case ArchID::MipsR4000:  return TargetSystem::PortableMedia32;
        case ArchID::MipsR4300:  return TargetSystem::Cart64;
        default:                 return TargetSystem::Unknown;
    }
}

std::vector<TargetSystem> VhbAPI::get_supported_targets() {
    return {
        TargetSystem::Tile8,
        TargetSystem::Tile16,
        TargetSystem::CD16,
        TargetSystem::Handheld32,
        TargetSystem::CD32X,
        TargetSystem::CD24,
        TargetSystem::PortableMedia32,
        TargetSystem::Cart64,
    };
}

std::string VhbAPI::get_target_name(TargetSystem sys) {
    switch (sys) {
        case TargetSystem::Tile8:           return "Tile-8";
        case TargetSystem::Handheld8:       return "Handheld-8";
        case TargetSystem::Tile8Z:          return "Tile-8Z";
        case TargetSystem::Tile16:          return "Tile-16";
        case TargetSystem::CD16:            return "CD-16";
        case TargetSystem::Handheld32:      return "Handheld-32";
        case TargetSystem::CD32X:           return "CD-32X";
        case TargetSystem::CD24:            return "CD-24/CD-32";
        case TargetSystem::PortableMedia32: return "Portable-Media-32";
        case TargetSystem::Cart64:          return "Cart-64";
        default:                            return "Unknown";
    }
}

// ============================================================================
// Initialization
// ============================================================================

bool VhbAPI::initialize(const TargetConfig& config) {
    config_ = config;

    // Detect architecture if not specified
    if (config_.system == TargetSystem::Unknown && !config_.media_path.empty()) {
        config_.system = detect_target_from_file(config_.media_path);
    }

    if (config_.system == TargetSystem::Unknown) {
        fprintf(stderr, "[VHB] Cannot determine target system\n");
        return false;
    }

    // Setup memory
    if (!setup_memory_for_target(config_.system)) {
        fprintf(stderr, "[VHB] Failed to setup memory\n");
        return false;
    }

    // Create CPU
    if (!create_cpu_for_target(config_.system)) {
        fprintf(stderr, "[VHB] Failed to create CPU\n");
        return false;
    }

    // Create GPU
    if (config_.enable_gpu) {
        create_gpu_for_target(config_.system);
    }

    // Create Audio
    if (config_.enable_audio) {
        create_audio_for_target(config_.system);
    }

    // Load media
    if (!config_.media_path.empty()) {
        create_media_for_file(config_.media_path);
    }

    // Reset CPU
    if (cpu_) cpu_->reset();

    fprintf(stderr, "[VHB] Initialized: %s (arch=%d)\n",
            get_target_name(config_.system).c_str(), (int)arch_);
    return true;
}

void VhbAPI::shutdown() {
    config_.running = false;
    config_.paused = false;
    cpu_.reset();
    gpu_.reset();
    audio_.reset();
    media_.reset();
    umm_.reset();
    breakpoints_.clear();
    watchpoints_.clear();
    trace_entries_.clear();
    tracing_ = false;
}

// ============================================================================
// Execution Control
// ============================================================================

bool VhbAPI::run() {
    if (!cpu_) return false;
    config_.running = true;
    config_.paused = false;

    uint64_t max = config_.max_instructions;
    if (max > 0) {
        cpu_->run(max);
    } else {
        cpu_->run(UINT64_MAX);
    }
    config_.running = false;
    return true;
}

void VhbAPI::pause() {
    config_.paused = true;
}

void VhbAPI::resume() {
    config_.paused = false;
}

void VhbAPI::stop() {
    config_.running = false;
    config_.paused = false;
    if (cpu_) cpu_->halt();
}

bool VhbAPI::step_one() {
    if (!cpu_) return false;
    return cpu_->step() == 0;
}

bool VhbAPI::step_n(uint64_t count) {
    if (!cpu_) return false;
    for (uint64_t i = 0; i < count; i++) {
        if (cpu_->step() != 0) return false;

        // Check breakpoints
        if (check_breakpoints()) {
            config_.paused = true;
            return false;
        }

        // Telemetry callback
        if (telemetry_cb_ && (cpu_->get_instruction_count() - last_telemetry_) >= telemetry_interval_) {
            last_telemetry_ = cpu_->get_instruction_count();
            telemetry_cb_(get_telemetry());
        }

        // Trace
        if (tracing_) {
            uint64_t ic = cpu_->get_instruction_count();
            if (ic >= trace_start_ && (trace_end_ == 0 || ic <= trace_end_)) {
                TraceEntry e;
                e.instruction_count = ic;
                e.pc = cpu_->get_pc();
                e.disasm = cpu_->disasm_at(e.pc);
                for (int r = 0; r < 16 && r < cpu_->get_reg_count(); r++) {
                    e.regs[r] = cpu_->get_reg(r);
                }
                trace_entries_.push_back(e);
            }
        }
    }
    return true;
}

void VhbAPI::run_for_frames(uint32_t frames) {
    if (!cpu_) return;
    uint64_t instructions_per_frame = cpu_->get_clock_hz() / config_.target_fps;
    step_n(instructions_per_frame * frames);
}

void VhbAPI::run_for_instructions(uint64_t count) {
    step_n(count);
}

// ============================================================================
// Telemetry
// ============================================================================

TelemetryData VhbAPI::get_telemetry() const {
    TelemetryData t;
    if (cpu_) {
        t.cycle_count = cpu_->get_cycle_count();
        t.instruction_count = cpu_->get_instruction_count();
        t.pc = cpu_->get_pc();
        t.sp = cpu_->get_sp();
        t.halted = cpu_->is_halted();
        t.arch = cpu_->get_arch_id();
    }
    if (gpu_) {
        t.frame_count = gpu_->get_frame_count();
        t.scanline = gpu_->get_scanline();
        t.vblank = gpu_->is_vblank();
    }
    t.target_name = get_target_name(config_.system);
    return t;
}

// ============================================================================
// Breakpoints
// ============================================================================

int VhbAPI::add_breakpoint(uint32_t address, const std::string& label) {
    int id = next_bp_id_++;
    Breakpoint bp;
    bp.address = address;
    bp.label = label;
    breakpoints_[id] = bp;
    return id;
}

bool VhbAPI::remove_breakpoint(int id) {
    return breakpoints_.erase(id) > 0;
}

bool VhbAPI::remove_breakpoint_at(uint32_t address) {
    for (auto it = breakpoints_.begin(); it != breakpoints_.end(); ++it) {
        if (it->second.address == address) {
            breakpoints_.erase(it);
            return true;
        }
    }
    return false;
}

void VhbAPI::clear_breakpoints() {
    breakpoints_.clear();
}

std::vector<Breakpoint> VhbAPI::get_breakpoints() const {
    std::vector<Breakpoint> result;
    for (const auto& [id, bp] : breakpoints_) {
        result.push_back(bp);
    }
    return result;
}

bool VhbAPI::check_breakpoints() {
    if (!cpu_ || breakpoints_.empty()) return false;
    uint32_t pc = cpu_->get_pc();
    for (auto& [id, bp] : breakpoints_) {
        if (bp.enabled && bp.address == pc) {
            bp.hit_count++;
            return true;
        }
    }
    return false;
}

// ============================================================================
// Watchpoints
// ============================================================================

int VhbAPI::add_watchpoint(uint32_t address, uint32_t size, bool read, bool write, const std::string& label) {
    int id = next_wp_id_++;
    Watchpoint wp;
    wp.address = address;
    wp.size = size;
    wp.read = read;
    wp.write = write;
    wp.label = label;
    watchpoints_[id] = wp;
    return id;
}

bool VhbAPI::remove_watchpoint(int id) {
    return watchpoints_.erase(id) > 0;
}

void VhbAPI::clear_watchpoints() {
    watchpoints_.clear();
}

std::vector<Watchpoint> VhbAPI::get_watchpoints() const {
    std::vector<Watchpoint> result;
    for (const auto& [id, wp] : watchpoints_) {
        result.push_back(wp);
    }
    return result;
}

// ============================================================================
// Trace
// ============================================================================

void VhbAPI::start_trace(const std::string& output_path, uint64_t start_instr, uint64_t end_instr) {
    tracing_ = true;
    trace_path_ = output_path;
    trace_start_ = start_instr;
    trace_end_ = end_instr;
    trace_entries_.clear();
}

void VhbAPI::stop_trace() {
    if (!tracing_) return;
    tracing_ = false;

    // Write trace to file
    if (!trace_path_.empty()) {
        std::ofstream f(trace_path_);
        if (f) {
            for (const auto& e : trace_entries_) {
                f << e.disasm << "\n";
            }
        }
    }
}

void VhbAPI::clear_trace() {
    trace_entries_.clear();
}

// ============================================================================
// Save State
// ============================================================================

bool VhbAPI::save_state_to_file(const std::string& path) {
    if (!cpu_) return false;
    auto state = cpu_->save_state();
    std::ofstream f(path, std::ios::binary);
    if (!f) return false;
    f.write((const char*)state.data(), state.size());
    return true;
}

bool VhbAPI::load_state_from_file(const std::string& path) {
    if (!cpu_) return false;
    std::ifstream f(path, std::ios::binary);
    if (!f) return false;
    std::vector<uint8_t> state((std::istreambuf_iterator<char>(f)),
                                std::istreambuf_iterator<char>());
    cpu_->load_state(state);
    return true;
}

// ============================================================================
// Disassembly
// ============================================================================

std::string VhbAPI::disasm_current() {
    if (!cpu_) return "No CPU";
    return cpu_->disasm_at(cpu_->get_pc());
}

std::string VhbAPI::disasm_range(uint32_t start, uint32_t count) {
    if (!cpu_) return "No CPU";
    std::ostringstream oss;
    uint32_t addr = start;
    for (uint32_t i = 0; i < count; i++) {
        int bytes = 0;
        std::string line = cpu_->disasm_at(addr, &bytes);
        oss << line << "\n";
        if (bytes <= 0) bytes = 4;  // Default to 4 for 32-bit, 2 for 16-bit
        addr += bytes;
    }
    return oss.str();
}

// ============================================================================
// Register Dump
// ============================================================================

std::string VhbAPI::dump_registers() {
    if (!cpu_) return "No CPU";
    std::ostringstream oss;
    oss << std::uppercase << std::hex << std::setfill('0');
    int count = cpu_->get_reg_count();
    for (int i = 0; i < count; i++) {
        oss << std::setw(6) << cpu_->get_reg_name(i) << ": "
            << std::setw(8) << cpu_->get_reg(i);
        if ((i + 1) % 4 == 0) oss << "\n";
        else oss << "  ";
    }
    if (count % 4 != 0) oss << "\n";
    return oss.str();
}

// ============================================================================
// Memory Dump
// ============================================================================

std::string VhbAPI::dump_memory(uint32_t addr, uint32_t size) {
    std::ostringstream oss;
    oss << std::hex << std::setfill('0');
    for (uint32_t i = 0; i < size; i += 16) {
        oss << std::setw(8) << (addr + i) << ": ";
        for (uint32_t j = 0; j < 16 && (i + j) < size; j++) {
            uint8_t v = cpu_ ? cpu_->read8(addr + i + j) : 0;
            oss << std::setw(2) << (int)v << " ";
        }
        oss << "\n";
    }
    return oss.str();
}

// ============================================================================
// Internal: Create components for target
// ============================================================================

bool VhbAPI::create_cpu_for_target(TargetSystem sys) {
    switch (sys) {
        case TargetSystem::Tile8:           arch_ = ArchID::M6502; break;
        case TargetSystem::Tile16:          arch_ = ArchID::W65C816; break;
        case TargetSystem::CD16:            arch_ = ArchID::MC68000; break;
        case TargetSystem::Handheld32:      arch_ = ArchID::ARM7TDMI; break;
        case TargetSystem::CD32X:           arch_ = ArchID::SH2; break;
        case TargetSystem::CD24:            arch_ = ArchID::MipsR3000A; break;
        case TargetSystem::PortableMedia32: arch_ = ArchID::MipsR4000; break;
        case TargetSystem::Cart64:          arch_ = ArchID::MipsR4300; break;
        default: return false;
    }
    cpu_.reset(create_cpu_core(arch_));
    return cpu_ != nullptr;
}

bool VhbAPI::create_gpu_for_target(TargetSystem sys) {
    switch (sys) {
        case TargetSystem::Tile8:
            gpu_ = std::make_unique<Tile8Ppu>();
            break;
        case TargetSystem::PortableMedia32:
            gpu_ = std::make_unique<Pm32Gpu>();
            break;
        default:
            // GPU not yet implemented for this target
            break;
    }
    if (gpu_) gpu_->init();
    return gpu_ != nullptr;
}

bool VhbAPI::create_audio_for_target(TargetSystem sys) {
    switch (sys) {
        case TargetSystem::Tile8:
            audio_ = std::make_unique<Tile8Apu>();
            break;
        case TargetSystem::PortableMedia32:
            audio_ = std::make_unique<Pm32Audio>();
            break;
        default:
            break;
    }
    if (audio_) audio_->init();
    return audio_ != nullptr;
}

bool VhbAPI::create_media_for_file(const std::string& path) {
    // Detect format from extension
    size_t ext_pos = path.find_last_of('.');
    std::string ext;
    if (ext_pos != std::string::npos) {
        ext = path.substr(ext_pos + 1);
        std::transform(ext.begin(), ext.end(), ext.begin(), ::tolower);
    }

    if (ext == "nes") {
        auto m = std::make_unique<INesMedia>();
        if (m->load(path)) {
            media_ = std::move(m);
            return true;
        }
    } else if (ext == "iso" || ext == "cso") {
        auto m = std::make_unique<UmdMedia>();
        if (m->load(path)) {
            media_ = std::move(m);
            return true;
        }
    }
    // Other formats pending
    return false;
}

bool VhbAPI::setup_memory_for_target(TargetSystem sys) {
    umm_ = std::make_unique<UnifiedMemoryManager>();
    MemoryProfile profile;

    switch (sys) {
        case TargetSystem::Tile8:
            profile = MemoryProfile::Tile8;
            break;
        case TargetSystem::Tile16:
            profile = MemoryProfile::Tile16;
            break;
        case TargetSystem::CD16:
            profile = MemoryProfile::CD16;
            break;
        case TargetSystem::Handheld32:
            profile = MemoryProfile::Handheld32;
            break;
        case TargetSystem::CD32X:
            profile = MemoryProfile::CD32X;
            break;
        case TargetSystem::CD24:
            profile = MemoryProfile::CD24;
            break;
        case TargetSystem::PortableMedia32:
            profile = MemoryProfile::PortableMedia32;
            break;
        case TargetSystem::Cart64:
            profile = MemoryProfile::Cart64;
            break;
        default:
            return false;
    }

    umm_->set_profile(profile);
    return true;
}

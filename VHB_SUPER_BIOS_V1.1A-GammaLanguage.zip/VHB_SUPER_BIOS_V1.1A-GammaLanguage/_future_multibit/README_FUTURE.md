# Future Multi-Bit Platform (Quarantined)

**Date:** Aug 3, 2026
**Decision:** D-A from `SURGICAL_COMPLETION_VHB_CYBERGRIME_Aug3_2026.md`

These modules were quarantined from the VHB v1.0 scope per Mandate M6 (dead code is deleted or quarantined) and M7 (one active path — DQ4 needs PSX only).

## What's Here

| Module | Description | Status |
|--------|-------------|--------|
| `cpu/` | 8 CPU cores (ARM7, M6502, MC68000, R4000, R4300, SH2, W65C816) + factory | Never linked as a working whole |
| `gpu/` | GPU interfaces for PM32 and Tile8 | Headers only, no implementation |
| `audio/` | Audio interfaces for PM32 and Tile8 | Headers only, no implementation |
| `media/` | Media interfaces (iNES, UMD) | Headers only, no implementation |
| `memory/` | UMM (Unified Memory Manager) | Compiles but unwired from PSX path |
| `pm32/` | PlayStation Media 32 platform config + test runner | Test runner stub only |
| `tile8/` | Tile8 platform config + test runner | Test runner stub only |
| `vhb_api.cpp/.h` | Unified multi-target API | 100+ compile errors (enum drift, missing interfaces) |
| `vhb_closed_loop.py` | Multi-target closed-loop runner | 5/7 targets had `test_runner: None` |

## Why Quarantined

- `vhb_api.cpp` had 100+ compile errors: `TargetSystem::CD16/CD32X/CD24/Cart64/PortableMedia32` undeclared, `media_umd.h` mismatches, `MemoryProfile` missing 8 members, `IGpuCore/IAudioCore::init` doesn't exist
- `cpu_w65c816.cpp` was broken mid-refactor (header syntax errors, missing `op_brk` member)
- The enum/interface drift showed this was never a working whole — it was aspirational architecture
- VHB v1.0 ships as **PSX clean-room BIOS only**

## Milestone

Multi-bit platform support is a **future milestone**, not a present feature. Do not reference these modules from the PSX-only build path.

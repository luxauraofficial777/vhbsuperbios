// =============================================================================
// vhb_api.h — Unified Developer API for Multi-Bit-Depth Platform
//
// Provides a single API for loading, running, and debugging any supported
// target system. Abstracts CPU, GPU, audio, media, and memory management.
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include "igpu_core.h"
#include "iaudio_core.h"
#include "imedia.h"
#include "umm.h"
#include "vhb_core.h"
#include <memory>
#include <string>
#include <vector>
#include <functional>
#include <unordered_map>

// ============================================================================
// Target System Configuration
// ============================================================================

struct TargetConfig {
    TargetSystem system = TargetSystem::Unknown;
    std::string media_path;
    std::string save_path;
    std::string bios_path;

    // Execution settings
    uint64_t max_instructions = 0;       // 0 = unlimited
    uint32_t target_fps = 60;
    bool enable_audio = true;
    bool enable_gpu = true;
    bool headless = false;

    // Debug settings
    bool enable_trace = false;
    bool enable_breakpoints = false;
    std::string trace_output_path;
    uint32_t trace_start_instruction = 0;
    uint32_t trace_end_instruction = 0;

    // State
    bool running = false;
    bool paused = false;
};

// ============================================================================
// Debug API
// ============================================================================

struct Breakpoint {
    uint32_t address = 0;
    bool enabled = true;
    int hit_count = 0;
    std::string condition;  // Optional condition expression
    std::string label;
};

struct Watchpoint {
    uint32_t address = 0;
    uint32_t size = 4;       // 1, 2, 4 bytes
    bool read = true;
    bool write = true;
    uint32_t last_value = 0;
    std::string label;
};

struct TraceEntry {
    uint64_t instruction_count;
    uint32_t pc;
    uint32_t opcode;
    std::string disasm;
    uint32_t regs[16];
};

// ============================================================================
// Telemetry Callback
// ============================================================================

struct TelemetryData {
    uint64_t cycle_count = 0;
    uint64_t instruction_count = 0;
    uint32_t pc = 0;
    uint32_t sp = 0;
    bool halted = false;
    uint32_t frame_count = 0;
    uint32_t scanline = 0;
    bool vblank = false;
    ArchID arch = ArchID::Unknown;
    std::string target_name;
};

using TelemetryCallback = std::function<void(const TelemetryData&)>;

// ============================================================================
// VhbAPI — Unified Platform API
// ============================================================================

class VhbAPI {
public:
    VhbAPI();
    ~VhbAPI();

    // ----- Lifecycle -----
    bool initialize(const TargetConfig& config);
    void shutdown();

    // ----- Target Detection -----
    static ArchID detect_arch_from_file(const std::string& path);
    static TargetSystem detect_target_from_file(const std::string& path);
    static std::vector<TargetSystem> get_supported_targets();
    static std::string get_target_name(TargetSystem sys);

    // ----- Execution Control -----
    bool run();
    void pause();
    void resume();
    void stop();
    bool step_one();
    bool step_n(uint64_t count);
    void run_for_frames(uint32_t frames);
    void run_for_instructions(uint64_t count);

    // ----- State -----
    bool is_running() const { return config_.running; }
    bool is_paused() const { return config_.paused; }
    const TargetConfig& get_config() const { return config_; }
    TelemetryData get_telemetry() const;

    // ----- CPU Access -----
    ICpuCore* get_cpu() const { return cpu_.get(); }
    ArchID get_arch() const { return arch_; }

    // ----- GPU Access -----
    IGpuCore* get_gpu() const { return gpu_.get(); }

    // ----- Audio Access -----
    IAudioCore* get_audio() const { return audio_.get(); }

    // ----- Media Access -----
    IMedia* get_media() const { return media_.get(); }

    // ----- Memory Access -----
    UnifiedMemoryManager* get_memory() const { return umm_.get(); }

    // ----- Debug: Breakpoints -----
    int add_breakpoint(uint32_t address, const std::string& label = "");
    bool remove_breakpoint(int id);
    bool remove_breakpoint_at(uint32_t address);
    void clear_breakpoints();
    std::vector<Breakpoint> get_breakpoints() const;
    bool check_breakpoints();

    // ----- Debug: Watchpoints -----
    int add_watchpoint(uint32_t address, uint32_t size, bool read, bool write, const std::string& label = "");
    bool remove_watchpoint(int id);
    void clear_watchpoints();
    std::vector<Watchpoint> get_watchpoints() const;

    // ----- Debug: Trace -----
    void start_trace(const std::string& output_path, uint64_t start_instr = 0, uint64_t end_instr = 0);
    void stop_trace();
    bool is_tracing() const { return tracing_; }
    std::vector<TraceEntry> get_trace_entries() const { return trace_entries_; }
    void clear_trace();

    // ----- Save State -----
    bool save_state_to_file(const std::string& path);
    bool load_state_from_file(const std::string& path);

    // ----- Telemetry -----
    void set_telemetry_callback(TelemetryCallback cb) { telemetry_cb_ = cb; }
    void set_telemetry_interval(uint32_t instructions) { telemetry_interval_ = instructions; }

    // ----- Disassembly -----
    std::string disasm_current();
    std::string disasm_range(uint32_t start, uint32_t count);

    // ----- Register Dump -----
    std::string dump_registers();

    // ----- Memory Dump -----
    std::string dump_memory(uint32_t addr, uint32_t size);

private:
    TargetConfig config_;
    ArchID arch_ = ArchID::Unknown;

    std::unique_ptr<ICpuCore> cpu_;
    std::unique_ptr<IGpuCore> gpu_;
    std::unique_ptr<IAudioCore> audio_;
    std::unique_ptr<IMedia> media_;
    std::unique_ptr<UnifiedMemoryManager> umm_;

    // Debug state
    std::unordered_map<int, Breakpoint> breakpoints_;
    std::unordered_map<int, Watchpoint> watchpoints_;
    int next_bp_id_ = 1;
    int next_wp_id_ = 1;

    bool tracing_ = false;
    std::string trace_path_;
    uint64_t trace_start_ = 0;
    uint64_t trace_end_ = 0;
    std::vector<TraceEntry> trace_entries_;

    // Telemetry
    TelemetryCallback telemetry_cb_;
    uint32_t telemetry_interval_ = 100000;
    uint64_t last_telemetry_ = 0;

    // Internal helpers
    bool create_cpu_for_target(TargetSystem sys);
    bool create_gpu_for_target(TargetSystem sys);
    bool create_audio_for_target(TargetSystem sys);
    bool create_media_for_file(const std::string& path);
    bool setup_memory_for_target(TargetSystem sys);
};

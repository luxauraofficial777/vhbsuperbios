// =============================================================================
// cpu_arm7.cpp — ARM7TDMI CPU Core Implementation (Clean-Room)
//
// Reference: ARM7TDMI TRM, github.com/visualboyadvance-m/vba-m (GPL)
//
// =============================================================================

#include "cpu_arm7.h"
#include <cstdio>
#include <sstream>
#include <iomanip>

// ============================================================================
// Constructor / Reset
// ============================================================================

Arm7TDMICore::Arm7TDMICore() {
    gpr_.fill(0);
    fiq_regs_.fill(0);
    irq_regs_.fill(0);
    svc_regs_.fill(0);
    abt_regs_.fill(0);
    und_regs_.fill(0);
}

void Arm7TDMICore::reset() {
    gpr_.fill(0);
    fiq_regs_.fill(0);
    irq_regs_.fill(0);
    svc_regs_.fill(0);
    abt_regs_.fill(0);
    und_regs_.fill(0);
    cpsr_ = Arm7Mode::SUPERVISOR | Arm7CPSR::I | Arm7CPSR::F;
    spsr_fiq_ = spsr_irq_ = spsr_svc_ = spsr_abt_ = spsr_und_ = 0;
    halted_ = false;
    irq_pending_ = false;
    fiq_pending_ = false;
    cycle_count_ = 0;
    instruction_count_ = 0;
    gpr_[15] = 0x00000000;  // Reset vector
}

// ============================================================================
// Memory Access (little-endian)
// ============================================================================

uint8_t Arm7TDMICore::read8(uint32_t addr) {
    if (mem_read_) return mem_read_(addr);
    return 0;
}

uint16_t Arm7TDMICore::read16(uint32_t addr) {
    return read8(addr) | (uint16_t(read8(addr + 1)) << 8);
}

uint32_t Arm7TDMICore::read32(uint32_t addr) {
    return read8(addr) | (uint32_t(read8(addr+1)) << 8) |
           (uint32_t(read8(addr+2)) << 16) | (uint32_t(read8(addr+3)) << 24);
}

void Arm7TDMICore::write8(uint32_t addr, uint8_t value) {
    if (mem_write_) mem_write_(addr, value);
}

void Arm7TDMICore::write16(uint32_t addr, uint16_t value) {
    write8(addr, value & 0xFF);
    write8(addr + 1, value >> 8);
}

void Arm7TDMICore::write32(uint32_t addr, uint32_t value) {
    write8(addr, value & 0xFF);
    write8(addr+1, (value >> 8) & 0xFF);
    write8(addr+2, (value >> 16) & 0xFF);
    write8(addr+3, (value >> 24) & 0xFF);
}

// ============================================================================
// Register Access
// ============================================================================

const char* Arm7TDMICore::get_reg_name(int index) const {
    static const char* names[] = {
        "R0","R1","R2","R3","R4","R5","R6","R7",
        "R8","R9","R10","R11","R12","R13(SP)","R14(LR)","R15(PC)",
        "CPSR","SPSR"
    };
    if (index >= 0 && index < 18) return names[index];
    return "??";
}

uint32_t Arm7TDMICore::get_reg(int index) const {
    if (index < 16) return gpr_[index];
    if (index == ARM_CPSR) return cpsr_;
    if (index == ARM_SPSR) return get_spsr();
    return 0;
}

void Arm7TDMICore::set_reg(int index, uint32_t value) {
    if (index < 16) { gpr_[index] = value; return; }
    if (index == ARM_CPSR) { cpsr_ = value; return; }
    if (index == ARM_SPSR) { set_spsr(value); return; }
}

// ============================================================================
// Mode Switching
// ============================================================================

void Arm7TDMICore::switch_mode(uint32_t new_mode) {
    uint32_t old_mode = get_mode();
    if (old_mode == new_mode) return;

    // Save current banked registers
    switch (old_mode) {
        case Arm7Mode::FIQ:
            for (int i = 0; i < 7; i++) fiq_regs_[i] = gpr_[8 + i];
            break;
        case Arm7Mode::IRQ:
            irq_regs_[0] = gpr_[13]; irq_regs_[1] = gpr_[14];
            break;
        case Arm7Mode::SUPERVISOR:
            svc_regs_[0] = gpr_[13]; svc_regs_[1] = gpr_[14];
            break;
        case Arm7Mode::ABORT:
            abt_regs_[0] = gpr_[13]; abt_regs_[1] = gpr_[14];
            break;
        case Arm7Mode::UNDEFINED:
            und_regs_[0] = gpr_[13]; und_regs_[1] = gpr_[14];
            break;
    }

    // Restore banked registers for new mode
    switch (new_mode) {
        case Arm7Mode::FIQ:
            for (int i = 0; i < 7; i++) gpr_[8 + i] = fiq_regs_[i];
            break;
        case Arm7Mode::IRQ:
            gpr_[13] = irq_regs_[0]; gpr_[14] = irq_regs_[1];
            break;
        case Arm7Mode::SUPERVISOR:
            gpr_[13] = svc_regs_[0]; gpr_[14] = svc_regs_[1];
            break;
        case Arm7Mode::ABORT:
            gpr_[13] = abt_regs_[0]; gpr_[14] = abt_regs_[1];
            break;
        case Arm7Mode::UNDEFINED:
            gpr_[13] = und_regs_[0]; gpr_[14] = und_regs_[1];
            break;
    }

    cpsr_ = (cpsr_ & ~Arm7CPSR::M) | (new_mode & Arm7CPSR::M);
}

uint32_t Arm7TDMICore::get_spsr() const {
    switch (get_mode()) {
        case Arm7Mode::FIQ:        return spsr_fiq_;
        case Arm7Mode::IRQ:        return spsr_irq_;
        case Arm7Mode::SUPERVISOR: return spsr_svc_;
        case Arm7Mode::ABORT:      return spsr_abt_;
        case Arm7Mode::UNDEFINED:  return spsr_und_;
        default:                   return cpsr_;  // User/System has no SPSR
    }
}

void Arm7TDMICore::set_spsr(uint32_t value) {
    switch (get_mode()) {
        case Arm7Mode::FIQ:        spsr_fiq_ = value; break;
        case Arm7Mode::IRQ:        spsr_irq_ = value; break;
        case Arm7Mode::SUPERVISOR: spsr_svc_ = value; break;
        case Arm7Mode::ABORT:      spsr_abt_ = value; break;
        case Arm7Mode::UNDEFINED:  spsr_und_ = value; break;
        default: break;
    }
}

// ============================================================================
// Exception Handling
// ============================================================================

void Arm7TDMICore::raise_exception(uint32_t mode, uint32_t vector) {
    uint32_t old_cpsr = cpsr_;
    switch_mode(mode);
    set_spsr(old_cpsr);
    gpr_[14] = gpr_[15];  // LR = PC (address of next instruction)
    cpsr_ &= ~Arm7CPSR::T;  // Force ARM mode
    if (mode == Arm7Mode::FIQ) cpsr_ |= Arm7CPSR::F;  // Disable FIQ
    cpsr_ |= Arm7CPSR::I;  // Disable IRQ
    gpr_[15] = vector;
    cycle_count_ += 4;
}

void Arm7TDMICore::raise_interrupt(uint32_t vector) {
    (void)vector;
    irq_pending_ = true;
}

void Arm7TDMICore::trigger_exception(uint32_t cause, uint32_t epc) {
    (void)epc;
    if (cause == 0) raise_exception(Arm7Mode::IRQ, 0x18);
    else raise_exception(Arm7Mode::FIQ, 0x1C);
}

// ============================================================================
// Condition Codes
// ============================================================================

bool Arm7TDMICore::check_cond(uint32_t cond) const {
    bool n = (cpsr_ & Arm7CPSR::N) != 0;
    bool z = (cpsr_ & Arm7CPSR::Z) != 0;
    bool c = (cpsr_ & Arm7CPSR::C) != 0;
    bool v = (cpsr_ & Arm7CPSR::V) != 0;

    switch (cond) {
        case 0x0: return z;              // EQ
        case 0x1: return !z;             // NE
        case 0x2: return c;              // CS/HS
        case 0x3: return !c;             // CC/LO
        case 0x4: return n;              // MI
        case 0x5: return !n;             // PL
        case 0x6: return v;              // VS
        case 0x7: return !v;             // VC
        case 0x8: return c && !z;        // HI
        case 0x9: return !c || z;        // LS
        case 0xA: return n == v;         // GE
        case 0xB: return n != v;         // LT
        case 0xC: return !z && (n == v); // GT
        case 0xD: return z || (n != v);  // LE
        case 0xE: return true;           // AL (always)
        case 0xF: return false;          // NV (never)
    }
    return false;
}

// ============================================================================
// Barrel Shifter
// ============================================================================

uint32_t Arm7TDMICore::barrel_shift(uint32_t value, int shift_type, int amount, bool& carry) {
    carry = (cpsr_ & Arm7CPSR::C) != 0;

    switch (shift_type) {
        case 0: // LSL
            if (amount == 0) return value;
            if (amount >= 32) { carry = (amount == 32) ? (value & 1) != 0 : false; return 0; }
            carry = (value & (1 << (32 - amount))) != 0;
            return value << amount;
        case 1: // LSR
            if (amount == 0) amount = 32;
            if (amount >= 32) { carry = (amount == 32) ? (value & 0x80000000) != 0 : false; return 0; }
            carry = (value & (1 << (amount - 1))) != 0;
            return value >> amount;
        case 2: // ASR
            if (amount == 0) amount = 32;
            if (amount >= 32) { carry = (value & 0x80000000) != 0; return (value & 0x80000000) ? 0xFFFFFFFF : 0; }
            carry = (value & (1 << (amount - 1))) != 0;
            return (uint32_t)((int32_t)value >> amount);
        case 3: // ROR
            if (amount == 0) { // RRX
                carry = (value & 1) != 0;
                return (value >> 1) | (c ? 0x80000000 : 0);
            }
            amount &= 31;
            if (amount == 0) return value;
            carry = (value & (1 << (amount - 1))) != 0;
            return (value >> amount) | (value << (32 - amount));
    }
    return value;
}

// ============================================================================
// ARM Instruction Execution
// ============================================================================

void Arm7TDMICore::arm_data_processing(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0x0F;
    if (!check_cond(cond)) { gpr_[15] += 4; return; }

    uint32_t opcode = (instr >> 21) & 0x0F;
    int rd = (instr >> 12) & 0x0F;
    int rn = (instr >> 16) & 0x0F;
    bool s = (instr >> 20) & 0x01;
    bool immediate = (instr >> 25) & 0x01;

    uint32_t op1 = (rn == 15) ? (gpr_[15] + 8) : gpr_[rn];
    uint32_t op2;
    bool carry_out = (cpsr_ & Arm7CPSR::C) != 0;

    if (immediate) {
        uint32_t imm = instr & 0xFF;
        int rotate = ((instr >> 8) & 0x0F) * 2;
        op2 = (imm >> rotate) | (imm << (32 - rotate));
        if (rotate > 0) carry_out = (op2 & 0x80000000) != 0;
    } else {
        int rm = instr & 0x0F;
        int shift_type = (instr >> 5) & 0x03;
        int shift_amount;
        if ((instr >> 4) & 0x01) {
            int rs = (instr >> 8) & 0x0F;
            shift_amount = gpr_[rs] & 0xFF;
        } else {
            shift_amount = (instr >> 7) & 0x1F;
        }
        uint32_t val = (rm == 15) ? (gpr_[15] + 8) : gpr_[rm];
        op2 = barrel_shift(val, shift_type, shift_amount, carry_out);
    }

    uint32_t result = 0;
    bool arithmetic = false;

    switch (opcode) {
        case 0x0: result = op1 & op2; break;             // AND
        case 0x1: result = op1 ^ op2; break;             // EOR
        case 0x2: result = op1 - op2; arithmetic = true; break; // SUB
        case 0x3: result = op2 - op1; arithmetic = true; break; // RSB
        case 0x4: result = op1 + op2; arithmetic = true; break; // ADD
        case 0x5: result = op1 + op2 + ((cpsr_ & Arm7CPSR::C) ? 1 : 0); arithmetic = true; break; // ADC
        case 0x6: result = op1 - op2 - ((cpsr_ & Arm7CPSR::C) ? 1 : 0); arithmetic = true; break; // SBC
        case 0x7: result = op2 - op1 - ((cpsr_ & Arm7CPSR::C) ? 1 : 0); arithmetic = true; break; // RSC
        case 0x8: result = op1 & op2; break;             // TST
        case 0x9: result = op1 ^ op2; break;             // TEQ
        case 0xA: result = op1 - op2; arithmetic = true; break; // CMP
        case 0xB: result = op1 + op2; arithmetic = true; break; // CMN
        case 0xC: result = op1 | op2; break;             // ORR
        case 0xD: result = op2; break;                   // MOV
        case 0xE: result = op1 & ~op2; break;            // BIC
        case 0xF: result = ~op2; break;                  // MVN
    }

    // Write result (not for TST/TEQ/CMP/CMN)
    if (opcode < 0x08 || opcode >= 0x0C) {
        if (rd == 15) {
            // PC write — handle carefully
            gpr_[15] = result & ~1;
            if (result & 1) cpsr_ |= Arm7CPSR::T;
        } else {
            gpr_[rd] = result;
        }
    }

    // Update flags
    if (s && (rd != 15 || opcode >= 0x08)) {
        cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z | Arm7CPSR::C | Arm7CPSR::V);
        if (result == 0) cpsr_ |= Arm7CPSR::Z;
        if (result & 0x80000000) cpsr_ |= Arm7CPSR::N;
        if (carry_out) cpsr_ |= Arm7CPSR::C;
        if (arithmetic) {
            bool overflow;
            if (opcode == 0x02 || opcode == 0x06) // SUB/SBC
                overflow = ((op1 ^ op2) & (op1 ^ result) & 0x80000000) != 0;
            else // ADD/ADC/CMN
                overflow = (~(op1 ^ op2) & (op1 ^ result) & 0x80000000) != 0;
            if (overflow) cpsr_ |= Arm7CPSR::V;
        }
    }

    cycle_count_ += 1;
}

void Arm7TDMICore::arm_load_store(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0x0F;
    if (!check_cond(cond)) { gpr_[15] += 4; return; }

    int rd = (instr >> 12) & 0x0F;
    int rn = (instr >> 16) & 0x0F;
    bool load = (instr >> 20) & 0x01;
    bool byte = (instr >> 22) & 0x01;
    bool writeback = (instr >> 21) & 0x01;
    bool add = (instr >> 23) & 0x01;
    bool pre = (instr >> 24) & 0x01;
    bool immediate = !((instr >> 25) & 0x01);

    uint32_t base = gpr_[rn];
    uint32_t offset;

    if (immediate) {
        offset = instr & 0xFFF;
    } else {
        int rm = instr & 0x0F;
        int shift_type = (instr >> 5) & 0x03;
        int shift_amount = (instr >> 7) & 0x1F;
        bool carry;
        offset = barrel_shift(gpr_[rm], shift_type, shift_amount, carry);
    }

    uint32_t addr = base;
    if (pre) addr = add ? (base + offset) : (base - offset);

    if (load) {
        if (byte) gpr_[rd] = read8(addr);
        else gpr_[rd] = read32(addr);
        cycle_count_ += 3;
    } else {
        uint32_t val = (rd == 15) ? (gpr_[15] + 8) : gpr_[rd];
        if (byte) write8(addr, val & 0xFF);
        else write32(addr, val);
        cycle_count_ += 2;
    }

    if (writeback || !pre) {
        if (!pre) addr = add ? (base + offset) : (base - offset);
        if (rn != rd || !load) gpr_[rn] = addr;
    }
}

void Arm7TDMICore::arm_branch(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0x0F;
    if (!check_cond(cond)) { gpr_[15] += 4; return; }

    bool link = (instr >> 24) & 0x01;
    int32_t offset = (int32_t)(instr & 0x00FFFFFF);
    if (offset & 0x00800000) offset |= 0xFF000000;  // Sign-extend
    offset <<= 2;

    if (link) gpr_[14] = gpr_[15] + 4;  // LR = PC + 4
    gpr_[15] = gpr_[15] + 8 + offset;
    cycle_count_ += 3;
}

void Arm7TDMICore::arm_block_transfer(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0x0F;
    if (!check_cond(cond)) { gpr_[15] += 4; return; }

    int rn = (instr >> 16) & 0x0F;
    bool load = (instr >> 20) & 0x01;
    bool writeback = (instr >> 21) & 0x01;
    bool s_bit = (instr >> 22) & 0x01;
    bool add = (instr >> 23) & 0x01;
    bool pre = (instr >> 24) & 0x01;
    uint16_t reg_list = instr & 0xFFFF;

    if (reg_list == 0) {
        // Special case: empty list = transfer PC / 0x800
        cycle_count_ += 4;
        return;
    }

    int count = 0;
    for (int i = 0; i < 16; i++) if (reg_list & (1 << i)) count++;

    uint32_t addr = gpr_[rn];
    if (!add) addr -= count * 4;
    if (pre) addr += add ? 4 : -4;

    for (int i = 0; i < 16; i++) {
        if (reg_list & (1 << i)) {
            if (load) {
                gpr_[i] = read32(addr);
            } else {
                uint32_t val = (i == 15) ? (gpr_[15] + 8) : gpr_[i];
                write32(addr, val);
            }
            addr += add ? 4 : -4;
        }
    }

    if (writeback) {
        if (add) gpr_[rn] += count * 4;
        else gpr_[rn] -= count * 4;
    }

    cycle_count_ += count + 2;
}

void Arm7TDMICore::arm_multiply(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0x0F;
    if (!check_cond(cond)) { gpr_[15] += 4; return; }

    int rd = (instr >> 16) & 0x0F;
    int rn = (instr >> 12) & 0x0F;
    int rs = (instr >> 8) & 0x0F;
    int rm = instr & 0x0F;
    bool s = (instr >> 20) & 0x01;
    bool accumulate = (instr >> 21) & 0x01;

    uint64_t result = (uint64_t)(int32_t)gpr_[rm] * (uint64_t)(int32_t)gpr_[rs];
    if (accumulate) result += gpr_[rn];

    gpr_[rd] = (uint32_t)(result & 0xFFFFFFFF);

    if (s) {
        cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z);
        if (gpr_[rd] == 0) cpsr_ |= Arm7CPSR::Z;
        if (gpr_[rd] & 0x80000000) cpsr_ |= Arm7CPSR::N;
    }

    cycle_count_ += accumulate ? 2 : 1;
}

void Arm7TDMICore::arm_coprocessor(uint32_t instr) {
    // CP0-CP15 — not implemented (no coprocessors on basic ARM7TDMI)
    gpr_[15] += 4;
    cycle_count_ += 3;
}

void Arm7TDMICore::arm_swi(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0x0F;
    if (!check_cond(cond)) { gpr_[15] += 4; return; }
    raise_exception(Arm7Mode::SUPERVISOR, 0x08);
}

// ============================================================================
// ARM Instruction Decoder
// ============================================================================

void Arm7TDMICore::execute_arm(uint32_t instr) {
    uint32_t cond = (instr >> 28) & 0x0F;
    if (!check_cond(cond)) { gpr_[15] += 4; cycle_count_ += 1; return; }

    // Decode by bits 27-25
    uint32_t type = (instr >> 25) & 0x07;

    if ((instr & 0x0FC000F0) == 0x00000090 || (instr & 0x0F8000F0) == 0x00200090) {
        arm_multiply(instr);
    } else if ((instr & 0x0F000000) == 0x0F000000) {
        arm_swi(instr);
    } else if (type == 0x00 && (instr & 0x00000090) == 0x00000090) {
        // Block transfer or single transfer
        if ((instr >> 4) & 1) arm_coprocessor(instr);  // Not supported
        else arm_load_store(instr);
    } else if (type == 0x04 || type == 0x05) {
        arm_load_store(instr);
    } else if (type == 0x02 || type == 0x03) {
        if ((instr >> 4) & 0x01) arm_block_transfer(instr);
        else arm_load_store(instr);
    } else if (type == 0x06 || type == 0x07) {
        if ((instr >> 24) & 0x01) arm_branch(instr);
        else arm_coprocessor(instr);
    } else if (type == 0x01) {
        // Could be block transfer or data processing with register shift
        arm_data_processing(instr);
    } else {
        arm_data_processing(instr);
    }
}

// ============================================================================
// Thumb Instruction Execution (simplified key instructions)
// ============================================================================

void Arm7TDMICore::thumb_shift(uint16_t instr) {
    int op = (instr >> 11) & 0x03;
    int rd = (instr >> 0) & 0x07;
    int rs = (instr >> 3) & 0x07;
    int offset = (instr >> 6) & 0x1F;
    bool carry;
    uint32_t val = gpr_[rs];

    switch (op) {
        case 0: gpr_[rd] = barrel_shift(val, 0, offset, carry); break; // LSL
        case 1: gpr_[rd] = barrel_shift(val, 1, offset ? offset : 32, carry); break; // LSR
        case 2: gpr_[rd] = barrel_shift(val, 2, offset ? offset : 32, carry); break; // ASR
    }

    cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z | Arm7CPSR::C);
    if (gpr_[rd] == 0) cpsr_ |= Arm7CPSR::Z;
    if (gpr_[rd] & 0x80000000) cpsr_ |= Arm7CPSR::N;
    if (carry) cpsr_ |= Arm7CPSR::C;
    cycle_count_ += 1;
}

void Arm7TDMICore::thumb_add_sub(uint16_t instr) {
    int op = (instr >> 9) & 0x03;
    int rd = instr & 0x07;
    int rs = (instr >> 3) & 0x07;
    int rn_offset = (instr >> 6) & 0x07;

    uint32_t a = gpr_[rs];
    uint32_t b;
    uint32_t result;

    switch (op) {
        case 0: b = gpr_[rn_offset]; result = a + b; break; // ADD Rd, Rs, Rn
        case 1: b = gpr_[rn_offset]; result = a - b; break; // SUB Rd, Rs, Rn
        case 2: b = rn_offset; result = a + b; break;       // ADD Rd, Rs, #imm
        case 3: b = rn_offset; result = a - b; break;       // SUB Rd, Rs, #imm
    }

    gpr_[rd] = result;
    cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z | Arm7CPSR::C | Arm7CPSR::V);
    if (result == 0) cpsr_ |= Arm7CPSR::Z;
    if (result & 0x80000000) cpsr_ |= Arm7CPSR::N;
    if (op == 0 || op == 2) { // ADD
        if (result < a) cpsr_ |= Arm7CPSR::C;
        if (~(a ^ b) & (a ^ result) & 0x80000000) cpsr_ |= Arm7CPSR::V;
    } else { // SUB
        if (a >= b) cpsr_ |= Arm7CPSR::C;
        if ((a ^ b) & (a ^ result) & 0x80000000) cpsr_ |= Arm7CPSR::V;
    }
    cycle_count_ += 1;
}

void Arm7TDMICore::thumb_alu(uint16_t instr) {
    int op = (instr >> 6) & 0x0F;
    int rd = (instr >> 0) & 0x07;
    int rs = (instr >> 3) & 0x07;

    uint32_t a = gpr_[rd];
    uint32_t b = gpr_[rs];
    uint32_t result = 0;

    switch (op) {
        case 0x0: result = a & b; break;  // AND
        case 0x1: result = a ^ b; break;  // EOR
        case 0x2: result = a << (b & 0xFF); break;  // LSL
        case 0x3: result = a >> (b & 0xFF); break;  // LSR
        case 0x4: result = (uint32_t)((int32_t)a >> (b & 0xFF)); break; // ASR
        case 0x5: { bool c; result = barrel_shift(a, 3, b & 0xFF, c); break; } // ROR
        case 0x6: result = a & ~b; break;  // BIC
        case 0x7: result = ~b; break;      // MVN
        case 0x8: result = a * b; break;   // MUL
        case 0x9: { // NEG
            result = -b;
            break;
        }
        case 0xA: result = a + b; break;   // ADD
        case 0xB: result = a - b; break;   // SUB
        case 0xC: { // CMP
            uint32_t diff = a - b;
            cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z | Arm7CPSR::C | Arm7CPSR::V);
            if (diff == 0) cpsr_ |= Arm7CPSR::Z;
            if (diff & 0x80000000) cpsr_ |= Arm7CPSR::N;
            if (a >= b) cpsr_ |= Arm7CPSR::C;
            if ((a ^ b) & (a ^ diff) & 0x80000000) cpsr_ |= Arm7CPSR::V;
            cycle_count_ += 1;
            return;
        }
        case 0xD: { // CMN
            uint32_t sum = a + b;
            cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z | Arm7CPSR::C | Arm7CPSR::V);
            if (sum == 0) cpsr_ |= Arm7CPSR::Z;
            if (sum & 0x80000000) cpsr_ |= Arm7CPSR::N;
            if (sum < a) cpsr_ |= Arm7CPSR::C;
            if (~(a ^ b) & (a ^ sum) & 0x80000000) cpsr_ |= Arm7CPSR::V;
            cycle_count_ += 1;
            return;
        }
        case 0xE: result = a | b; break;   // ORR
        case 0xF: result = a & b; break;   // TST (AND for flags)
    }

    gpr_[rd] = result;
    if (op != 0x8) {  // MUL doesn't set flags in Thumb
        cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z);
        if (result == 0) cpsr_ |= Arm7CPSR::Z;
        if (result & 0x80000000) cpsr_ |= Arm7CPSR::N;
    }
    cycle_count_ += 1;
}

void Arm7TDMICore::thumb_load_store(uint16_t instr) {
    int op = (instr >> 12) & 0x0F;
    if (op == 0x08 || op == 0x09) {
        // Load/store with immediate offset
        bool load = (instr >> 11) & 1;
        bool byte = (instr >> 12) & 1;
        int rd = (instr >> 0) & 0x07;
        int rb = (instr >> 3) & 0x07;
        int offset = ((instr >> 6) & 0x1F) * (byte ? 1 : 4);
        uint32_t addr = gpr_[rb] + offset;
        if (load) gpr_[rd] = byte ? read8(addr) : read32(addr);
        else { uint32_t v = gpr_[rd]; byte ? write8(addr, v & 0xFF) : write32(addr, v); }
        cycle_count_ += 2;
    } else if (op == 0x0C || op == 0x0D) {
        // Load/store with register offset
        bool load = (instr >> 11) & 1;
        bool byte = (instr >> 10) & 1;
        int rd = instr & 0x07;
        int rb = (instr >> 3) & 0x07;
        int ro = (instr >> 6) & 0x07;
        uint32_t addr = gpr_[rb] + gpr_[ro];
        if (load) gpr_[rd] = byte ? read8(addr) : read32(addr);
        else { uint32_t v = gpr_[rd]; byte ? write8(addr, v & 0xFF) : write32(addr, v); }
        cycle_count_ += 2;
    } else if (op == 0x0E) {
        // Load/store halfword
        bool load = (instr >> 11) & 1;
        int rd = instr & 0x07;
        int rb = (instr >> 3) & 0x07;
        int offset = ((instr >> 6) & 0x1F) * 2;
        uint32_t addr = gpr_[rb] + offset;
        if (load) gpr_[rd] = read16(addr);
        else write16(addr, gpr_[rd] & 0xFFFF);
        cycle_count_ += 2;
    }
}

void Arm7TDMICore::thumb_branch(uint16_t instr) {
    int op = (instr >> 10) & 0x0F;
    if (op == 0x0C) { // B
        int32_t offset = (int32_t)(int8_t)(instr & 0xFF) << 1;
        gpr_[15] += 4 + offset;
        cycle_count_ += 3;
    } else if (op == 0x0D) { // BL suffix
        int32_t offset = (int32_t)(int8_t)(instr & 0xFF) << 1;
        gpr_[14] = gpr_[15] + 4 + offset;
        cycle_count_ += 1;
    } else if (op == 0x0E) { // B (conditional)
        int cond = (instr >> 8) & 0x0F;
        if (check_cond(cond)) {
            int32_t offset = (int32_t)(int8_t)(instr & 0xFF) << 1;
            gpr_[15] += 4 + offset;
        }
        cycle_count_ += 3;
    } else if (op == 0x0F) { // BLX / SWI
        if ((instr & 0xFF) == 0) { // BLX
            uint32_t target = gpr_[14] + ((int32_t)(int8_t)(instr & 0xFF) << 1);
            gpr_[14] = (gpr_[15] + 2) | 1;
            gpr_[15] = target & ~1;
            cpsr_ &= ~Arm7CPSR::T;  // Switch to ARM mode
        } else {
            raise_exception(Arm7Mode::SUPERVISOR, 0x08);
        }
        cycle_count_ += 3;
    }
}

void Arm7TDMICore::thumb_data_processing(uint16_t instr) {
    if ((instr & 0xF800) == 0x2000) { // MOV Rd, #imm
        int rd = (instr >> 8) & 0x07;
        uint32_t imm = instr & 0xFF;
        gpr_[rd] = imm;
        cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z);
        if (imm == 0) cpsr_ |= Arm7CPSR::Z;
        cycle_count_ += 1;
    } else if ((instr & 0xF800) == 0x2800) { // CMP Rd, #imm
        int rd = (instr >> 8) & 0x07;
        uint32_t imm = instr & 0xFF;
        uint32_t diff = gpr_[rd] - imm;
        cpsr_ &= ~(Arm7CPSR::N | Arm7CPSR::Z | Arm7CPSR::C | Arm7CPSR::V);
        if (diff == 0) cpsr_ |= Arm7CPSR::Z;
        if (diff & 0x80000000) cpsr_ |= Arm7CPSR::N;
        if (gpr_[rd] >= imm) cpsr_ |= Arm7CPSR::C;
        cycle_count_ += 1;
    } else if ((instr & 0xF800) == 0x3000) { // ADD Rd, #imm
        int rd = (instr >> 8) & 0x07;
        uint32_t imm = instr & 0xFF;
        gpr_[rd] += imm;
        cycle_count_ += 1;
    } else if ((instr & 0xF800) == 0x3800) { // SUB Rd, #imm
        int rd = (instr >> 8) & 0x07;
        uint32_t imm = instr & 0xFF;
        gpr_[rd] -= imm;
        cycle_count_ += 1;
    }
}

void Arm7TDMICore::execute_thumb(uint16_t instr) {
    int type = (instr >> 12) & 0x0F;

    switch (type) {
        case 0x00: case 0x01: case 0x02: case 0x03:
            thumb_shift(instr);
            break;
        case 0x04: case 0x05:
            thumb_add_sub(instr);
            break;
        case 0x06: case 0x07:
            thumb_alu(instr);
            break;
        case 0x08: case 0x09: case 0x0A: case 0x0B:
            thumb_load_store(instr);
            break;
        case 0x0C: case 0x0D: case 0x0E:
            thumb_load_store(instr);
            break;
        case 0x0F:
            thumb_branch(instr);
            break;
        case 0x02: case 0x03:
            if (instr & 0x0800) thumb_alu(instr);
            else thumb_data_processing(instr);
            break;
        default:
            cycle_count_ += 1;
            break;
    }
}

// ============================================================================
// Step / Run
// ============================================================================

int Arm7TDMICore::step() {
    if (halted_) return -1;

    // Check for interrupts
    if (fiq_pending_ && !(cpsr_ & Arm7CPSR::F)) {
        fiq_pending_ = false;
        raise_exception(Arm7Mode::FIQ, 0x1C);
        return 0;
    }
    if (irq_pending_ && !(cpsr_ & Arm7CPSR::I)) {
        irq_pending_ = false;
        raise_exception(Arm7Mode::IRQ, 0x18);
        return 0;
    }

    if (is_thumb()) {
        uint16_t instr = fetch16_thumb();
        execute_thumb(instr);
    } else {
        uint32_t instr = fetch32_arm();
        execute_arm(instr);
    }

    instruction_count_++;
    return 0;
}

void Arm7TDMICore::run(uint64_t max_instructions) {
    while (!halted_ && instruction_count_ < max_instructions) {
        step();
    }
}

// ============================================================================
// Disassembly
// ============================================================================

std::string Arm7TDMICore::disasm_at(uint32_t addr, int* bytes_consumed) {
    if (is_thumb()) {
        uint16_t instr = read16(addr);
        if (bytes_consumed) *bytes_consumed = 2;
        std::ostringstream oss;
        oss << std::uppercase << std::hex << std::setfill('0');
        oss << std::setw(8) << addr << ":  " << std::setw(4) << instr << "  (Thumb)";
        return oss.str();
    } else {
        uint32_t instr = read32(addr);
        if (bytes_consumed) *bytes_consumed = 4;
        std::ostringstream oss;
        oss << std::uppercase << std::hex << std::setfill('0');
        oss << std::setw(8) << addr << ":  " << std::setw(8) << instr << "  (ARM)";
        return oss.str();
    }
}

// ============================================================================
// State Save/Restore
// ============================================================================

std::vector<uint8_t> Arm7TDMICore::save_state() const {
    std::vector<uint8_t> state;
    auto append = [&](const void* data, size_t len) {
        state.insert(state.end(), (const uint8_t*)data, (const uint8_t*)data + len);
    };
    for (int i = 0; i < 16; i++) append(&gpr_[i], 4);
    append(&cpsr_, 4);
    for (int i = 0; i < 7; i++) append(&fiq_regs_[i], 4);
    for (int i = 0; i < 2; i++) append(&irq_regs_[i], 4);
    for (int i = 0; i < 2; i++) append(&svc_regs_[i], 4);
    for (int i = 0; i < 2; i++) append(&abt_regs_[i], 4);
    for (int i = 0; i < 2; i++) append(&und_regs_[i], 4);
    append(&spsr_fiq_, 4); append(&spsr_irq_, 4); append(&spsr_svc_, 4);
    append(&spsr_abt_, 4); append(&spsr_und_, 4);
    append(&halted_, 1); append(&irq_pending_, 1); append(&fiq_pending_, 1);
    for (int i = 0; i < 8; i++) state.push_back((cycle_count_ >> (i*8)) & 0xFF);
    for (int i = 0; i < 8; i++) state.push_back((instruction_count_ >> (i*8)) & 0xFF);
    return state;
}

void Arm7TDMICore::load_state(const std::vector<uint8_t>& state) {
    if (state.size() < 120) return;
    size_t off = 0;
    for (int i = 0; i < 16; i++) {
        gpr_[i] = state[off] | (uint32_t(state[off+1]) << 8) |
                  (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24);
        off += 4;
    }
    cpsr_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    // Remaining fields skipped for brevity
}

CpuStateSnapshot Arm7TDMICore::get_snapshot() const {
    CpuStateSnapshot s;
    s.pc = gpr_[15];
    s.next_pc = gpr_[15];
    s.sp = gpr_[13];
    for (int i = 0; i < 16; i++) s.regs[i] = gpr_[i];
    s.cycle_count = cycle_count_;
    s.instruction_count = instruction_count_;
    s.halted = halted_;
    s.arch = ArchID::ARM7TDMI;
    return s;
}

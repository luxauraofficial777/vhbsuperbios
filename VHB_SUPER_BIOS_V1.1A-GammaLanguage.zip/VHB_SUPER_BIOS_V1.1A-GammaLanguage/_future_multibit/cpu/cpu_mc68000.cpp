// =============================================================================
// cpu_mc68000.cpp — Motorola 68000 CPU Core Implementation (Clean-Room)
//
// Reference: M68000 PRM, github.com/kstenerud/Musashi (MIT)
//
// =============================================================================

#include "cpu_mc68000.h"
#include <cstdio>
#include <sstream>
#include <iomanip>

// ============================================================================
// Constructor / Reset
// ============================================================================

MC68000Core::MC68000Core() {
    regs_.fill(0);
}

void MC68000Core::reset() {
    regs_.fill(0);
    pc_ = 0;
    sr_ = 0x2700;
    halted_ = false;
    irq_pending_ = false;
    irq_level_ = 0;
    cycle_count_ = 0;
    instruction_count_ = 0;

    // Read reset vector: SSP at 0x000, PC at 0x004
    regs_[15] = read32(0x000000);  // Supervisor stack pointer
    pc_ = read32(0x000004);         // Program counter
    pc_ &= 0xFFFFFF;                // 24-bit address bus
}

// ============================================================================
// Memory Access (big-endian)
// ============================================================================

uint8_t MC68000Core::read8(uint32_t addr) {
    if (mem_read_) return mem_read_(addr & 0xFFFFFF);
    return 0;
}

uint16_t MC68000Core::read16(uint32_t addr) {
    return (uint16_t(read8(addr)) << 8) | read8(addr + 1);
}

uint32_t MC68000Core::read32(uint32_t addr) {
    return (uint32_t(read8(addr)) << 24) | (uint32_t(read8(addr+1)) << 16) |
           (uint32_t(read8(addr+2)) << 8) | read8(addr+3);
}

void MC68000Core::write8(uint32_t addr, uint8_t value) {
    if (mem_write_) mem_write_(addr & 0xFFFFFF, value);
}

void MC68000Core::write16(uint32_t addr, uint16_t value) {
    write8(addr, value >> 8);
    write8(addr + 1, value & 0xFF);
}

void MC68000Core::write32(uint32_t addr, uint32_t value) {
    write8(addr, value >> 24);
    write8(addr+1, (value >> 16) & 0xFF);
    write8(addr+2, (value >> 8) & 0xFF);
    write8(addr+3, value & 0xFF);
}

// ============================================================================
// Register Access
// ============================================================================

const char* MC68000Core::get_reg_name(int index) const {
    static const char* names[] = {
        "D0","D1","D2","D3","D4","D5","D6","D7",
        "A0","A1","A2","A3","A4","A5","A6","A7",
        "SR","PC"
    };
    if (index >= 0 && index < 18) return names[index];
    return "??";
}

uint32_t MC68000Core::get_reg(int index) const {
    if (index >= 0 && index < 16) return regs_[index];
    if (index == M68K_SR) return sr_;
    if (index == M68K_PC) return pc_;
    return 0;
}

void MC68000Core::set_reg(int index, uint32_t value) {
    if (index >= 0 && index < 16) {
        regs_[index] = (index >= 8) ? (value & 0xFFFFFF) : value;
    } else if (index == M68K_SR) {
        sr_ = value & 0xFFFF;
    } else if (index == M68K_PC) {
        pc_ = value & 0xFFFFFF;
    }
}

// ============================================================================
// Exception Handling
// ============================================================================

void MC68000Core::raise_exception(int vector) {
    uint32_t old_sr = sr_;
    uint32_t old_pc = pc_;

    // Save state
    bool was_supervisor = is_supervisor();
    sr_ |= M68kFlags::S;  // Enter supervisor mode
    sr_ &= ~(M68kFlags::T0 | M68kFlags::T1);  // Clear trace

    // Push old SR and PC
    push32(old_pc);
    push16(old_sr);

    // Load new PC from vector
    uint32_t vector_addr = vector * 4;
    pc_ = read32(vector_addr) & 0xFFFFFF;

    cycle_count_ += 34;
}

void MC68000Core::handle_interrupt() {
    if (irq_level_ <= get_int_mask()) return;

    int vector;
    if (irq_level_ == 7) {
        vector = EXC_IRQ_LEVEL7;
    } else {
        vector = EXC_IRQ_LEVEL1 + irq_level_ - 1;
    }

    // Auto-vector (simplified — real hardware uses IACK)
    uint32_t old_sr = sr_;
    sr_ |= M68kFlags::S;
    sr_ = (sr_ & ~(M68kFlags::I0 | M68kFlags::I1 | M68kFlags::I2)) |
          (uint16_t(irq_level_) << 8);
    sr_ &= ~(M68kFlags::T0 | M68kFlags::T1);

    push32(pc_);
    push16(old_sr);

    pc_ = read32(vector * 4) & 0xFFFFFF;
    irq_pending_ = false;
    cycle_count_ += 44;
}

void MC68000Core::raise_interrupt(uint32_t vector) {
    (void)vector;
    irq_pending_ = true;
}

void MC68000Core::trigger_exception(uint32_t cause, uint32_t epc) {
    (void)epc;
    raise_exception(cause);
}

// ============================================================================
// Addressing Modes
// ============================================================================

uint32_t MC68000Core::ea_data_reg(int mode, int reg, int size) {
    (void)mode;
    return reg;  // Return register index for data register direct
}

uint32_t MC68000Core::ea_addr_reg(int mode, int reg, int size) {
    (void)mode; (void)size;
    return reg + 8;  // Return register index for address register direct
}

uint32_t MC68000Core::ea_displacement(int reg) {
    int16_t disp = (int16_t)fetch16();
    return (regs_[reg + 8] + disp) & 0xFFFFFF;
}

uint32_t MC68000Core::ea_indexed(int reg) {
    uint16_t ext = fetch16();
    int8_t disp = (int8_t)(ext & 0xFF);
    int index_reg = (ext >> 12) & 0x0F;
    bool is_long = (ext & 0x0800) != 0;
    uint32_t index = is_long ? regs_[index_reg] : (regs_[index_reg] & 0xFFFF);
    if (!is_long && (index & 0x8000)) index |= 0xFFFF0000;  // Sign-extend
    return (regs_[reg + 8] + disp + index) & 0xFFFFFF;
}

uint32_t MC68000Core::ea_absolute_short() {
    int16_t addr = (int16_t)fetch16();
    return (uint32_t)(int32_t)addr & 0xFFFFFF;
}

uint32_t MC68000Core::ea_absolute_long() {
    return fetch32() & 0xFFFFFF;
}

uint32_t MC68000Core::ea_pc_displacement() {
    int16_t disp = (int16_t)fetch16();
    return (pc_ + disp - 2) & 0xFFFFFF;
}

uint32_t MC68000Core::ea_pc_indexed() {
    uint16_t ext = fetch16();
    int8_t disp = (int8_t)(ext & 0xFF);
    int index_reg = (ext >> 12) & 0x0F;
    bool is_long = (ext & 0x0800) != 0;
    uint32_t index = is_long ? regs_[index_reg] : (regs_[index_reg] & 0xFFFF);
    if (!is_long && (index & 0x8000)) index |= 0xFFFF0000;
    return (pc_ + disp + index - 2) & 0xFFFFFF;
}

uint32_t MC68000Core::ea_immediate(int size) {
    uint32_t addr = pc_;
    if (size == 1) pc_ += 2;  // Byte immediate is padded to word
    else if (size == 2) pc_ += 2;
    else pc_ += 4;
    return addr;
}

uint32_t MC68000Core::read_ea(int mode, int reg, int size) {
    switch (mode) {
        case 0: { // Dn
            uint32_t val = regs_[reg];
            if (size == 1) return val & 0xFF;
            if (size == 2) return val & 0xFFFF;
            return val;
        }
        case 1: { // An
            return regs_[reg + 8] & 0xFFFFFF;
        }
        case 2: { // (An)
            return read_ea_at(regs_[reg + 8], size);
        }
        case 3: { // (An)+
            uint32_t addr = regs_[reg + 8];
            uint32_t val = read_ea_at(addr, size);
            int inc = (size == 1) ? 2 : (size == 2) ? 2 : 4;
            if (reg == 7 && size == 1) inc = 2;  // A7 stays word-aligned
            regs_[reg + 8] = (addr + inc) & 0xFFFFFF;
            return val;
        }
        case 4: { // -(An)
            int dec = (size == 1) ? 2 : (size == 2) ? 2 : 4;
            if (reg == 7 && size == 1) dec = 2;
            uint32_t addr = (regs_[reg + 8] - dec) & 0xFFFFFF;
            regs_[reg + 8] = addr;
            return read_ea_at(addr, size);
        }
        case 5: { // d(An)
            uint32_t addr = ea_displacement(reg);
            return read_ea_at(addr, size);
        }
        case 6: { // d(An,Xn)
            uint32_t addr = ea_indexed(reg);
            return read_ea_at(addr, size);
        }
        case 7: {
            switch (reg) {
                case 0: { // xxx.W
                    uint32_t addr = ea_absolute_short();
                    return read_ea_at(addr, size);
                }
                case 1: { // xxx.L
                    uint32_t addr = ea_absolute_long();
                    return read_ea_at(addr, size);
                }
                case 2: { // d(PC)
                    uint32_t addr = ea_pc_displacement();
                    return read_ea_at(addr, size);
                }
                case 3: { // d(PC,Xn)
                    uint32_t addr = ea_pc_indexed();
                    return read_ea_at(addr, size);
                }
                case 4: { // #imm
                    uint32_t addr = ea_immediate(size);
                    if (size == 1) return read8(addr);
                    if (size == 2) return read16(addr);
                    return read32(addr);
                }
            }
        }
    }
    return 0;
}

void MC68000Core::write_ea(int mode, int reg, int size, uint32_t value) {
    switch (mode) {
        case 0: { // Dn
            if (size == 1) {
                regs_[reg] = (regs_[reg] & 0xFFFFFF00) | (value & 0xFF);
            } else if (size == 2) {
                regs_[reg] = (regs_[reg] & 0xFFFF0000) | (value & 0xFFFF);
            } else {
                regs_[reg] = value;
            }
            break;
        }
        case 1: { // An
            regs_[reg + 8] = value & 0xFFFFFF;
            break;
        }
        case 2: { // (An)
            write_ea_at(regs_[reg + 8], size, value);
            break;
        }
        case 3: { // (An)+
            write_ea_at(regs_[reg + 8], size, value);
            int inc = (size == 1) ? 2 : (size == 2) ? 2 : 4;
            if (reg == 7 && size == 1) inc = 2;
            regs_[reg + 8] = (regs_[reg + 8] + inc) & 0xFFFFFF;
            break;
        }
        case 4: { // -(An)
            int dec = (size == 1) ? 2 : (size == 2) ? 2 : 4;
            if (reg == 7 && size == 1) dec = 2;
            uint32_t addr = (regs_[reg + 8] - dec) & 0xFFFFFF;
            regs_[reg + 8] = addr;
            write_ea_at(addr, size, value);
            break;
        }
        case 5: { // d(An)
            uint32_t addr = ea_displacement(reg);
            write_ea_at(addr, size, value);
            break;
        }
        case 6: { // d(An,Xn)
            uint32_t addr = ea_indexed(reg);
            write_ea_at(addr, size, value);
            break;
        }
        case 7: {
            switch (reg) {
                case 0: { // xxx.W
                    uint32_t addr = ea_absolute_short();
                    write_ea_at(addr, size, value);
                    break;
                }
                case 1: { // xxx.L
                    uint32_t addr = ea_absolute_long();
                    write_ea_at(addr, size, value);
                    break;
                }
            }
            break;
        }
    }
}

inline uint32_t MC68000Core::read_ea_at(uint32_t addr, int size) {
    if (size == 1) return read8(addr);
    if (size == 2) return read16(addr);
    return read32(addr);
}

inline void MC68000Core::write_ea_at(uint32_t addr, int size, uint32_t value) {
    if (size == 1) write8(addr, value & 0xFF);
    else if (size == 2) write16(addr, value & 0xFFFF);
    else write32(addr, value);
}

// ============================================================================
// Condition Codes
// ============================================================================

bool MC68000Core::check_cc(int cc) const {
    bool c = (sr_ & M68kFlags::C) != 0;
    bool v = (sr_ & M68kFlags::V) != 0;
    bool z = (sr_ & M68kFlags::Z) != 0;
    bool n = (sr_ & M68kFlags::N) != 0;

    switch (cc) {
        case 0: return true;           // T
        case 1: return false;          // F
        case 2: return !c && !z;       // HI
        case 3: return c || z;         // LS
        case 4: return !c;             // CC/HS
        case 5: return c;              // CS/LO
        case 6: return !z;             // NE
        case 7: return z;              // EQ
        case 8: return !v;             // VC
        case 9: return v;              // VS
        case 10: return !n;            // PL
        case 11: return n;             // MI
        case 12: return n == v;        // GE
        case 13: return n != v;        // LT
        case 14: return !z && (n == v); // GT
        case 15: return z || (n != v); // LE
    }
    return false;
}

// ============================================================================
// Instruction Handlers (key instructions)
// ============================================================================

void MC68000Core::op_move(int size, int src_mode, int src_reg, int dst_mode, int dst_reg) {
    uint32_t val = read_ea(src_mode, src_reg, size);
    write_ea(dst_mode, dst_reg, size, val);

    int s = (size == 1) ? 1 : (size == 2) ? 2 : 4;
    set_flag(M68kFlags::N, val & (1 << (s * 8 - 1)));
    set_flag(M68kFlags::Z, (val & ((1 << (s * 8)) - 1)) == 0);
    sr_ &= ~(M68kFlags::V | M68kFlags::C);
    cycle_count_ += (s == 4) ? 8 : 4;
}

void MC68000Core::op_moveq(int data, int dst_reg) {
    int8_t val = (int8_t)data;
    regs_[dst_reg] = (uint32_t)(int32_t)val;
    set_nz32(regs_[dst_reg]);
    sr_ &= ~(M68kFlags::V | M68kFlags::C);
    cycle_count_ += 4;
}

void MC68000Core::op_add(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg) {
    uint32_t src = read_ea(src_mode, src_reg, size);
    uint32_t dst;
    if (ea_to_reg) {
        dst = (dst_reg < 8) ? regs_[dst_reg] : regs_[dst_reg + 8];
    } else {
        dst = read_ea(dst_mode, dst_reg, size);
    }

    uint64_t result;
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);

    result = (uint64_t)(src & mask) + (uint64_t)(dst & mask);
    uint32_t res = result & mask;

    set_flag(M68kFlags::C, result & (1ULL << bits));
    set_flag(M68kFlags::V, (~(src ^ dst) & (src ^ res) & (1 << (bits - 1))) != 0);
    set_flag(M68kFlags::Z, (res & mask) == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    set_flag(M68kFlags::X, result & (1ULL << bits));

    if (ea_to_reg) {
        if (dst_reg < 8) {
            if (size == 1) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFFFF00) | res;
            else if (size == 2) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFF0000) | res;
            else regs_[dst_reg] = res;
        } else {
            regs_[dst_reg + 8] = res & 0xFFFFFF;
        }
    } else {
        write_ea(dst_mode, dst_reg, size, res);
    }
    cycle_count_ += (size == 4) ? 8 : 4;
}

void MC68000Core::op_sub(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg) {
    uint32_t src = read_ea(src_mode, src_reg, size);
    uint32_t dst;
    if (ea_to_reg) {
        dst = (dst_reg < 8) ? regs_[dst_reg] : regs_[dst_reg + 8];
    } else {
        dst = read_ea(dst_mode, dst_reg, size);
    }

    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t res = (dst & mask) - (src & mask);

    set_flag(M68kFlags::C, (dst & mask) < (src & mask));
    set_flag(M68kFlags::V, ((src ^ dst) & (dst ^ res) & (1 << (bits - 1))) != 0);
    set_flag(M68kFlags::Z, (res & mask) == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    set_flag(M68kFlags::X, (dst & mask) < (src & mask));

    if (ea_to_reg) {
        if (dst_reg < 8) {
            if (size == 1) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFFFF00) | (res & 0xFF);
            else if (size == 2) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFF0000) | (res & 0xFFFF);
            else regs_[dst_reg] = res;
        } else {
            regs_[dst_reg + 8] = res & 0xFFFFFF;
        }
    } else {
        write_ea(dst_mode, dst_reg, size, res);
    }
    cycle_count_ += (size == 4) ? 8 : 4;
}

void MC68000Core::op_and(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg) {
    uint32_t src = read_ea(src_mode, src_reg, size);
    uint32_t dst = ea_to_reg ? regs_[dst_reg] : read_ea(dst_mode, dst_reg, size);
    uint32_t res = src & dst;

    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    set_flag(M68kFlags::Z, (res & mask) == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    sr_ &= ~(M68kFlags::V | M68kFlags::C);

    if (ea_to_reg) {
        if (size == 1) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFFFF00) | (res & 0xFF);
        else if (size == 2) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFF0000) | (res & 0xFFFF);
        else regs_[dst_reg] = res;
    } else {
        write_ea(dst_mode, dst_reg, size, res);
    }
    cycle_count_ += (size == 4) ? 8 : 4;
}

void MC68000Core::op_or(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg) {
    uint32_t src = read_ea(src_mode, src_reg, size);
    uint32_t dst = ea_to_reg ? regs_[dst_reg] : read_ea(dst_mode, dst_reg, size);
    uint32_t res = src | dst;

    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    set_flag(M68kFlags::Z, (res & mask) == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    sr_ &= ~(M68kFlags::V | M68kFlags::C);

    if (ea_to_reg) {
        if (size == 1) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFFFF00) | (res & 0xFF);
        else if (size == 2) regs_[dst_reg] = (regs_[dst_reg] & 0xFFFF0000) | (res & 0xFFFF);
        else regs_[dst_reg] = res;
    } else {
        write_ea(dst_mode, dst_reg, size, res);
    }
    cycle_count_ += (size == 4) ? 8 : 4;
}

void MC68000Core::op_eor(int size, int src_mode, int src_reg, int dst_mode, int dst_reg) {
    uint32_t src = regs_[src_reg];
    uint32_t dst = read_ea(dst_mode, dst_reg, size);
    uint32_t res = src ^ dst;

    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    set_flag(M68kFlags::Z, (res & mask) == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    sr_ &= ~(M68kFlags::V | M68kFlags::C);

    write_ea(dst_mode, dst_reg, size, res);
    cycle_count_ += (size == 4) ? 12 : 8;
}

void MC68000Core::op_cmp(int size, int src_mode, int src_reg, int dst_reg) {
    uint32_t src = read_ea(src_mode, src_reg, size);
    uint32_t dst = regs_[dst_reg];

    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t res = (dst & mask) - (src & mask);

    set_flag(M68kFlags::C, (dst & mask) < (src & mask));
    set_flag(M68kFlags::V, ((src ^ dst) & (dst ^ res) & (1 << (bits - 1))) != 0);
    set_flag(M68kFlags::Z, (res & mask) == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    cycle_count_ += (size == 4) ? 6 : 4;
}

void MC68000Core::op_lea(int src_mode, int src_reg, int dst_reg) {
    uint32_t addr = 0;
    switch (src_mode) {
        case 5: addr = ea_displacement(src_reg); break;
        case 6: addr = ea_indexed(src_reg); break;
        case 7:
            if (src_reg == 0) addr = ea_absolute_short();
            else if (src_reg == 1) addr = ea_absolute_long();
            else if (src_reg == 2) addr = ea_pc_displacement();
            else if (src_reg == 3) addr = ea_pc_indexed();
            break;
    }
    regs_[dst_reg + 8] = addr & 0xFFFFFF;
    cycle_count_ += 4;
}

void MC68000Core::op_jmp(int src_mode, int src_reg) {
    uint32_t addr = 0;
    switch (src_mode) {
        case 5: addr = ea_displacement(src_reg); break;
        case 6: addr = ea_indexed(src_reg); break;
        case 7:
            if (src_reg == 0) addr = ea_absolute_short();
            else if (src_reg == 1) addr = ea_absolute_long();
            else if (src_reg == 2) addr = ea_pc_displacement();
            else if (src_reg == 3) addr = ea_pc_indexed();
            break;
    }
    pc_ = addr & 0xFFFFFF;
    cycle_count_ += 8;
}

void MC68000Core::op_jsr(int src_mode, int src_reg) {
    uint32_t addr = 0;
    switch (src_mode) {
        case 5: addr = ea_displacement(src_reg); break;
        case 6: addr = ea_indexed(src_reg); break;
        case 7:
            if (src_reg == 0) addr = ea_absolute_short();
            else if (src_reg == 1) addr = ea_absolute_long();
            else if (src_reg == 2) addr = ea_pc_displacement();
            else if (src_reg == 3) addr = ea_pc_indexed();
            break;
    }
    push32(pc_);
    pc_ = addr & 0xFFFFFF;
    cycle_count_ += 12;
}

void MC68000Core::op_bra(int8_t offset) {
    if (offset == 0) {
        int16_t ext = (int16_t)fetch16();
        pc_ = (pc_ + ext - 2) & 0xFFFFFF;
    } else {
        pc_ = (pc_ + offset) & 0xFFFFFF;
    }
    cycle_count_ += 10;
}

void MC68000Core::op_bsr(int8_t offset) {
    push32(pc_);
    if (offset == 0) {
        int16_t ext = (int16_t)fetch16();
        pc_ = (pc_ + ext - 2) & 0xFFFFFF;
    } else {
        pc_ = (pc_ + offset) & 0xFFFFFF;
    }
    cycle_count_ += 12;
}

void MC68000Core::op_bcc(int cc, int8_t offset) {
    if (check_cc(cc)) {
        if (offset == 0) {
            int16_t ext = (int16_t)fetch16();
            pc_ = (pc_ + ext - 2) & 0xFFFFFF;
        } else {
            pc_ = (pc_ + offset) & 0xFFFFFF;
        }
        cycle_count_ += 10;
    } else {
        if (offset == 0) pc_ += 2;
        cycle_count_ += 8;
    }
}

void MC68000Core::op_dbcc(int cc, int reg, int16_t offset) {
    if (!check_cc(cc)) {
        uint16_t val = (regs_[reg] - 1) & 0xFFFF;
        regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        if (val != 0xFFFF) {
            pc_ = (pc_ + offset - 2) & 0xFFFFFF;
            cycle_count_ += 10;
        } else {
            cycle_count_ += 14;
        }
    } else {
        cycle_count_ += 8;
    }
}

void MC68000Core::op_rts() {
    pc_ = pop32() & 0xFFFFFF;
    cycle_count_ += 16;
}

void MC68000Core::op_rte() {
    sr_ = pop16();
    pc_ = pop32() & 0xFFFFFF;
    cycle_count_ += 20;
}

void MC68000Core::op_tst(int size, int mode, int reg) {
    uint32_t val = read_ea(mode, reg, size);
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    set_flag(M68kFlags::Z, (val & mask) == 0);
    set_flag(M68kFlags::N, val & (1 << (bits - 1)));
    sr_ &= ~(M68kFlags::V | M68kFlags::C);
    cycle_count_ += 4;
}

void MC68000Core::op_clr(int size, int mode, int reg) {
    write_ea(mode, reg, size, 0);
    sr_ &= ~(M68kFlags::C | M68kFlags::V | M68kFlags::N);
    sr_ |= M68kFlags::Z;
    cycle_count_ += (size == 4) ? 6 : 4;
}

void MC68000Core::op_neg(int size, int mode, int reg) {
    uint32_t val = read_ea(mode, reg, size);
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t res = 0 - (val & mask);

    set_flag(M68kFlags::C, val & mask);
    set_flag(M68kFlags::V, (val & (1 << (bits - 1))) && ((val & mask) == (1 << (bits - 1))));
    set_flag(M68kFlags::Z, (res & mask) == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    set_flag(M68kFlags::X, val & mask);

    write_ea(mode, reg, size, res);
    cycle_count_ += (size == 4) ? 8 : 4;
}

void MC68000Core::op_not(int size, int mode, int reg) {
    uint32_t val = read_ea(mode, reg, size);
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t res = ~val & mask;

    set_flag(M68kFlags::Z, res == 0);
    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
    sr_ &= ~(M68kFlags::V | M68kFlags::C);

    write_ea(mode, reg, size, res);
    cycle_count_ += (size == 4) ? 8 : 4;
}

void MC68000Core::op_swap(int reg) {
    regs_[reg] = (regs_[reg] >> 16) | (regs_[reg] << 16);
    set_nz32(regs_[reg]);
    sr_ &= ~(M68kFlags::V | M68kFlags::C);
    cycle_count_ += 4;
}

void MC68000Core::op_ext(int size, int reg) {
    if (size == 2) {
        int8_t val = regs_[reg] & 0xFF;
        regs_[reg] = (regs_[reg] & 0xFFFF0000) | ((uint16_t)(int16_t)val);
        set_nz16(regs_[reg] & 0xFFFF);
    } else {
        int16_t val = regs_[reg] & 0xFFFF;
        regs_[reg] = (uint32_t)(int32_t)val;
        set_nz32(regs_[reg]);
    }
    sr_ &= ~(M68kFlags::V | M68kFlags::C);
    cycle_count_ += 4;
}

void MC68000Core::op_pea(int mode, int reg) {
    uint32_t addr = 0;
    switch (mode) {
        case 5: addr = ea_displacement(reg); break;
        case 6: addr = ea_indexed(reg); break;
        case 7:
            if (reg == 0) addr = ea_absolute_short();
            else if (reg == 1) addr = ea_absolute_long();
            else if (reg == 2) addr = ea_pc_displacement();
            else if (reg == 3) addr = ea_pc_indexed();
            break;
    }
    push32(addr);
    cycle_count_ += 8;
}

void MC68000Core::op_link(int reg, int16_t offset) {
    push32(regs_[reg + 8]);
    regs_[reg + 8] = regs_[15];
    regs_[15] = (regs_[15] + offset) & 0xFFFFFF;
    cycle_count_ += 16;
}

void MC68000Core::op_unlk(int reg) {
    regs_[15] = regs_[reg + 8];
    regs_[reg + 8] = pop32();
    cycle_count_ += 12;
}

void MC68000Core::op_trap(int vector) {
    raise_exception(EXC_TRAP_0 + (vector & 0x0F));
}

void MC68000Core::op_stop() {
    uint16_t new_sr = fetch16();
    sr_ = new_sr;
    halted_ = true;
    cycle_count_ += 4;
}

void MC68000Core::op_reset() {
    // Hardware reset pulse — no-op in emulator
    cycle_count_ += 132;
}

void MC68000Core::op_nop() {
    cycle_count_ += 4;
}

// Shift operations
void MC68000Core::op_lsl(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;

    for (int i = 0; i < count; i++) {
        set_flag(M68kFlags::X, val & (1 << (bits - 1)));
        val = (val << 1) & mask;
    }
    set_flag(M68kFlags::C, sr_ & M68kFlags::X);
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & (1 << (bits - 1)));
    sr_ &= ~M68kFlags::V;

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_lsr(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;

    for (int i = 0; i < count; i++) {
        set_flag(M68kFlags::X, val & 1);
        val >>= 1;
    }
    set_flag(M68kFlags::C, sr_ & M68kFlags::X);
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & (1 << (bits - 1)));
    sr_ &= ~M68kFlags::V;

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_asl(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;
    uint32_t sign_bit = 1 << (bits - 1);

    for (int i = 0; i < count; i++) {
        bool last_c = val & sign_bit;
        bool sign = val & sign_bit;
        val = (val << 1) & mask;
        if (count == 1 && (sign != (bool)(val & sign_bit))) {
            sr_ |= M68kFlags::V;
        }
        set_flag(M68kFlags::X, last_c);
    }
    set_flag(M68kFlags::C, sr_ & M68kFlags::X);
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & sign_bit);

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_asr(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;
    uint32_t sign_bit = 1 << (bits - 1);
    bool sign = val & sign_bit;

    for (int i = 0; i < count; i++) {
        set_flag(M68kFlags::X, val & 1);
        val >>= 1;
        if (sign) val |= sign_bit;
    }
    set_flag(M68kFlags::C, sr_ & M68kFlags::X);
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & sign_bit);
    sr_ &= ~M68kFlags::V;

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_rol(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;

    for (int i = 0; i < count; i++) {
        bool carry = val & (1 << (bits - 1));
        val = ((val << 1) | (carry ? 1 : 0)) & mask;
        set_flag(M68kFlags::C, carry);
    }
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & (1 << (bits - 1)));
    sr_ &= ~M68kFlags::V;

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_ror(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;

    for (int i = 0; i < count; i++) {
        bool carry = val & 1;
        val = (val >> 1) | (carry ? (1 << (bits - 1)) : 0);
        val &= mask;
        set_flag(M68kFlags::C, carry);
    }
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & (1 << (bits - 1)));
    sr_ &= ~M68kFlags::V;

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_roxl(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;
    bool x = sr_ & M68kFlags::X;

    for (int i = 0; i < count; i++) {
        bool new_x = val & (1 << (bits - 1));
        val = ((val << 1) | (x ? 1 : 0)) & mask;
        x = new_x;
    }
    set_flag(M68kFlags::X, x);
    set_flag(M68kFlags::C, x);
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & (1 << (bits - 1)));
    sr_ &= ~M68kFlags::V;

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_roxr(int size, int count, int mode, int reg) {
    int bits = size * 8;
    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
    uint32_t val = (mode == 0) ? regs_[reg] : read_ea(mode, reg, size);
    val &= mask;
    bool x = sr_ & M68kFlags::X;

    for (int i = 0; i < count; i++) {
        bool new_x = val & 1;
        val = (val >> 1) | (x ? (1 << (bits - 1)) : 0);
        val &= mask;
        x = new_x;
    }
    set_flag(M68kFlags::X, x);
    set_flag(M68kFlags::C, x);
    set_flag(M68kFlags::Z, val == 0);
    set_flag(M68kFlags::N, val & (1 << (bits - 1)));
    sr_ &= ~M68kFlags::V;

    if (mode == 0) {
        if (size == 1) regs_[reg] = (regs_[reg] & 0xFFFFFF00) | val;
        else if (size == 2) regs_[reg] = (regs_[reg] & 0xFFFF0000) | val;
        else regs_[reg] = val;
    } else {
        write_ea(mode, reg, size, val);
    }
    cycle_count_ += count * 2;
}

void MC68000Core::op_mulu(int src_mode, int src_reg, int dst_reg) {
    uint16_t src = read_ea(src_mode, src_reg, 2);
    uint16_t dst = regs_[dst_reg] & 0xFFFF;
    uint32_t result = (uint32_t)src * (uint32_t)dst;
    regs_[dst_reg] = result;
    set_flag(M68kFlags::Z, result == 0);
    set_flag(M68kFlags::N, result & 0x80000000);
    sr_ &= ~(M68kFlags::C | M68kFlags::V);
    cycle_count_ += 70;
}

void MC68000Core::op_muls(int src_mode, int src_reg, int dst_reg) {
    int16_t src = (int16_t)read_ea(src_mode, src_reg, 2);
    int16_t dst = (int16_t)(regs_[dst_reg] & 0xFFFF);
    int32_t result = (int32_t)src * (int32_t)dst;
    regs_[dst_reg] = (uint32_t)result;
    set_flag(M68kFlags::Z, result == 0);
    set_flag(M68kFlags::N, result < 0);
    sr_ &= ~(M68kFlags::C | M68kFlags::V);
    cycle_count_ += 70;
}

void MC68000Core::op_divu(int src_mode, int src_reg, int dst_reg) {
    uint16_t src = read_ea(src_mode, src_reg, 2);
    uint32_t dst = regs_[dst_reg];
    if (src == 0) {
        raise_exception(EXC_DIV_BY_ZERO);
        return;
    }
    uint32_t quotient = dst / src;
    uint32_t remainder = dst % src;
    if (quotient <= 0xFFFF) {
        regs_[dst_reg] = (quotient & 0xFFFF) | (remainder << 16);
        set_flag(M68kFlags::Z, quotient == 0);
        set_flag(M68kFlags::N, quotient & 0x8000);
        sr_ &= ~(M68kFlags::V | M68kFlags::C);
    } else {
        sr_ |= M68kFlags::V;
    }
    cycle_count_ += 140;
}

void MC68000Core::op_divs(int src_mode, int src_reg, int dst_reg) {
    int16_t src = (int16_t)read_ea(src_mode, src_reg, 2);
    int32_t dst = (int32_t)regs_[dst_reg];
    if (src == 0) {
        raise_exception(EXC_DIV_BY_ZERO);
        return;
    }
    int32_t quotient = dst / src;
    int32_t remainder = dst % src;
    if (quotient >= -32768 && quotient <= 32767) {
        regs_[dst_reg] = ((uint16_t)quotient) | ((uint16_t)remainder << 16);
        set_flag(M68kFlags::Z, quotient == 0);
        set_flag(M68kFlags::N, quotient < 0);
        sr_ &= ~(M68kFlags::V | M68kFlags::C);
    } else {
        sr_ |= M68kFlags::V;
    }
    cycle_count_ += 158;
}

// ============================================================================
// Step — Main Instruction Decoder
// ============================================================================

int MC68000Core::step() {
    if (halted_) return -1;

    // Check for pending interrupt
    if (irq_pending_ && irq_level_ > get_int_mask()) {
        handle_interrupt();
        return 0;
    }

    uint16_t opcode = fetch16();

    // Decode by major opcode groups
    int op = (opcode >> 12) & 0x0F;
    int reg = (opcode >> 9) & 0x07;
    int mode = (opcode >> 3) & 0x07;
    int r = opcode & 0x07;
    int size_field = (opcode >> 6) & 0x03;

    switch (op) {
        case 0x00: { // Bit manipulation / logic / arithmetic
            int op_type = (opcode >> 6) & 0x07;
            if (op_type == 0x04) { // BTST Dn,<ea>
                uint32_t val = read_ea(mode, r, 1);
                uint32_t bit = regs_[reg] & 0x1F;
                set_flag(M68kFlags::Z, !(val & (1 << bit)));
                cycle_count_ += 8;
            } else if (op_type == 0x00) { // ORI
                // Simplified — skip for now
                cycle_count_ += 8;
            } else {
                cycle_count_ += 4;
            }
            break;
        }

        case 0x01: { // MOVE.B
            int src_mode = (opcode >> 3) & 0x07;
            int src_reg = opcode & 0x07;
            int dst_reg = (opcode >> 9) & 0x07;
            int dst_mode = (opcode >> 6) & 0x07; // Actually 1 for .B
            op_move(1, src_mode, src_reg, dst_mode, dst_reg);
            break;
        }

        case 0x02: { // MOVE.L
            int src_mode = (opcode >> 3) & 0x07;
            int src_reg = opcode & 0x07;
            int dst_reg = (opcode >> 9) & 0x07;
            int dst_mode = (opcode >> 6) & 0x07;
            op_move(4, src_mode, src_reg, dst_mode, dst_reg);
            break;
        }

        case 0x03: { // MOVE.W
            int src_mode = (opcode >> 3) & 0x07;
            int src_reg = opcode & 0x07;
            int dst_reg = (opcode >> 9) & 0x07;
            int dst_mode = (opcode >> 6) & 0x07;
            op_move(2, src_mode, src_reg, dst_mode, dst_reg);
            break;
        }

        case 0x04: { // Miscellaneous
            int op_type = (opcode >> 8) & 0x0F;
            switch (op_type) {
                case 0x00: op_neg(1, mode, r); break;  // NEG.B
                case 0x01: { // MOVE from SR
                    uint32_t addr = 0;
                    // Simplified
                    cycle_count_ += 6;
                    break;
                }
                case 0x02: op_clr(1, mode, r); break; // CLR.B
                case 0x03: { // MOVE to CCR
                    uint16_t val = read_ea(mode, r, 2);
                    sr_ = val;
                    cycle_count_ += 12;
                    break;
                }
                case 0x04: op_neg(2, mode, r); break; // NEG.W
                case 0x05: { // MOVE to SR
                    uint16_t val = read_ea(mode, r, 2);
                    sr_ = val;
                    cycle_count_ += 12;
                    break;
                }
                case 0x06: op_clr(2, mode, r); break; // CLR.W
                case 0x08: op_neg(4, mode, r); break; // NEG.L
                case 0x0A: op_clr(4, mode, r); break; // CLR.L
                case 0x0C: { // MOVE from SR
                    write_ea(mode, r, 2, sr_);
                    cycle_count_ += 6;
                    break;
                }
                default:
                    cycle_count_ += 4;
                    break;
            }
            break;
        }

        case 0x05: { // ADDQ / SUBQ / Scc / DBcc
            int op_type = (opcode >> 8) & 0x01;
            int data = (opcode >> 9) & 0x07;
            if (data == 0) data = 8;
            int size = size_field;
            if (size == 3) { // Scc or DBcc
                if (mode == 1) { // DBcc
                    int16_t offset = (int16_t)fetch16();
                    op_dbcc(reg, r, offset);
                } else { // Scc
                    uint8_t val = check_cc(reg) ? 0xFF : 0x00;
                    write_ea(mode, r, 1, val);
                    cycle_count_ += 6;
                }
            } else {
                if (op_type == 0) { // ADDQ
                    uint32_t val = read_ea(mode, r, size);
                    // Simplified ADDQ
                    int bits = size * 8;
                    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
                    uint32_t res = (val & mask) + data;
                    set_flag(M68kFlags::Z, (res & mask) == 0);
                    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
                    set_flag(M68kFlags::C, res & (1ULL << bits));
                    sr_ &= ~M68kFlags::V;
                    write_ea(mode, r, size, res);
                    cycle_count_ += 8;
                } else { // SUBQ
                    uint32_t val = read_ea(mode, r, size);
                    int bits = size * 8;
                    uint32_t mask = (bits == 32) ? 0xFFFFFFFF : ((1 << bits) - 1);
                    uint32_t res = (val & mask) - data;
                    set_flag(M68kFlags::Z, (res & mask) == 0);
                    set_flag(M68kFlags::N, res & (1 << (bits - 1)));
                    set_flag(M68kFlags::C, (val & mask) < (uint32_t)data);
                    sr_ &= ~M68kFlags::V;
                    write_ea(mode, r, size, res);
                    cycle_count_ += 8;
                }
            }
            break;
        }

        case 0x06: { // BRA / BSR / Bcc
            int cc = (opcode >> 8) & 0x0F;
            int8_t offset = opcode & 0xFF;
            if (cc == 0) { // BRA
                op_bra(offset);
            } else if (cc == 1) { // BSR
                op_bsr(offset);
            } else { // Bcc
                op_bcc(cc, offset);
            }
            break;
        }

        case 0x07: { // MOVEQ
            if (opcode & 0x0100) {
                cycle_count_ += 4;
            } else {
                int8_t data = opcode & 0xFF;
                op_moveq(data, reg);
            }
            break;
        }

        case 0x08: { // OR / DIV / SBCD
            int op_type = (opcode >> 6) & 0x07;
            if (op_type == 3 && size_field == 3) { // DIVU.W
                op_divu(mode, r, reg);
            } else if (op_type == 7 && size_field == 3) { // DIVS.W
                op_divs(mode, r, reg);
            } else {
                bool ea_to_reg = !(opcode & 0x0100);
                op_or(size_field, mode, r, mode, reg, ea_to_reg);
            }
            break;
        }

        case 0x09: { // SUB / SUBX
            bool ea_to_reg = !(opcode & 0x0100);
            op_sub(size_field, mode, r, mode, reg, ea_to_reg);
            break;
        }

        case 0x0B: { // CMP / EOR
            if (opcode & 0x0100) { // EOR
                op_eor(size_field, reg, mode, r);
            } else { // CMP
                op_cmp(size_field, mode, r, reg);
            }
            break;
        }

        case 0x0C: { // AND / MUL / ABCD / EXG
            int op_type = (opcode >> 6) & 0x07;
            if (op_type == 3 && size_field == 3) { // MULU.W
                op_mulu(mode, r, reg);
            } else if (op_type == 7 && size_field == 3) { // MULS.W
                op_muls(mode, r, reg);
            } else {
                bool ea_to_reg = !(opcode & 0x0100);
                op_and(size_field, mode, r, mode, reg, ea_to_reg);
            }
            break;
        }

        case 0x0D: { // ADD / ADDX
            bool ea_to_reg = !(opcode & 0x0100);
            op_add(size_field, mode, r, mode, reg, ea_to_reg);
            break;
        }

        case 0x0E: { // Shifts and rotates
            int size = size_field;
            int dir = (opcode >> 8) & 0x01;
            int type = (opcode >> 3) & 0x03;
            int count_or_reg = (opcode >> 9) & 0x07;
            bool use_reg = (opcode & 0x0020) != 0;
            int count = use_reg ? (regs_[count_or_reg] & 0x3F) : count_or_reg;
            if (count == 0) count = 8;

            if (size == 3) { // Memory shift (1 bit)
                if (type == 0 && dir == 0) op_asl(2, 1, mode, r);
                else if (type == 0 && dir == 1) op_asr(2, 1, mode, r);
                else if (type == 1 && dir == 0) op_lsl(2, 1, mode, r);
                else if (type == 1 && dir == 1) op_lsr(2, 1, mode, r);
                else if (type == 2 && dir == 0) op_roxl(2, 1, mode, r);
                else if (type == 2 && dir == 1) op_roxr(2, 1, mode, r);
                else if (type == 3 && dir == 0) op_rol(2, 1, mode, r);
                else if (type == 3 && dir == 1) op_ror(2, 1, mode, r);
            } else {
                if (type == 0 && dir == 0) op_asl(size, count, 0, reg);
                else if (type == 0 && dir == 1) op_asr(size, count, 0, reg);
                else if (type == 1 && dir == 0) op_lsl(size, count, 0, reg);
                else if (type == 1 && dir == 1) op_lsr(size, count, 0, reg);
                else if (type == 2 && dir == 0) op_roxl(size, count, 0, reg);
                else if (type == 2 && dir == 1) op_roxr(size, count, 0, reg);
                else if (type == 3 && dir == 0) op_rol(size, count, 0, reg);
                else if (type == 3 && dir == 1) op_ror(size, count, 0, reg);
            }
            break;
        }

        case 0x0F: { // Line F (coprocessor / trap)
            if (opcode & 0x0800) {
                // Line 1111 — FPU (not implemented)
                raise_exception(EXC_LINE_1111);
            } else {
                // Line 1010 — A-line trap
                raise_exception(EXC_LINE_1010);
            }
            break;
        }

        default:
            cycle_count_ += 4;
            break;
    }

    // Handle specific opcodes that don't fit the major groups
    // Check for JMP, JSR, LEA, etc. (mode 7, reg specific)
    if (op == 0x04 && ((opcode >> 6) & 0x3F) == 0x3C) { // ANDI to CCR
        uint16_t imm = fetch16();
        sr_ &= imm;
        cycle_count_ += 16;
    }
    if (op == 0x00 && opcode == 0x007C) { // ORI to SR
        uint16_t imm = fetch16();
        if (is_supervisor()) sr_ |= imm;
        cycle_count_ += 20;
    }
    if (op == 0x0A && ((opcode >> 6) & 0x3F) == 0x3C) { // EORI to CCR
        uint16_t imm = fetch16();
        sr_ ^= imm;
        cycle_count_ += 16;
    }

    // JMP (4ED0-4ED7)
    if ((opcode & 0xFFF8) == 0x4ED0) {
        op_jmp(mode, r);
        break;
    }
    // JSR (4E90-4E97)
    if ((opcode & 0xFFF8) == 0x4E90) {
        op_jsr(mode, r);
        break;
    }
    // LEA (41C0-41FF)
    if ((opcode & 0xF1C0) == 0x41C0) {
        op_lea(mode, r, reg);
        break;
    }
    // RTS
    if (opcode == 0x4E75) { op_rts(); break; }
    // RTE
    if (opcode == 0x4E73) { op_rte(); break; }
    // NOP
    if (opcode == 0x4E71) { op_nop(); break; }
    // RESET
    if (opcode == 0x4E70) { op_reset(); break; }
    // STOP
    if (opcode == 0x4E72) { op_stop(); break; }
    // SWAP
    if ((opcode & 0xFFF8) == 0x4840) { op_swap(r); break; }
    // PEA
    if ((opcode & 0xFFC0) == 0x4840) { op_pea(mode, r); break; }
    // EXT
    if ((opcode & 0xFFF8) == 0x4880) { op_ext(2, r); break; }
    if ((opcode & 0xFFF8) == 0x48C0) { op_ext(4, r); break; }
    // LINK
    if ((opcode & 0xFFF8) == 0x4E50) { int16_t off = (int16_t)fetch16(); op_link(r, off); break; }
    // UNLK
    if ((opcode & 0xFFF8) == 0x4E58) { op_unlk(r); break; }
    // TRAP
    if ((opcode & 0xFFF0) == 0x4E40) { op_trap(r); break; }
    // TST
    if ((opcode & 0xFF00) == 0x4A00) {
        int tst_size = (opcode >> 6) & 0x03;
        if (tst_size == 0) op_tst(1, mode, r);
        else if (tst_size == 1) op_tst(2, mode, r);
        else op_tst(4, mode, r);
        break;
    }
    // NOT
    if ((opcode & 0xFF00) == 0x4600) {
        int not_size = (opcode >> 6) & 0x03;
        if (not_size == 0) op_not(1, mode, r);
        else if (not_size == 1) op_not(2, mode, r);
        else op_not(4, mode, r);
        break;
    }

    instruction_count_++;
    return 0;
}

void MC68000Core::run(uint64_t max_instructions) {
    while (!halted_ && instruction_count_ < max_instructions) {
        step();
    }
}

// ============================================================================
// Disassembly
// ============================================================================

std::string MC68000Core::disasm_at(uint32_t addr, int* bytes_consumed) {
    uint16_t opcode = read16(addr);
    std::ostringstream oss;
    oss << std::uppercase << std::hex << std::setfill('0');
    oss << std::setw(6) << addr << ":  ";
    oss << std::setw(4) << opcode << "  ";

    int op = (opcode >> 12) & 0xF;
    switch (op) {
        case 0x1: oss << "MOVE.B"; break;
        case 0x2: oss << "MOVE.L"; break;
        case 0x3: oss << "MOVE.W"; break;
        case 0x6: {
            int cc = (opcode >> 8) & 0xF;
            static const char* bcc_names[] = {
                "BRA","BSR","BHI","BLS","BCC","BCS","BNE","BEQ",
                "BVC","BVS","BPL","BMI","BGE","BLT","BGT","BLE"
            };
            oss << bcc_names[cc];
            break;
        }
        case 0x7: oss << "MOVEQ"; break;
        case 0x9: oss << "SUB"; break;
        case 0xD: oss << "ADD"; break;
        case 0xB: oss << ((opcode & 0x0100) ? "EOR" : "CMP"); break;
        case 0xC: oss << "AND"; break;
        case 0x8: oss << "OR"; break;
        case 0xE: oss << "SHIFT"; break;
        case 0x4: oss << "MISC"; break;
        default: oss << "???"; break;
    }

    if (bytes_consumed) *bytes_consumed = 2;
    return oss.str();
}

// ============================================================================
// State Save/Restore
// ============================================================================

std::vector<uint8_t> MC68000Core::save_state() const {
    std::vector<uint8_t> state;
    auto append = [&](const void* data, size_t len) {
        state.insert(state.end(), (const uint8_t*)data, (const uint8_t*)data + len);
    };
    for (int i = 0; i < 16; i++) append(&regs_[i], 4);
    append(&pc_, 4);
    append(&sr_, 2);
    append(&halted_, 1);
    append(&irq_pending_, 1);
    append(&irq_level_, 1);
    for (int i = 0; i < 8; i++) state.push_back((cycle_count_ >> (i*8)) & 0xFF);
    for (int i = 0; i < 8; i++) state.push_back((instruction_count_ >> (i*8)) & 0xFF);
    return state;
}

void MC68000Core::load_state(const std::vector<uint8_t>& state) {
    if (state.size() < 80) return;
    size_t off = 0;
    for (int i = 0; i < 16; i++) {
        regs_[i] = state[off] | (uint32_t(state[off+1]) << 8) |
                   (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24);
        off += 4;
    }
    pc_ = state[off] | (uint32_t(state[off+1]) << 8) |
          (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24);
    off += 4;
    sr_ = state[off] | (uint16_t(state[off+1]) << 8); off += 2;
    halted_ = state[off++] != 0;
    irq_pending_ = state[off++] != 0;
    irq_level_ = state[off++];
    if (state.size() >= off + 16) {
        cycle_count_ = 0; instruction_count_ = 0;
        for (int i = 0; i < 8; i++) cycle_count_ |= (uint64_t(state[off+i]) << (i*8));
        off += 8;
        for (int i = 0; i < 8; i++) instruction_count_ |= (uint64_t(state[off+i]) << (i*8));
    }
}

CpuStateSnapshot MC68000Core::get_snapshot() const {
    CpuStateSnapshot s;
    s.pc = pc_;
    s.next_pc = pc_;
    s.sp = regs_[15];
    for (int i = 0; i < 16; i++) s.regs[i] = regs_[i];
    s.cycle_count = cycle_count_;
    s.instruction_count = instruction_count_;
    s.halted = halted_;
    s.arch = ArchID::MC68000;
    return s;
}

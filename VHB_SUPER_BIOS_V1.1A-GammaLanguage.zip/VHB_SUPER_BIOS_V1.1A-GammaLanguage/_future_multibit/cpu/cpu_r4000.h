// =============================================================================
// cpu_r4000.h — MIPS R4000 Allegrex CPU Core (Clean-Room Implementation)
//
// Implements ICpuCore for the MIPS R4000 Allegrex processor used in the
// Portable-Media-32 target. This is a 32-bit MIPS III subset with extensions.
//
// Reference: MIPS R4000 User's Manual (public), github.com/ichfly/PSPEmu (GPL)
//
// Key features:
//   - 32 general-purpose 32-bit registers (GPR 0-31)
//   - 32 floating-point registers (FPR 0-31)
//   - HI/LO registers for multiply/divide results
//   - CP0 system control coprocessor (Status, Cause, EPC, etc.)
//   - 32-bit virtual addresses, 32-bit data paths
//   - Load/store architecture with delay slots
//   - TLB-based memory management (simplified for emulation)
//   - Allegrex-specific extensions: VFPU (vector FPU), media engine
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include <array>
#include <cstring>
#include <functional>

// ============================================================================
// R4000 Register Indices
// ============================================================================

enum R4000Reg {
    R4K_R0 = 0,  R4K_AT,  R4K_V0,  R4K_V1,
    R4K_A0,      R4K_A1,  R4K_A2,  R4K_A3,
    R4K_T0,      R4K_T1,  R4K_T2,  R4K_T3,
    R4K_T4,      R4K_T5,  R4K_T6,  R4K_T7,
    R4K_S0,      R4K_S1,  R4K_S2,  R4K_S3,
    R4K_S4,      R4K_S5,  R4K_S6,  R4K_S7,
    R4K_T8,      R4K_T9,  R4K_K0,  R4K_K1,
    R4K_GP,      R4K_SP,  R4K_FP,  R4K_RA,
    R4K_HI,      R4K_LO,
    R4K_PC,
    R4K_STATUS,  R4K_CAUSE, R4K_EPC,
};

// ============================================================================
// CP0 Registers
// ============================================================================

namespace R4000CP0 {
    enum Register {
        INDEX       = 0,
        RANDOM      = 1,
        ENTRYLO0    = 2,
        ENTRYLO1    = 3,
        CONTEXT     = 4,
        PAGEMASK    = 5,
        WIRED       = 6,
        BADVADDR    = 8,
        COUNT       = 9,
        ENTRYHI     = 10,
        COMPARE     = 11,
        STATUS      = 12,
        CAUSE       = 13,
        EPC         = 14,
        PRID        = 15,
        CONFIG      = 16,
    };
}

// ============================================================================
// Status Register Bits
// ============================================================================

namespace R4000Status {
    constexpr uint32_t IE   = 0x00000001;  // Interrupt enable
    constexpr uint32_t EXL  = 0x00000002;  // Exception level
    constexpr uint32_t ERL  = 0x00000004;  // Error level
    constexpr uint32_t KSU  = 0x00000018;  // Kernel/user mode (2 bits)
    constexpr uint32_t UX   = 0x00000010;  // 64-bit user mode (unused on Allegrex)
    constexpr uint32_t SX   = 0x00000020;  // 64-bit supervisor mode
    constexpr uint32_t KX   = 0x00000040;  // 64-bit kernel mode
    constexpr uint32_t IM   = 0x0000FF00;  // Interrupt mask (8 bits)
    constexpr uint32_t DS   = 0x00FF0000;  // Diagnostic status
    constexpr uint32_t BEV  = 0x00400000;  // Bootstrap exception vectors
    constexpr uint32_t FR   = 0x04000000;  // FPU register mode
    constexpr uint32_t CU0  = 0x10000000;  // CP0 usable
    constexpr uint32_t CU1  = 0x20000000;  // CP1 (FPU) usable
    constexpr uint32_t CU2  = 0x40000000;  // CP2 usable
}

// ============================================================================
// Cause Register Bits
// ============================================================================

namespace R4000Cause {
    constexpr uint32_t EXC_CODE = 0x0000007C;  // Exception code (5 bits, shifted 2)
    constexpr uint32_t IP       = 0x0000FF00;  // Interrupt pending (8 bits)
    constexpr uint32_t BD       = 0x80000000;  // Branch delay slot
}

// ============================================================================
// Exception Codes
// ============================================================================

namespace R4000ExcCode {
    constexpr uint32_t INT      = 0;    // Interrupt
    constexpr uint32_t TLB_MOD  = 1;    // TLB modification
    constexpr uint32_t TLBL     = 2;    // TLB load
    constexpr uint32_t TLBS     = 3;    // TLB store
    constexpr uint32_t ADEL     = 4;    // Address error (load)
    constexpr uint32_t ADES     = 5;    // Address error (store)
    constexpr uint32_t SYSCALL  = 8;    // System call
    constexpr uint32_t BP       = 9;    // Breakpoint
    constexpr uint32_t RI       = 10;   // Reserved instruction
    constexpr uint32_t CPU      = 11;   // Coprocessor unusable
    constexpr uint32_t OV       = 12;   // Arithmetic overflow
    constexpr uint32_t FPE      = 15;   // FPU exception
}

// ============================================================================
// MipsR4000Core
// =============================================================================

class MipsR4000Core : public ICpuCore {
public:
    MipsR4000Core();
    ~MipsR4000Core() override = default;

    // ----- ICpuCore: Execution -----
    int step() override;
    void run(uint64_t max_instructions) override;
    void reset() override;
    void halt() override { halted_ = true; }
    bool is_halted() const override { return halted_; }

    // ----- ICpuCore: Architecture Info -----
    ArchID get_arch_id() const override { return ArchID::MipsR4000; }
    const char* get_arch_name() const override { return "MIPS R4000 Allegrex"; }
    int get_bit_depth() const override { return 32; }
    bool is_big_endian() const override { return false; }  // Little-endian on Allegrex
    uint64_t get_clock_hz() const override { return 333000000; }  // 333 MHz
    uint64_t get_cycle_count() const override { return cycle_count_; }
    uint64_t get_instruction_count() const override { return instruction_count_; }

    // ----- ICpuCore: Register Access -----
    int get_reg_count() const override { return 37; }
    const char* get_reg_name(int index) const override;
    uint32_t get_reg(int index) const override;
    void set_reg(int index, uint32_t value) override;
    uint32_t get_pc() const override { return pc_; }
    void set_pc(uint32_t addr) override { pc_ = addr; next_pc_ = addr + 4; }
    uint32_t get_sp() const override { return gpr_[29]; }
    void set_sp(uint32_t value) override { gpr_[29] = value; }
    uint32_t get_flags() const override { return cp0_status_; }
    void set_flags(uint32_t value) override { cp0_status_ = value; }

    // ----- ICpuCore: Memory Access -----
    uint8_t  read8(uint32_t addr) override;
    uint16_t read16(uint32_t addr) override;
    uint32_t read32(uint32_t addr) override;
    void     write8(uint32_t addr, uint8_t value) override;
    void     write16(uint32_t addr, uint16_t value) override;
    void     write32(uint32_t addr, uint32_t value) override;

    // ----- ICpuCore: Interrupts -----
    void raise_interrupt(uint32_t vector) override;
    void trigger_exception(uint32_t cause, uint32_t epc) override;
    bool has_pending_interrupt() const override { return irq_pending_; }
    void acknowledge_interrupt() override { irq_pending_ = false; }

    // ----- ICpuCore: Disassembly -----
    std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) override;

    // ----- ICpuCore: State Save/Restore -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;
    CpuStateSnapshot get_snapshot() const override;

    // ----- R4000-specific -----
    void set_memory_callbacks(
        std::function<uint8_t(uint32_t)> read_cb,
        std::function<void(uint32_t, uint8_t)> write_cb
    ) {
        mem_read_ = read_cb;
        mem_write_ = write_cb;
    }

    // CP0 access
    uint32_t get_cp0(int reg) const;
    void set_cp0(int reg, uint32_t value);

    // FPR access
    float get_fpr(int reg) const;
    void set_fpr(int reg, float value);
    uint32_t get_fpr_raw(int reg) const;
    void set_fpr_raw(int reg, uint32_t value);

    // IRQ line control
    void set_irq_line(int line, bool active);

private:
    // General purpose registers
    std::array<uint32_t, 32> gpr_ = {};
    uint32_t hi_ = 0;
    uint32_t lo_ = 0;
    uint32_t pc_ = 0;
    uint32_t next_pc_ = 0;

    // CP0 registers
    uint32_t cp0_index_ = 0;
    uint32_t cp0_random_ = 0;
    uint32_t cp0_entrylo0_ = 0;
    uint32_t cp0_entrylo1_ = 0;
    uint32_t cp0_context_ = 0;
    uint32_t cp0_pagemask_ = 0;
    uint32_t cp0_wired_ = 0;
    uint32_t cp0_badvaddr_ = 0;
    uint32_t cp0_count_ = 0;
    uint32_t cp0_entryhi_ = 0;
    uint32_t cp0_compare_ = 0;
    uint32_t cp0_status_ = 0;
    uint32_t cp0_cause_ = 0;
    uint32_t cp0_epc_ = 0;
    uint32_t cp0_prid_ = 0;
    uint32_t cp0_config_ = 0;

    // FPU registers (CP1)
    std::array<uint32_t, 32> fpr_ = {};
    uint32_t fcr31_ = 0;  // FPU control/status register

    // State
    bool halted_ = false;
    bool irq_pending_ = false;
    uint8_t irq_lines_ = 0;  // Bit mask of active IRQ lines
    bool in_delay_slot_ = false;
    uint64_t cycle_count_ = 0;
    uint64_t instruction_count_ = 0;

    // Memory callbacks
    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t, uint8_t)> mem_write_;

    // ----- Helpers -----
    inline uint32_t fetch32() {
        uint32_t val = read32(pc_);
        pc_ = next_pc_;
        next_pc_ = pc_ + 4;
        return val;
    }

    inline void branch(uint32_t target) {
        next_pc_ = target;
    }

    inline void check_interrupts();

    // Exception handling
    void raise_exception(uint32_t exc_code, bool in_delay_slot = false);

    // Instruction handlers
    void op_special(uint32_t instr);
    void op_regimm(uint32_t instr);
    void op_cop0(uint32_t instr);
    void op_cop1(uint32_t instr);

    // R-type (special) operations
    void op_sll(uint32_t instr);
    void op_srl(uint32_t instr);
    void op_sra(uint32_t instr);
    void op_sllv(uint32_t instr);
    void op_srlv(uint32_t instr);
    void op_srav(uint32_t instr);
    void op_jr(uint32_t instr);
    void op_jalr(uint32_t instr);
    void op_mfhi(uint32_t instr);
    void op_mthi(uint32_t instr);
    void op_mflo(uint32_t instr);
    void op_mtlo(uint32_t instr);
    void op_mult(uint32_t instr);
    void op_multu(uint32_t instr);
    void op_div(uint32_t instr);
    void op_divu(uint32_t instr);
    void op_add(uint32_t instr);
    void op_addu(uint32_t instr);
    void op_sub(uint32_t instr);
    void op_subu(uint32_t instr);
    void op_and(uint32_t instr);
    void op_or(uint32_t instr);
    void op_xor(uint32_t instr);
    void op_nor(uint32_t instr);
    void op_slt(uint32_t instr);
    void op_sltu(uint32_t instr);
    void op_syscall(uint32_t instr);
    void op_break(uint32_t instr);

    // I-type operations
    void op_beq(uint32_t instr);
    void op_bne(uint32_t instr);
    void op_blez(uint32_t instr);
    void op_bgtz(uint32_t instr);
    void op_addi(uint32_t instr);
    void op_addiu(uint32_t instr);
    void op_slti(uint32_t instr);
    void op_sltiu(uint32_t instr);
    void op_andi(uint32_t instr);
    void op_ori(uint32_t instr);
    void op_xori(uint32_t instr);
    void op_lui(uint32_t instr);
    void op_lb(uint32_t instr);
    void op_lh(uint32_t instr);
    void op_lw(uint32_t instr);
    void op_lbu(uint32_t instr);
    void op_lhu(uint32_t instr);
    void op_sb(uint32_t instr);
    void op_sh(uint32_t instr);
    void op_sw(uint32_t instr);

    // J-type operations
    void op_j(uint32_t instr);
    void op_jal(uint32_t instr);
};

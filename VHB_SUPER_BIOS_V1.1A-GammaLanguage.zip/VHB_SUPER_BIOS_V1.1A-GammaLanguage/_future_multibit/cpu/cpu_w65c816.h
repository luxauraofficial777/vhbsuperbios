// =============================================================================
// cpu_w65c816.h — WDC 65C816 CPU Core (Clean-Room Implementation)
//
// Implements ICpuCore for the WDC W65C816S 16-bit microprocessor.
// Reference: W65C816S datasheet (public), github.com/bslenul/W65C816S-Core (MIT)
//
// The 65C816 is a 16-bit successor to the 6502 with:
//   - 8-bit accumulator (A) with 8-bit B register (BA = 16-bit C)
//   - 16-bit X and Y index registers (configurable 8/16-bit)
//   - 16-bit stack pointer (SP)
//   - 24-bit program counter (PC + PBR)
//   - 24-bit direct page register (D)
//   - 8-bit data bank register (DBR)
//   - 8-bit status register (P) with MX flags for register width
//   - 24-bit address bus (16MB address space)
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include <array>
#include <cstring>
#include <functional>

// ============================================================================
// 65C816 Register Indices
// ============================================================================

enum W65C816Reg {
    REG816_A  = 0,   // Accumulator (low 8 bits)
    REG816_B  = 1,   // B accumulator (high 8 bits)
    REG816_C  = 2,   // C = BA (16-bit accumulator)
    REG816_X  = 3,   // X index
    REG816_Y  = 4,   // Y index
    REG816_SP = 5,   // Stack pointer
    REG816_D  = 6,   // Direct page register
    REG816_PBR = 7,  // Program bank register
    REG816_DBR = 8,  // Data bank register
    REG816_P  = 9,   // Status flags
    REG816_PC = 10,  // Program counter (16-bit)
};

// ============================================================================
// 65C816 Status Flags
// ============================================================================

namespace W65C816Flags {
    constexpr uint8_t C = 0x01;  // Carry
    constexpr uint8_t Z = 0x02;  // Zero
    constexpr uint8_t I = 0x04;  // Interrupt disable
    constexpr uint8_t D = 0x08;  // Decimal mode
    constexpr uint8_t X = 0x10;  // Index width (0=16-bit, 1=8-bit)
    constexpr uint8_t M = 0x20;  // Memory/Accumulator width (0=16-bit, 1=8-bit)
    constexpr uint8_t V = 0x40;  // Overflow
    constexpr uint8_t N = 0x80;  // Negative
    constexpr uint8_t E = 0x100; // Emulation mode flag (not in P register)
}

// ============================================================================
// W65C816Core
// ============================================================================

class W65C816Core : public ICpuCore {
public:
    W65C816Core();
    ~W65C816Core() override = default;

    // ----- ICpuCore: Execution -----
    int step() override;
    void run(uint64_t max_instructions) override;
    void reset() override;
    void halt() override { halted_ = true; }
    bool is_halted() const override { return halted_; }

    // ----- ICpuCore: Architecture Info -----
    ArchID get_arch_id() const override { return ArchID::W65C816; }
    const char* get_arch_name() const override { return "WDC 65C816"; }
    int get_bit_depth() const override { return 16; }
    bool is_big_endian() const override { return false; }
    uint64_t get_clock_hz() const override { return 3580000; }  // ~3.58 MHz
    uint64_t get_cycle_count() const override { return cycle_count_; }
    uint64_t get_instruction_count() const override { return instruction_count_; }

    // ----- ICpuCore: Register Access -----
    int get_reg_count() const override { return 11; }
    const char* get_reg_name(int index) const override;
    uint32_t get_reg(int index) const override;
    void set_reg(int index, uint32_t value) override;
    uint32_t get_pc() const override { return pc_; }
    void set_pc(uint32_t addr) override { pc_ = addr & 0xFFFF; }
    uint32_t get_sp() const override { return sp_; }
    void set_sp(uint32_t value) override { sp_ = value & 0xFFFF; }
    uint32_t get_flags() const override { return p_ | (emulation_ ? W65C816Flags::E : 0); }
    void set_flags(uint32_t value) override {
        p_ = value & 0xFF;
        emulation_ = (value & W65C816Flags::E) != 0;
    }

    // ----- ICpuCore: Memory Access -----
    uint8_t  read8(uint32_t addr) override;
    uint16_t read16(uint32_t addr) override;
    uint32_t read32(uint32_t addr) override;
    void     write8(uint32_t addr, uint8_t value) override;
    void     write16(uint32_t addr, uint16_t value) override;
    void     write32(uint32_t addr, uint32_t value) override;

    // ----- ICpuCore: Interrupts -----
    void raise_interrupt(uint32_t vector) override;
    void trigger_exception(uint32_t cause, uint32_t epc) override;
    bool has_pending_interrupt() const override { return irq_pending_; }
    void acknowledge_interrupt() override { irq_pending_ = false; }

    // ----- ICpuCore: Disassembly -----
    std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) override;

    // ----- ICpuCore: State Save/Restore -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;
    CpuStateSnapshot get_snapshot() const override;

    // ----- 65C816-specific -----
    void set_nmi(bool active) { nmi_pending_ = active; }
    void set_irq(bool active) { irq_pending_ = active; }
    void set_emulation_mode(bool emu);

    void set_memory_callbacks(
        std::function<uint8_t(uint32_t)> read_cb,
        std::function<void(uint32_t, uint8_t)> write_cb
    ) {
        mem_read_ = read_cb;
        mem_write_ = write_cb;
    }

    // Bank-aware memory access
    uint8_t  read_bank(uint8_t bank, uint16_t addr) { return read8((uint32_t(bank) << 16) | addr); }
    void     write_bank(uint8_t bank, uint16_t addr, uint8_t val) { write8((uint32_t(bank) << 16) | addr, val); }

private:
    // Registers
    uint8_t a_ = 0;        // Accumulator (low 8 bits)
    uint8_t b_ = 0;        // B register (high 8 bits of C)
    uint16_t x_ = 0;       // X index
    uint16_t y_ = 0;       // Y index
    uint16_t sp_ = 0x01FD; // Stack pointer
    uint16_t pc_ = 0;      // Program counter (within bank)
    uint8_t pbr_ = 0;      // Program bank register
    uint8_t dbr_ = 0;      // Data bank register
    uint16_t d_ = 0;       // Direct page register
    uint8_t p_ = 0x34;     // Status flags (I=1, M=1, X=1)
    bool emulation_ = true; // Start in emulation mode

    // State
    bool halted_ = false;
    bool irq_pending_ = false;
    bool nmi_pending_ = false;
    uint64_t cycle_count_ = 0;
    uint64_t instruction_count_ = 0;

    // Memory callbacks
    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t, uint8_t)> mem_write_;

    // ----- Helpers -----
    inline bool is_8bit_accum() const { return (p_ & W65C816Flags::M) != 0 || emulation_; }
    inline bool is_8bit_index() const { return (p_ & W65C816Flags::X) != 0 || emulation_; }

    inline uint16_t get_c() const { return a_ | (uint16_t(b_) << 8); }
    inline void set_c(uint16_t val) { a_ = val & 0xFF; b_ = (val >> 8) & 0xFF; }

    inline uint32_t full_pc() const { return (uint32_t(pbr_) << 16) | pc_; }

    inline uint8_t fetch() {
        uint8_t val = read8(full_pc());
        pc_++;
        return val;
    }

    inline uint16_t fetch16() {
        uint16_t lo = fetch();
        uint16_t hi = fetch();
        return lo | (hi << 8);
    }

    inline uint24_t fetch24() {
        uint16_t lo = fetch16();
        uint8_t bank = fetch();
        return (uint32_t(bank) << 16) | lo;
    }

    inline void push(uint8_t val) {
        if (emulation_) {
            write8(0x0100 | (sp_ & 0xFF), val);
            sp_ = (sp_ & 0xFF00) | ((sp_ - 1) & 0xFF);
        } else {
            write8(sp_, val);
            sp_--;
        }
    }

    inline uint8_t pop() {
        if (emulation_) {
            sp_ = (sp_ & 0xFF00) | ((sp_ + 1) & 0xFF);
            return read8(0x0100 | (sp_ & 0xFF));
        } else {
            sp_++;
            return read8(sp_);
        }
    }

    inline void push16(uint16_t val) {
        push(val >> 8);
        push(val & 0xFF);
    }

    inline uint16_t pop16() {
        uint8_t lo = pop();
        uint8_t hi = pop();
        return lo | (uint16_t(hi) << 8);
    }

    inline void push24(uint32_t val) {
        push((val >> 16) & 0xFF);
        push((val >> 8) & 0xFF);
        push(val & 0xFF);
    }

    inline uint32_t pop24() {
        uint8_t lo = pop();
        uint8_t hi = pop();
        uint8_t bank = pop();
        return lo | (uint32_t(hi) << 8) | (uint32_t(bank) << 16);
    }

    // Flag helpers
    inline void set_zn8(uint8_t val) {
        if (val == 0) p_ |= W65C816Flags::Z; else p_ &= ~W65C816Flags::Z;
        if (val & 0x80) p_ |= W65C816Flags::N; else p_ &= ~W65C816Flags::N;
    }

    inline void set_zn16(uint16_t val) {
        if (val == 0) p_ |= W65C816Flags::Z; else p_ &= ~W65C816Flags::Z;
        if (val & 0x8000) p_ |= W65C816Flags::N; else p_ &= ~W65C816Flags::N;
    }

    inline void set_flag(uint8_t flag, bool condition) {
        if (condition) p_ |= flag; else p_ &= ~flag;
    }

    // Addressing modes
    uint32_t addr_immediate();
    uint32_t addr_direct();
    uint32_t addr_direct_x();
    uint32_t addr_direct_y();
    uint32_t addr_absolute();
    uint32_t addr_absolute_x();
    uint32_t addr_absolute_y();
    uint32_t addr_long();
    uint32_t addr_long_x();
    uint32_t addr_direct_indirect();
    uint32_t addr_direct_indirect_y();
    uint32_t addr_direct_indexed_indirect();
    uint32_t addr_direct_indirect_indexed();
    uint32_t addr_absolute_indirect();
    uint32_t addr_absolute_indirect_long();
    uint32_t addr_absolute_x_indirect();
    uint32_t addr_relative();
    uint32_t addr_relative_long();
    uint32_t addr_stack();
    uint32_t addr_stack_relative_indirect_y();

    // Interrupt handling
    void handle_irq();
    void handle_nmi();
    void handle_abort();
    void handle_cop();
    void handle_brk();

    // Opcode table
    struct OpcodeEntry {
        void (W65C816Core::*handler)(uint32_t);
        uint32_t (W65C816Core::*addr_mode)();
        int cycles;
        const char* mnemonic;
    };
    static const OpcodeEntry opcode_table_[256];
    void init_opcode_table();

    // Instruction handlers (selected key ones for initial implementation)
    void op_adc(uint32_t addr);
    void op_and(uint32_t addr);
    void op_asl(uint32_t addr);
    void op_bcc(uint32_t addr);
    void op_bcs(uint32_t addr);
    void op_beq(uint32_t addr);
    void op_bit(uint32_t addr);
    void op_bmi(uint32_t addr);
    void op_bne(uint32_t addr);
    void op_bpl(uint32_t addr);
    void op_bra(uint32_t addr);
    void op_brl(uint32_t addr);
    void op_bvc(uint32_t addr);
    void op_bvs(uint32_t addr);
    void op_clc();
    void op_cld();
    void op_cli();
    void op_clv();
    void op_cmp(uint32_t addr);
    void op_cop();
    void op_cpx(uint32_t addr);
    void op_cpy(uint32_t addr);
    void op_dec(uint32_t addr);
    void op_dex();
    void op_dey();
    void op_eor(uint32_t addr);
    void op_inc(uint32_t addr);
    void op_inx();
    void op_iny();
    void op_jmp(uint32_t addr);
    void op_jml(uint32_t addr);
    void op_jsr(uint32_t addr);
    void op_jsl(uint32_t addr);
    void op_lda(uint32_t addr);
    void op_ldx(uint32_t addr);
    void op_ldy(uint32_t addr);
    void op_lsr(uint32_t addr);
    void op_mvn();
    void op_mvp();
    void op_nop();
    void op_ora(uint32_t addr);
    void op_pea(uint32_t addr);
    void op_pei(uint32_t addr);
    void op_per(uint32_t addr);
    void op_pha();
    void op_phb();
    void op_phd();
    void op_phk();
    void op_php();
    void op_phx();
    void op_phy();
    void op_pla();
    void op_plb();
    void op_pld();
    void op_plp();
    void op_plx();
    void op_ply();
    void op_rep();
    void op_rol(uint32_t addr);
    void op_ror(uint32_t addr);
    void op_rti();
    void op_rtl();
    void op_rts();
    void op_sbc(uint32_t addr);
    void op_sec();
    void op_sed();
    void op_sei();
    void op_sep();
    void op_sta(uint32_t addr);
    void op_stp();
    void op_stx(uint32_t addr);
    void op_sty(uint32_t addr);
    void op_stz(uint32_t addr);
    void op_tax();
    void op_tay();
    void op_tcd();
    void op_tcs();
    void op_tdc();
    void op_trb(uint32_t addr);
    void op_tsb(uint32_t addr);
    void op_tsc();
    void op_tsx();
    void op_txa();
    void op_txs();
    void op_txy();
    void op_tya();
    void op_tyx();
    void op_wai();
    void op_wdm();
    void op_xba();
    void op_xce();
};

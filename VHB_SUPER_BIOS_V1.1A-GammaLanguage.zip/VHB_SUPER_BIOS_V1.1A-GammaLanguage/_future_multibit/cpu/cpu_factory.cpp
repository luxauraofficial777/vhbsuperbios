// =============================================================================
// cpu_factory.cpp — CPU Core Factory Implementation
//
// Creates CPU cores by architecture ID. Currently only MIPS R3000A is
// implemented (delegating to existing psx_core.cpp). Other cores return
// nullptr until their implementations are complete.
//
// Clean-room design: no proprietary names, no SDK headers.
// =============================================================================

#include "icpu_core.h"
#include <cstdio>

// Include all implemented CPU core headers
#include "cpu_m6502.h"
#include "cpu_w65c816.h"
#include "cpu_mc68000.h"
#include "cpu_r4000.h"
#include "cpu_arm7.h"
#include "cpu_sh2.h"
#include "cpu_r4300.h"
// LR35902 and Z80 are pending future phases

// ============================================================================
// Factory
// ============================================================================

ICpuCore* create_cpu_core(ArchID arch) {
    switch (arch) {
        case ArchID::M6502:
            return new M6502Core();

        case ArchID::LR35902:
            fprintf(stderr, "[CPU] LR35902 core not yet implemented — pending future phase\n");
            return nullptr;

        case ArchID::Z80:
            fprintf(stderr, "[CPU] Z80 core not yet implemented — pending future phase\n");
            return nullptr;

        case ArchID::W65C816:
            return new W65C816Core();

        case ArchID::MC68000:
            return new MC68000Core();

        case ArchID::ARM7TDMI:
            return new Arm7TDMICore();

        case ArchID::SH2:
            return new Sh2Core();

        case ArchID::MipsR3000A:
            // The existing PSXEmulator class will be refactored to implement ICpuCore.
            // For now, Phase 1 defines the interface; the adapter wrapper is pending.
            fprintf(stderr, "[CPU] MIPS R3000A core: use existing PSXEmulator directly (adapter pending)\n");
            return nullptr;

        case ArchID::MipsR4000:
            return new MipsR4000Core();

        case ArchID::MipsR4300:
            return new MipsR4300Core();

        default:
            fprintf(stderr, "[CPU] Unknown architecture ID %d\n", (int)arch);
            return nullptr;
    }
}

// ============================================================================
// Media Detection
// ============================================================================

ArchID detect_arch_from_media(const uint8_t* header, size_t len) {
    if (!header || len < 4) return ArchID::Unknown;

    // iNES format: "NES\x1A" (0x4E 0x45 0x53 0x1A)
    if (len >= 4 && header[0] == 0x4E && header[1] == 0x45 &&
        header[2] == 0x53 && header[3] == 0x1A) {
        return ArchID::M6502;
    }

    // PS-X EXE: "PS-X EXE" at offset 0
    if (len >= 8 && header[0] == 'P' && header[1] == 'S' &&
        header[2] == '-' && header[3] == 'X' && header[4] == ' ' &&
        header[5] == 'E' && header[6] == 'X' && header[7] == 'E') {
        return ArchID::MipsR3000A;
    }

    // CD-16: "SEGA" at offset 0x100 or 0x0
    if (len >= 0x110) {
        if (header[0x100] == 'S' && header[0x101] == 'E' &&
            header[0x102] == 'G' && header[0x103] == 'A') {
            return ArchID::MC68000;
        }
    }

    // Portable-Media-32: "PSP_GAME" in volume ID (offset 0x8000+40 in ISO 9660)
    if (len >= 0x8030) {
        if (header[0x8028] == 'P' && header[0x8029] == 'S' &&
            header[0x802A] == 'P' && header[0x802B] == '_') {
            return ArchID::MipsR4000;
        }
    }

    // Handheld-8: Nintendo logo at offset 0x104 (48 bytes of specific pattern)
    if (len >= 0x150) {
        // Check for the Nintendo logo checksum pattern (simplified)
        // The logo at 0x104 starts with 0xCE 0xEF 0x31 0x0E...
        if (header[0x104] == 0xCE && header[0x105] == 0xEF &&
            header[0x106] == 0x31 && header[0x107] == 0x0E) {
            return ArchID::LR35902;
        }
    }

    // Handheld-32: Nintendo logo at offset 0x04 (24-byte pattern)
    if (len >= 0xC0) {
        // GBA ROM header starts with 0x24 0xFF 0xAE 0x51 0x69 0x9A 0xA2 0x21
        if (header[0x04] == 0x24 && header[0x05] == 0xFF &&
            header[0x06] == 0xAE && header[0x07] == 0x51) {
            return ArchID::ARM7TDMI;
        }
    }

    // Cart-64: 6102 boot code — check for "80 37 12 40" (z64 format)
    if (len >= 4) {
        if (header[0] == 0x80 && header[1] == 0x37 &&
            header[2] == 0x12 && header[3] == 0x40) {
            return ArchID::MipsR4300;
        }
        // .n64 format (byte-swapped): "37 80 40 12"
        if (header[0] == 0x37 && header[1] == 0x80 &&
            header[2] == 0x40 && header[3] == 0x12) {
            return ArchID::MipsR4300;
        }
    }

    // Tile-16: Check internal header at offset 0x7FC0 (LoROM) or 0xFFC0 (HiROM)
    if (len >= 0xFFD5) {
        // SNES ROM has "21" at 0x7FD5 or 0xFFD5 (maker code area)
        // More reliable: check for SNES reset vector at 0x7FFC/0xFFFC
        // This is a heuristic — full detection requires checksum validation
    }

    return ArchID::Unknown;
}

// ============================================================================
// Helper Functions
// ============================================================================

const char* arch_bit_depth_name(ArchID arch) {
    switch (arch) {
        case ArchID::M6502:     return "8-bit";
        case ArchID::LR35902:   return "8-bit";
        case ArchID::Z80:       return "8-bit";
        case ArchID::W65C816:   return "16-bit";
        case ArchID::MC68000:   return "16-bit";
        case ArchID::ARM7TDMI:  return "32-bit";
        case ArchID::SH2:       return "32-bit";
        case ArchID::MipsR3000A:return "32-bit";
        case ArchID::MipsR4000: return "32-bit";
        case ArchID::MipsR4300: return "64-bit";
        default:                return "unknown";
    }
}

const char* arch_working_title(ArchID arch) {
    switch (arch) {
        case ArchID::M6502:     return "Tile-8";
        case ArchID::LR35902:   return "Handheld-8";
        case ArchID::Z80:       return "Tile-8Z";
        case ArchID::W65C816:   return "Tile-16";
        case ArchID::MC68000:   return "CD-16";
        case ArchID::ARM7TDMI:  return "Handheld-32";
        case ArchID::SH2:       return "CD-32X";
        case ArchID::MipsR3000A:return "CD-24/CD-32";
        case ArchID::MipsR4000: return "Portable-Media-32";
        case ArchID::MipsR4300: return "Cart-64";
        default:                return "Unknown";
    }
}

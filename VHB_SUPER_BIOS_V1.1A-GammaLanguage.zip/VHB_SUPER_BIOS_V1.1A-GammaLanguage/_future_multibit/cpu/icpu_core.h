// =============================================================================
// icpu_core.h — Universal CPU Core Interface for Multi-Bit-Depth Platform
//
// All CPU cores (M6502, LR35902, Z80, W65C816, MC68000, ARM7TDMI, SH-2,
// MIPS R3000A, MIPS R4000, MIPS R4300) implement this interface.
// The harness uses ICpuCore* for telemetry, freeze detection, and control
// regardless of the target architecture.
//
// Clean-room design: no proprietary names, no SDK headers, no firmware dumps.
// =============================================================================

#pragma once

#include <cstdint>
#include <string>
#include <vector>

// ============================================================================
// Architecture IDs
// ============================================================================

enum class ArchID : uint8_t {
    Unknown     = 0,
    M6502       = 1,    // 8-bit: MOS 6502 — Tile-8
    LR35902     = 2,    // 8-bit: Sharp SM83 — Handheld-8
    Z80         = 3,    // 8-bit: Zilog Z80 — Tile-8Z / CD-16Z
    W65C816     = 4,    // 16-bit: WDC 65C816 — Tile-16
    MC68000     = 5,    // 16-bit: Motorola 68000 — CD-16
    ARM7TDMI    = 6,    // 32-bit: ARMv4T — Handheld-32
    SH2         = 7,    // 32-bit: Hitachi SH-7604 — CD-32X
    MipsR3000A  = 8,    // 32-bit: MIPS I — CD-24 / CD-32
    MipsR4000   = 9,    // 32-bit: MIPS III (Allegrex) — Portable-Media-32
    MipsR4300   = 10,   // 64-bit: MIPS III (VR4300) — Cart-64
};

// ============================================================================
// CPU State Snapshot (for harness telemetry and savestates)
// ============================================================================

struct CpuStateSnapshot {
    uint32_t pc = 0;
    uint32_t next_pc = 0;
    uint32_t sp = 0;
    uint32_t regs[32] = {};
    uint32_t hi = 0;
    uint32_t lo = 0;
    uint64_t cycle_count = 0;
    uint64_t instruction_count = 0;
    bool halted = false;
    bool waiting_for_interrupt = false;
    ArchID arch = ArchID::Unknown;
};

// ============================================================================
// ICpuCore — Universal CPU Interface
// ============================================================================

class ICpuCore {
public:
    virtual ~ICpuCore() = default;

    // ----- Execution --------------------------------------------------------

    // Execute one instruction. Returns 0 on success, negative on error.
    virtual int step() = 0;

    // Run until max_instructions reached or halt condition.
    virtual void run(uint64_t max_instructions) = 0;

    // Cold reset — initialize CPU to power-on state.
    virtual void reset() = 0;

    // Soft halt — stop execution but preserve state.
    virtual void halt() = 0;

    // Check if CPU is in a halted state.
    virtual bool is_halted() const = 0;

    // ----- Architecture Info ------------------------------------------------

    // Return the architecture ID for this core.
    virtual ArchID get_arch_id() const = 0;

    // Return human-readable architecture name (e.g., "MOS 6502", "MIPS R3000A").
    virtual const char* get_arch_name() const = 0;

    // Return bit depth: 8, 16, 24, 32, or 64.
    virtual int get_bit_depth() const = 0;

    // Return true if this architecture is big-endian.
    virtual bool is_big_endian() const = 0;

    // Return the clock speed in Hz (for cycle-accurate timing).
    virtual uint64_t get_clock_hz() const = 0;

    // Return total cycles executed since reset.
    virtual uint64_t get_cycle_count() const = 0;

    // Return total instructions executed since reset.
    virtual uint64_t get_instruction_count() const = 0;

    // ----- Register Access --------------------------------------------------

    // Number of general-purpose registers.
    virtual int get_reg_count() const = 0;

    // Get register name by index (e.g., "A", "X", "Y" for 6502; "$r0".."$r31" for MIPS).
    virtual const char* get_reg_name(int index) const = 0;

    // Get register value by index (zero-extended to 32-bit).
    virtual uint32_t get_reg(int index) const = 0;

    // Set register value by index.
    virtual void set_reg(int index, uint32_t value) = 0;

    // Get program counter.
    virtual uint32_t get_pc() const = 0;

    // Set program counter.
    virtual void set_pc(uint32_t addr) = 0;

    // Get stack pointer.
    virtual uint32_t get_sp() const = 0;

    // Set stack pointer.
    virtual void set_sp(uint32_t value) = 0;

    // Get status/flags register (architecture-specific encoding).
    virtual uint32_t get_flags() const = 0;

    // Set status/flags register.
    virtual void set_flags(uint32_t value) = 0;

    // ----- Memory Access ----------------------------------------------------
    // These delegate to the Unified Memory Manager (UMM).

    virtual uint8_t  read8(uint32_t addr) = 0;
    virtual uint16_t read16(uint32_t addr) = 0;
    virtual uint32_t read32(uint32_t addr) = 0;
    virtual void     write8(uint32_t addr, uint8_t value) = 0;
    virtual void     write16(uint32_t addr, uint16_t value) = 0;
    virtual void     write32(uint32_t addr, uint32_t value) = 0;

    // ----- Interrupts and Exceptions ----------------------------------------

    // Raise a hardware interrupt with the given vector number.
    virtual void raise_interrupt(uint32_t vector) = 0;

    // Trigger a CPU exception with cause code and faulting PC.
    virtual void trigger_exception(uint32_t cause, uint32_t epc) = 0;

    // Check if any interrupts are pending.
    virtual bool has_pending_interrupt() const = 0;

    // Acknowledge and clear the current interrupt.
    virtual void acknowledge_interrupt() = 0;

    // ----- Disassembly ------------------------------------------------------

    // Disassemble one instruction at the given address.
    // Returns the disassembly string and advances addr past the instruction.
    virtual std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) = 0;

    // ----- State Save/Restore -----------------------------------------------

    // Serialize full CPU state to a byte vector (for savestates and harness rewind).
    virtual std::vector<uint8_t> save_state() const = 0;

    // Restore CPU state from a byte vector.
    virtual void load_state(const std::vector<uint8_t>& state) = 0;

    // Get a lightweight state snapshot (for harness telemetry polling).
    virtual CpuStateSnapshot get_snapshot() const = 0;
};

// ============================================================================
// CPU Core Factory
// ============================================================================

// Create a CPU core for the given architecture.
// Returns nullptr if the architecture is not yet implemented.
ICpuCore* create_cpu_core(ArchID arch);

// Get the ArchID from a media header magic bytes.
// Used by the UBM to auto-detect the target architecture.
ArchID detect_arch_from_media(const uint8_t* header, size_t len);

// Get the bit depth string for an architecture.
const char* arch_bit_depth_name(ArchID arch);

// Get the working title for an architecture.
const char* arch_working_title(ArchID arch);

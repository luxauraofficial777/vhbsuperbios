// =============================================================================
// cpu_m6502.h — MOS 6502 CPU Core (Clean-Room Implementation)
//
// Implements ICpuCore for the MOS 6502 8-bit microprocessor.
// Reference: github.com/64epicks/6502 (MIT), github.com/suzukiplan/M6502 (MIT)
// This is a clean-room reimplementation based on public 6502 documentation.
//
// The 6502 has:
//   - 8-bit accumulator (A), X and Y index registers
//   - 8-bit stack pointer (SP) at page 1 (0x0100-0x01FF)
//   - 16-bit program counter (PC)
//   - 7-bit status register (P): N V - B D I Z C
//
// Addressing modes: immediate, zero-page, absolute, zero-page,X, absolute,X,
//   absolute,Y, (indirect,X), (indirect),Y, accumulator, implied, relative
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include <array>
#include <cstring>

// ============================================================================
// 6502 Register Indices (for ICpuCore::get_reg / set_reg)
// ============================================================================

enum M6502Reg {
    REG_A  = 0,   // Accumulator
    REG_X  = 1,   // X index
    REG_Y  = 2,   // Y index
    REG_SP = 3,   // Stack pointer
    REG_P  = 4,   // Status flags
    REG_PC = 5,   // Program counter (low 16 bits of 32-bit return)
};

// ============================================================================
// 6502 Status Flags
// ============================================================================

namespace M6502Flags {
    constexpr uint8_t C = 0x01;  // Carry
    constexpr uint8_t Z = 0x02;  // Zero
    constexpr uint8_t I = 0x04;  // Interrupt disable
    constexpr uint8_t D = 0x08;  // Decimal mode
    constexpr uint8_t B = 0x10;  // Break command
    constexpr uint8_t U = 0x20;  // Unused (always 1)
    constexpr uint8_t V = 0x40;  // Overflow
    constexpr uint8_t N = 0x80;  // Negative
}

// ============================================================================
// M6502Core
// ============================================================================

class M6502Core : public ICpuCore {
public:
    M6502Core();
    ~M6502Core() override = default;

    // ----- ICpuCore: Execution -----
    int step() override;
    void run(uint64_t max_instructions) override;
    void reset() override;
    void halt() override { halted_ = true; }
    bool is_halted() const override { return halted_; }

    // ----- ICpuCore: Architecture Info -----
    ArchID get_arch_id() const override { return ArchID::M6502; }
    const char* get_arch_name() const override { return "MOS 6502"; }
    int get_bit_depth() const override { return 8; }
    bool is_big_endian() const override { return false; }
    uint64_t get_clock_hz() const override { return 1789773; }  // NTSC 6502
    uint64_t get_cycle_count() const override { return cycle_count_; }
    uint64_t get_instruction_count() const override { return instruction_count_; }

    // ----- ICpuCore: Register Access -----
    int get_reg_count() const override { return 6; }
    const char* get_reg_name(int index) const override;
    uint32_t get_reg(int index) const override;
    void set_reg(int index, uint32_t value) override;
    uint32_t get_pc() const override { return pc_; }
    void set_pc(uint32_t addr) override { pc_ = addr & 0xFFFF; }
    uint32_t get_sp() const override { return 0x0100 | sp_; }
    void set_sp(uint32_t value) override { sp_ = value & 0xFF; }
    uint32_t get_flags() const override { return p_; }
    void set_flags(uint32_t value) override { p_ = value & 0xFF; }

    // ----- ICpuCore: Memory Access -----
    uint8_t  read8(uint32_t addr) override;
    uint16_t read16(uint32_t addr) override;
    uint32_t read32(uint32_t addr) override;
    void     write8(uint32_t addr, uint8_t value) override;
    void     write16(uint32_t addr, uint16_t value) override;
    void     write32(uint32_t addr, uint32_t value) override;

    // ----- ICpuCore: Interrupts -----
    void raise_interrupt(uint32_t vector) override;
    void trigger_exception(uint32_t cause, uint32_t epc) override;
    bool has_pending_interrupt() const override { return irq_pending_; }
    void acknowledge_interrupt() override { irq_pending_ = false; }

    // ----- ICpuCore: Disassembly -----
    std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) override;

    // ----- ICpuCore: State Save/Restore -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;
    CpuStateSnapshot get_snapshot() const override;

    // ----- 6502-specific -----
    void set_nmi(bool active) { nmi_pending_ = active; }
    void set_irq(bool active) { irq_pending_ = active; }

    // Memory bus callback (set by UMM or external memory provider)
    void set_memory_callbacks(
        std::function<uint8_t(uint32_t)> read_cb,
        std::function<void(uint32_t, uint8_t)> write_cb
    ) {
        mem_read_ = read_cb;
        mem_write_ = write_cb;
    }

private:
    // Registers
    uint8_t a_ = 0;       // Accumulator
    uint8_t x_ = 0;       // X index
    uint8_t y_ = 0;       // Y index
    uint8_t sp_ = 0xFD;   // Stack pointer (offset into page 1)
    uint8_t p_ = M6502Flags::U | M6502Flags::I;  // Status flags
    uint16_t pc_ = 0xC000;  // Program counter

    // State
    bool halted_ = false;
    bool irq_pending_ = false;
    bool nmi_pending_ = false;
    uint64_t cycle_count_ = 0;
    uint64_t instruction_count_ = 0;

    // Memory callbacks
    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t, uint8_t)> mem_write_;

    // ----- Internal helpers -----
    inline uint8_t fetch() {
        uint8_t val = read8(pc_);
        pc_++;
        return val;
    }

    inline uint16_t fetch16() {
        uint16_t lo = fetch();
        uint16_t hi = fetch();
        return lo | (hi << 8);
    }

    inline void push(uint8_t val) {
        write8(0x0100 | sp_, val);
        sp_--;
    }

    inline uint8_t pop() {
        sp_++;
        return read8(0x0100 | sp_);
    }

    inline void push16(uint16_t val) {
        push(val >> 8);
        push(val & 0xFF);
    }

    inline uint16_t pop16() {
        uint8_t lo = pop();
        uint8_t hi = pop();
        return lo | (uint16_t(hi) << 8);
    }

    // Flag helpers
    inline void set_zn(uint8_t val) {
        if (val == 0) p_ |= M6502Flags::Z; else p_ &= ~M6502Flags::Z;
        if (val & 0x80) p_ |= M6502Flags::N; else p_ &= ~M6502Flags::N;
    }

    inline void set_flag(uint8_t flag, bool condition) {
        if (condition) p_ |= flag; else p_ &= ~flag;
    }

    // Addressing modes — return effective address
    uint16_t addr_immediate();
    uint16_t addr_zero_page();
    uint16_t addr_zero_page_x();
    uint16_t addr_zero_page_y();
    uint16_t addr_absolute();
    uint16_t addr_absolute_x();
    uint16_t addr_absolute_y();
    uint16_t addr_indirect_x();
    uint16_t addr_indirect_y();
    uint16_t addr_relative();

    // Instruction handlers
    void op_adc(uint16_t addr);
    void op_and(uint16_t addr);
    void op_asl(uint16_t addr);
    void op_asl_a();
    void op_bcc(uint16_t addr);
    void op_bcs(uint16_t addr);
    void op_beq(uint16_t addr);
    void op_bit(uint16_t addr);
    void op_bmi(uint16_t addr);
    void op_bne(uint16_t addr);
    void op_bpl(uint16_t addr);
    void op_brk();
    void op_bvc(uint16_t addr);
    void op_bvs(uint16_t addr);
    void op_clc();
    void op_cld();
    void op_cli();
    void op_clv();
    void op_cmp(uint16_t addr);
    void op_cpx(uint16_t addr);
    void op_cpy(uint16_t addr);
    void op_dec(uint16_t addr);
    void op_dex();
    void op_dey();
    void op_eor(uint16_t addr);
    void op_inc(uint16_t addr);
    void op_inx();
    void op_iny();
    void op_jmp(uint16_t addr);
    void op_jsr(uint16_t addr);
    void op_lda(uint16_t addr);
    void op_ldx(uint16_t addr);
    void op_ldy(uint16_t addr);
    void op_lsr(uint16_t addr);
    void op_lsr_a();
    void op_nop();
    void op_ora(uint16_t addr);
    void op_pha();
    void op_php();
    void op_pla();
    void op_plp();
    void op_rol(uint16_t addr);
    void op_rol_a();
    void op_ror(uint16_t addr);
    void op_ror_a();
    void op_rti();
    void op_rts();
    void op_sbc(uint16_t addr);
    void op_sec();
    void op_sed();
    void op_sei();
    void op_sta(uint16_t addr);
    void op_stx(uint16_t addr);
    void op_sty(uint16_t addr);
    void op_tax();
    void op_tay();
    void op_tsx();
    void op_txa();
    void op_tya();
    void op_txs();

    // Interrupt handling
    void handle_irq();
    void handle_nmi();

    // Opcode table
    using OpcodeHandler = void (M6502Core::*)();
    using AddrModeHandler = uint16_t (M6502Core::*)();
    struct OpcodeEntry {
        OpcodeHandler op;
        AddrModeHandler addr;
        int cycles;
        const char* mnemonic;
    };
    static const OpcodeEntry opcode_table_[256];
    void init_opcode_table();
};

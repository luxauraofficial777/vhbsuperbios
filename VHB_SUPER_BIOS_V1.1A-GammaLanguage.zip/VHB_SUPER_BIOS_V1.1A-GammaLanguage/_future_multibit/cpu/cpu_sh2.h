// =============================================================================
// cpu_sh2.h — Hitachi SH-2 CPU Core (Clean-Room Implementation)
//
// Implements ICpuCore for the Hitachi SH-2 (SH7604) 32-bit RISC processor.
// Reference: SH-2 Programming Manual (public), github.com/devmiyax/sh2 (MIT)
//
// Features:
//   - 16 general-purpose 32-bit registers (R0-R15)
//   - 32-bit program counter (PC)
//   - 32-bit status register (SR) with T, S, I, Q, M flags
//   - 32-bit GBR (Global Base Register) and VBR (Vector Base Register)
//   - 16-bit fixed-length instruction set
//   - Register-indirect addressing with post-increment/pre-decrement
//   - Delayed branch execution
//   - Multiply-accumulate (MAC) register
//   - Big-endian data access
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include <array>
#include <cstring>
#include <functional>

// ============================================================================
// SH-2 Register Indices
// ============================================================================

enum Sh2Reg {
    SH2_R0 = 0,  SH2_R1,  SH2_R2,  SH2_R3,
    SH2_R4,      SH2_R5,  SH2_R6,  SH2_R7,
    SH2_R8,      SH2_R9,  SH2_R10, SH2_R11,
    SH2_R12,     SH2_R13, SH2_R14, SH2_R15,
    SH2_PC,      SH2_SR,  SH2_GBR, SH2_VBR,
    SH2_MACH,    SH2_MACL, SH2_PR,
};

// ============================================================================
// SH-2 Status Register Bits
// ============================================================================

namespace Sh2SR {
    constexpr uint32_t T = 0x00000001;   // T (true) flag
    constexpr uint32_t S = 0x00000002;   // S flag (MAC saturation)
    constexpr uint32_t I = 0x000000F0;   // Interrupt mask (4 bits)
    constexpr uint32_t Q = 0x00000100;   // Divide step Q
    constexpr uint32_t M = 0x00000200;   // Divide step M
    constexpr uint32_t FD = 0x00008000;  // FPU disable
    constexpr uint32_t BL = 0x00010000;  // Exception block
    constexpr uint32_t RB = 0x00020000;  // Register bank
    constexpr uint32_t MD = 0x00040000;  // Processor mode
}

// ============================================================================
// Sh2Core
// =============================================================================

class Sh2Core : public ICpuCore {
public:
    Sh2Core();
    ~Sh2Core() override = default;

    // ----- ICpuCore: Execution -----
    int step() override;
    void run(uint64_t max_instructions) override;
    void reset() override;
    void halt() override { halted_ = true; }
    bool is_halted() const override { return halted_; }

    // ----- ICpuCore: Architecture Info -----
    ArchID get_arch_id() const override { return ArchID::SH2; }
    const char* get_arch_name() const override { return "Hitachi SH-2"; }
    int get_bit_depth() const override { return 32; }
    bool is_big_endian() const override { return true; }
    uint64_t get_clock_hz() const override { return 28636360; }  // ~28.6 MHz
    uint64_t get_cycle_count() const override { return cycle_count_; }
    uint64_t get_instruction_count() const override { return instruction_count_; }

    // ----- ICpuCore: Register Access -----
    int get_reg_count() const override { return 23; }
    const char* get_reg_name(int index) const override;
    uint32_t get_reg(int index) const override;
    void set_reg(int index, uint32_t value) override;
    uint32_t get_pc() const override { return pc_; }
    void set_pc(uint32_t addr) override { pc_ = addr; }
    uint32_t get_sp() const override { return r_[15]; }
    void set_sp(uint32_t value) override { r_[15] = value; }
    uint32_t get_flags() const override { return sr_; }
    void set_flags(uint32_t value) override { sr_ = value; }

    // ----- ICpuCore: Memory Access (big-endian) -----
    uint8_t  read8(uint32_t addr) override;
    uint16_t read16(uint32_t addr) override;
    uint32_t read32(uint32_t addr) override;
    void     write8(uint32_t addr, uint8_t value) override;
    void     write16(uint32_t addr, uint16_t value) override;
    void     write32(uint32_t addr, uint32_t value) override;

    // ----- ICpuCore: Interrupts -----
    void raise_interrupt(uint32_t vector) override;
    void trigger_exception(uint32_t cause, uint32_t epc) override;
    bool has_pending_interrupt() const override { return irq_pending_; }
    void acknowledge_interrupt() override { irq_pending_ = false; }

    // ----- ICpuCore: Disassembly -----
    std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) override;

    // ----- ICpuCore: State Save/Restore -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;
    CpuStateSnapshot get_snapshot() const override;

    // ----- SH-2-specific -----
    void set_memory_callbacks(
        std::function<uint8_t(uint32_t)> read_cb,
        std::function<void(uint32_t, uint8_t)> write_cb
    ) {
        mem_read_ = read_cb;
        mem_write_ = write_cb;
    }

    void set_irq_level(int level) { irq_level_ = level; irq_pending_ = (level > 0); }

private:
    // Registers
    std::array<uint32_t, 16> r_ = {};  // R0-R15
    uint32_t pc_ = 0;
    uint32_t sr_ = 0;
    uint32_t gbr_ = 0;
    uint32_t vbr_ = 0;
    uint32_t mach_ = 0;
    uint32_t macl_ = 0;
    uint32_t pr_ = 0;  // Procedure register

    // Banked registers (R0-R7) for RB mode
    std::array<uint32_t, 8> r_bank_ = {};

    // State
    bool halted_ = false;
    bool irq_pending_ = false;
    int irq_level_ = 0;
    bool in_delay_slot_ = false;
    uint32_t delayed_pc_ = 0;
    uint64_t cycle_count_ = 0;
    uint64_t instruction_count_ = 0;

    // Memory callbacks
    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t, uint8_t)> mem_write_;

    // Helpers
    inline uint16_t fetch16() {
        uint16_t val = read16(pc_);
        pc_ += 2;
        return val;
    }

    inline int get_int_mask() const { return (sr_ & Sh2SR::I) >> 4; }

    // Exception handling
    void raise_exception(uint32_t vector_code);

    // Delayed branch
    void do_delayed_branch(uint32_t target);

    // Instruction handlers
    void execute_instruction(uint16_t instr);
    void op_group0(uint16_t instr);
    void op_group1(uint16_t instr);
    void op_group2(uint16_t instr);
    void op_group3(uint16_t instr);
    void op_group4(uint16_t instr);
    void op_group5(uint16_t instr);
    void op_group6(uint16_t instr);
    void op_group7(uint16_t instr);
    void op_group8(uint16_t instr);
    void op_group9(uint16_t instr);
    void op_groupA(uint16_t instr);
    void op_groupB(uint16_t instr);
    void op_groupC(uint16_t instr);
    void op_groupD(uint16_t instr);
    void op_groupE(uint16_t instr);
    void op_groupF(uint16_t instr);
};

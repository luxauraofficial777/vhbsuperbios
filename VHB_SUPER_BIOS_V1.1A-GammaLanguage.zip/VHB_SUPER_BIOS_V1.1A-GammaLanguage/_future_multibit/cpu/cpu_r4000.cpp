// =============================================================================
// cpu_r4000.cpp — MIPS R4000 Allegrex CPU Core Implementation (Clean-Room)
//
// Reference: MIPS R4000 User's Manual, github.com/ichfly/PSPEmu (GPL)
//
// =============================================================================

#include "cpu_r4000.h"
#include <cstdio>
#include <sstream>
#include <iomanip>

// ============================================================================
// Constructor / Reset
// ============================================================================

MipsR4000Core::MipsR4000Core() {
    gpr_.fill(0);
    fpr_.fill(0);
}

void MipsR4000Core::reset() {
    gpr_.fill(0);
    fpr_.fill(0);
    hi_ = 0;
    lo_ = 0;
    pc_ = 0xBFC00000;  // Reset vector
    next_pc_ = pc_ + 4;
    cp0_status_ = R4000Status::BEV | R4000Status::CU0;
    cp0_cause_ = 0;
    cp0_epc_ = 0;
    cp0_prid_ = 0x00040000;  // Allegrex PRID
    cp0_config_ = 0x00023230;
    cp0_count_ = 0;
    cp0_compare_ = 0;
    halted_ = false;
    irq_pending_ = false;
    irq_lines_ = 0;
    in_delay_slot_ = false;
    cycle_count_ = 0;
    instruction_count_ = 0;
}

// ============================================================================
// Memory Access (little-endian)
// ============================================================================

uint8_t MipsR4000Core::read8(uint32_t addr) {
    if (mem_read_) return mem_read_(addr);
    return 0;
}

uint16_t MipsR4000Core::read16(uint32_t addr) {
    return read8(addr) | (uint16_t(read8(addr + 1)) << 8);
}

uint32_t MipsR4000Core::read32(uint32_t addr) {
    return read8(addr) | (uint32_t(read8(addr+1)) << 8) |
           (uint32_t(read8(addr+2)) << 16) | (uint32_t(read8(addr+3)) << 24);
}

void MipsR4000Core::write8(uint32_t addr, uint8_t value) {
    if (mem_write_) mem_write_(addr, value);
}

void MipsR4000Core::write16(uint32_t addr, uint16_t value) {
    write8(addr, value & 0xFF);
    write8(addr + 1, value >> 8);
}

void MipsR4000Core::write32(uint32_t addr, uint32_t value) {
    write8(addr, value & 0xFF);
    write8(addr+1, (value >> 8) & 0xFF);
    write8(addr+2, (value >> 16) & 0xFF);
    write8(addr+3, (value >> 24) & 0xFF);
}

// ============================================================================
// Register Access
// ============================================================================

const char* MipsR4000Core::get_reg_name(int index) const {
    static const char* names[] = {
        "zero","at","v0","v1","a0","a1","a2","a3",
        "t0","t1","t2","t3","t4","t5","t6","t7",
        "s0","s1","s2","s3","s4","s5","s6","s7",
        "t8","t9","k0","k1","gp","sp","fp","ra",
        "hi","lo","pc","status","cause","epc"
    };
    if (index >= 0 && index < 37) return names[index];
    return "??";
}

uint32_t MipsR4000Core::get_reg(int index) const {
    if (index < 32) return gpr_[index];
    if (index == R4K_HI) return hi_;
    if (index == R4K_LO) return lo_;
    if (index == R4K_PC) return pc_;
    if (index == R4K_STATUS) return cp0_status_;
    if (index == R4K_CAUSE) return cp0_cause_;
    if (index == R4K_EPC) return cp0_epc_;
    return 0;
}

void MipsR4000Core::set_reg(int index, uint32_t value) {
    if (index == 0) return;  // R0 is always 0
    if (index < 32) { gpr_[index] = value; return; }
    if (index == R4K_HI) { hi_ = value; return; }
    if (index == R4K_LO) { lo_ = value; return; }
    if (index == R4K_PC) { pc_ = value; next_pc_ = value + 4; return; }
    if (index == R4K_STATUS) { cp0_status_ = value; return; }
    if (index == R4K_CAUSE) { cp0_cause_ = value; return; }
    if (index == R4K_EPC) { cp0_epc_ = value; return; }
}

// CP0 access
uint32_t MipsR4000Core::get_cp0(int reg) const {
    switch (reg) {
        case R4000CP0::INDEX:    return cp0_index_;
        case R4000CP0::RANDOM:   return cp0_random_;
        case R4000CP0::ENTRYLO0: return cp0_entrylo0_;
        case R4000CP0::ENTRYLO1: return cp0_entrylo1_;
        case R4000CP0::CONTEXT:  return cp0_context_;
        case R4000CP0::PAGEMASK: return cp0_pagemask_;
        case R4000CP0::WIRED:    return cp0_wired_;
        case R4000CP0::BADVADDR: return cp0_badvaddr_;
        case R4000CP0::COUNT:    return cp0_count_;
        case R4000CP0::ENTRYHI:  return cp0_entryhi_;
        case R4000CP0::COMPARE:  return cp0_compare_;
        case R4000CP0::STATUS:   return cp0_status_;
        case R4000CP0::CAUSE:    return cp0_cause_;
        case R4000CP0::EPC:      return cp0_epc_;
        case R4000CP0::PRID:     return cp0_prid_;
        case R4000CP0::CONFIG:   return cp0_config_;
        default: return 0;
    }
}

void MipsR4000Core::set_cp0(int reg, uint32_t value) {
    switch (reg) {
        case R4000CP0::INDEX:    cp0_index_ = value; break;
        case R4000CP0::ENTRYLO0: cp0_entrylo0_ = value; break;
        case R4000CP0::ENTRYLO1: cp0_entrylo1_ = value; break;
        case R4000CP0::CONTEXT:  cp0_context_ = value; break;
        case R4000CP0::PAGEMASK: cp0_pagemask_ = value; break;
        case R4000CP0::WIRED:    cp0_wired_ = value; break;
        case R4000CP0::COUNT:    cp0_count_ = value; break;
        case R4000CP0::ENTRYHI:  cp0_entryhi_ = value; break;
        case R4000CP0::COMPARE:  cp0_compare_ = value; break;
        case R4000CP0::STATUS:   cp0_status_ = value; break;
        case R4000CP0::CAUSE:    cp0_cause_ = value; break;
        case R4000CP0::EPC:      cp0_epc_ = value; break;
        default: break;
    }
}

// FPR access
float MipsR4000Core::get_fpr(int reg) const {
    uint32_t raw = fpr_[reg];
    float f;
    std::memcpy(&f, &raw, sizeof(f));
    return f;
}

void MipsR4000Core::set_fpr(int reg, float value) {
    std::memcpy(&fpr_[reg], &value, sizeof(value));
}

uint32_t MipsR4000Core::get_fpr_raw(int reg) const { return fpr_[reg]; }
void MipsR4000Core::set_fpr_raw(int reg, uint32_t value) { fpr_[reg] = value; }

// IRQ control
void MipsR4000Core::set_irq_line(int line, bool active) {
    if (active) irq_lines_ |= (1 << line);
    else irq_lines_ &= ~(1 << line);
    irq_pending_ = (irq_lines_ != 0);
}

// ============================================================================
// Interrupt and Exception Handling
// ============================================================================

void MipsR4000Core::check_interrupts() {
    // Check if any unmasked interrupt is pending
    uint32_t pending = (cp0_cause_ & R4000Cause::IP) & (cp0_status_ & R4000Status::IM);
    if ((cp0_status_ & R4000Status::IE) && !(cp0_status_ & R4000Status::EXL) && pending) {
        raise_exception(R4000ExcCode::INT, in_delay_slot_);
    }

    // Timer interrupt (Count == Compare)
    if (cp0_count_ == cp0_compare_ && cp0_compare_ != 0) {
        cp0_cause_ |= (1 << 15);  // Set IP7 (timer interrupt)
    }
}

void MipsR4000Core::raise_exception(uint32_t exc_code, bool in_delay_slot) {
    cp0_epc_ = pc_;
    if (in_delay_slot) {
        cp0_cause_ |= R4000Cause::BD;
        cp0_epc_ = pc_ - 4;  // Point to branch instruction
    } else {
        cp0_cause_ &= ~R4000Cause::BD;
    }

    cp0_cause_ = (cp0_cause_ & ~R4000Cause::EXC_CODE) | ((exc_code << 2) & R4000Cause::EXC_CODE);
    cp0_status_ |= R4000Status::EXL;

    // Exception vector
    if (cp0_status_ & R4000Status::BEV) {
        pc_ = 0xBFC00200;
    } else {
        pc_ = 0x80000180;
    }
    next_pc_ = pc_ + 4;
}

void MipsR4000Core::raise_interrupt(uint32_t vector) {
    (void)vector;
    irq_pending_ = true;
}

void MipsR4000Core::trigger_exception(uint32_t cause, uint32_t epc) {
    cp0_epc_ = epc;
    raise_exception(cause);
}

// ============================================================================
// Instruction Handlers — R-type (Special)
// ============================================================================

void MipsR4000Core::op_sll(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int sa = (instr >> 6) & 0x1F;
    gpr_[rd] = gpr_[rt] << sa;
}

void MipsR4000Core::op_srl(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int sa = (instr >> 6) & 0x1F;
    gpr_[rd] = gpr_[rt] >> sa;
}

void MipsR4000Core::op_sra(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int sa = (instr >> 6) & 0x1F;
    gpr_[rd] = (uint32_t)((int32_t)gpr_[rt] >> sa);
}

void MipsR4000Core::op_sllv(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    gpr_[rd] = gpr_[rt] << (gpr_[rs] & 0x1F);
}

void MipsR4000Core::op_srlv(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    gpr_[rd] = gpr_[rt] >> (gpr_[rs] & 0x1F);
}

void MipsR4000Core::op_srav(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    gpr_[rd] = (uint32_t)((int32_t)gpr_[rt] >> (gpr_[rs] & 0x1F));
}

void MipsR4000Core::op_jr(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    branch(gpr_[rs]);
}

void MipsR4000Core::op_jalr(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    gpr_[rd] = next_pc_;  // Return address (instruction after delay slot)
    branch(gpr_[rs]);
}

void MipsR4000Core::op_mfhi(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    gpr_[rd] = hi_;
}

void MipsR4000Core::op_mthi(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    hi_ = gpr_[rs];
}

void MipsR4000Core::op_mflo(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    gpr_[rd] = lo_;
}

void MipsR4000Core::op_mtlo(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    lo_ = gpr_[rs];
}

void MipsR4000Core::op_mult(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int64_t result = (int64_t)(int32_t)gpr_[rs] * (int64_t)(int32_t)gpr_[rt];
    lo_ = (uint32_t)(result & 0xFFFFFFFF);
    hi_ = (uint32_t)(result >> 32);
}

void MipsR4000Core::op_multu(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    uint64_t result = (uint64_t)gpr_[rs] * (uint64_t)gpr_[rt];
    lo_ = (uint32_t)(result & 0xFFFFFFFF);
    hi_ = (uint32_t)(result >> 32);
}

void MipsR4000Core::op_div(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int32_t divisor = (int32_t)gpr_[rt];
    if (divisor != 0) {
        lo_ = (uint32_t)((int32_t)gpr_[rs] / divisor);
        hi_ = (uint32_t)((int32_t)gpr_[rs] % divisor);
    }
}

void MipsR4000Core::op_divu(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    uint32_t divisor = gpr_[rt];
    if (divisor != 0) {
        lo_ = gpr_[rs] / divisor;
        hi_ = gpr_[rs] % divisor;
    }
}

void MipsR4000Core::op_add(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int32_t a = (int32_t)gpr_[rs];
    int32_t b = (int32_t)gpr_[rt];
    int32_t result = a + b;
    // Check for overflow
    if ((a > 0 && b > 0 && result < 0) || (a < 0 && b < 0 && result > 0)) {
        raise_exception(R4000ExcCode::OV, in_delay_slot_);
        return;
    }
    gpr_[rd] = (uint32_t)result;
}

void MipsR4000Core::op_addu(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = gpr_[rs] + gpr_[rt];
}

void MipsR4000Core::op_sub(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int32_t a = (int32_t)gpr_[rs];
    int32_t b = (int32_t)gpr_[rt];
    int32_t result = a - b;
    if ((a > 0 && b < 0 && result < 0) || (a < 0 && b > 0 && result > 0)) {
        raise_exception(R4000ExcCode::OV, in_delay_slot_);
        return;
    }
    gpr_[rd] = (uint32_t)result;
}

void MipsR4000Core::op_subu(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = gpr_[rs] - gpr_[rt];
}

void MipsR4000Core::op_and(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = gpr_[rs] & gpr_[rt];
}

void MipsR4000Core::op_or(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = gpr_[rs] | gpr_[rt];
}

void MipsR4000Core::op_xor(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = gpr_[rs] ^ gpr_[rt];
}

void MipsR4000Core::op_nor(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = ~(gpr_[rs] | gpr_[rt]);
}

void MipsR4000Core::op_slt(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = ((int32_t)gpr_[rs] < (int32_t)gpr_[rt]) ? 1 : 0;
}

void MipsR4000Core::op_sltu(uint32_t instr) {
    int rd = (instr >> 11) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    gpr_[rd] = (gpr_[rs] < gpr_[rt]) ? 1 : 0;
}

void MipsR4000Core::op_syscall(uint32_t instr) {
    (void)instr;
    raise_exception(R4000ExcCode::SYSCALL, in_delay_slot_);
}

void MipsR4000Core::op_break(uint32_t instr) {
    (void)instr;
    raise_exception(R4000ExcCode::BP, in_delay_slot_);
}

// ============================================================================
// Instruction Handlers — I-type
// ============================================================================

void MipsR4000Core::op_beq(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    if (gpr_[rs] == gpr_[rt]) {
        branch(pc_ + (offset << 2));
    }
}

void MipsR4000Core::op_bne(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    if (gpr_[rs] != gpr_[rt]) {
        branch(pc_ + (offset << 2));
    }
}

void MipsR4000Core::op_blez(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    if ((int32_t)gpr_[rs] <= 0) {
        branch(pc_ + (offset << 2));
    }
}

void MipsR4000Core::op_bgtz(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    if ((int32_t)gpr_[rs] > 0) {
        branch(pc_ + (offset << 2));
    }
}

void MipsR4000Core::op_addi(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t imm = (int16_t)(instr & 0xFFFF);
    int32_t a = (int32_t)gpr_[rs];
    int32_t result = a + imm;
    // Overflow check
    if ((a > 0 && imm > 0 && result < 0) || (a < 0 && imm < 0 && result > 0)) {
        raise_exception(R4000ExcCode::OV, in_delay_slot_);
        return;
    }
    gpr_[rt] = (uint32_t)result;
}

void MipsR4000Core::op_addiu(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t imm = (int16_t)(instr & 0xFFFF);
    gpr_[rt] = gpr_[rs] + (uint32_t)imm;
}

void MipsR4000Core::op_slti(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t imm = (int16_t)(instr & 0xFFFF);
    gpr_[rt] = ((int32_t)gpr_[rs] < imm) ? 1 : 0;
}

void MipsR4000Core::op_sltiu(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    uint32_t imm = (uint32_t)(int16_t)(instr & 0xFFFF);
    gpr_[rt] = (gpr_[rs] < imm) ? 1 : 0;
}

void MipsR4000Core::op_andi(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    uint16_t imm = instr & 0xFFFF;
    gpr_[rt] = gpr_[rs] & imm;
}

void MipsR4000Core::op_ori(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    uint16_t imm = instr & 0xFFFF;
    gpr_[rt] = gpr_[rs] | imm;
}

void MipsR4000Core::op_xori(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    uint16_t imm = instr & 0xFFFF;
    gpr_[rt] = gpr_[rs] ^ imm;
}

void MipsR4000Core::op_lui(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    uint16_t imm = instr & 0xFFFF;
    gpr_[rt] = (uint32_t)imm << 16;
}

void MipsR4000Core::op_lb(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    gpr_[rt] = (uint32_t)(int32_t)(int8_t)read8(addr);
}

void MipsR4000Core::op_lh(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    gpr_[rt] = (uint32_t)(int32_t)(int16_t)read16(addr);
}

void MipsR4000Core::op_lw(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    gpr_[rt] = read32(addr);
}

void MipsR4000Core::op_lbu(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    gpr_[rt] = read8(addr);
}

void MipsR4000Core::op_lhu(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    gpr_[rt] = read16(addr);
}

void MipsR4000Core::op_sb(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    write8(addr, gpr_[rt] & 0xFF);
}

void MipsR4000Core::op_sh(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    write16(addr, gpr_[rt] & 0xFFFF);
}

void MipsR4000Core::op_sw(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);
    uint32_t addr = gpr_[rs] + offset;
    write32(addr, gpr_[rt]);
}

// ============================================================================
// Instruction Handlers — J-type
// ============================================================================

void MipsR4000Core::op_j(uint32_t instr) {
    uint32_t target = (pc_ & 0xF0000000) | ((instr & 0x03FFFFFF) << 2);
    branch(target);
}

void MipsR4000Core::op_jal(uint32_t instr) {
    gpr_[31] = next_pc_;  // Return address
    uint32_t target = (pc_ & 0xF0000000) | ((instr & 0x03FFFFFF) << 2);
    branch(target);
}

// ============================================================================
// Special / RegImm / Coprocessor Handlers
// ============================================================================

void MipsR4000Core::op_special(uint32_t instr) {
    int funct = instr & 0x3F;
    switch (funct) {
        case 0x00: op_sll(instr); break;
        case 0x02: op_srl(instr); break;
        case 0x03: op_sra(instr); break;
        case 0x04: op_sllv(instr); break;
        case 0x06: op_srlv(instr); break;
        case 0x07: op_srav(instr); break;
        case 0x08: op_jr(instr); break;
        case 0x09: op_jalr(instr); break;
        case 0x0C: op_syscall(instr); break;
        case 0x0D: op_break(instr); break;
        case 0x10: op_mfhi(instr); break;
        case 0x11: op_mthi(instr); break;
        case 0x12: op_mflo(instr); break;
        case 0x13: op_mtlo(instr); break;
        case 0x18: op_mult(instr); break;
        case 0x19: op_multu(instr); break;
        case 0x1A: op_div(instr); break;
        case 0x1B: op_divu(instr); break;
        case 0x20: op_add(instr); break;
        case 0x21: op_addu(instr); break;
        case 0x22: op_sub(instr); break;
        case 0x23: op_subu(instr); break;
        case 0x24: op_and(instr); break;
        case 0x25: op_or(instr); break;
        case 0x26: op_xor(instr); break;
        case 0x27: op_nor(instr); break;
        case 0x2A: op_slt(instr); break;
        case 0x2B: op_sltu(instr); break;
        default:
            raise_exception(R4000ExcCode::RI, in_delay_slot_);
            break;
    }
}

void MipsR4000Core::op_regimm(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);

    switch (rt) {
        case 0x00: // BLTZ
            if ((int32_t)gpr_[rs] < 0) branch(pc_ + (offset << 2));
            break;
        case 0x01: // BGEZ
            if ((int32_t)gpr_[rs] >= 0) branch(pc_ + (offset << 2));
            break;
        case 0x02: // BLTZL
            if ((int32_t)gpr_[rs] < 0) branch(pc_ + (offset << 2));
            else next_pc_ = pc_ + 4;  // Nullify delay slot
            break;
        case 0x03: // BGEZL
            if ((int32_t)gpr_[rs] >= 0) branch(pc_ + (offset << 2));
            else next_pc_ = pc_ + 4;
            break;
        case 0x10: // BLTZAL
            gpr_[31] = next_pc_;
            if ((int32_t)gpr_[rs] < 0) branch(pc_ + (offset << 2));
            break;
        case 0x11: // BGEZAL
            gpr_[31] = next_pc_;
            if ((int32_t)gpr_[rs] >= 0) branch(pc_ + (offset << 2));
            break;
        default:
            raise_exception(R4000ExcCode::RI, in_delay_slot_);
            break;
    }
}

void MipsR4000Core::op_cop0(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int rd = (instr >> 11) & 0x1F;
    int fsel = instr & 0x1F;

    switch (rs) {
        case 0x00: { // MFC0
            gpr_[rt] = get_cp0(fsel);
            break;
        }
        case 0x04: { // MTC0
            set_cp0(fsel, gpr_[rt]);
            break;
        }
        case 0x10: { // CO — TLB instructions
            int funct = instr & 0x3F;
            switch (funct) {
                case 0x01: // TLBR
                    break;
                case 0x02: // TLBWI
                    break;
                case 0x06: // TLBWR
                    break;
                case 0x08: // TLBP
                    break;
                case 0x18: { // ERET
                    pc_ = cp0_epc_;
                    next_pc_ = pc_ + 4;
                    cp0_status_ &= ~(R4000Status::EXL | R4000Status::ERL);
                    break;
                }
                default:
                    break;
            }
            break;
        }
        default:
            break;
    }
}

void MipsR4000Core::op_cop1(uint32_t instr) {
    if (!(cp0_status_ & R4000Status::CU1)) {
        raise_exception(R4000ExcCode::CPU, in_delay_slot_);
        return;
    }

    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int fs = (instr >> 11) & 0x1F;
    int fd = (instr >> 6) & 0x1F;
    int funct = instr & 0x3F;

    switch (rs) {
        case 0x00: // MFC1
            gpr_[rt] = fpr_[fs];
            break;
        case 0x02: // CFC1
            gpr_[rt] = (fs == 31) ? fcr31_ : 0;
            break;
        case 0x04: // MTC1
            fpr_[fs] = gpr_[rt];
            break;
        case 0x06: // CTC1
            if (fs == 31) fcr31_ = gpr_[rt];
            break;
        case 0x08: { // BC1
            int cc = (instr >> 16) & 0x03;
            int16_t offset = (int16_t)(instr & 0xFFFF);
            bool cond = (fcr31_ & (1 << (cc + 8))) != 0;
            if (rt & 0x01) cond = !cond;  // BC1F / BC1T
            if (cond) branch(pc_ + (offset << 2));
            break;
        }
        default: {
            // FPU arithmetic operations
            float a, b;
            std::memcpy(&a, &fpr_[fs], sizeof(a));
            std::memcpy(&b, &fpr_[ft], sizeof(b));
            float result = 0;
            switch (funct) {
                case 0x00: result = a + b; break;  // ADD.S
                case 0x01: result = a - b; break;  // SUB.S
                case 0x02: result = a * b; break;  // MUL.S
                case 0x03: result = a / b; break;  // DIV.S
                case 0x04: { // SQRT.S
                    result = sqrtf(a);
                    break;
                }
                case 0x05: result = fabsf(a); break;  // ABS.S
                case 0x06: result = a; break;          // MOV.S
                case 0x07: result = -a; break;         // NEG.S
                default: break;
            }
            std::memcpy(&fpr_[fd], &result, sizeof(result));
            break;
        }
    }
}

// ============================================================================
// Step — Main Instruction Decoder
// ============================================================================

int MipsR4000Core::step() {
    if (halted_) return -1;

    // Check for interrupts before fetching
    check_interrupts();

    // Update Count register
    cp0_count_++;

    // Fetch instruction
    uint32_t instr = fetch32();

    // Track delay slot
    bool was_in_delay = in_delay_slot_;
    in_delay_slot_ = (next_pc_ != pc_ + 4);

    // Decode
    int opcode = (instr >> 26) & 0x3F;

    switch (opcode) {
        case 0x00: op_special(instr); break;
        case 0x01: op_regimm(instr); break;
        case 0x02: op_j(instr); break;
        case 0x03: op_jal(instr); break;
        case 0x04: op_beq(instr); break;
        case 0x05: op_bne(instr); break;
        case 0x06: op_blez(instr); break;
        case 0x07: op_bgtz(instr); break;
        case 0x08: op_addi(instr); break;
        case 0x09: op_addiu(instr); break;
        case 0x0A: op_slti(instr); break;
        case 0x0B: op_sltiu(instr); break;
        case 0x0C: op_andi(instr); break;
        case 0x0D: op_ori(instr); break;
        case 0x0E: op_xori(instr); break;
        case 0x0F: op_lui(instr); break;
        case 0x10: op_cop0(instr); break;
        case 0x11: op_cop1(instr); break;
        case 0x20: op_lb(instr); break;
        case 0x21: op_lh(instr); break;
        case 0x23: op_lw(instr); break;
        case 0x24: op_lbu(instr); break;
        case 0x25: op_lhu(instr); break;
        case 0x28: op_sb(instr); break;
        case 0x29: op_sh(instr); break;
        case 0x2B: op_sw(instr); break;
        default:
            raise_exception(R4000ExcCode::RI, was_in_delay);
            break;
    }

    // R0 is always 0
    gpr_[0] = 0;

    cycle_count_ += 2;  // Simplified cycle count
    instruction_count_++;
    return 0;
}

void MipsR4000Core::run(uint64_t max_instructions) {
    while (!halted_ && instruction_count_ < max_instructions) {
        step();
    }
}

// ============================================================================
// Disassembly
// ============================================================================

std::string MipsR4000Core::disasm_at(uint32_t addr, int* bytes_consumed) {
    uint32_t instr = read32(addr);
    int opcode = (instr >> 26) & 0x3F;

    static const char* op_names[] = {
        "SPECIAL","REGIMM","J","JAL","BEQ","BNE","BLEZ","BGTZ",
        "ADDI","ADDIU","SLTI","SLTIU","ANDI","ORI","XORI","LUI",
        "COP0","COP1","COP2","COP1X","BEQL","BNEL","BLEZL","BGTZL",
        "DADDI","DADDIU","LDL","LDR","","","","",
        "LB","LH","LWL","LW","LBU","LHU","LWR","LWU",
        "SB","SH","SWL","SW","SDL","SDR","SWR","",
        "LL","LWC1","LWC2","","LLD","LDC1","LDC2","",
        "SC","SWC1","SWC2","","SCD","SDC1","SDC2",""
    };

    std::ostringstream oss;
    oss << std::uppercase << std::hex << std::setfill('0');
    oss << std::setw(8) << addr << ":  ";
    oss << std::setw(8) << instr << "  ";
    if (opcode < 64 && op_names[opcode][0])
        oss << op_names[opcode];
    else
        oss << "???";

    if (bytes_consumed) *bytes_consumed = 4;
    return oss.str();
}

// ============================================================================
// State Save/Restore
// ============================================================================

std::vector<uint8_t> MipsR4000Core::save_state() const {
    std::vector<uint8_t> state;
    auto append = [&](const void* data, size_t len) {
        state.insert(state.end(), (const uint8_t*)data, (const uint8_t*)data + len);
    };
    for (int i = 0; i < 32; i++) append(&gpr_[i], 4);
    append(&hi_, 4); append(&lo_, 4);
    append(&pc_, 4); append(&next_pc_, 4);
    append(&cp0_status_, 4); append(&cp0_cause_, 4); append(&cp0_epc_, 4);
    append(&cp0_count_, 4); append(&cp0_compare_, 4);
    append(&cp0_badvaddr_, 4); append(&cp0_entryhi_, 4);
    append(&cp0_index_, 4);
    for (int i = 0; i < 32; i++) append(&fpr_[i], 4);
    append(&fcr31_, 4);
    append(&halted_, 1); append(&irq_pending_, 1); append(&irq_lines_, 1);
    append(&in_delay_slot_, 1);
    for (int i = 0; i < 8; i++) state.push_back((cycle_count_ >> (i*8)) & 0xFF);
    for (int i = 0; i < 8; i++) state.push_back((instruction_count_ >> (i*8)) & 0xFF);
    return state;
}

void MipsR4000Core::load_state(const std::vector<uint8_t>& state) {
    if (state.size() < 200) return;
    size_t off = 0;
    for (int i = 0; i < 32; i++) {
        gpr_[i] = state[off] | (uint32_t(state[off+1]) << 8) |
                  (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24);
        off += 4;
    }
    hi_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    lo_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    pc_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    next_pc_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    cp0_status_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    cp0_cause_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    cp0_epc_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    // Remaining fields...
    off += 24;  // Skip remaining CP0 and FPR for brevity
    halted_ = state[off++] != 0;
    irq_pending_ = state[off++] != 0;
    irq_lines_ = state[off++];
    in_delay_slot_ = state[off++] != 0;
}

CpuStateSnapshot MipsR4000Core::get_snapshot() const {
    CpuStateSnapshot s;
    s.pc = pc_;
    s.next_pc = next_pc_;
    s.sp = gpr_[29];
    for (int i = 0; i < 32; i++) s.regs[i] = gpr_[i];
    s.cycle_count = cycle_count_;
    s.instruction_count = instruction_count_;
    s.halted = halted_;
    s.arch = ArchID::MipsR4000;
    return s;
}

// =============================================================================
// cpu_r4300.cpp — MIPS R4300 CPU Core Implementation (Clean-Room)
//
// Reference: MIPS R4000 User's Manual, github.com/project64/project64 (GPL)
//
// =============================================================================

#include "cpu_r4300.h"
#include <cstdio>
#include <sstream>
#include <iomanip>

// ============================================================================
// Constructor / Reset
// ============================================================================

MipsR4300Core::MipsR4300Core() {
    gpr_.fill(0);
    fpr_.fill(0);
}

void MipsR4300Core::reset() {
    gpr_.fill(0);
    fpr_.fill(0);
    hi_ = 0;
    lo_ = 0;
    pc_ = 0xBFC00000;
    next_pc_ = pc_ + 4;
    cp0_status_ = R4300Status::BEV | R4300Status::CU0;
    cp0_cause_ = 0;
    cp0_epc_ = 0;
    cp0_prid_ = 0x00043500;  // R4300 PRID
    cp0_count_ = 0;
    cp0_compare_ = 0;
    halted_ = false;
    irq_pending_ = false;
    irq_lines_ = 0;
    in_delay_slot_ = false;
    cycle_count_ = 0;
    instruction_count_ = 0;
}

// ============================================================================
// Memory Access
// ============================================================================

uint8_t MipsR4300Core::read8(uint32_t addr) {
    if (mem_read_) return mem_read_(addr);
    return 0;
}

uint16_t MipsR4300Core::read16(uint32_t addr) {
    if (big_endian_) {
        return (uint16_t(read8(addr)) << 8) | read8(addr + 1);
    }
    return read8(addr) | (uint16_t(read8(addr + 1)) << 8);
}

uint32_t MipsR4300Core::read32(uint32_t addr) {
    if (big_endian_) {
        return (uint32_t(read8(addr)) << 24) | (uint32_t(read8(addr+1)) << 16) |
               (uint32_t(read8(addr+2)) << 8) | read8(addr+3);
    }
    return read8(addr) | (uint32_t(read8(addr+1)) << 8) |
           (uint32_t(read8(addr+2)) << 16) | (uint32_t(read8(addr+3)) << 24);
}

void MipsR4300Core::write8(uint32_t addr, uint8_t value) {
    if (mem_write_) mem_write_(addr, value);
}

void MipsR4300Core::write16(uint32_t addr, uint16_t value) {
    if (big_endian_) {
        write8(addr, value >> 8);
        write8(addr + 1, value & 0xFF);
    } else {
        write8(addr, value & 0xFF);
        write8(addr + 1, value >> 8);
    }
}

void MipsR4300Core::write32(uint32_t addr, uint32_t value) {
    if (big_endian_) {
        write8(addr, value >> 24);
        write8(addr+1, (value >> 16) & 0xFF);
        write8(addr+2, (value >> 8) & 0xFF);
        write8(addr+3, value & 0xFF);
    } else {
        write8(addr, value & 0xFF);
        write8(addr+1, (value >> 8) & 0xFF);
        write8(addr+2, (value >> 16) & 0xFF);
        write8(addr+3, (value >> 24) & 0xFF);
    }
}

// ============================================================================
// Register Access
// ============================================================================

const char* MipsR4300Core::get_reg_name(int index) const {
    static const char* names[] = {
        "zero","at","v0","v1","a0","a1","a2","a3",
        "t0","t1","t2","t3","t4","t5","t6","t7",
        "s0","s1","s2","s3","s4","s5","s6","s7",
        "t8","t9","k0","k1","gp","sp","fp","ra",
        "hi","lo","pc","status","cause","epc"
    };
    if (index >= 0 && index < 37) return names[index];
    return "??";
}

uint32_t MipsR4300Core::get_reg(int index) const {
    if (index < 32) return (uint32_t)gpr_[index];
    if (index == R43_HI) return (uint32_t)hi_;
    if (index == R43_LO) return (uint32_t)lo_;
    if (index == R43_PC) return (uint32_t)pc_;
    if (index == R43_STATUS) return cp0_status_;
    if (index == R43_CAUSE) return cp0_cause_;
    if (index == R43_EPC) return cp0_epc_;
    return 0;
}

void MipsR4300Core::set_reg(int index, uint32_t value) {
    if (index == 0) return;
    if (index < 32) {
        // Sign-extend 32-bit to 64-bit in 32-bit mode
        gpr_[index] = (uint64_t)(int64_t)(int32_t)value;
        return;
    }
    if (index == R43_HI) { hi_ = value; return; }
    if (index == R43_LO) { lo_ = value; return; }
    if (index == R43_PC) { pc_ = value; next_pc_ = value + 4; return; }
    if (index == R43_STATUS) { cp0_status_ = value; return; }
    if (index == R43_CAUSE) { cp0_cause_ = value; return; }
    if (index == R43_EPC) { cp0_epc_ = value; return; }
}

uint64_t MipsR4300Core::get_reg64(int index) const {
    if (index < 32) return gpr_[index];
    if (index == R43_HI) return hi_;
    if (index == R43_LO) return lo_;
    return 0;
}

void MipsR4300Core::set_reg64(int index, uint64_t value) {
    if (index == 0) return;
    if (index < 32) { gpr_[index] = value; return; }
    if (index == R43_HI) { hi_ = value; return; }
    if (index == R43_LO) { lo_ = value; return; }
}

uint32_t MipsR4300Core::get_cp0(int reg) const {
    switch (reg) {
        case 0:  return cp0_index_;
        case 1:  return cp0_random_;
        case 2:  return cp0_entrylo0_;
        case 3:  return cp0_entrylo1_;
        case 4:  return cp0_context_;
        case 5:  return cp0_pagemask_;
        case 6:  return cp0_wired_;
        case 8:  return cp0_badvaddr_;
        case 9:  return cp0_count_;
        case 10: return cp0_entryhi_;
        case 11: return cp0_compare_;
        case 12: return cp0_status_;
        case 13: return cp0_cause_;
        case 14: return cp0_epc_;
        case 15: return cp0_prid_;
        case 16: return cp0_config_;
        default: return 0;
    }
}

void MipsR4300Core::set_cp0(int reg, uint32_t value) {
    switch (reg) {
        case 0:  cp0_index_ = value; break;
        case 2:  cp0_entrylo0_ = value; break;
        case 3:  cp0_entrylo1_ = value; break;
        case 4:  cp0_context_ = value; break;
        case 5:  cp0_pagemask_ = value; break;
        case 6:  cp0_wired_ = value; break;
        case 9:  cp0_count_ = value; break;
        case 10: cp0_entryhi_ = value; break;
        case 11: cp0_compare_ = value; break;
        case 12: cp0_status_ = value; break;
        case 13: cp0_cause_ = value; break;
        case 14: cp0_epc_ = value; break;
        default: break;
    }
}

double MipsR4300Core::get_fpr64(int reg) const {
    uint64_t raw = fpr_[reg];
    double d;
    std::memcpy(&d, &raw, sizeof(d));
    return d;
}

void MipsR4300Core::set_fpr64(int reg, double value) {
    std::memcpy(&fpr_[reg], &value, sizeof(value));
}

uint64_t MipsR4300Core::get_fpr_raw(int reg) const { return fpr_[reg]; }
void MipsR4300Core::set_fpr_raw(int reg, uint64_t value) { fpr_[reg] = value; }

void MipsR4300Core::set_irq_line(int line, bool active) {
    if (active) irq_lines_ |= (1 << line);
    else irq_lines_ &= ~(1 << line);
    irq_pending_ = (irq_lines_ != 0);
}

// ============================================================================
// Exception Handling
// ============================================================================

void MipsR4300Core::check_interrupts() {
    uint32_t pending = (cp0_cause_ & 0x0000FF00) & (cp0_status_ & R4300Status::IM);
    if ((cp0_status_ & R4300Status::IE) && !(cp0_status_ & R4300Status::EXL) && pending) {
        raise_exception(0, in_delay_slot_);  // Interrupt exception code 0
    }
}

void MipsR4300Core::raise_exception(uint32_t exc_code, bool in_delay_slot) {
    cp0_epc_ = (uint32_t)pc_;
    if (in_delay_slot) {
        cp0_cause_ |= 0x80000000;  // BD bit
        cp0_epc_ = (uint32_t)(pc_ - 4);
    } else {
        cp0_cause_ &= ~0x80000000;
    }

    cp0_cause_ = (cp0_cause_ & ~0x0000007C) | ((exc_code << 2) & 0x0000007C);
    cp0_status_ |= R4300Status::EXL;

    if (cp0_status_ & R4300Status::BEV) {
        pc_ = 0xBFC00200;
    } else {
        pc_ = 0x80000180;
    }
    next_pc_ = pc_ + 4;
}

void MipsR4300Core::raise_interrupt(uint32_t vector) {
    (void)vector;
    irq_pending_ = true;
}

void MipsR4300Core::trigger_exception(uint32_t cause, uint32_t epc) {
    cp0_epc_ = epc;
    raise_exception(cause);
}

// ============================================================================
// Instruction Execution
// ============================================================================

void MipsR4300Core::execute_special(uint32_t instr) {
    int funct = instr & 0x3F;
    int rd = (instr >> 11) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int sa = (instr >> 6) & 0x1F;

    switch (funct) {
        case 0x00: gpr_[rd] = (int64_t)(int32_t)(gpr_[rt] << sa); break;  // SLL
        case 0x02: gpr_[rd] = (int64_t)(int32_t)((uint32_t)gpr_[rt] >> sa); break;  // SRL
        case 0x03: gpr_[rd] = (int64_t)(int32_t)((int32_t)gpr_[rt] >> sa); break;  // SRA
        case 0x04: gpr_[rd] = gpr_[rt] << (gpr_[rs] & 0x1F); break;  // SLLV
        case 0x06: gpr_[rd] = (int64_t)(int32_t)((uint32_t)gpr_[rt] >> (gpr_[rs] & 0x1F)); break;  // SRLV
        case 0x07: gpr_[rd] = (int64_t)(int32_t)((int32_t)gpr_[rt] >> (gpr_[rs] & 0x1F)); break;  // SRAV
        case 0x08: branch((uint32_t)gpr_[rs]); break;  // JR
        case 0x09: gpr_[rd] = next_pc_; branch((uint32_t)gpr_[rs]); break;  // JALR
        case 0x0C: raise_exception(8, in_delay_slot_); break;  // SYSCALL
        case 0x0D: raise_exception(9, in_delay_slot_); break;  // BREAK
        case 0x10: gpr_[rd] = hi_; break;  // MFHI
        case 0x11: hi_ = gpr_[rs]; break;  // MTHI
        case 0x12: gpr_[rd] = lo_; break;  // MFLO
        case 0x13: lo_ = gpr_[rs]; break;  // MTLO
        case 0x18: { // MULT (64-bit result)
            int64_t result = (int64_t)(int32_t)gpr_[rs] * (int64_t)(int32_t)gpr_[rt];
            lo_ = (uint64_t)result;
            hi_ = (uint64_t)(result >> 32);
            break;
        }
        case 0x19: { // MULTU
            uint64_t result = (uint64_t)(uint32_t)gpr_[rs] * (uint64_t)(uint32_t)gpr_[rt];
            lo_ = result;
            hi_ = result >> 32;
            break;
        }
        case 0x1A: { // DIV
            int32_t divisor = (int32_t)gpr_[rt];
            if (divisor != 0) {
                lo_ = (uint64_t)(int64_t)((int32_t)gpr_[rs] / divisor);
                hi_ = (uint64_t)(int64_t)((int32_t)gpr_[rs] % divisor);
            }
            break;
        }
        case 0x1B: { // DIVU
            uint32_t divisor = (uint32_t)gpr_[rt];
            if (divisor != 0) {
                lo_ = (uint64_t)((uint32_t)gpr_[rs] / divisor);
                hi_ = (uint64_t)((uint32_t)gpr_[rs] % divisor);
            }
            break;
        }
        case 0x20: { // ADD (overflow checked)
            int32_t a = (int32_t)gpr_[rs], b = (int32_t)gpr_[rt];
            int32_t result = a + b;
            if ((a > 0 && b > 0 && result < 0) || (a < 0 && b < 0 && result > 0))
                raise_exception(12, in_delay_slot_);
            else
                gpr_[rd] = (int64_t)(int32_t)result;
            break;
        }
        case 0x21: gpr_[rd] = gpr_[rs] + gpr_[rt]; break;  // ADDU
        case 0x22: { // SUB
            int32_t a = (int32_t)gpr_[rs], b = (int32_t)gpr_[rt];
            int32_t result = a - b;
            if ((a > 0 && b < 0 && result < 0) || (a < 0 && b > 0 && result > 0))
                raise_exception(12, in_delay_slot_);
            else
                gpr_[rd] = (int64_t)(int32_t)result;
            break;
        }
        case 0x23: gpr_[rd] = gpr_[rs] - gpr_[rt]; break;  // SUBU
        case 0x24: gpr_[rd] = gpr_[rs] & gpr_[rt]; break;  // AND
        case 0x25: gpr_[rd] = gpr_[rs] | gpr_[rt]; break;  // OR
        case 0x26: gpr_[rd] = gpr_[rs] ^ gpr_[rt]; break;  // XOR
        case 0x27: gpr_[rd] = ~(gpr_[rs] | gpr_[rt]); break;  // NOR
        case 0x2A: gpr_[rd] = ((int64_t)gpr_[rs] < (int64_t)gpr_[rt]) ? 1 : 0; break;  // SLT
        case 0x2B: gpr_[rd] = (gpr_[rs] < gpr_[rt]) ? 1 : 0; break;  // SLTU
        case 0x2C: { // DADD (64-bit add)
            gpr_[rd] = gpr_[rs] + gpr_[rt];
            break;
        }
        case 0x2D: gpr_[rd] = gpr_[rs] + gpr_[rt]; break;  // DADDU
        case 0x2E: { // DSUB
            gpr_[rd] = gpr_[rs] - gpr_[rt];
            break;
        }
        case 0x2F: gpr_[rd] = gpr_[rs] - gpr_[rt]; break;  // DSUBU
        case 0x30: { // DSLL
            gpr_[rd] = gpr_[rt] << sa;
            break;
        }
        case 0x32: { // DSRL
            gpr_[rd] = gpr_[rt] >> sa;
            break;
        }
        case 0x33: { // DSRA (arithmetic)
            gpr_[rd] = (uint64_t)((int64_t)gpr_[rt] >> sa);
            break;
        }
        case 0x34: { // DSLLV
            gpr_[rd] = gpr_[rt] << (gpr_[rs] & 0x3F);
            break;
        }
        case 0x36: { // DSRLV
            gpr_[rd] = gpr_[rt] >> (gpr_[rs] & 0x3F);
            break;
        }
        case 0x37: { // DSRAV
            gpr_[rd] = (uint64_t)((int64_t)gpr_[rt] >> (gpr_[rs] & 0x3F));
            break;
        }
        case 0x38: { // DSLL32
            gpr_[rd] = gpr_[rt] << (sa + 32);
            break;
        }
        case 0x3A: { // DSRL32
            gpr_[rd] = gpr_[rt] >> (sa + 32);
            break;
        }
        case 0x3B: { // DSRA32
            gpr_[rd] = (uint64_t)((int64_t)gpr_[rt] >> (sa + 32));
            break;
        }
        default:
            raise_exception(10, in_delay_slot_);  // Reserved instruction
            break;
    }
}

void MipsR4300Core::execute_regimm(uint32_t instr) {
    int rt = (instr >> 16) & 0x1F;
    int rs = (instr >> 21) & 0x1F;
    int16_t offset = (int16_t)(instr & 0xFFFF);

    switch (rt) {
        case 0x00: if ((int64_t)gpr_[rs] < 0) branch((uint32_t)(pc_ + (offset << 2))); break;  // BLTZ
        case 0x01: if ((int64_t)gpr_[rs] >= 0) branch((uint32_t)(pc_ + (offset << 2))); break;  // BGEZ
        case 0x02: if ((int64_t)gpr_[rs] < 0) branch((uint32_t)(pc_ + (offset << 2))); else next_pc_ = pc_ + 4; break;  // BLTZL
        case 0x03: if ((int64_t)gpr_[rs] >= 0) branch((uint32_t)(pc_ + (offset << 2))); else next_pc_ = pc_ + 4; break;  // BGEZL
        case 0x10: gpr_[31] = next_pc_; if ((int64_t)gpr_[rs] < 0) branch((uint32_t)(pc_ + (offset << 2))); break;  // BLTZAL
        case 0x11: gpr_[31] = next_pc_; if ((int64_t)gpr_[rs] >= 0) branch((uint32_t)(pc_ + (offset << 2))); break;  // BGEZAL
        default: raise_exception(10, in_delay_slot_); break;
    }
}

void MipsR4300Core::execute_cop0(uint32_t instr) {
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int fsel = instr & 0x1F;

    switch (rs) {
        case 0x00: gpr_[rt] = (int64_t)(int32_t)get_cp0(fsel); break;  // MFC0
        case 0x04: set_cp0(fsel, (uint32_t)gpr_[rt]); break;  // MTC0
        case 0x10: { // CO — TLB/ERET
            int funct = instr & 0x3F;
            switch (funct) {
                case 0x18: { // ERET
                    pc_ = cp0_epc_;
                    next_pc_ = pc_ + 4;
                    cp0_status_ &= ~(R4300Status::EXL | R4300Status::ERL);
                    break;
                }
                default: break;
            }
            break;
        }
        default: break;
    }
}

void MipsR4300Core::execute_cop1(uint32_t instr) {
    if (!(cp0_status_ & R4300Status::CU1)) {
        raise_exception(11, in_delay_slot_);
        return;
    }

    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int fs = (instr >> 11) & 0x1F;
    int fd = (instr >> 6) & 0x1F;
    int funct = instr & 0x3F;

    switch (rs) {
        case 0x00: gpr_[rt] = (int64_t)(int32_t)(uint32_t)fpr_[fs]; break;  // MFC1 (32-bit)
        case 0x01: { // DMFC1 (64-bit)
            gpr_[rt] = fpr_[fs];
            break;
        }
        case 0x02: gpr_[rt] = (int64_t)(int32_t)((fs == 31) ? fcr31_ : 0); break;  // CFC1
        case 0x04: fpr_[fs] = (uint64_t)(uint32_t)gpr_[rt]; break;  // MTC1 (32-bit)
        case 0x05: fpr_[fs] = gpr_[rt]; break;  // DMTC1 (64-bit)
        case 0x06: if (fs == 31) fcr31_ = (uint32_t)gpr_[rt]; break;  // CTC1
        case 0x08: { // BC1
            int16_t offset = (int16_t)(instr & 0xFFFF);
            bool cond = (fcr31_ & (1 << 8)) != 0;
            if (rt & 1) cond = !cond;
            if (cond) branch((uint32_t)(pc_ + (offset << 2)));
            break;
        }
        default: {
            // FPU operations (simplified — single precision)
            float a, b, result;
            std::memcpy(&a, &fpr_[fs], sizeof(float));
            std::memcpy(&b, &fpr_[rt], sizeof(float));  // Note: rt field used as ft in COP1
            switch (funct) {
                case 0x00: result = a + b; break;  // ADD.S
                case 0x01: result = a - b; break;  // SUB.S
                case 0x02: result = a * b; break;  // MUL.S
                case 0x03: result = a / b; break;  // DIV.S
                case 0x04: result = sqrtf(a); break;  // SQRT.S
                case 0x05: result = fabsf(a); break;  // ABS.S
                case 0x06: result = a; break;  // MOV.S
                case 0x07: result = -a; break;  // NEG.S
                case 0x20: { // CVT.S.W (int to float)
                    int32_t int_val;
                    std::memcpy(&int_val, &fpr_[fs], sizeof(int32_t));
                    result = (float)int_val;
                    break;
                }
                default: result = 0; break;
            }
            std::memcpy(&fpr_[fd], &result, sizeof(float));
            break;
        }
    }
}

// ============================================================================
// Step / Run
// ============================================================================

int MipsR4300Core::step() {
    if (halted_) return -1;

    check_interrupts();
    cp0_count_++;

    uint32_t instr = fetch32();
    bool was_in_delay = in_delay_slot_;
    in_delay_slot_ = (next_pc_ != pc_ + 4);

    int opcode = (instr >> 26) & 0x3F;
    int rs = (instr >> 21) & 0x1F;
    int rt = (instr >> 16) & 0x1F;
    int16_t imm = (int16_t)(instr & 0xFFFF);

    switch (opcode) {
        case 0x00: execute_special(instr); break;
        case 0x01: execute_regimm(instr); break;
        case 0x02: { // J
            uint32_t target = (uint32_t)(pc_ & 0xFFFFFFFF00000000) | ((instr & 0x03FFFFFF) << 2);
            branch(target);
            break;
        }
        case 0x03: { // JAL
            gpr_[31] = next_pc_;
            uint32_t target = (uint32_t)(pc_ & 0xFFFFFFFF00000000) | ((instr & 0x03FFFFFF) << 2);
            branch(target);
            break;
        }
        case 0x04: if (gpr_[rs] == gpr_[rt]) branch((uint32_t)(pc_ + (imm << 2))); break;  // BEQ
        case 0x05: if (gpr_[rs] != gpr_[rt]) branch((uint32_t)(pc_ + (imm << 2))); break;  // BNE
        case 0x06: if ((int64_t)gpr_[rs] <= 0) branch((uint32_t)(pc_ + (imm << 2))); break;  // BLEZ
        case 0x07: if ((int64_t)gpr_[rs] > 0) branch((uint32_t)(pc_ + (imm << 2))); break;   // BGTZ
        case 0x08: { // ADDI
            int32_t a = (int32_t)gpr_[rs];
            int32_t result = a + imm;
            if ((a > 0 && imm > 0 && result < 0) || (a < 0 && imm < 0 && result > 0))
                raise_exception(12, was_in_delay);
            else
                gpr_[rt] = (int64_t)(int32_t)result;
            break;
        }
        case 0x09: gpr_[rt] = (int64_t)(int32_t)((uint32_t)gpr_[rs] + (uint32_t)imm); break;  // ADDIU
        case 0x0A: gpr_[rt] = ((int64_t)gpr_[rs] < imm) ? 1 : 0; break;  // SLTI
        case 0x0B: gpr_[rt] = (gpr_[rs] < (uint64_t)(uint32_t)imm) ? 1 : 0; break;  // SLTIU
        case 0x0C: gpr_[rt] = gpr_[rs] & (uint16_t)imm; break;  // ANDI
        case 0x0D: gpr_[rt] = gpr_[rs] | (uint16_t)imm; break;  // ORI
        case 0x0E: gpr_[rt] = gpr_[rs] ^ (uint16_t)imm; break;  // XORI
        case 0x0F: gpr_[rt] = (int64_t)(int32_t)((uint32_t)(uint16_t)imm << 16); break;  // LUI
        case 0x10: execute_cop0(instr); break;
        case 0x11: execute_cop1(instr); break;
        case 0x20: { // LB
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            gpr_[rt] = (int64_t)(int32_t)(int8_t)read8(addr);
            break;
        }
        case 0x21: { // LH
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            gpr_[rt] = (int64_t)(int32_t)(int16_t)read16(addr);
            break;
        }
        case 0x23: { // LW
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            gpr_[rt] = (int64_t)(int32_t)read32(addr);
            break;
        }
        case 0x24: { // LBU
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            gpr_[rt] = read8(addr);
            break;
        }
        case 0x25: { // LHU
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            gpr_[rt] = read16(addr);
            break;
        }
        case 0x27: { // LWU (unsigned 32-bit load)
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            gpr_[rt] = read32(addr);
            break;
        }
        case 0x28: { // SB
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            write8(addr, (uint8_t)gpr_[rt]);
            break;
        }
        case 0x29: { // SH
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            write16(addr, (uint16_t)gpr_[rt]);
            break;
        }
        case 0x2B: { // SW
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            write32(addr, (uint32_t)gpr_[rt]);
            break;
        }
        case 0x37: { // LD (64-bit load)
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            uint32_t lo = read32(addr);
            uint32_t hi = read32(addr + 4);
            gpr_[rt] = ((uint64_t)hi << 32) | lo;
            break;
        }
        case 0x3F: { // SD (64-bit store)
            uint32_t addr = (uint32_t)gpr_[rs] + imm;
            write32(addr, (uint32_t)gpr_[rt]);
            write32(addr + 4, (uint32_t)(gpr_[rt] >> 32));
            break;
        }
        default:
            raise_exception(10, was_in_delay);  // Reserved instruction
            break;
    }

    gpr_[0] = 0;  // R0 is always 0
    cycle_count_ += 2;
    instruction_count_++;
    return 0;
}

void MipsR4300Core::run(uint64_t max_instructions) {
    while (!halted_ && instruction_count_ < max_instructions) {
        step();
    }
}

// ============================================================================
// Disassembly
// ============================================================================

std::string MipsR4300Core::disasm_at(uint32_t addr, int* bytes_consumed) {
    uint32_t instr = read32(addr);
    int opcode = (instr >> 26) & 0x3F;

    static const char* op_names[] = {
        "SPECIAL","REGIMM","J","JAL","BEQ","BNE","BLEZ","BGTZ",
        "ADDI","ADDIU","SLTI","SLTIU","ANDI","ORI","XORI","LUI",
        "COP0","COP1","COP2","COP1X","BEQL","BNEL","BLEZL","BGTZL",
        "DADDI","DADDIU","LDL","LDR","","","","",
        "LB","LH","LWL","LW","LBU","LHU","LWR","LWU",
        "SB","SH","SWL","SW","SDL","SDR","SWR","",
        "LL","LWC1","LWC2","","LLD","LDC1","LDC2","",
        "SC","SWC1","SWC2","","SCD","SDC1","SDC2",""
    };

    std::ostringstream oss;
    oss << std::uppercase << std::hex << std::setfill('0');
    oss << std::setw(8) << addr << ":  " << std::setw(8) << instr << "  ";
    if (opcode < 64 && op_names[opcode][0])
        oss << op_names[opcode];
    else
        oss << "???";

    if (bytes_consumed) *bytes_consumed = 4;
    return oss.str();
}

// ============================================================================
// State Save/Restore
// ============================================================================

std::vector<uint8_t> MipsR4300Core::save_state() const {
    std::vector<uint8_t> state;
    auto append = [&](const void* data, size_t len) {
        state.insert(state.end(), (const uint8_t*)data, (const uint8_t*)data + len);
    };
    for (int i = 0; i < 32; i++) append(&gpr_[i], 8);
    append(&hi_, 8); append(&lo_, 8);
    append(&pc_, 8); append(&next_pc_, 8);
    append(&cp0_status_, 4); append(&cp0_cause_, 4); append(&cp0_epc_, 4);
    append(&cp0_count_, 4); append(&cp0_compare_, 4);
    for (int i = 0; i < 32; i++) append(&fpr_[i], 8);
    append(&fcr31_, 4);
    append(&halted_, 1); append(&irq_pending_, 1); append(&irq_lines_, 1);
    append(&in_delay_slot_, 1); append(&big_endian_, 1);
    for (int i = 0; i < 8; i++) state.push_back((cycle_count_ >> (i*8)) & 0xFF);
    for (int i = 0; i < 8; i++) state.push_back((instruction_count_ >> (i*8)) & 0xFF);
    return state;
}

void MipsR4300Core::load_state(const std::vector<uint8_t>& state) {
    if (state.size() < 320) return;
    size_t off = 0;
    for (int i = 0; i < 32; i++) {
        gpr_[i] = 0;
        for (int j = 0; j < 8; j++) gpr_[i] |= (uint64_t(state[off+j]) << (j*8));
        off += 8;
    }
    hi_ = 0; for (int j = 0; j < 8; j++) hi_ |= (uint64_t(state[off+j]) << (j*8)); off += 8;
    lo_ = 0; for (int j = 0; j < 8; j++) lo_ |= (uint64_t(state[off+j]) << (j*8)); off += 8;
    pc_ = 0; for (int j = 0; j < 8; j++) pc_ |= (uint64_t(state[off+j]) << (j*8)); off += 8;
    next_pc_ = 0; for (int j = 0; j < 8; j++) next_pc_ |= (uint64_t(state[off+j]) << (j*8)); off += 8;
    // Remaining fields skipped for brevity
}

CpuStateSnapshot MipsR4300Core::get_snapshot() const {
    CpuStateSnapshot s;
    s.pc = (uint32_t)pc_;
    s.next_pc = (uint32_t)next_pc_;
    s.sp = (uint32_t)gpr_[29];
    for (int i = 0; i < 32; i++) s.regs[i] = (uint32_t)gpr_[i];
    s.cycle_count = cycle_count_;
    s.instruction_count = instruction_count_;
    s.halted = halted_;
    s.arch = ArchID::MipsR4300;
    return s;
}

// =============================================================================
// cpu_r4300.h — MIPS R4300 CPU Core (Clean-Room Implementation)
//
// Implements ICpuCore for the MIPS R4300 64-bit RISC processor.
// Reference: MIPS R4000 User's Manual (public), github.com/project64/project64 (GPL)
//
// Features:
//   - 32 general-purpose 64-bit registers (GPR 0-31)
//   - 64-bit HI/LO registers
//   - CP0 system control coprocessor
//   - CP1 floating-point coprocessor (32 x 64-bit FPR)
//   - 32-bit address space (32-bit mode)
//   - Little-endian / big-endian configurable
//   - Load/store architecture with delay slots
//   - MIPS III instruction set (64-bit extensions)
//   - LL/SC atomic operations
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include <array>
#include <cstring>
#include <functional>

// ============================================================================
// R4300 Register Indices
// ============================================================================

enum R4300Reg {
    R43_R0 = 0,  R43_AT,  R43_V0,  R43_V1,
    R43_A0,      R43_A1,  R43_A2,  R43_A3,
    R43_T0,      R43_T1,  R43_T2,  R43_T3,
    R43_T4,      R43_T5,  R43_T6,  R43_T7,
    R43_S0,      R43_S1,  R43_S2,  R43_S3,
    R43_S4,      R43_S5,  R43_S6,  R43_S7,
    R43_T8,      R43_T9,  R43_K0,  R43_K1,
    R43_GP,      R43_SP,  R43_FP,  R43_RA,
    R43_HI,      R43_LO,  R43_PC,
    R43_STATUS,  R43_CAUSE, R43_EPC,
};

// ============================================================================
// Status Register Bits (same as R4000)
// ============================================================================

namespace R4300Status {
    constexpr uint32_t IE   = 0x00000001;
    constexpr uint32_t EXL  = 0x00000002;
    constexpr uint32_t ERL  = 0x00000004;
    constexpr uint32_t IM   = 0x0000FF00;
    constexpr uint32_t BEV  = 0x00400000;
    constexpr uint32_t FR   = 0x04000000;
    constexpr uint32_t CU0  = 0x10000000;
    constexpr uint32_t CU1  = 0x20000000;
}

// ============================================================================
// MipsR4300Core
// =============================================================================

class MipsR4300Core : public ICpuCore {
public:
    MipsR4300Core();
    ~MipsR4300Core() override = default;

    // ----- ICpuCore: Execution -----
    int step() override;
    void run(uint64_t max_instructions) override;
    void reset() override;
    void halt() override { halted_ = true; }
    bool is_halted() const override { return halted_; }

    // ----- ICpuCore: Architecture Info -----
    ArchID get_arch_id() const override { return ArchID::MipsR4300; }
    const char* get_arch_name() const override { return "MIPS R4300"; }
    int get_bit_depth() const override { return 32; }  // 32-bit address space
    bool is_big_endian() const override { return big_endian_; }
    uint64_t get_clock_hz() const override { return 93750000; }  // 93.75 MHz
    uint64_t get_cycle_count() const override { return cycle_count_; }
    uint64_t get_instruction_count() const override { return instruction_count_; }

    // ----- ICpuCore: Register Access -----
    int get_reg_count() const override { return 37; }
    const char* get_reg_name(int index) const override;
    uint32_t get_reg(int index) const override;
    void set_reg(int index, uint32_t value) override;
    uint32_t get_pc() const override { return (uint32_t)pc_; }
    void set_pc(uint32_t addr) override { pc_ = addr; next_pc_ = addr + 4; }
    uint32_t get_sp() const override { return (uint32_t)gpr_[29]; }
    void set_sp(uint32_t value) override { gpr_[29] = value; }
    uint32_t get_flags() const override { return cp0_status_; }
    void set_flags(uint32_t value) override { cp0_status_ = value; }

    // ----- ICpuCore: Memory Access -----
    uint8_t  read8(uint32_t addr) override;
    uint16_t read16(uint32_t addr) override;
    uint32_t read32(uint32_t addr) override;
    void     write8(uint32_t addr, uint8_t value) override;
    void     write16(uint32_t addr, uint16_t value) override;
    void     write32(uint32_t addr, uint32_t value) override;

    // ----- ICpuCore: Interrupts -----
    void raise_interrupt(uint32_t vector) override;
    void trigger_exception(uint32_t cause, uint32_t epc) override;
    bool has_pending_interrupt() const override { return irq_pending_; }
    void acknowledge_interrupt() override { irq_pending_ = false; }

    // ----- ICpuCore: Disassembly -----
    std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) override;

    // ----- ICpuCore: State Save/Restore -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;
    CpuStateSnapshot get_snapshot() const override;

    // ----- R4300-specific -----
    void set_memory_callbacks(
        std::function<uint8_t(uint32_t)> read_cb,
        std::function<void(uint32_t, uint8_t)> write_cb
    ) {
        mem_read_ = read_cb;
        mem_write_ = write_cb;
    }

    void set_big_endian(bool be) { big_endian_ = be; }

    // 64-bit register access
    uint64_t get_reg64(int index) const;
    void set_reg64(int index, uint64_t value);

    // CP0 access
    uint32_t get_cp0(int reg) const;
    void set_cp0(int reg, uint32_t value);

    // FPR access (64-bit)
    double get_fpr64(int reg) const;
    void set_fpr64(int reg, double value);
    uint64_t get_fpr_raw(int reg) const;
    void set_fpr_raw(int reg, uint64_t value);

    void set_irq_line(int line, bool active);

private:
    // 64-bit general purpose registers
    std::array<uint64_t, 32> gpr_ = {};
    uint64_t hi_ = 0;
    uint64_t lo_ = 0;
    uint64_t pc_ = 0;
    uint64_t next_pc_ = 0;

    // CP0 registers
    uint32_t cp0_status_ = 0;
    uint32_t cp0_cause_ = 0;
    uint32_t cp0_epc_ = 0;
    uint32_t cp0_count_ = 0;
    uint32_t cp0_compare_ = 0;
    uint32_t cp0_badvaddr_ = 0;
    uint32_t cp0_index_ = 0;
    uint32_t cp0_random_ = 0;
    uint32_t cp0_entryhi_ = 0;
    uint32_t cp0_entrylo0_ = 0;
    uint32_t cp0_entrylo1_ = 0;
    uint32_t cp0_pagemask_ = 0;
    uint32_t cp0_wired_ = 0;
    uint32_t cp0_context_ = 0;
    uint32_t cp0_prid_ = 0;
    uint32_t cp0_config_ = 0;

    // FPU registers (CP1) — 32 x 64-bit
    std::array<uint64_t, 32> fpr_ = {};
    uint32_t fcr31_ = 0;

    // State
    bool halted_ = false;
    bool irq_pending_ = false;
    uint8_t irq_lines_ = 0;
    bool in_delay_slot_ = false;
    bool big_endian_ = false;
    uint64_t cycle_count_ = 0;
    uint64_t instruction_count_ = 0;

    // Memory callbacks
    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t, uint8_t)> mem_write_;

    // Helpers
    inline uint32_t fetch32() {
        uint32_t val = read32((uint32_t)pc_);
        pc_ = next_pc_;
        next_pc_ = pc_ + 4;
        return val;
    }

    inline void branch(uint32_t target) {
        next_pc_ = target;
    }

    void check_interrupts();
    void raise_exception(uint32_t exc_code, bool in_delay_slot = false);

    // Instruction handlers (reuse R4000 patterns with 64-bit extensions)
    void execute_special(uint32_t instr);
    void execute_regimm(uint32_t instr);
    void execute_cop0(uint32_t instr);
    void execute_cop1(uint32_t instr);
};

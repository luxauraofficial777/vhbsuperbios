// =============================================================================
// cpu_arm7.h — ARM7TDMI CPU Core (Clean-Room Implementation)
//
// Implements ICpuCore for the ARM7TDMI 32-bit RISC processor.
// Reference: ARM7TDMI Technical Reference Manual (public),
//            github.com/visualboyadvance-m/vba-m (GPL)
//
// Features:
//   - 16 general-purpose 32-bit registers (R0-R15, R15=PC)
   //   - CPSR (Current Program Status Register) + SPSR (Saved Program Status)
//   - ARM (32-bit) and Thumb (16-bit) instruction sets
//   - 7 processor modes: User, FIQ, IRQ, Supervisor, Abort, Undefined, System
//   - Barrel shifter, conditional execution
//   - Load/store architecture
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include <array>
#include <cstring>
#include <functional>

// ============================================================================
// ARM7 Register Indices
// ============================================================================

enum Arm7Reg {
    ARM_R0 = 0,  ARM_R1,  ARM_R2,  ARM_R3,
    ARM_R4,      ARM_R5,  ARM_R6,  ARM_R7,
    ARM_R8,      ARM_R9,  ARM_R10, ARM_R11,
    ARM_R12,     ARM_R13, ARM_R14, ARM_R15,
    ARM_CPSR,    ARM_SPSR,
};

// ============================================================================
// CPSR Flags
// ============================================================================

namespace Arm7CPSR {
    constexpr uint32_t M = 0x0000001F;   // Mode bits
    constexpr uint32_t T = 0x00000020;   // Thumb state
    constexpr uint32_t F = 0x00000040;   // FIQ disable
    constexpr uint32_t I = 0x00000080;   // IRQ disable
    constexpr uint32_t V = 0x10000000;   // Overflow
    constexpr uint32_t C = 0x20000000;   // Carry
    constexpr uint32_t Z = 0x40000000;   // Zero
    constexpr uint32_t N = 0x80000000;   // Negative
}

// ============================================================================
// Processor Modes
// ============================================================================

namespace Arm7Mode {
    constexpr uint32_t USER       = 0x10;
    constexpr uint32_t FIQ        = 0x11;
    constexpr uint32_t IRQ        = 0x12;
    constexpr uint32_t SUPERVISOR = 0x13;
    constexpr uint32_t ABORT      = 0x17;
    constexpr uint32_t UNDEFINED  = 0x1B;
    constexpr uint32_t SYSTEM     = 0x1F;
}

// ============================================================================
// Arm7TDMICore
// =============================================================================

class Arm7TDMICore : public ICpuCore {
public:
    Arm7TDMICore();
    ~Arm7TDMICore() override = default;

    // ----- ICpuCore: Execution -----
    int step() override;
    void run(uint64_t max_instructions) override;
    void reset() override;
    void halt() override { halted_ = true; }
    bool is_halted() const override { return halted_; }

    // ----- ICpuCore: Architecture Info -----
    ArchID get_arch_id() const override { return ArchID::ARM7TDMI; }
    const char* get_arch_name() const override { return "ARM7TDMI"; }
    int get_bit_depth() const override { return 32; }
    bool is_big_endian() const override { return false; }
    uint64_t get_clock_hz() const override { return 16780000; }  // 16.78 MHz
    uint64_t get_cycle_count() const override { return cycle_count_; }
    uint64_t get_instruction_count() const override { return instruction_count_; }

    // ----- ICpuCore: Register Access -----
    int get_reg_count() const override { return 18; }
    const char* get_reg_name(int index) const override;
    uint32_t get_reg(int index) const override;
    void set_reg(int index, uint32_t value) override;
    uint32_t get_pc() const override { return gpr_[15]; }
    void set_pc(uint32_t addr) override { gpr_[15] = addr; }
    uint32_t get_sp() const override { return gpr_[13]; }
    void set_sp(uint32_t value) override { gpr_[13] = value; }
    uint32_t get_flags() const override { return cpsr_; }
    void set_flags(uint32_t value) override { cpsr_ = value; }

    // ----- ICpuCore: Memory Access -----
    uint8_t  read8(uint32_t addr) override;
    uint16_t read16(uint32_t addr) override;
    uint32_t read32(uint32_t addr) override;
    void     write8(uint32_t addr, uint8_t value) override;
    void     write16(uint32_t addr, uint16_t value) override;
    void     write32(uint32_t addr, uint32_t value) override;

    // ----- ICpuCore: Interrupts -----
    void raise_interrupt(uint32_t vector) override;
    void trigger_exception(uint32_t cause, uint32_t epc) override;
    bool has_pending_interrupt() const override { return irq_pending_; }
    void acknowledge_interrupt() override { irq_pending_ = false; }

    // ----- ICpuCore: Disassembly -----
    std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) override;

    // ----- ICpuCore: State Save/Restore -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;
    CpuStateSnapshot get_snapshot() const override;

    // ----- ARM7-specific -----
    void set_memory_callbacks(
        std::function<uint8_t(uint32_t)> read_cb,
        std::function<void(uint32_t, uint8_t)> write_cb
    ) {
        mem_read_ = read_cb;
        mem_write_ = write_cb;
    }

    void set_irq(bool active) { irq_pending_ = active; }
    void set_fiq(bool active) { fiq_pending_ = active; }

private:
    // General purpose registers (banked per mode)
    // R0-R7 are shared, R8-R14 are banked
    std::array<uint32_t, 16> gpr_ = {};      // User/system view
    std::array<uint32_t, 7>  fiq_regs_ = {};  // R8-R14 FIQ
    std::array<uint32_t, 2>  irq_regs_ = {};  // R13-R14 IRQ
    std::array<uint32_t, 2>  svc_regs_ = {};  // R13-R14 SVC
    std::array<uint32_t, 2>  abt_regs_ = {};  // R13-R14 ABT
    std::array<uint32_t, 2>  und_regs_ = {};  // R13-R14 UND

    uint32_t cpsr_ = 0;
    uint32_t spsr_fiq_ = 0, spsr_irq_ = 0, spsr_svc_ = 0;
    uint32_t spsr_abt_ = 0, spsr_und_ = 0;

    bool halted_ = false;
    bool irq_pending_ = false;
    bool fiq_pending_ = false;
    uint64_t cycle_count_ = 0;
    uint64_t instruction_count_ = 0;

    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t, uint8_t)> mem_write_;

    // Helpers
    inline bool is_thumb() const { return cpsr_ & Arm7CPSR::T; }
    inline uint32_t get_mode() const { return cpsr_ & Arm7CPSR::M; }
    inline bool check_cond(uint32_t cond) const;

    inline uint32_t fetch32_arm() {
        uint32_t val = read32(gpr_[15]);
        gpr_[15] += 4;
        return val;
    }

    inline uint16_t fetch16_thumb() {
        uint16_t val = read16(gpr_[15]);
        gpr_[15] += 2;
        return val;
    }

    // Barrel shifter
    uint32_t barrel_shift(uint32_t value, int shift_type, int amount, bool& carry);

    // Mode switching
    void switch_mode(uint32_t new_mode);
    uint32_t get_spsr() const;
    void set_spsr(uint32_t value);

    // Exception handling
    void raise_exception(uint32_t mode, uint32_t vector);

    // ARM instruction handlers
    void execute_arm(uint32_t instr);
    void execute_thumb(uint16_t instr);

    // ARM instruction groups
    void arm_data_processing(uint32_t instr);
    void arm_load_store(uint32_t instr);
    void arm_branch(uint32_t instr);
    void arm_block_transfer(uint32_t instr);
    void arm_multiply(uint32_t instr);
    void arm_coprocessor(uint32_t instr);
    void arm_swi(uint32_t instr);

    // Thumb instruction groups
    void thumb_data_processing(uint16_t instr);
    void thumb_load_store(uint16_t instr);
    void thumb_branch(uint16_t instr);
    void thumb_add_sub(uint16_t instr);
    void thumb_alu(uint16_t instr);
    void thumb_shift(uint16_t instr);
};

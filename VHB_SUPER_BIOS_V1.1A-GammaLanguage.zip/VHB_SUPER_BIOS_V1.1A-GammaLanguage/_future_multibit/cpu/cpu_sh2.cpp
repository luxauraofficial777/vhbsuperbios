// =============================================================================
// cpu_sh2.cpp — Hitachi SH-2 CPU Core Implementation (Clean-Room)
//
// Reference: SH-2 Programming Manual, github.com/devmiyax/sh2 (MIT)
//
// =============================================================================

#include "cpu_sh2.h"
#include <cstdio>
#include <sstream>
#include <iomanip>

// ============================================================================
// Constructor / Reset
// ============================================================================

Sh2Core::Sh2Core() {
    r_.fill(0);
    r_bank_.fill(0);
}

void Sh2Core::reset() {
    r_.fill(0);
    r_bank_.fill(0);
    pc_ = 0xA0000000;  // Reset vector (typical SH-2)
    sr_ = 0x000000F0;  // Interrupts masked, user mode
    gbr_ = 0;
    vbr_ = 0;
    mach_ = 0;
    macl_ = 0;
    pr_ = 0;
    halted_ = false;
    irq_pending_ = false;
    irq_level_ = 0;
    in_delay_slot_ = false;
    delayed_pc_ = 0;
    cycle_count_ = 0;
    instruction_count_ = 0;

    // Read reset vector from memory
    pc_ = read32(0x00000000);
    vbr_ = read32(0x00000004);
}

// ============================================================================
// Memory Access (big-endian)
// ============================================================================

uint8_t Sh2Core::read8(uint32_t addr) {
    if (mem_read_) return mem_read_(addr);
    return 0;
}

uint16_t Sh2Core::read16(uint32_t addr) {
    return (uint16_t(read8(addr)) << 8) | read8(addr + 1);
}

uint32_t Sh2Core::read32(uint32_t addr) {
    return (uint32_t(read8(addr)) << 24) | (uint32_t(read8(addr+1)) << 16) |
           (uint32_t(read8(addr+2)) << 8) | read8(addr+3);
}

void Sh2Core::write8(uint32_t addr, uint8_t value) {
    if (mem_write_) mem_write_(addr, value);
}

void Sh2Core::write16(uint32_t addr, uint16_t value) {
    write8(addr, value >> 8);
    write8(addr + 1, value & 0xFF);
}

void Sh2Core::write32(uint32_t addr, uint32_t value) {
    write8(addr, value >> 24);
    write8(addr+1, (value >> 16) & 0xFF);
    write8(addr+2, (value >> 8) & 0xFF);
    write8(addr+3, value & 0xFF);
}

// ============================================================================
// Register Access
// ============================================================================

const char* Sh2Core::get_reg_name(int index) const {
    static const char* names[] = {
        "R0","R1","R2","R3","R4","R5","R6","R7",
        "R8","R9","R10","R11","R12","R13","R14","R15",
        "PC","SR","GBR","VBR","MACH","MACL","PR"
    };
    if (index >= 0 && index < 23) return names[index];
    return "??";
}

uint32_t Sh2Core::get_reg(int index) const {
    if (index < 16) return r_[index];
    switch (index) {
        case SH2_PC: return pc_;
        case SH2_SR: return sr_;
        case SH2_GBR: return gbr_;
        case SH2_VBR: return vbr_;
        case SH2_MACH: return mach_;
        case SH2_MACL: return macl_;
        case SH2_PR: return pr_;
    }
    return 0;
}

void Sh2Core::set_reg(int index, uint32_t value) {
    if (index < 16) { r_[index] = value; return; }
    switch (index) {
        case SH2_PC: pc_ = value; return;
        case SH2_SR: sr_ = value; return;
        case SH2_GBR: gbr_ = value; return;
        case SH2_VBR: vbr_ = value; return;
        case SH2_MACH: mach_ = value; return;
        case SH2_MACL: macl_ = value; return;
        case SH2_PR: pr_ = value; return;
    }
}

// ============================================================================
// Exception Handling
// ============================================================================

void Sh2Core::raise_exception(uint32_t vector_code) {
    uint32_t old_sr = sr_;
    sr_ |= Sh2SR::BL;  // Block exceptions
    sr_ = (sr_ & ~Sh2SR::I) | 0x000000F0;  // Mask all interrupts

    // Push SR and PC
    r_[15] -= 4;
    write32(r_[15], pc_);
    r_[15] -= 4;
    write32(r_[15], old_sr);

    // Vector address
    uint32_t vector_addr = vbr_ + vector_code * 4;
    pc_ = read32(vector_addr);
    cycle_count_ += 8;
}

void Sh2Core::raise_interrupt(uint32_t vector) {
    (void)vector;
    irq_pending_ = true;
}

void Sh2Core::trigger_exception(uint32_t cause, uint32_t epc) {
    (void)epc;
    raise_exception(cause);
}

void Sh2Core::do_delayed_branch(uint32_t target) {
    // Execute one more instruction, then jump
    in_delay_slot_ = true;
    delayed_pc_ = target;
}

// ============================================================================
// Instruction Groups
// ============================================================================

void Sh2Core::op_group0(uint16_t instr) {
    int sub = (instr >> 8) & 0x0F;
    switch (sub) {
        case 0x00: { // STC SR, Rn
            int n = (instr >> 8) & 0x0F;
            r_[n] = sr_;
            cycle_count_ += 1;
            break;
        }
        case 0x01: { // STC GBR, Rn
            int n = (instr >> 8) & 0x0F;
            r_[n] = gbr_;
            cycle_count_ += 1;
            break;
        }
        case 0x02: { // STC VBR, Rn
            int n = (instr >> 8) & 0x0F;
            r_[n] = vbr_;
            cycle_count_ += 1;
            break;
        }
        case 0x04: { // ROTL Rn
            int n = instr & 0x0F;
            bool carry = (r_[n] & 0x80000000) != 0;
            r_[n] = (r_[n] << 1) | (carry ? 1 : 0);
            sr_ = (sr_ & ~Sh2SR::T) | (carry ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x05: { // ROTR Rn
            int n = instr & 0x0F;
            bool carry = (r_[n] & 1) != 0;
            r_[n] = (r_[n] >> 1) | (carry ? 0x80000000 : 0);
            sr_ = (sr_ & ~Sh2SR::T) | (carry ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x06: { // LDS.L @Rm+, MACH
            int m = (instr >> 8) & 0x0F;
            mach_ = read32(r_[m]);
            r_[m] += 4;
            cycle_count_ += 2;
            break;
        }
        case 0x07: { // LDS.L @Rm+, MACL
            int m = (instr >> 8) & 0x0F;
            macl_ = read32(r_[m]);
            r_[m] += 4;
            cycle_count_ += 2;
            break;
        }
        case 0x08: { // SHL2 Rn
            int n = instr & 0x0F;
            r_[n] <<= 2;
            cycle_count_ += 1;
            break;
        }
        case 0x09: { // SHL8 Rn
            int n = instr & 0x0F;
            r_[n] <<= 8;
            cycle_count_ += 1;
            break;
        }
        case 0x0A: { // SHL16 Rn
            int n = instr & 0x0F;
            r_[n] <<= 16;
            cycle_count_ += 1;
            break;
        }
        case 0x0B: { // SHLR2 Rn
            int n = instr & 0x0F;
            r_[n] >>= 2;
            cycle_count_ += 1;
            break;
        }
        case 0x0C: { // SHLR8 Rn
            int n = instr & 0x0F;
            r_[n] >>= 8;
            cycle_count_ += 1;
            break;
        }
        case 0x0D: { // SHLR16 Rn
            int n = instr & 0x0F;
            r_[n] >>= 16;
            cycle_count_ += 1;
            break;
        }
        case 0x0E: { // LDC.L @Rm+, SR
            int m = (instr >> 8) & 0x0F;
            sr_ = read32(r_[m]);
            r_[m] += 4;
            cycle_count_ += 3;
            break;
        }
        default:
            cycle_count_ += 1;
            break;
    }
}

void Sh2Core::op_group1(uint16_t instr) {
    // ADD #imm, Rn
    int n = (instr >> 8) & 0x0F;
    int8_t imm = (int8_t)(instr & 0xFF);
    r_[n] += (uint32_t)(int32_t)imm;
    cycle_count_ += 1;
}

void Sh2Core::op_group2(uint16_t instr) {
    int sub = (instr >> 8) & 0x0F;
    int n = instr & 0x0F;
    switch (sub) {
        case 0x00: { // MOVBS Rm, @Rn
            int m = (instr >> 4) & 0x0F;
            write8(r_[n], r_[m] & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x01: { // MOVWS Rm, @Rn
            int m = (instr >> 4) & 0x0F;
            write16(r_[n], r_[m] & 0xFFFF);
            cycle_count_ += 1;
            break;
        }
        case 0x02: { // MOVLS Rm, @Rn
            int m = (instr >> 4) & 0x0F;
            write32(r_[n], r_[m]);
            cycle_count_ += 1;
            break;
        }
        case 0x04: { // MOVBL @Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = (uint32_t)(int32_t)(int8_t)read8(r_[m]);
            cycle_count_ += 2;
            break;
        }
        case 0x05: { // MOVWL @Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = (uint32_t)(int32_t)(int16_t)read16(r_[m]);
            cycle_count_ += 2;
            break;
        }
        case 0x06: { // MOVLL @Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = read32(r_[m]);
            cycle_count_ += 2;
            break;
        }
        case 0x07: { // NOT Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = ~r_[m];
            cycle_count_ += 1;
            break;
        }
        case 0x08: { // SWAP.B Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = (r_[m] & 0xFFFF0000) | ((r_[m] & 0xFF) << 8) | ((r_[m] >> 8) & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x09: { // SWAP.W Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = (r_[m] & 0xFFFF0000) | ((r_[m] >> 16) & 0xFFFF) | ((r_[m] & 0xFFFF) << 16);
            cycle_count_ += 1;
            break;
        }
        case 0x0A: { // NEGC Rm, Rn
            int m = (instr >> 4) & 0x0F;
            uint32_t tmp = r_[m];
            r_[n] = -tmp;
            if (tmp != 0) sr_ |= Sh2SR::T; else sr_ &= ~Sh2SR::T;
            cycle_count_ += 1;
            break;
        }
        case 0x0B: { // NEG Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = -r_[m];
            cycle_count_ += 1;
            break;
        }
        case 0x0C: { // EXTU.B Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = r_[m] & 0xFF;
            cycle_count_ += 1;
            break;
        }
        case 0x0D: { // EXTU.W Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = r_[m] & 0xFFFF;
            cycle_count_ += 1;
            break;
        }
        case 0x0E: { // EXTS.B Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = (uint32_t)(int32_t)(int8_t)(r_[m] & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x0F: { // EXTS.W Rm, Rn
            int m = (instr >> 4) & 0x0F;
            r_[n] = (uint32_t)(int32_t)(int16_t)(r_[m] & 0xFFFF);
            cycle_count_ += 1;
            break;
        }
        default:
            cycle_count_ += 1;
            break;
    }
}

void Sh2Core::op_group3(uint16_t instr) {
    int sub = (instr >> 4) & 0x0F;
    int m = (instr >> 8) & 0x0F;
    int n = instr & 0x0F;

    switch (sub) {
        case 0x00: r_[n] += r_[m]; cycle_count_ += 1; break; // ADD
        case 0x01: r_[n] += r_[m]; sr_ = (sr_ & ~Sh2SR::T) | (r_[n] < r_[m] ? Sh2SR::T : 0); cycle_count_ += 1; break; // ADDC
        case 0x02: r_[n] -= r_[m]; cycle_count_ += 1; break; // SUB
        case 0x03: r_[n] -= r_[m]; sr_ = (sr_ & ~Sh2SR::T) | (r_[n] <= r_[m] ? Sh2SR::T : 0); cycle_count_ += 1; break; // SUBC
        case 0x04: { // CMP/STR
            uint32_t tmp = r_[n] ^ r_[m];
            bool t = false;
            for (int i = 0; i < 4; i++) {
                if (((tmp >> (i*8)) & 0xFF) == 0) t = true;
            }
            sr_ = (sr_ & ~Sh2SR::T) | (t ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x05: r_[n] += r_[m]; cycle_count_ += 1; break; // ADDV (simplified)
        case 0x06: r_[n] -= r_[m]; cycle_count_ += 1; break; // SUBV (simplified)
        case 0x07: { // CMP/HI
            sr_ = (sr_ & ~Sh2SR::T) | (r_[n] > r_[m] ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x08: { // CMP/EQ
            sr_ = (sr_ & ~Sh2SR::T) | (r_[n] == r_[m] ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x09: r_[n] &= r_[m]; cycle_count_ += 1; break; // AND
        case 0x0A: r_[n] |= r_[m]; cycle_count_ += 1; break; // OR
        case 0x0B: r_[n] ^= r_[m]; cycle_count_ += 1; break; // XOR
        case 0x0C: r_[n] = r_[n] & ~r_[m]; cycle_count_ += 1; break; // ANDC (simplified)
        case 0x0D: { // XTRCT
            r_[n] = (r_[n] >> 16) | (r_[m] << 16);
            cycle_count_ += 1;
            break;
        }
        case 0x0E: { // MULU.W
            macl_ = (uint32_t)(r_[n] & 0xFFFF) * (uint32_t)(r_[m] & 0xFFFF);
            cycle_count_ += 3;
            break;
        }
        case 0x0F: { // MULS.W
            macl_ = (uint32_t)((int16_t)(r_[n] & 0xFFFF) * (int16_t)(r_[m] & 0xFFFF));
            cycle_count_ += 3;
            break;
        }
    }
}

void Sh2Core::op_group4(uint16_t instr) {
    int sub = (instr >> 8) & 0x0F;
    int n = instr & 0x0F;
    switch (sub) {
        case 0x00: { // SHLL Rn
            bool carry = (r_[n] & 0x80000000) != 0;
            r_[n] <<= 1;
            sr_ = (sr_ & ~Sh2SR::T) | (carry ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x01: { // SHLR Rn
            bool carry = (r_[n] & 1) != 0;
            r_[n] >>= 1;
            sr_ = (sr_ & ~Sh2SR::T) | (carry ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x04: { // ROTCL Rn
            bool carry = (r_[n] & 0x80000000) != 0;
            r_[n] = (r_[n] << 1) | ((sr_ & Sh2SR::T) ? 1 : 0);
            sr_ = (sr_ & ~Sh2SR::T) | (carry ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x05: { // ROTCR Rn
            bool carry = (r_[n] & 1) != 0;
            r_[n] = (r_[n] >> 1) | ((sr_ & Sh2SR::T) ? 0x80000000 : 0);
            sr_ = (sr_ & ~Sh2SR::T) | (carry ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x06: { // LDS.L @Rm+, MACH
            int m = n;
            mach_ = read32(r_[m]);
            r_[m] += 4;
            cycle_count_ += 2;
            break;
        }
        case 0x07: { // LDS.L @Rm+, MACL
            int m = n;
            macl_ = read32(r_[m]);
            r_[m] += 4;
            cycle_count_ += 2;
            break;
        }
        case 0x08: { // SHLL2 Rn
            r_[n] <<= 2;
            cycle_count_ += 1;
            break;
        }
        case 0x09: { // SHLL8 Rn
            r_[n] <<= 8;
            cycle_count_ += 1;
            break;
        }
        case 0x0A: { // SHLL16 Rn
            r_[n] <<= 16;
            cycle_count_ += 1;
            break;
        }
        case 0x0B: { // SHLR2 Rn
            r_[n] >>= 2;
            cycle_count_ += 1;
            break;
        }
        case 0x0C: { // SHLR8 Rn
            r_[n] >>= 8;
            cycle_count_ += 1;
            break;
        }
        case 0x0D: { // SHLR16 Rn
            r_[n] >>= 16;
            cycle_count_ += 1;
            break;
        }
        case 0x0E: { // LDC.L @Rm+, SR
            int m = n;
            sr_ = read32(r_[m]);
            r_[m] += 4;
            cycle_count_ += 3;
            break;
        }
        case 0x0F: { // MAC.W @Rm+,@Rn+ (simplified)
            int m = (instr >> 4) & 0x0F;
            int16_t a = (int16_t)read16(r_[m]);
            int16_t b = (int16_t)read16(r_[n]);
            int32_t result = a * b;
            macl_ += (uint32_t)result;
            r_[m] += 2;
            r_[n] += 2;
            cycle_count_ += 3;
            break;
        }
        default:
            cycle_count_ += 1;
            break;
    }
}

void Sh2Core::op_group5(uint16_t instr) {
    int sub = (instr >> 8) & 0x0F;
    int m = (instr >> 4) & 0x0F;
    int n = instr & 0x0F;

    switch (sub) {
        case 0x00: write8(r_[n], r_[m] & 0xFF); r_[n] += 1; cycle_count_ += 1; break; // MOV.B Rm,@-Rn
        case 0x01: write16(r_[n] - 2, r_[m] & 0xFFFF); r_[n] -= 2; cycle_count_ += 1; break; // MOV.W Rm,@-Rn
        case 0x02: r_[n] -= 4; write32(r_[n], r_[m]); cycle_count_ += 2; break; // MOV.L Rm,@-Rn
        case 0x04: r_[n] = (uint32_t)(int32_t)(int8_t)read8(r_[m]); r_[m] += 1; cycle_count_ += 2; break; // MOV.B @Rm+,Rn
        case 0x05: r_[n] = (uint32_t)(int32_t)(int16_t)read16(r_[m]); r_[m] += 2; cycle_count_ += 2; break; // MOV.W @Rm+,Rn
        case 0x06: r_[n] = read32(r_[m]); r_[m] += 4; cycle_count_ += 2; break; // MOV.L @Rm+,Rn
        case 0x07: r_[n] = r_[m]; cycle_count_ += 1; break; // MOV Rm,Rn
        case 0x08: { // CMP/EQ #imm,Rn (handled in group1)
            cycle_count_ += 1;
            break;
        }
        case 0x09: { // TST #imm,R0
            uint8_t imm = instr & 0xFF;
            sr_ = (sr_ & ~Sh2SR::T) | ((r_[0] & imm) == 0 ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x0A: { // AND #imm,R0
            uint8_t imm = instr & 0xFF;
            r_[0] &= imm;
            cycle_count_ += 1;
            break;
        }
        case 0x0B: { // OR #imm,R0
            uint8_t imm = instr & 0xFF;
            r_[0] |= imm;
            cycle_count_ += 1;
            break;
        }
        case 0x0C: { // XOR #imm,R0
            uint8_t imm = instr & 0xFF;
            r_[0] ^= imm;
            cycle_count_ += 1;
            break;
        }
        case 0x0D: { // AND.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) & imm);
            cycle_count_ += 3;
            break;
        }
        case 0x0E: { // OR.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) | imm);
            cycle_count_ += 3;
            break;
        }
        case 0x0F: { // XOR.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) ^ imm);
            cycle_count_ += 3;
            break;
        }
        default:
            cycle_count_ += 1;
            break;
    }
}

void Sh2Core::op_group6(uint16_t instr) {
    // MOV.L @(disp,Rm),Rn
    int m = (instr >> 4) & 0x0F;
    int n = (instr >> 8) & 0x0F;
    uint32_t disp = (instr & 0x0F) * 4;
    r_[n] = read32(r_[m] + disp);
    cycle_count_ += 2;
}

void Sh2Core::op_group7(uint16_t instr) {
    // MOV.L Rm,@(disp,Rn)
    int m = (instr >> 4) & 0x0F;
    int n = (instr >> 8) & 0x0F;
    uint32_t disp = (instr & 0x0F) * 4;
    write32(r_[n] + disp, r_[m]);
    cycle_count_ += 2;
}

void Sh2Core::op_group8(uint16_t instr) {
    int sub = (instr >> 8) & 0x0F;
    int n = instr & 0x0F;

    switch (sub) {
        case 0x00: { // CMP/EQ #imm,Rn
            int8_t imm = (int8_t)(instr & 0xFF);
            sr_ = (sr_ & ~Sh2SR::T) | (((int32_t)r_[n] == (int32_t)imm) ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x01: { // BT/S disp
            if (sr_ & Sh2SR::T) {
                int8_t disp = (int8_t)(instr & 0xFF);
                do_delayed_branch(pc_ + disp * 2);
            }
            cycle_count_ += 2;
            break;
        }
        case 0x02: { // BF/S disp
            if (!(sr_ & Sh2SR::T)) {
                int8_t disp = (int8_t)(instr & 0xFF);
                do_delayed_branch(pc_ + disp * 2);
            }
            cycle_count_ += 2;
            break;
        }
        case 0x03: { // BT disp
            if (sr_ & Sh2SR::T) {
                int8_t disp = (int8_t)(instr & 0xFF);
                do_delayed_branch(pc_ + disp * 2);
            }
            cycle_count_ += 2;
            break;
        }
        case 0x04: { // BF disp
            if (!(sr_ & Sh2SR::T)) {
                int8_t disp = (int8_t)(instr & 0xFF);
                do_delayed_branch(pc_ + disp * 2);
            }
            cycle_count_ += 2;
            break;
        }
        case 0x05: { // LDC.L @Rm+,GBR
            gbr_ = read32(r_[n]);
            r_[n] += 4;
            cycle_count_ += 3;
            break;
        }
        case 0x06: { // LDC.L @Rm+,VBR
            vbr_ = read32(r_[n]);
            r_[n] += 4;
            cycle_count_ += 3;
            break;
        }
        case 0x07: { // LDC Rm,VBR
            vbr_ = r_[n];
            cycle_count_ += 1;
            break;
        }
        case 0x08: { // TST #imm,R0
            uint8_t imm = instr & 0xFF;
            sr_ = (sr_ & ~Sh2SR::T) | ((r_[0] & imm) == 0 ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x09: { // AND #imm,R0
            r_[0] &= (instr & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x0A: { // OR #imm,R0
            r_[0] |= (instr & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x0B: { // XOR #imm,R0
            r_[0] ^= (instr & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x0C: { // TST.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            sr_ = (sr_ & ~Sh2SR::T) | ((read8(addr) & imm) == 0 ? Sh2SR::T : 0);
            cycle_count_ += 3;
            break;
        }
        case 0x0D: { // AND.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) & imm);
            cycle_count_ += 3;
            break;
        }
        case 0x0E: { // OR.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) | imm);
            cycle_count_ += 3;
            break;
        }
        case 0x0F: { // XOR.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) ^ imm);
            cycle_count_ += 3;
            break;
        }
    }
}

void Sh2Core::op_group9(uint16_t instr) {
    // MOV.W @(disp,PC),Rn
    int n = (instr >> 8) & 0x0F;
    uint32_t disp = (instr & 0xFF) * 2;
    uint32_t addr = (pc_ & ~1) + disp;
    r_[n] = (uint32_t)(int32_t)(int16_t)read16(addr);
    cycle_count_ += 2;
}

void Sh2Core::op_groupA(uint16_t instr) {
    // BRA disp
    int32_t disp = (int32_t)(int16_t)(instr & 0xFFF);
    if (disp & 0x800) disp |= 0xFFFFF000;
    do_delayed_branch(pc_ + disp * 2);
    cycle_count_ += 2;
}

void Sh2Core::op_groupB(uint16_t instr) {
    // BSR disp
    int32_t disp = (int32_t)(int16_t)(instr & 0xFFF);
    if (disp & 0x800) disp |= 0xFFFFF000;
    pr_ = pc_;  // Save return address
    do_delayed_branch(pc_ + disp * 2);
    cycle_count_ += 2;
}

void Sh2Core::op_groupC(uint16_t instr) {
    int sub = (instr >> 8) & 0x0F;
    switch (sub) {
        case 0x00: { // MOV.B R0,@(disp,GBR)
            uint32_t disp = instr & 0xFF;
            write8(gbr_ + disp, r_[0] & 0xFF);
            cycle_count_ += 2;
            break;
        }
        case 0x01: { // MOV.W R0,@(disp,GBR)
            uint32_t disp = (instr & 0xFF) * 2;
            write16(gbr_ + disp, r_[0] & 0xFFFF);
            cycle_count_ += 2;
            break;
        }
        case 0x02: { // MOV.L R0,@(disp,GBR)
            uint32_t disp = (instr & 0xFF) * 4;
            write32(gbr_ + disp, r_[0]);
            cycle_count_ += 2;
            break;
        }
        case 0x03: { // TRAPA #imm
            uint8_t imm = instr & 0xFF;
            r_[15] -= 4; write32(r_[15], pc_);
            r_[15] -= 4; write32(r_[15], sr_);
            pc_ = read32(vbr_ + imm * 4);
            cycle_count_ += 8;
            break;
        }
        case 0x04: { // MOV.B @(disp,GBR),R0
            uint32_t disp = instr & 0xFF;
            r_[0] = read8(gbr_ + disp);
            cycle_count_ += 2;
            break;
        }
        case 0x05: { // MOV.W @(disp,GBR),R0
            uint32_t disp = (instr & 0xFF) * 2;
            r_[0] = read16(gbr_ + disp);
            cycle_count_ += 2;
            break;
        }
        case 0x06: { // MOV.L @(disp,GBR),R0
            uint32_t disp = (instr & 0xFF) * 4;
            r_[0] = read32(gbr_ + disp);
            cycle_count_ += 2;
            break;
        }
        case 0x07: { // MOVA @(disp,PC),R0
            uint32_t disp = (instr & 0xFF) * 4;
            r_[0] = ((pc_ & ~3) + disp);
            cycle_count_ += 2;
            break;
        }
        case 0x08: { // TST #imm,R0
            uint8_t imm = instr & 0xFF;
            sr_ = (sr_ & ~Sh2SR::T) | ((r_[0] & imm) == 0 ? Sh2SR::T : 0);
            cycle_count_ += 1;
            break;
        }
        case 0x09: { // AND #imm,R0
            r_[0] &= (instr & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x0A: { // OR #imm,R0
            r_[0] |= (instr & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x0B: { // XOR #imm,R0
            r_[0] ^= (instr & 0xFF);
            cycle_count_ += 1;
            break;
        }
        case 0x0C: { // TST.B #imm,@(R0,GBR)
            uint8_t imm = instr & 0xFF;
            sr_ = (sr_ & ~Sh2SR::T) | ((read8(gbr_ + r_[0]) & imm) == 0 ? Sh2SR::T : 0);
            cycle_count_ += 3;
            break;
        }
        case 0x0D: { // AND.B
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) & imm);
            cycle_count_ += 3;
            break;
        }
        case 0x0E: { // OR.B
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) | imm);
            cycle_count_ += 3;
            break;
        }
        case 0x0F: { // XOR.B
            uint8_t imm = instr & 0xFF;
            uint32_t addr = gbr_ + r_[0];
            write8(addr, read8(addr) ^ imm);
            cycle_count_ += 3;
            break;
        }
    }
}

void Sh2Core::op_groupD(uint16_t instr) {
    // MOV.L @(disp,PC),Rn
    int n = (instr >> 8) & 0x0F;
    uint32_t disp = (instr & 0xFF) * 4;
    uint32_t addr = ((pc_ & ~3) + disp);
    r_[n] = read32(addr);
    cycle_count_ += 2;
}

void Sh2Core::op_groupE(uint16_t instr) {
    // MOV #imm,Rn
    int n = (instr >> 8) & 0x0F;
    int8_t imm = (int8_t)(instr & 0xFF);
    r_[n] = (uint32_t)(int32_t)imm;
    cycle_count_ += 1;
}

void Sh2Core::op_groupF(uint16_t instr) {
    int sub = (instr >> 4) & 0x0F;
    int m = (instr >> 8) & 0x0F;
    int n = instr & 0x0F;

    switch (sub) {
        case 0x00: { // FADD (FPU — simplified)
            cycle_count_ += 3;
            break;
        }
        case 0x04: { // FCMPEQ
            sr_ = (sr_ & ~Sh2SR::T) | Sh2SR::T;  // Simplified
            cycle_count_ += 3;
            break;
        }
        case 0x05: { // FCMPGT
            sr_ = (sr_ & ~Sh2SR::T);
            cycle_count_ += 3;
            break;
        }
        case 0x0A: { // FSTS (simplified)
            cycle_count_ += 1;
            break;
        }
        case 0x0E: { // FMOV.S @Rm,FRn (simplified)
            cycle_count_ += 1;
            break;
        }
        case 0x0F: { // MAC.L @Rm+,@Rn+
            int32_t a = (int32_t)read32(r_[m]);
            int32_t b = (int32_t)read32(r_[n]);
            int64_t result = (int64_t)a * (int64_t)b;
            result += (int64_t)(int32_t)mach_ << 32 | (uint32_t)macl_;
            if (sr_ & Sh2SR::S) {
                // Saturated
                if (result > 0x7FFFFFFF) result = 0x7FFFFFFF;
                if (result < -0x80000000LL) result = -0x80000000LL;
            }
            mach_ = (uint32_t)(result >> 32);
            macl_ = (uint32_t)(result & 0xFFFFFFFF);
            r_[m] += 4;
            r_[n] += 4;
            cycle_count_ += 3;
            break;
        }
        default:
            cycle_count_ += 1;
            break;
    }
}

// ============================================================================
// Main Instruction Decoder
// ============================================================================

void Sh2Core::execute_instruction(uint16_t instr) {
    int group = (instr >> 12) & 0x0F;
    switch (group) {
        case 0x0: op_group0(instr); break;
        case 0x1: op_group1(instr); break;
        case 0x2: op_group2(instr); break;
        case 0x3: op_group3(instr); break;
        case 0x4: op_group4(instr); break;
        case 0x5: op_group5(instr); break;
        case 0x6: op_group6(instr); break;
        case 0x7: op_group7(instr); break;
        case 0x8: op_group8(instr); break;
        case 0x9: op_group9(instr); break;
        case 0xA: op_groupA(instr); break;
        case 0xB: op_groupB(instr); break;
        case 0xC: op_groupC(instr); break;
        case 0xD: op_groupD(instr); break;
        case 0xE: op_groupE(instr); break;
        case 0xF: op_groupF(instr); break;
    }
}

// ============================================================================
// Step / Run
// ============================================================================

int Sh2Core::step() {
    if (halted_) return -1;

    // Check for interrupts
    if (irq_pending_ && irq_level_ > get_int_mask()) {
        raise_exception(irq_level_);  // Level-indexed vector
        irq_pending_ = false;
        return 0;
    }

    uint16_t instr = fetch16();
    execute_instruction(instr);

    // Handle delayed branch
    if (in_delay_slot_) {
        in_delay_slot_ = false;
        pc_ = delayed_pc_;
    }

    instruction_count_++;
    return 0;
}

void Sh2Core::run(uint64_t max_instructions) {
    while (!halted_ && instruction_count_ < max_instructions) {
        step();
    }
}

// ============================================================================
// Disassembly
// ============================================================================

std::string Sh2Core::disasm_at(uint32_t addr, int* bytes_consumed) {
    uint16_t instr = read16(addr);
    int group = (instr >> 12) & 0x0F;

    static const char* group_names[] = {
        "GR0","ADD#imm","GR2","GR3","GR4","GR5","MOV.L@disp","MOV.L@disp",
        "GR8","MOV.W@PC","BRA","BSR","GRC","MOV.L@PC","MOV#imm","GRF"
    };

    std::ostringstream oss;
    oss << std::uppercase << std::hex << std::setfill('0');
    oss << std::setw(8) << addr << ":  " << std::setw(4) << instr << "  ";
    oss << group_names[group];

    if (bytes_consumed) *bytes_consumed = 2;
    return oss.str();
}

// ============================================================================
// State Save/Restore
// ============================================================================

std::vector<uint8_t> Sh2Core::save_state() const {
    std::vector<uint8_t> state;
    auto append = [&](const void* data, size_t len) {
        state.insert(state.end(), (const uint8_t*)data, (const uint8_t*)data + len);
    };
    for (int i = 0; i < 16; i++) append(&r_[i], 4);
    append(&pc_, 4); append(&sr_, 4); append(&gbr_, 4); append(&vbr_, 4);
    append(&mach_, 4); append(&macl_, 4); append(&pr_, 4);
    for (int i = 0; i < 8; i++) append(&r_bank_[i], 4);
    append(&halted_, 1); append(&irq_pending_, 1); append(&irq_level_, 1);
    append(&in_delay_slot_, 1);
    for (int i = 0; i < 8; i++) state.push_back((cycle_count_ >> (i*8)) & 0xFF);
    for (int i = 0; i < 8; i++) state.push_back((instruction_count_ >> (i*8)) & 0xFF);
    return state;
}

void Sh2Core::load_state(const std::vector<uint8_t>& state) {
    if (state.size() < 100) return;
    size_t off = 0;
    for (int i = 0; i < 16; i++) {
        r_[i] = state[off] | (uint32_t(state[off+1]) << 8) |
                (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24);
        off += 4;
    }
    pc_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    sr_ = state[off] | (uint32_t(state[off+1]) << 8) | (uint32_t(state[off+2]) << 16) | (uint32_t(state[off+3]) << 24); off += 4;
    // Remaining fields skipped for brevity
}

CpuStateSnapshot Sh2Core::get_snapshot() const {
    CpuStateSnapshot s;
    s.pc = pc_;
    s.next_pc = pc_;
    s.sp = r_[15];
    for (int i = 0; i < 16; i++) s.regs[i] = r_[i];
    s.cycle_count = cycle_count_;
    s.instruction_count = instruction_count_;
    s.halted = halted_;
    s.arch = ArchID::SH2;
    return s;
}

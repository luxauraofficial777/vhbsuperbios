// =============================================================================
// cpu_mc68000.h — Motorola 68000 CPU Core (Clean-Room Implementation)
//
// Implements ICpuCore for the Motorola 68000 16/32-bit microprocessor.
// Reference: M68000 Programmer's Reference Manual (public),
//            github.com/tonytomov/M68k (MIT), github.com/kstenerud/Musashi (MIT)
//
// The 68000 has:
//   - 16 32-bit general-purpose registers (D0-D7 data, A0-A7 address)
//   - 32-bit program counter (24-bit external address bus = 16MB)
//   - 16-bit status register (SR): 8-bit system byte + 8-bit user byte (CCR)
//   - Supervisor and user modes
//   - 8/16/32-bit data operations
//   - 56 instruction types with 14 addressing modes
//
// =============================================================================

#pragma once

#include "icpu_core.h"
#include <array>
#include <cstring>
#include <functional>

// ============================================================================
// 68000 Register Indices
// ============================================================================

enum M68kReg {
    M68K_D0 = 0, M68K_D1, M68K_D2, M68K_D3, M68K_D4,
    M68K_D5, M68K_D6, M68K_D7,
    M68K_A0, M68K_A1, M68K_A2, M68K_A3, M68K_A4,
    M68K_A5, M68K_A6, M68K_A7,
    M68K_SR, M68K_PC,
};

// ============================================================================
// 68000 Status Register Flags
// ============================================================================

namespace M68kFlags {
    // Condition Code Register (low byte)
    constexpr uint16_t C = 0x0001;  // Carry
    constexpr uint16_t V = 0x0002;  // Overflow
    constexpr uint16_t Z = 0x0004;  // Zero
    constexpr uint16_t N = 0x0008;  // Negative
    constexpr uint16_t X = 0x0010;  // Extend
    // System Byte (high byte)
    constexpr uint16_t I0 = 0x0100; // Interrupt mask bit 0
    constexpr uint16_t I1 = 0x0200; // Interrupt mask bit 1
    constexpr uint16_t I2 = 0x0400; // Interrupt mask bit 2
    constexpr uint16_t M  = 0x1000; // Master/interrupt state
    constexpr uint16_t S  = 0x2000; // Supervisor mode
    constexpr uint16_t T0 = 0x4000; // Trace mode bit 0
    constexpr uint16_t T1 = 0x8000; // Trace mode bit 1
}

// ============================================================================
// MC68000Core
// =============================================================================

class MC68000Core : public ICpuCore {
public:
    MC68000Core();
    ~MC68000Core() override = default;

    // ----- ICpuCore: Execution -----
    int step() override;
    void run(uint64_t max_instructions) override;
    void reset() override;
    void halt() override { halted_ = true; }
    bool is_halted() const override { return halted_; }

    // ----- ICpuCore: Architecture Info -----
    ArchID get_arch_id() const override { return ArchID::MC68000; }
    const char* get_arch_name() const override { return "Motorola 68000"; }
    int get_bit_depth() const override { return 16; }
    bool is_big_endian() const override { return true; }
    uint64_t get_clock_hz() const override { return 7600000; }  // 7.67 MHz
    uint64_t get_cycle_count() const override { return cycle_count_; }
    uint64_t get_instruction_count() const override { return instruction_count_; }

    // ----- ICpuCore: Register Access -----
    int get_reg_count() const override { return 18; }
    const char* get_reg_name(int index) const override;
    uint32_t get_reg(int index) const override;
    void set_reg(int index, uint32_t value) override;
    uint32_t get_pc() const override { return pc_; }
    void set_pc(uint32_t addr) override { pc_ = addr & 0xFFFFFF; }
    uint32_t get_sp() const override { return regs_[15]; }  // A7
    void set_sp(uint32_t value) override { regs_[15] = value & 0xFFFFFF; }
    uint32_t get_flags() const override { return sr_; }
    void set_flags(uint32_t value) override { sr_ = value & 0xFFFF; }

    // ----- ICpuCore: Memory Access -----
    uint8_t  read8(uint32_t addr) override;
    uint16_t read16(uint32_t addr) override;
    uint32_t read32(uint32_t addr) override;
    void     write8(uint32_t addr, uint8_t value) override;
    void     write16(uint32_t addr, uint16_t value) override;
    void     write32(uint32_t addr, uint32_t value) override;

    // ----- ICpuCore: Interrupts -----
    void raise_interrupt(uint32_t vector) override;
    void trigger_exception(uint32_t cause, uint32_t epc) override;
    bool has_pending_interrupt() const override { return irq_pending_; }
    void acknowledge_interrupt() override { irq_pending_ = false; }

    // ----- ICpuCore: Disassembly -----
    std::string disasm_at(uint32_t addr, int* bytes_consumed = nullptr) override;

    // ----- ICpuCore: State Save/Restore -----
    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;
    CpuStateSnapshot get_snapshot() const override;

    // ----- 68000-specific -----
    void set_irq_level(int level) { irq_level_ = level; irq_pending_ = (level > 0); }

    void set_memory_callbacks(
        std::function<uint8_t(uint32_t)> read_cb,
        std::function<void(uint32_t, uint8_t)> write_cb
    ) {
        mem_read_ = read_cb;
        mem_write_ = write_cb;
    }

    // Exception vectors
    enum ExceptionVector {
        EXC_RESET_SP       = 0,
        EXC_RESET_PC       = 1,
        EXC_BUS_ERROR      = 2,
        EXC_ADDRESS_ERROR  = 3,
        EXC_ILLEGAL_INSTR  = 4,
        EXC_DIV_BY_ZERO    = 5,
        EXC_CHK_INSTR      = 6,
        EXC_TRAPV          = 7,
        EXC_PRIVILEGE      = 8,
        EXC_TRACE          = 9,
        EXC_LINE_1010      = 10,
        EXC_LINE_1111      = 11,
        EXC_UNINITIALIZED  = 15,
        EXC_SPURIOUS_IRQ   = 24,
        EXC_IRQ_LEVEL1     = 25,
        EXC_IRQ_LEVEL2     = 26,
        EXC_IRQ_LEVEL3     = 27,
        EXC_IRQ_LEVEL4     = 28,
        EXC_IRQ_LEVEL5     = 29,
        EXC_IRQ_LEVEL6     = 30,
        EXC_IRQ_LEVEL7     = 31,
        EXC_TRAP_0         = 32,
        EXC_TRAP_15        = 47,
    };

private:
    // Registers: D0-D7 (0-7), A0-A7 (8-15)
    std::array<uint32_t, 16> regs_ = {};
    uint32_t pc_ = 0;
    uint16_t sr_ = 0x2700;  // Supervisor mode, interrupt mask 7

    // State
    bool halted_ = false;
    bool irq_pending_ = false;
    int irq_level_ = 0;
    uint64_t cycle_count_ = 0;
    uint64_t instruction_count_ = 0;

    // Memory callbacks
    std::function<uint8_t(uint32_t)> mem_read_;
    std::function<void(uint32_t, uint8_t)> mem_write_;

    // ----- Helpers -----
    inline uint32_t read_reg(int idx) const { return regs_[idx & 0x0F]; }
    inline void write_reg(int idx, uint32_t val) { regs_[idx & 0x0F] = val; }

    inline bool is_supervisor() const { return (sr_ & M68kFlags::S) != 0; }
    inline int get_int_mask() const { return (sr_ >> 8) & 0x07; }

    inline uint16_t fetch16() {
        uint16_t val = read16(pc_);
        pc_ += 2;
        return val;
    }

    inline uint32_t fetch32() {
        uint32_t val = read32(pc_);
        pc_ += 4;
        return val;
    }

    // Stack operations
    inline void push32(uint32_t val) {
        regs_[15] -= 4;
        write32(regs_[15], val);
    }

    inline uint32_t pop32() {
        uint32_t val = read32(regs_[15]);
        regs_[15] += 4;
        return val;
    }

    inline void push16(uint16_t val) {
        regs_[15] -= 2;
        write16(regs_[15], val);
    }

    inline uint16_t pop16() {
        uint16_t val = read16(regs_[15]);
        regs_[15] += 2;
        return val;
    }

    // Flag helpers
    inline void set_flag(uint16_t flag, bool condition) {
        if (condition) sr_ |= flag; else sr_ &= ~flag;
    }

    inline void set_nz8(uint8_t val) {
        set_flag(M68kFlags::Z, val == 0);
        set_flag(M68kFlags::N, val & 0x80);
    }

    inline void set_nz16(uint16_t val) {
        set_flag(M68kFlags::Z, val == 0);
        set_flag(M68kFlags::N, val & 0x8000);
    }

    inline void set_nz32(uint32_t val) {
        set_flag(M68kFlags::Z, val == 0);
        set_flag(M68kFlags::N, val & 0x80000000);
    }

    // Exception handling
    void raise_exception(int vector);
    void handle_interrupt();

    // Addressing modes
    uint32_t ea_data_reg(int mode, int reg, int size);
    uint32_t ea_addr_reg(int mode, int reg, int size);
    uint32_t ea_displacement(int reg);
    uint32_t ea_indexed(int reg);
    uint32_t ea_absolute_short();
    uint32_t ea_absolute_long();
    uint32_t ea_pc_displacement();
    uint32_t ea_pc_indexed();
    uint32_t ea_immediate(int size);

    uint32_t read_ea(int mode, int reg, int size);
    void write_ea(int mode, int reg, int size, uint32_t value);

    // Instruction handlers
    void op_move(int size, int src_mode, int src_reg, int dst_mode, int dst_reg);
    void op_moveq(int data, int dst_reg);
    void op_add(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg);
    void op_sub(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg);
    void op_and(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg);
    void op_or(int size, int src_mode, int src_reg, int dst_mode, int dst_reg, bool ea_to_reg);
    void op_eor(int size, int src_mode, int src_reg, int dst_mode, int dst_reg);
    void op_cmp(int size, int src_mode, int src_reg, int dst_reg);
    void op_lea(int src_mode, int src_reg, int dst_reg);
    void op_jmp(int src_mode, int src_reg);
    void op_jsr(int src_mode, int src_reg);
    void op_bra(int8_t offset);
    void op_bsr(int8_t offset);
    void op_bcc(int cc, int8_t offset);
    void op_dbcc(int cc, int reg, int16_t offset);
    void op_rts();
    void op_rte();
    void op_tst(int size, int mode, int reg);
    void op_clr(int size, int mode, int reg);
    void op_neg(int size, int mode, int reg);
    void op_not(int size, int mode, int reg);
    void op_swap(int reg);
    void op_ext(int size, int reg);
    void op_pea(int mode, int reg);
    void op_link(int reg, int16_t offset);
    void op_unlk(int reg);
    void op_trap(int vector);
    void op_stop();
    void op_reset();
    void op_nop();
    void op_lsl(int size, int count, int mode, int reg);
    void op_lsr(int size, int count, int mode, int reg);
    void op_asl(int size, int count, int mode, int reg);
    void op_asr(int size, int count, int mode, int reg);
    void op_rol(int size, int count, int mode, int reg);
    void op_ror(int size, int count, int mode, int reg);
    void op_roxl(int size, int count, int mode, int reg);
    void op_roxr(int size, int count, int mode, int reg);
    void op_mulu(int src_mode, int src_reg, int dst_reg);
    void op_muls(int src_mode, int src_reg, int dst_reg);
    void op_divu(int src_mode, int src_reg, int dst_reg);
    void op_divs(int src_mode, int src_reg, int dst_reg);

    // Condition codes
    bool check_cc(int cc) const;
};

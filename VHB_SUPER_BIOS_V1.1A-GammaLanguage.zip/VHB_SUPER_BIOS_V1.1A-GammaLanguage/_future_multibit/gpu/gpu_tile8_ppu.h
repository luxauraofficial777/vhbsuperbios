// =============================================================================
// gpu_tile8_ppu.h — Tile-8 PPU (Picture Processing Unit) — Clean-Room
//
// Emulates the Tile-8 PPU: tile-based rendering with 2bpp/4bpp tiles,
// sprites, scroll, and nametable mirroring.
// Reference: public PPU documentation, github.com/AndreaOrru/LaiNES (BSD-2)
//
// PPU Memory Map:
//   $0000-$0FFF: Pattern table 0 (256 tiles)
//   $1000-$1FFF: Pattern table 1 (256 tiles)
//   $2000-$23FF: Nametable 0
//   $2400-$27FF: Nametable 1
//   $2800-$2BFF: Nametable 2
//   $2C00-$2FFF: Nametable 3
//   $3000-$3EFF: Mirror of $2000-$2EFF
//   $3F00-$3F1F: Palette RAM (32 bytes)
//   $3F20-$3FFF: Mirror of $3F00-$3F1F
//
// Registers (CPU-mapped at $2000-$2007):
//   $2000: PPUCTRL   — NMI, rendering mode, nametable base, increment
//   $2001: PPUMASK   — color, sprite/tile enable, clipping
//   $2002: PPUSTATUS — vblank, sprite 0 hit, sprite overflow
//   $2003: OAMADDR   — OAM address
//   $2004: OAMDATA   — OAM data
//   $2005: PPUSCROLL — scroll X/Y
//   $2006: PPUADDR   — VRAM address
//   $2007: PPUDATA   — VRAM data
//
// =============================================================================

#pragma once

#include "igpu_core.h"
#include <array>
#include <cstring>
#include <functional>

class Tile8Ppu : public IGpuCore {
public:
    Tile8Ppu();
    ~Tile8Ppu() override = default;

    void reset() override;
    void step(int cycles) override;

    uint32_t read_reg(uint32_t addr) override;
    void write_reg(uint32_t addr, uint32_t value) override;

    void dma_write(const uint8_t* data, uint32_t len) override;
    void dma_read(uint8_t* dest, uint32_t len) override;

    const uint32_t* get_framebuffer() const override { return framebuffer_.data(); }
    int get_width() const override { return 256; }
    int get_height() const override { return 240; }
    int get_color_depth() const override { return 2; }  // 2bpp default

    GpuTypeID get_type_id() const override { return GpuTypeID::Tile8Ppu; }
    const char* get_type_name() const override { return "Tile-8 PPU"; }
    uint32_t get_frame_count() const override { return frame_count_; }
    uint32_t get_command_count() const override { return reg_write_count_; }
    uint32_t get_draw_count() const override { return draw_count_; }
    uint32_t get_scanline() const override { return scanline_; }
    bool is_vblank() const override { return scanline_ >= 240; }
    bool is_hblank() const override { return dot_ >= 256; }

    GpuStateSnapshot get_snapshot() const override {
        GpuStateSnapshot s;
        s.frame_count = frame_count_;
        s.scanline = scanline_;
        s.dot = dot_;
        s.command_count = reg_write_count_;
        s.draw_count = draw_count_;
        s.vblank = is_vblank();
        s.hblank = is_hblank();
        s.type = GpuTypeID::Tile8Ppu;
        return s;
    }

    std::vector<uint8_t> save_state() const override;
    void load_state(const std::vector<uint8_t>& state) override;

    // PPU-specific
    void set_nmi_callback(std::function<void()> cb) { nmi_callback_ = cb; }
    void set_vram_read(std::function<uint8_t(uint16_t)> cb) { vram_read_ = cb; }
    void set_vram_write(std::function<void(uint16_t, uint8_t)> cb) { vram_write_ = cb; }

    // OAM DMA (256 bytes from CPU page)
    void oam_dma(const uint8_t* page_data);

    // Rendering
    void render_scanline();
    void render_background();
    void render_sprites();

    // Pattern table access (for CHR ROM/RAM)
    void load_chr_rom(const uint8_t* chr, uint32_t len);

private:
    // PPU registers
    uint8_t ppuctrl_ = 0;    // $2000
    uint8_t ppumask_ = 0;    // $2001
    uint8_t ppustatus_ = 0;  // $2002
    uint8_t oam_addr_ = 0;   // $2003
    uint16_t ppu_addr_ = 0;  // $2006 (latched)
    bool addr_latch_ = false;
    uint8_t scroll_x_ = 0;
    uint8_t scroll_y_ = 0;
    bool scroll_latch_ = false;

    // OAM (Object Attribute Memory) — 256 bytes, 64 sprites
    std::array<uint8_t, 256> oam_{};

    // VRAM (2KB nametables + palette)
    std::array<uint8_t, 2048> vram_{};
    std::array<uint8_t, 32> palette_{};

    // CHR RAM/ROM (8KB)
    std::array<uint8_t, 8192> chr_{};

    // Framebuffer (256x240, 32-bit RGBA)
    std::array<uint32_t, 256 * 240> framebuffer_{};

    // State
    int scanline_ = 0;       // 0-261 (NTSC)
    int dot_ = 0;            // 0-340
    uint32_t frame_count_ = 0;
    uint32_t reg_write_count_ = 0;
    uint32_t draw_count_ = 0;

    // Callbacks
    std::function<void()> nmi_callback_;
    std::function<uint8_t(uint16_t)> vram_read_;
    std::function<void(uint16_t, uint8_t)> vram_write_;

    // Helpers
    inline uint16_t vram_addr(uint16_t addr) {
        // Nametable mirroring
        addr &= 0x3FFF;
        if (addr >= 0x3000 && addr < 0x3F00) addr -= 0x1000;
        if (addr >= 0x3F20) addr = 0x3F00 + (addr & 0x1F);
        return addr;
    }

    inline uint8_t read_vram(uint16_t addr) {
        addr = vram_addr(addr);
        if (addr < 0x2000) return chr_[addr];
        if (addr < 0x3000) return vram_[addr - 0x2000];
        if (addr >= 0x3F00) return palette_[addr & 0x1F];
        return 0;
    }

    inline void write_vram(uint16_t addr, uint8_t val) {
        addr = vram_addr(addr);
        if (addr < 0x2000) chr_[addr] = val;
        else if (addr < 0x3000) vram_[addr - 0x2000] = val;
        else if (addr >= 0x3F00) palette_[addr & 0x1F] = val;
    }

    // Palette to RGBA
    inline uint32_t palette_to_rgba(uint8_t index) {
        // Simplified — use a basic 64-color palette
        static const uint32_t ntsc_palette[64] = {
            0x666666FF, 0x002A88FF, 0x1412A7FF, 0x3B00A4FF, 0x5C0078FF, 0x6E0064FF, 0x6C0060FF, 0x520030FF,
            0x33000AFF, 0x020000FF, 0x0A1A00FF, 0x0A2C00FF, 0x083A00FF, 0x052C00FF, 0x000000FF, 0x000000FF,
            0xADADADFF, 0x155FD9FF, 0x4240FFFF, 0x7527FEFF, 0xA01ACCFF, 0xB71E7BFF, 0xB52620FF, 0x991000FF,
            0x671000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF,
            0xFFFFFF, 0x6FB7FFFF, 0x9999FFFF, 0xC0A0FFFF, 0xF271FFFF, 0xFF6CC5FF, 0xFF8132FF, 0xFF9A00FF,
            0xFFB300FF, 0xFFC700FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF,
            0xFFFFFF, 0xC6C6FFFF, 0xD7D7FFFF, 0xE5E5FFFF, 0xF5D4FFFF, 0xFFAEE7FF, 0xFFB3B3FF, 0xFFD1A3FF,
            0xFFE3A3FF, 0xFFF0A3FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF, 0x000000FF,
        };
        return ntsc_palette[index & 0x3F];
    }
};

// =============================================================================
// igpu_core.h — Universal GPU/Display Interface for Multi-Bit-Depth Platform
//
// All GPU cores (Tile-8 PPU, Tile-16 PPU, CD-16 VDP, Handheld-8 PPU,
// Handheld-32 PPU, Cart-64 RDP, Portable-Media-32 GPU, CD-24/32 GPU)
// implement this interface.
//
// Clean-room design: no proprietary names, no SDK headers.
// =============================================================================

#pragma once

#include <cstdint>
#include <string>
#include <vector>

// ============================================================================
// GPU Types
// ============================================================================

enum class GpuTypeID : uint8_t {
    Unknown     = 0,
    Tile8Ppu    = 1,    // Tile-based PPU, 2bpp/4bpp tiles + sprites
    Tile16Ppu   = 2,    // Mode-based PPU, affine, HDMA, 15-bit color
    Cd16Vdp     = 3,    // VDP with planes, sprites, DMA, shadow/highlight
    Hh8Ppu      = 4,    // LCD-based PPU, scanline renderer
    Hh32Ppu     = 5,    // Mode-based PPU, OBJ, affine, 16-bit color
    Cd32Gpu     = 6,    // Framebuffer + 3D polygon commands
    Cd32xVdp    = 7,    // Dual VDP (VDP1 + VDP2) with polygon sprites
    Cart64Rdp   = 8,    // RDP rasterizer + RSP microcode
    Pm32Gpu     = 9,    // 3D pipeline GPU, 480x272, 16-bit framebuffer
};

struct GpuStateSnapshot {
    uint32_t frame_count = 0;
    uint32_t scanline = 0;
    uint32_t dot = 0;
    uint32_t command_count = 0;
    uint32_t draw_count = 0;
    uint32_t dma_count = 0;
    bool vblank = false;
    bool hblank = false;
    GpuTypeID type = GpuTypeID::Unknown;
};

// ============================================================================
// IGpuCore — Universal GPU Interface
// ============================================================================

class IGpuCore {
public:
    virtual ~IGpuCore() = default;

    // ----- Lifecycle --------------------------------------------------------

    virtual void reset() = 0;

    // Advance the GPU by the given number of cycles.
    virtual void step(int cycles) = 0;

    // ----- Register Access --------------------------------------------------

    virtual uint32_t read_reg(uint32_t addr) = 0;
    virtual void write_reg(uint32_t addr, uint32_t value) = 0;

    // ----- DMA ---------------------------------------------------------------

    // DMA write to GPU (e.g., command FIFO or VRAM fill).
    virtual void dma_write(const uint8_t* data, uint32_t len) = 0;

    // DMA read from GPU (e.g., VRAM readback).
    virtual void dma_read(uint8_t* dest, uint32_t len) = 0;

    // ----- Framebuffer -------------------------------------------------------

    // Get the current framebuffer as 32-bit RGBA (for screenshot/visual bridge).
    virtual const uint32_t* get_framebuffer() const = 0;

    // Framebuffer dimensions.
    virtual int get_width() const = 0;
    virtual int get_height() const = 0;

    // Color depth in bits per pixel (2, 4, 8, 15, 16, 24, 32).
    virtual int get_color_depth() const = 0;

    // ----- Status and Telemetry ---------------------------------------------

    // Get GPU type ID.
    virtual GpuTypeID get_type_id() const = 0;

    // Get human-readable GPU name.
    virtual const char* get_type_name() const = 0;

    // Total frames rendered since reset.
    virtual uint32_t get_frame_count() const = 0;

    // Total GPU commands processed.
    virtual uint32_t get_command_count() const = 0;

    // Total draw operations (sprites, polygons, tiles).
    virtual uint32_t get_draw_count() const = 0;

    // Current scanline (0 = top of frame).
    virtual uint32_t get_scanline() const = 0;

    // Is the GPU currently in VBlank?
    virtual bool is_vblank() const = 0;

    // Is the GPU currently in HBlank?
    virtual bool is_hblank() const = 0;

    // Get a lightweight state snapshot for harness telemetry.
    virtual GpuStateSnapshot get_snapshot() const = 0;

    // ----- State Save/Restore -----------------------------------------------

    virtual std::vector<uint8_t> save_state() const = 0;
    virtual void load_state(const std::vector<uint8_t>& state) = 0;
};

// ============================================================================
// GPU Core Factory
// ============================================================================

IGpuCore* create_gpu_core(GpuTypeID type);

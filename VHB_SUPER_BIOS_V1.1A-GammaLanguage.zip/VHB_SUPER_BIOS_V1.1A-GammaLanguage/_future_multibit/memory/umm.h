// =============================================================================
// umm.h — Unified Memory Manager for Multi-Bit-Depth Platform
//
// Provides a soft-MMU with per-target memory profiles, bank switching,
// and DMA channel management. All CPU cores delegate memory access here.
//
// Clean-room design: no proprietary names, no SDK headers.
// =============================================================================

#pragma once

#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <unordered_map>
#include <functional>

// ============================================================================
// Memory Region Types
// ============================================================================

enum class MemRegionType : uint8_t {
    RAM         = 0,
    VRAM        = 1,
    AudioRAM    = 2,
    Scratchpad  = 3,
    Expansion   = 4,
    ROM         = 5,
    SRAM        = 6,
    HWReg       = 7,
    Unmapped    = 8,
};

struct MemRegion {
    uint32_t start;
    uint32_t end;
    const char* name;
    MemRegionType type;
    bool writable;
    bool executable;
};

// ============================================================================
// Memory Profile (per-target configuration)
// ============================================================================

struct MemoryProfile {
    const char* name;
    uint32_t system_ram;
    uint32_t video_ram;
    uint32_t audio_ram;
    uint32_t scratchpad;
    uint32_t expansion_ram;
    uint32_t rom_space;
    uint32_t sram_space;
    bool has_bank_switching;
    uint32_t bank_size;
    uint32_t max_banks;
    bool big_endian;
};

// ============================================================================
// Predefined Memory Profiles
// ============================================================================

namespace MemoryProfiles {
    // CD-24/CD-32 (MIPS R3000A, 2MB RAM)
    extern const MemoryProfile Cd32_2MB;
    // CD-24/CD-32 (MIPS R3000A, 8MB RAM)
    extern const MemoryProfile Cd32_8MB;
    // Tile-8 (MOS 6502, 2KB RAM)
    extern const MemoryProfile Tile8;
    // Tile-16 (WDC 65C816, 128KB RAM)
    extern const MemoryProfile Tile16;
    // CD-16 (Motorola 68000, 64KB RAM)
    extern const MemoryProfile Cd16;
    // Handheld-8 (LR35902, 8KB RAM)
    extern const MemoryProfile Hh8;
    // Handheld-32 (ARM7TDMI, 256KB RAM)
    extern const MemoryProfile Hh32;
    // CD-32X (Dual SH-2, 256KB RAM)
    extern const MemoryProfile Cd32x;
    // Cart-64 (MIPS R4300, 4MB RAM)
    extern const MemoryProfile Cart64;
    // Portable-Media-32 (MIPS R4000, 32MB RAM)
    extern const MemoryProfile Pm32;
}

// ============================================================================
// DMA Channel
// ============================================================================

struct DmaChannel {
    uint32_t src = 0;
    uint32_t dest = 0;
    uint32_t block_size = 0;
    uint32_t block_count = 0;
    bool enabled = false;
    bool irq_on_completion = false;
    int channel_id = 0;
};

// ============================================================================
// Unified Memory Manager
// ============================================================================

class UnifiedMemoryManager {
public:
    UnifiedMemoryManager();
    ~UnifiedMemoryManager();

    // Initialize with a memory profile.
    void init(const MemoryProfile& profile);

    // Reset to power-on state.
    void reset();

    // ----- Memory Access (called by ICpuCore implementations) ---------------

    uint8_t  read8(uint32_t addr);
    uint16_t read16(uint32_t addr);
    uint32_t read32(uint32_t addr);
    void     write8(uint32_t addr, uint8_t value);
    void     write16(uint32_t addr, uint16_t value);
    void     write32(uint32_t addr, uint32_t value);

    // Bulk read/write.
    void read_block(uint32_t addr, uint8_t* dest, size_t len);
    void write_block(uint32_t addr, const uint8_t* src, size_t len);

    // Direct memory access (bypasses MMU mapping — for BIOS loading).
    uint8_t* get_ram_ptr();
    uint32_t get_ram_size() const;

    // ----- Region Management ------------------------------------------------

    void register_region(uint32_t start, uint32_t end, const char* name,
                         MemRegionType type, bool writable, bool executable);

    const MemRegion* find_region(uint32_t addr) const;
    bool is_address_valid(uint32_t addr) const;
    bool is_writable(uint32_t addr) const;
    bool is_executable(uint32_t addr) const;

    // ----- Bank Switching ---------------------------------------------------

    void load_banks(const std::vector<uint8_t>& rom, uint32_t bank_size);
    void switch_bank(uint32_t bank_idx);
    uint32_t get_current_bank() const;
    uint32_t get_switch_count() const;

    // ----- DMA Channels -----------------------------------------------------

    void set_dma_channel(int channel, const DmaChannel& config);
    void trigger_dma(int channel);
    bool is_dma_active(int channel) const;
    void set_dma_callback(int channel, std::function<void()> callback);

    // ----- Telemetry --------------------------------------------------------

    uint64_t get_read_count() const;
    uint64_t get_write_count() const;
    uint64_t get_dma_transfer_count() const;

    // ----- State Save/Restore -----------------------------------------------

    std::vector<uint8_t> save_state() const;
    void load_state(const std::vector<uint8_t>& state);

private:
    struct Impl;
    Impl* m;
};

// =============================================================================
// umm.cpp — Unified Memory Manager Implementation
//
// Clean-room design: no proprietary names, no SDK headers.
// =============================================================================

#include "umm.h"
#include <algorithm>
#include <cstring>

// ============================================================================
// Memory Profiles
// ============================================================================

namespace MemoryProfiles {

const MemoryProfile Cd32_2MB = {
    "CD-32 (2MB)", 2*1024*1024, 1024*1024, 512*1024, 1024,
    8*1024*1024, 0, 128*1024, false, 0, 0, false
};

const MemoryProfile Cd32_8MB = {
    "CD-32 (8MB)", 8*1024*1024, 1024*1024, 512*1024, 1024,
    0, 0, 128*1024, false, 0, 0, false
};

const MemoryProfile Tile8 = {
    "Tile-8", 2*1024, 2*1024, 0, 0,
    0, 32*1024, 8*1024, true, 16*1024, 256, false
};

const MemoryProfile Tile16 = {
    "Tile-16", 128*1024, 64*1024 + 256 + 64*1024, 64*1024, 0,
    0, 6*1024*1024, 32*1024, true, 32*1024, 64, false
};

const MemoryProfile Cd16 = {
    "CD-16", 64*1024, 64*1024, 8*1024, 0,
    0, 4*1024*1024, 8*1024, false, 0, 0, true
};

const MemoryProfile Hh8 = {
    "Handheld-8", 8*1024, 8*1024, 0, 0,
    0, 32*1024, 32*1024, true, 16*1024, 512, false
};

const MemoryProfile Hh32 = {
    "Handheld-32", 256*1024, 96*1024 + 1024, 64*1024, 16*1024,
    0, 32*1024*1024, 64*1024, false, 0, 0, false
};

const MemoryProfile Cd32x = {
    "CD-32X", 256*1024, 256*1024, 256*1024, 0,
    0, 4*1024*1024, 8*1024, false, 0, 0, true
};

const MemoryProfile Cart64 = {
    "Cart-64", 4*1024*1024, 4*1024, 0, 16*1024 + 4*1024,
    4*1024*1024, 64*1024*1024, 32*1024, false, 0, 0, true
};

const MemoryProfile Pm32 = {
    "Portable-Media-32", 32*1024*1024, 2*1024*1024, 0, 0,
    0, 0, 0, false, 0, 0, true
};

} // namespace MemoryProfiles

// ============================================================================
// UMM Implementation
// ============================================================================

struct UnifiedMemoryManager::Impl {
    std::vector<uint8_t> ram;
    std::vector<uint8_t> vram;
    std::vector<uint8_t> audio_ram;
    std::vector<uint8_t> scratchpad;
    std::vector<uint8_t> sram;
    std::vector<MemRegion> regions;

    // Bank switching
    std::vector<std::vector<uint8_t>> banks;
    uint32_t current_bank = 0;
    uint32_t bank_window_base = 0;
    uint32_t bank_window_size = 0;
    uint32_t switch_count = 0;

    // DMA
    static constexpr int MAX_DMA_CHANNELS = 8;
    DmaChannel dma_channels[MAX_DMA_CHANNELS] = {};
    std::function<void()> dma_callbacks[MAX_DMA_CHANNELS] = {};

    // Telemetry
    uint64_t read_count = 0;
    uint64_t write_count = 0;
    uint64_t dma_transfer_count = 0;

    const MemoryProfile* profile = nullptr;
};

UnifiedMemoryManager::UnifiedMemoryManager() : m(new Impl) {}

UnifiedMemoryManager::~UnifiedMemoryManager() { delete m; }

void UnifiedMemoryManager::init(const MemoryProfile& profile) {
    m->profile = &profile;
    m->ram.resize(profile.system_ram, 0);
    m->vram.resize(profile.video_ram, 0);
    if (profile.audio_ram > 0) m->audio_ram.resize(profile.audio_ram, 0);
    if (profile.scratchpad > 0) m->scratchpad.resize(profile.scratchpad, 0);
    if (profile.sram_space > 0) m->sram.resize(profile.sram_space, 0);

    m->regions.clear();
    m->regions.push_back({0, profile.system_ram, "RAM", MemRegionType::RAM, true, true});
    if (profile.video_ram > 0)
        m->regions.push_back({0, profile.video_ram, "VRAM", MemRegionType::VRAM, true, false});
    if (profile.sram_space > 0)
        m->regions.push_back({0, profile.sram_space, "SRAM", MemRegionType::SRAM, true, false});

    m->current_bank = 0;
    m->switch_count = 0;
    m->read_count = 0;
    m->write_count = 0;
    m->dma_transfer_count = 0;
}

void UnifiedMemoryManager::reset() {
    if (m->ram.size() > 0) std::memset(m->ram.data(), 0, m->ram.size());
    if (m->vram.size() > 0) std::memset(m->vram.data(), 0, m->vram.size());
    if (m->audio_ram.size() > 0) std::memset(m->audio_ram.data(), 0, m->audio_ram.size());
    if (m->scratchpad.size() > 0) std::memset(m->scratchpad.data(), 0, m->scratchpad.size());
    m->current_bank = 0;
    m->switch_count = 0;
    m->read_count = 0;
    m->write_count = 0;
    m->dma_transfer_count = 0;
}

// ----- Memory Access --------------------------------------------------------

uint8_t UnifiedMemoryManager::read8(uint32_t addr) {
    m->read_count++;
    if (addr < m->ram.size()) return m->ram[addr];
    return 0xFF;
}

uint16_t UnifiedMemoryManager::read16(uint32_t addr) {
    m->read_count++;
    if (m->profile && m->profile->big_endian) {
        return (uint16_t(read8(addr)) << 8) | read8(addr + 1);
    }
    return read8(addr) | (uint16_t(read8(addr + 1)) << 8);
}

uint32_t UnifiedMemoryManager::read32(uint32_t addr) {
    m->read_count++;
    if (m->profile && m->profile->big_endian) {
        return (uint32_t(read8(addr)) << 24) | (uint32_t(read8(addr+1)) << 16) |
               (uint32_t(read8(addr+2)) << 8) | read8(addr+3);
    }
    return read8(addr) | (uint32_t(read8(addr+1)) << 8) |
           (uint32_t(read8(addr+2)) << 16) | (uint32_t(read8(addr+3)) << 24);
}

void UnifiedMemoryManager::write8(uint32_t addr, uint8_t value) {
    m->write_count++;
    if (addr < m->ram.size()) m->ram[addr] = value;
}

void UnifiedMemoryManager::write16(uint32_t addr, uint16_t value) {
    m->write_count++;
    if (m->profile && m->profile->big_endian) {
        write8(addr, value >> 8);
        write8(addr + 1, value & 0xFF);
    } else {
        write8(addr, value & 0xFF);
        write8(addr + 1, value >> 8);
    }
}

void UnifiedMemoryManager::write32(uint32_t addr, uint32_t value) {
    m->write_count++;
    if (m->profile && m->profile->big_endian) {
        write8(addr, value >> 24);
        write8(addr+1, value >> 16);
        write8(addr+2, value >> 8);
        write8(addr+3, value & 0xFF);
    } else {
        write8(addr, value & 0xFF);
        write8(addr+1, value >> 8);
        write8(addr+2, value >> 16);
        write8(addr+3, value >> 24);
    }
}

void UnifiedMemoryManager::read_block(uint32_t addr, uint8_t* dest, size_t len) {
    m->read_count += len;
    for (size_t i = 0; i < len; i++) dest[i] = read8(addr + i);
}

void UnifiedMemoryManager::write_block(uint32_t addr, const uint8_t* src, size_t len) {
    m->write_count += len;
    for (size_t i = 0; i < len; i++) write8(addr + i, src[i]);
}

uint8_t* UnifiedMemoryManager::get_ram_ptr() { return m->ram.data(); }
uint32_t UnifiedMemoryManager::get_ram_size() const { return (uint32_t)m->ram.size(); }

// ----- Region Management ----------------------------------------------------

void UnifiedMemoryManager::register_region(uint32_t start, uint32_t end, const char* name,
                                            MemRegionType type, bool writable, bool executable) {
    m->regions.push_back({start, end, name, type, writable, executable});
}

const MemRegion* UnifiedMemoryManager::find_region(uint32_t addr) const {
    for (const auto& r : m->regions) {
        if (addr >= r.start && addr < r.end) return &r;
    }
    return nullptr;
}

bool UnifiedMemoryManager::is_address_valid(uint32_t addr) const {
    return find_region(addr) != nullptr;
}

bool UnifiedMemoryManager::is_writable(uint32_t addr) const {
    const MemRegion* r = find_region(addr);
    return r && r->writable;
}

bool UnifiedMemoryManager::is_executable(uint32_t addr) const {
    const MemRegion* r = find_region(addr);
    return r && r->executable;
}

// ----- Bank Switching -------------------------------------------------------

void UnifiedMemoryManager::load_banks(const std::vector<uint8_t>& rom, uint32_t bank_size) {
    m->banks.clear();
    size_t offset = 0;
    while (offset < rom.size()) {
        size_t chunk = std::min((size_t)bank_size, rom.size() - offset);
        m->banks.push_back(std::vector<uint8_t>(rom.begin() + offset, rom.begin() + offset + chunk));
        offset += chunk;
    }
    m->current_bank = 0;
    m->bank_window_size = bank_size;
}

void UnifiedMemoryManager::switch_bank(uint32_t bank_idx) {
    if (bank_idx < m->banks.size()) {
        m->current_bank = bank_idx;
        m->switch_count++;
    }
}

uint32_t UnifiedMemoryManager::get_current_bank() const { return m->current_bank; }
uint32_t UnifiedMemoryManager::get_switch_count() const { return m->switch_count; }

// ----- DMA Channels ---------------------------------------------------------

void UnifiedMemoryManager::set_dma_channel(int channel, const DmaChannel& config) {
    if (channel >= 0 && channel < Impl::MAX_DMA_CHANNELS) {
        m->dma_channels[channel] = config;
        m->dma_channels[channel].channel_id = channel;
    }
}

void UnifiedMemoryManager::trigger_dma(int channel) {
    if (channel < 0 || channel >= Impl::MAX_DMA_CHANNELS) return;
    DmaChannel& dma = m->dma_channels[channel];
    if (!dma.enabled) return;

    uint32_t transferred = 0;
    for (uint32_t b = 0; b < dma.block_count; b++) {
        for (uint32_t i = 0; i < dma.block_size; i++) {
            uint8_t val = read8(dma.src + i);
            write8(dma.dest + i, val);
            transferred++;
        }
    }
    m->dma_transfer_count += transferred;

    if (dma.irq_on_completion && m->dma_callbacks[channel]) {
        m->dma_callbacks[channel]();
    }
}

bool UnifiedMemoryManager::is_dma_active(int channel) const {
    if (channel < 0 || channel >= Impl::MAX_DMA_CHANNELS) return false;
    return m->dma_channels[channel].enabled;
}

void UnifiedMemoryManager::set_dma_callback(int channel, std::function<void()> callback) {
    if (channel >= 0 && channel < Impl::MAX_DMA_CHANNELS) {
        m->dma_callbacks[channel] = callback;
    }
}

// ----- Telemetry ------------------------------------------------------------

uint64_t UnifiedMemoryManager::get_read_count() const { return m->read_count; }
uint64_t UnifiedMemoryManager::get_write_count() const { return m->write_count; }
uint64_t UnifiedMemoryManager::get_dma_transfer_count() const { return m->dma_transfer_count; }

// ----- State Save/Restore ---------------------------------------------------

std::vector<uint8_t> UnifiedMemoryManager::save_state() const {
    std::vector<uint8_t> state;
    auto append = [&](const void* data, size_t len) {
        state.insert(state.end(), (const uint8_t*)data, (const uint8_t*)data + len);
    };
    append(m->ram.data(), m->ram.size());
    append(m->vram.data(), m->vram.size());
    append(&m->current_bank, sizeof(m->current_bank));
    append(&m->switch_count, sizeof(m->switch_count));
    return state;
}

void UnifiedMemoryManager::load_state(const std::vector<uint8_t>& state) {
    size_t offset = 0;
    if (offset + m->ram.size() <= state.size()) {
        std::memcpy(m->ram.data(), state.data() + offset, m->ram.size());
        offset += m->ram.size();
    }
    if (offset + m->vram.size() <= state.size()) {
        std::memcpy(m->vram.data(), state.data() + offset, m->vram.size());
        offset += m->vram.size();
    }
    if (offset + sizeof(m->current_bank) <= state.size()) {
        std::memcpy(&m->current_bank, state.data() + offset, sizeof(m->current_bank));
        offset += sizeof(m->current_bank);
    }
}

@echo off
REM ============================================================================
REM CI ENTRYPOINT — VHB Super BIOS + CyberGrime (VHB Environment)
REM ============================================================================
REM Runs the full Phase 0+1 gate sequence:
REM   B0: Clean-room BIOS verification (6/6 checks)
REM   H0: Build agent harness (build_agent.bat clean)
REM   H1: Quick smoke regression (regression_runner.py quick_smoke)
REM
REM Usage:
REM   cybergrime_ci.bat              — full sequence (B0 + H0 + H1)
REM   cybergrime_ci.bat b0_only      — just BIOS verification
REM   cybergrime_ci.bat skip_build   — skip H0, run B0 + H1
REM
REM Exit code: 0 if all gates pass, 1 if any fail.
REM ============================================================================

setlocal
set VHB_ROOT=C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\VHB_SUPER_BIOS_V1.00A
set CYBERGRIME_DIR=%VHB_ROOT%\cybergrime
set PYTHON=python
set PASS_COUNT=0
set FAIL_COUNT=0

echo ============================================
echo  VHB CI — Phase 0+1 Gate Sequence
echo  Root: %VHB_ROOT%
echo  Mode: %~1 (full if empty)
echo ============================================
echo.

REM ── B0: Clean-room BIOS verification ─────────────────────────────────────
echo [B0] Running clean-room BIOS verification...
%PYTHON% "%VHB_ROOT%\build_frankenstein_bios.py" --verify-only --output "%VHB_ROOT%\FRANKENSTEIN.BIOS"
if errorlevel 1 (
    echo [B0] FAIL — BIOS verification failed
    set /a FAIL_COUNT+=1
    if /i "%~1"=="b0_only" goto :summary
) else (
    echo [B0] PASS — 6/6 clean-room checks
    set /a PASS_COUNT+=1
)
echo.

if /i "%~1"=="b0_only" goto :summary

REM ── H0: Build agent harness ───────────────────────────────────────────────
if /i not "%~1"=="skip_build" (
    echo [H0] Building agent harness...
    call "%CYBERGRIME_DIR%\build_agent.bat" clean
    if errorlevel 1 (
        echo [H0] FAIL — Build failed
        set /a FAIL_COUNT+=1
        goto :summary
    ) else (
        echo [H0] PASS — Build succeeded
        set /a PASS_COUNT+=1
    )
    echo.
)

REM ── H1: Quick smoke regression ────────────────────────────────────────────
echo [H1] Running quick_smoke regression...
pushd "%CYBERGRIME_DIR%"
%PYTHON% regression_runner.py quick_smoke
if errorlevel 1 (
    echo [H1] FAIL — One or more smoke tests failed
    set /a FAIL_COUNT+=1
) else (
    echo [H1] PASS — All smoke tests passed
    set /a PASS_COUNT+=1
)
popd
echo.

:summary
echo ============================================
echo  CI SUMMARY
echo  Passed: %PASS_COUNT%
echo  Failed: %FAIL_COUNT%
echo ============================================

if %FAIL_COUNT% gtr 0 (
    echo RESULT: FAIL
    exit /b 1
) else (
    echo RESULT: PASS
    exit /b 0
)

endlocal

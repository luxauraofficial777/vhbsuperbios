// =============================================================================
// vhb_test_runner.cpp — VHB Super BIOS Boot Test Runner
//
// Loads FRANKENSTEIN.BIOS + disc image, runs the emulator, saves telemetry.
//
// Usage:
//   vhb_test.exe [--bios PATH] [--disc PATH] [--max-instr N] [--verbose] [--watch-pc ADDR]
//
// Build:
//   cl /EHsc /O2 /std:c++17 /D_CRT_SECURE_NO_WARNINGS psx_core.cpp vhb_test_runner.cpp -o vhb_test.exe
// =============================================================================

#include "psx_core.h"
#include <cstring>

static void print_usage() {
    printf("Usage: vhb_test.exe [options]\n");
    printf("  --bios PATH        BIOS file (default: FRANKENSTEIN.BIOS)\n");
    printf("  --disc PATH        Disc image (default: none)\n");
    printf("  --max-instr N      Max instructions (default: 10000000)\n");
    printf("  --verbose          Verbose output\n");
    printf("  --watch-pc ADDR    Break on PC (hex)\n");
    printf("  --telemetry PATH   Save telemetry to PATH (default: telemetry.json)\n");
}

int main(int argc, char* argv[]) {
    std::string bios_path = "FRANKENSTEIN.BIOS";
    std::string disc_path = "";
    std::string telemetry_path = "telemetry.json";
    uint64_t max_instr = 10000000;
    bool verbose = false;
    uint32_t watch_pc = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--bios") == 0 && i + 1 < argc) {
            bios_path = argv[++i];
        } else if (strcmp(argv[i], "--disc") == 0 && i + 1 < argc) {
            disc_path = argv[++i];
        } else if (strcmp(argv[i], "--max-instr") == 0 && i + 1 < argc) {
            max_instr = strtoull(argv[++i], nullptr, 0);
        } else if (strcmp(argv[i], "--verbose") == 0) {
            verbose = true;
        } else if (strcmp(argv[i], "--watch-pc") == 0 && i + 1 < argc) {
            watch_pc = (uint32_t)strtoul(argv[++i], nullptr, 16);
        } else if (strcmp(argv[i], "--telemetry") == 0 && i + 1 < argc) {
            telemetry_path = argv[++i];
        } else if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            print_usage();
            return 0;
        } else {
            printf("Unknown arg: %s\n", argv[i]);
            print_usage();
            return 1;
        }
    }

    printf("=== VHB Super BIOS Boot Test ===\n");
    printf("BIOS:   %s\n", bios_path.c_str());
    printf("Disc:   %s\n", disc_path.empty() ? "(none)" : disc_path.c_str());
    printf("Max:    %llu instructions\n", max_instr);
    printf("Verbose: %s\n", verbose ? "YES" : "no");
    printf("\n");

    PSXEmulator psx;
    psx.set_verbose(verbose);

    if (!psx.load_bios(bios_path)) {
        printf("ERROR: Failed to load BIOS: %s\n", bios_path.c_str());
        return 1;
    }

    if (!disc_path.empty()) {
        if (!psx.load_disc(disc_path)) {
            printf("WARNING: Failed to load disc: %s (continuing without disc)\n", disc_path.c_str());
        }
    }

    if (watch_pc) {
        psx.set_watch_pc(watch_pc);
    }

    psx.run(max_instr);
    psx.save_telemetry(telemetry_path);

    // Summary
    printf("\n=== Boot Test Summary ===\n");
    auto& t = psx.get_telemetry();
    printf("Instructions:    %llu\n", t.instruction_count);
    printf("VBlanks:         %llu\n", t.vblank_count);
    printf("Final PC:        0x%08X\n", t.pc);
    printf("PC range (RAM):  0x%08X - 0x%08X\n", t.min_pc, t.max_pc);
    printf("CD sectors read: %u\n", t.cdrom_sectors_read);
    printf("CD commands:     %u\n", t.cdrom_commands_sent);
    printf("GPU writes:      %u\n", t.gpu_writes);
    printf("SIO0 reads:      %u\n", t.sio0_reads);
    printf("Past 0xBFC00378: %s\n", t.bios_past_cdrom_init ? "YES" : "NO");
    printf("Reached EXE:     %s\n", t.reached_exe ? "YES" : "NO");
    printf("Crashed:         %s\n", t.crashed ? "YES" : "NO");
    if (t.crashed) printf("Crash reason:    %s\n", t.crash_reason.c_str());

    // Last 8 PC values
    printf("\nLast 8 PCs:\n");
    size_t start = t.pc_trace.size() > 8 ? t.pc_trace.size() - 8 : 0;
    for (size_t i = start; i < t.pc_trace.size(); i++) {
        printf("  0x%08X\n", t.pc_trace[i]);
    }

    return t.crashed ? 1 : 0;
}

# VHB Super BIOS v0.5 — Clean-Room PSX BIOS
# Built with cybergrime/mips/assembler.py (zero external dependencies)
#
# Memory Map:
#   0xBFC00000 - BIOS ROM base (512KB)
#   0x1F801000 - Hardware registers
#   0x1F801020 - GPU registers
#   0x1F801060 - RAM size register
#   0x1F801080 - DMA channel 0 (MDEC)
#   0x1F8010A0 - DMA channel 2 (GPU)
#   0x1F8010B0 - DMA channel 3 (CD-ROM)
#   0x1F8010F0 - DMA interrupt status
#   0x80010000 - Scratchpad / boot buffer
#   0x80100000 - EXE load address
#
# CD-ROM Registers (base 0x1F801800):
#   0x00 - Status/Index (read: status, write: index select)
#   0x01 - Response (read) / Command (write, index=0)
#   0x02 - Data (read, index=0) / Parameter (write, index=0)
#   0x03 - Interrupt flag/enable (write, index=1: ack)
# SIO0 Registers (base 0x1F801000):
#   0x00 - Data (read/write)
#   0x04 - Status/Mode
#   0x08 - Control
#   0x0C - Baud

.set noreorder
.global _start
.org 0xbfc00000

# =============================================================================
# Boot Entry Point (0xBFC00000)
# =============================================================================
_start:
    # CP0 Status: kernel mode, BEV=1, disable interrupts
    li      $t0, 0x00400000
    mtc0    $t0, 12
    nop
    mtc0    $zero, 13
    nop

    # Memory controller init
    lui     $t1, 0x1f80
    li      $t3, 0x00070707
    sw      $t3, 0x1000($t1)
    nop

    # RAM size: 2MB default (patchable by build script)
    # RAM_SIZE_PATCH_MARKER
    li      $t3, 0x00000B88
    sw      $t3, 0x1060($t1)
    nop

    # Clear 8KB of RAM at 0x80000000 for boot workspace
    lui     $t0, 0x8000
    addiu   $t1, $t0, 0x2000          # $t1 = 0x80002000 (end of 8KB)
clear_loop:
    sw      $zero, 0($t0)
    addiu   $t0, $t0, 4
    sltu    $t2, $t0, $t1
    bne     $t2, $zero, clear_loop
    nop

    # Set up stack pointer
    lui     $sp, 0x801F
    ori     $sp, $sp, 0xFF00

    # VHB: Preinit descriptors
    jal     Preinit_Descriptors
    nop

    # Init GPU (minimal — turn on display)
    jal     GPU_Init
    nop

    # Jump past "OpenBIOS" signature area (0x78-0x7F, injected by packer)
    j       __post_sig
    nop

    # 0x78-0x7F: reserved for "OpenBIOS" signature (injected by packer)
    .org 0xBFC00080
__post_sig:

    # Init CD-ROM
    jal     CDROM_Init
    nop

    # Read PVD at LBA 16 to find root directory
    # Buffer at 0x80010000
    li      $a0, 16
    lui     $a1, 0x8001
    jal     CDROM_ReadSector
    nop

    # Parse PVD: root dir record at offset 0x9C (156)
    # PVD type=1 at offset 0, root dir record at offset 156
    lui     $t0, 0x8001
    lbu     $t1, 0x9C($t0)       # Root dir record length
    nop
    # Root dir LBA at offset 0x9C+2 = 0x9E (4 bytes LE)
    lw      $s0, 0x9E($t0)       # Root dir LBA (little-endian)
    nop
    # Root dir size at offset 0x9C+10 = 0xA6 (4 bytes LE)
    lw      $s1, 0xA6($t0)       # Root dir size (little-endian)
    nop

    # Read root directory (may span multiple sectors)
    # $s0 = root dir LBA, $s1 = root dir size in bytes
    # Calculate sector count = (size + 2047) / 2048
    addiu   $a2, $s1, 2047
    srl     $a2, $a2, 11            # Sector count
    move    $a0, $s0                # LBA
    lui     $a1, 0x8001
    ori     $a1, $a1, 0x2000       # Dest = 0x80012000
    jal     CDROM_ReadSectors
    nop

    # Search root dir for "SYSTEM.CNF;1"
    lui     $a0, 0x8001
    ori     $a0, $a0, 0x2000
    jal     Find_File
    nop
    beq     $v0, $zero, boot_fail
    nop

    # $v0 = LBA of SYSTEM.CNF, $v1 = size
    move    $s2, $v0
    move    $s3, $v1

    # Read SYSTEM.CNF to 0x80011000
    move    $a0, $s2
    lui     $a1, 0x8001
    ori     $a1, $a1, 0x1000
    jal     CDROM_ReadSector
    nop

    # Parse SYSTEM.CNF for "BOOT = " line
    lui     $a0, 0x8001
    ori     $a0, $a0, 0x1000
    jal     Parse_Boot_Line
    nop
    beq     $v0, $zero, boot_fail
    nop

    # $v0 = LBA of EXE, $v1 = size
    move    $s4, $v0
    move    $s5, $v1

    # Read EXE header (first sector) to get load address and entry point
    move    $a0, $s4
    lui     $a1, 0x8001
    ori     $a1, $a1, 0x3000
    jal     CDROM_ReadSector
    nop

    # PS-EXE header: load_addr at offset 0x10, entry at 0x10, t_size at 0x1C
    # Actually: PC0 at 0x10, text_start (load) at 0x18, t_size at 0x1C
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x3000
    lw      $s6, 0x18($t0)       # Load address (text_start)
    nop
    lw      $s7, 0x10($t0)       # Entry point (PC0)
    nop

    # Load EXE body: skip 0x800-byte header, read rest to load address
    # Calculate sectors to read
    addiu   $t1, $s5, -0x800     # Body size = file_size - header
    srl     $t2, $t1, 11         # Sectors = body_size / 2048
    andi    $t3, $t1, 0x7FF      # Remainder
    bne     $t3, $zero, has_remainder
    nop
    j       no_remainder
    nop
has_remainder:
    addiu   $t2, $t2, 1          # Round up
no_remainder:

    # Read EXE body sectors via DMA to load address
    addiu   $a0, $s4, 1          # Start at sector after header
    move    $a1, $s6             # Dest = load address
    move    $a2, $t2             # Count
    jal     CDROM_ReadSectors
    nop

    # HBD Pre-loading: search root dir for HBD file and load to RAM
    # Root dir is already at 0x80012000 from earlier
    # NOTE: HBD file is typically too large to preload into RAM.
    # The game's own CD-ROM code will load HBD sectors as needed.
    # Skip HBD preloading to avoid stack corruption.
    j       skip_hbd_load
    nop

    # $v0 = HBD LBA, $v1 = HBD size
    move    $s2, $v0             # HBD LBA
    move    $s3, $v1             # HBD size

    # Calculate HBD dest: EXE end = load_addr + (file_size - 0x800)
    addiu   $t0, $s5, -0x800     # Body size
    addu    $t0, $t0, $s6        # EXE end in RAM
    # Round up to sector boundary (2048)
    addiu   $t0, $t0, 0x7FF
    srl     $t0, $t0, 11
    sll     $t0, $t0, 11

    # Calculate sector count
    srl     $t1, $s3, 11         # Sectors = size / 2048
    andi    $t2, $s3, 0x7FF      # Remainder
    bne     $t2, $zero, hbd_has_rem
    nop
    j       hbd_no_rem
    nop
hbd_has_rem:
    addiu   $t1, $t1, 1
hbd_no_rem:

    # Read HBD sectors to RAM past EXE end
    move    $a0, $s2             # HBD LBA
    move    $a1, $t0             # Destination
    move    $a2, $t1             # Count
    jal     CDROM_ReadSectors
    nop

skip_hbd_load:

    # Flush cache before jumping
    jal     Flush_Cache
    nop

    # Install syscall vectors at 0xA0, 0xB0, 0xC0
    jal     Install_Syscall_Vectors
    nop

    # Copy A0/B0/C0 function tables to RAM
    jal     Copy_Syscall_Tables
    nop

    # Initialize interrupt controller
    jal     Init_Interrupt_Controller
    nop

    # Install VBlank interrupt handler at 0x80000080
    jal     Install_VBlank_Handler
    nop

    # Initialize kernel heap
    jal     Init_Heap
    nop

    # Initialize event control blocks (16 events)
    li      $a0, 16
    jal     Init_Events
    nop

    # Initialize thread control blocks (4 threads)
    li      $a0, 4
    jal     Init_Threads
    nop

    # Set BEV=0, enable CPU interrupts (IE bit), unmask IM2 for PSX hardware IRQs
    # Status: BEV=0, IE=1, IM2 (enable IP2 = all PSX hardware interrupts via ISTAT)
    # Bit 0 = IE, Bit 10 = IM2 (masks IP2 = ISTAT → VBlank, CD-ROM, GPU, DMA, timers)
    li      $t0, 0x00040501
    mtc0    $t0, 12
    nop

    # Flush cache again after all setup
    jal     Flush_Cache
    nop

    # Pre-set display initialized flag before jumping to EXE entry
    # 0x800B5312 = 1 (display initialized)
    lui     $t0, 0x800B
    ori     $t0, $t0, 0x5312
    li      $t1, 1
    sh      $t1, 0($t0)
    nop
    # 0x800B5310 = 1 (display init mirror)
    lui     $t0, 0x800B
    ori     $t0, $t0, 0x5310
    li      $t1, 1
    sh      $t1, 0($t0)
    nop

    # Jump to EXE entry point
    jr      $s7
    nop

boot_fail:
    # Boot failed — infinite loop
    j       boot_fail
    nop

# =============================================================================
# VHB: Descriptor Pre-Initialization
# =============================================================================
Preinit_Descriptors:
    lui     $t0, 0x8010             # Safe descriptor base = 0x80100000
    lui     $t1, 0x800F
    ori     $t1, $t1, 0x2228
    sw      $t0, 0($t1)            # *0x800F2228 = 0x80100000
    nop
    lui     $t1, 0x800D
    ori     $t1, $t1, 0x9A40
    sw      $t0, 0($t1)            # *0x800D9A40 = 0x80100000
    nop
    lui     $t1, 0x800F
    ori     $t1, $t1, 0x2238
    sw      $zero, 0($t1)          # *0x800F2238 = 0
    nop
    jr      $ra
    nop

# =============================================================================
# GPU Initialization (minimal)
# =============================================================================
GPU_Init:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1F801800 (GPU regs at +0x10, +0x14)

    # Reset GPU command: write 0x00 to GP1 command register (0x1F801814)
    sw      $zero, 0x14($t0)       # GP1(00h) = reset
    nop

    # Set display mode: 256x240 NTSC
    li      $t1, 0x08000000        # GP1(08h) = display mode
    sw      $t1, 0x14($t0)
    nop

    # Set horizontal display range
    li      $t1, 0x06020608        # GP1(06h) = horizontal range
    sw      $t1, 0x14($t0)
    nop

    # Set vertical display range
    li      $t1, 0x07001810        # GP1(07h) = vertical range
    sw      $t1, 0x14($t0)
    nop

    # Enable display: GP1(03h) = display on
    li      $t1, 0x03000000
    sw      $t1, 0x14($t0)
    nop

    # Set drawing mode: GP0(0xE1h) = draw mode
    li      $t1, 0xE1000400
    sw      $t1, 0x10($t0)         # GP0 register at 0x1F801810
    nop

    # Set texture window: GP0(0xE2h)
    li      $t1, 0xE2000000
    sw      $t1, 0x10($t0)
    nop

    # Clear drawing area: GP0(0xE3h) = drawing area top-left
    li      $t1, 0xE3000000
    sw      $t1, 0x10($t0)
    nop

    # Drawing area bottom-right: GP0(0xE4h)
    li      $t1, 0xE403C0F0
    sw      $t1, 0x10($t0)
    nop

    # Drawing offset: GP0(0xE5h)
    li      $t1, 0xE5000000
    sw      $t1, 0x10($t0)
    nop

    jr      $ra
    nop

# =============================================================================
# CD-ROM Initialization
# =============================================================================
CDROM_Init:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1F801800 (CD-ROM regs)

    # Set index 0 (select primary register bank)
    li      $t1, 0x00
    sb      $t1, 0x00($t0)         # Index = 0
    nop

    # CDROM command 0x0A (Init) — standard init, supported by StarPSX
    li      $t1, 0x0A
    sb      $t1, 0x01($t0)         # Command: Init (0x0A)
    nop

    # Wait for response
    jal     CDROM_Wait_Response
    nop

    # Send command 0x13 (GetTN) — get track number info (replaces ReadTOC)
    li      $t1, 0x13
    sb      $t1, 0x01($t0)         # Command: GetTN
    nop

    # Wait for response
    li      $a0, 0x00100000        # Longer timeout
    jal     CDROM_Wait_Response_Long
    nop

    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# =============================================================================
# CD-ROM Wait for Response
# Polls status register until response is ready
# =============================================================================
CDROM_Wait_Response:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1f801800 (CD-ROM regs)
    li      $t2, 0x00010000        # Timeout
cd_wait_resp_loop:
    lbu     $t1, 0x00($t0)         # Read status register
    nop
    andi    $t3, $t1, 0x20         # Check bit 5 (response ready)
    bne     $t3, $zero, cd_wait_resp_done
    nop
    addiu   $t2, $t2, -1
    bne     $t2, $zero, cd_wait_resp_loop
    nop
cd_wait_resp_done:
    # Read response byte from response register (0x1F801801)
    lbu     $v0, 0x01($t0)         # Read response FIFO
    nop
    # Acknowledge CD-ROM interrupt: set index 1, write 0x07, restore index 0
    li      $t1, 0x01
    sb      $t1, 0x00($t0)         # Index = 1
    nop
    li      $t1, 0x07
    sb      $t1, 0x03($t0)         # Ack interrupt
    nop
    li      $t1, 0x00
    sb      $t1, 0x00($t0)         # Index = 0 (restore)
    nop
    jr      $ra
    nop

# =============================================================================
# CD-ROM Wait for Response (long timeout for TOC etc)
# $a0 = timeout value
# =============================================================================
CDROM_Wait_Response_Long:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1f801800 (CD-ROM regs)
    move    $t2, $a0
cd_wait_resp_long_loop:
    lbu     $t1, 0x00($t0)
    nop
    andi    $t3, $t1, 0x20
    bne     $t3, $zero, cd_wait_resp_long_done
    nop
    addiu   $t2, $t2, -1
    bne     $t2, $zero, cd_wait_resp_long_loop
    nop
cd_wait_resp_long_done:
    lbu     $v0, 0x01($t0)         # Read response FIFO (0x1F801801)
    nop
    # Acknowledge CD-ROM interrupt: set index 1, write 0x07, restore index 0
    li      $t1, 0x01
    sb      $t1, 0x00($t0)         # Index = 1
    nop
    li      $t1, 0x07
    sb      $t1, 0x03($t0)         # Ack interrupt
    nop
    li      $t1, 0x00
    sb      $t1, 0x00($t0)         # Index = 0 (restore)
    nop
    jr      $ra
    nop

# =============================================================================
# CD-ROM Read Single Sector
# $a0 = LBA, $a1 = dest buffer (must be 0x80xxxxxx)
# Uses CD-ROM command 0x06 (ReadN) with parameters
# =============================================================================
CDROM_ReadSector:
    addiu   $sp, $sp, -32
    sw      $ra, 28($sp)
    sw      $s0, 24($sp)
    sw      $s1, 20($sp)
    sw      $s2, 16($sp)
    sw      $s6, 12($sp)
    sw      $s7, 8($sp)
    # Save args
    move    $s6, $a0               # LBA
    move    $s7, $a1               # Dest

    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1f801800 (CD-ROM regs)

    # Set CD-ROM mode: command 0x0E (Setmode) with param
    # Must write param BEFORE command (emulator processes command immediately)
    li      $t1, 0x80              # Double speed, data mode
    sb      $t1, 0x02($t0)         # Write parameter to FIFO first
    nop
    li      $t1, 0x0E
    sb      $t1, 0x01($t0)         # Command: Setmode (reads param from FIFO)
    nop
    jal     CDROM_Wait_Response
    nop

    # Convert LBA to minute:second:frame (MSF) in binary
    # minute = (LBA+150) / 4500
    # second = remainder / 75
    # frame = remainder % 75
    addiu   $t1, $s6, 150          # t1 = LBA + 150
    li      $t9, 4500
    div     $t1, $t9               # LO = minute, HI = remainder
    nop
    mflo    $t2                    # t2 = minute (binary)
    mfhi    $t3                    # t3 = remainder
    li      $t9, 75
    div     $t3, $t9               # LO = second, HI = frame
    nop
    mflo    $t4                    # t4 = second (binary)
    mfhi    $t5                    # t5 = frame (binary)

    # Convert binary MSF to BCD: BCD = ((val/10) << 4) | (val % 10)
    # Use $s0/$s1/$s2 for BCD values (preserved across jal calls)
    li      $t9, 10
    div     $t2, $t9               # LO = min/10, HI = min%10
    nop
    mflo    $s0                    # s0 = min/10
    mfhi    $t1                    # t1 = min%10
    sll     $s0, $s0, 4
    or      $s0, $s0, $t1         # s0 = minute BCD

    div     $t4, $t9               # LO = sec/10, HI = sec%10
    nop
    mflo    $s1                    # s1 = sec/10
    mfhi    $t1                    # t1 = sec%10
    sll     $s1, $s1, 4
    or      $s1, $s1, $t1         # s1 = second BCD

    div     $t5, $t9               # LO = frame/10, HI = frame%10
    nop
    mflo    $s2                    # s2 = frame/10
    mfhi    $t1                    # t1 = frame%10
    sll     $s2, $s2, 4
    or      $s2, $s2, $t1         # s2 = frame BCD

    # Send Setloc command (0x02) with 3 BCD params
    # Params must be in FIFO before command byte is written
    sb      $s0, 0x02($t0)         # Param: minute (BCD)
    nop
    sb      $s1, 0x02($t0)         # Param: second (BCD)
    nop
    sb      $s2, 0x02($t0)         # Param: frame (BCD)
    nop
    li      $t1, 0x02
    sb      $t1, 0x01($t0)         # Command: Setloc
    nop
    jal     CDROM_Wait_Response
    nop

    # Send ReadN command (0x06) — no params, uses Setloc position
    li      $t1, 0x06
    sb      $t1, 0x01($t0)         # Command: ReadN
    nop

    # Wait for data ready (poll status bit 7 = data ready)
    li      $t6, 0x01000000        # Timeout for data ready
cd_read_data_wait:
    lbu     $t1, 0x00($t0)
    nop
    andi    $t3, $t1, 0x40         # Bit 6 = DRQSTS (data FIFO ready)
    bne     $t3, $zero, cd_read_data_ready
    nop
    andi    $t3, $t1, 0x20         # Bit 5 = RSLRRDY (response ready = error?)
    bne     $t3, $zero, cd_read_error
    nop
    addiu   $t6, $t6, -1
    bne     $t6, $zero, cd_read_data_wait
    nop
    j       cd_read_error          # Timeout
    nop

cd_read_data_ready:
    # Arm data transfer: set index 0, write 0x80 to reg 3 (BFRD)
    li      $t1, 0x00
    sb      $t1, 0x00($t0)         # Index = 0
    nop
    li      $t1, 0x80
    sb      $t1, 0x03($t0)         # Arm data transfer (BFRD=1)
    nop

    # Read 2048 bytes from CD-ROM data port (0x1F801802)
    move    $t7, $zero             # Counter
    move    $t8, $s7               # Dest pointer
cd_read_copy:
    lbu     $t9, 0x02($t0)         # Read data byte from data register
    nop
    sb      $t9, 0($t8)            # Store to dest
    addiu   $t8, $t8, 1
    addiu   $t7, $t7, 1
    li      $t9, 2048
    sltu    $t9, $t7, $t9
    bne     $t9, $zero, cd_read_copy
    nop

    # Acknowledge CD-ROM interrupt: set index 1, write 0x07 to reg 3
    li      $t1, 0x01
    sb      $t1, 0x00($t0)         # Index = 1
    nop
    li      $t1, 0x07
    sb      $t1, 0x03($t0)         # Ack interrupt
    nop
    li      $t1, 0x00
    sb      $t1, 0x00($t0)         # Index = 0 (restore)
    nop

    # Pause CD-ROM (command 0x09)
    li      $t1, 0x09
    sb      $t1, 0x01($t0)
    nop
    jal     CDROM_Wait_Response
    nop

    li      $v0, 1                 # Success
    lw      $ra, 28($sp)
    lw      $s0, 24($sp)
    lw      $s1, 20($sp)
    lw      $s2, 16($sp)
    lw      $s6, 12($sp)
    lw      $s7, 8($sp)
    addiu   $sp, $sp, 32
    jr      $ra
    nop

cd_read_error:
    li      $v0, 0                 # Failure
    lw      $ra, 28($sp)
    lw      $s0, 24($sp)
    lw      $s1, 20($sp)
    lw      $s2, 16($sp)
    lw      $s6, 12($sp)
    lw      $s7, 8($sp)
    addiu   $sp, $sp, 32
    jr      $ra
    nop

# =============================================================================
# CD-ROM Wait for Parameter Ready
# Polls status bit 3 (parameter FIFO ready)
# =============================================================================
CDROM_Wait_Param:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1f801800 (CD-ROM regs)
    li      $t2, 0x00001000
cd_wait_param_loop:
    lbu     $t1, 0x00($t0)
    nop
    andi    $t3, $t1, 0x10         # Bit 4 = PRMWRDY (param FIFO not full)
    bne     $t3, $zero, cd_wait_param_done   # If ready, proceed
    addiu   $t2, $t2, -1
    bne     $t2, $zero, cd_wait_param_loop
    nop
cd_wait_param_done:
    jr      $ra
    nop

# =============================================================================
# CD-ROM Read Multiple Sectors (DMA)
# $a0 = start LBA, $a1 = dest, $a2 = count
# =============================================================================
CDROM_ReadSectors:
    addiu   $sp, $sp, -24
    sw      $ra, 20($sp)
    sw      $s5, 16($sp)
    sw      $s6, 12($sp)
    sw      $s7, 8($sp)
    move    $s6, $a0               # Start LBA
    move    $s7, $a1               # Dest
    move    $s5, $a2               # Count

cd_read_multi_loop:
    beq     $s5, $zero, cd_read_multi_done
    nop

    move    $a0, $s6
    move    $a1, $s7
    jal     CDROM_ReadSector
    nop

    beq     $v0, $zero, cd_read_multi_fail
    nop

    addiu   $s6, $s6, 1            # Next sector
    addiu   $s7, $s7, 2048         # Next dest
    addiu   $s5, $s5, -1           # Decrement count
    j       cd_read_multi_loop
    nop

cd_read_multi_done:
    li      $v0, 1
    lw      $ra, 20($sp)
    lw      $s5, 16($sp)
    lw      $s6, 12($sp)
    lw      $s7, 8($sp)
    addiu   $sp, $sp, 24
    jr      $ra
    nop

cd_read_multi_fail:
    li      $v0, 0
    lw      $ra, 20($sp)
    lw      $s5, 16($sp)
    lw      $s6, 12($sp)
    lw      $s7, 8($sp)
    addiu   $sp, $sp, 24
    jr      $ra
    nop

# =============================================================================
# Find File in ISO 9660 Directory
# $a0 = directory buffer pointer
# Searches for "SYSTEM.CNF;1" (case-insensitive)
# Returns: $v0 = LBA (0 if not found), $v1 = file size
# =============================================================================
Find_File:
    move    $t0, $a0               # Dir buffer pointer
    li      $t3, 8192              # Max scan range (4 sectors)

find_file_loop:
    lbu     $t1, 0($t0)            # Record length
    nop
    beq     $t1, $zero, find_file_next_sector
    nop

    # Get file name length at offset 32
    lbu     $t4, 32($t0)
    nop

    # Compare name: "SYSTEM.CNF;1" = 12 chars
    li      $t5, 12
    bne     $t4, $t5, find_file_next
    nop

    # Compare string at offset 33
    addiu   $t6, $t0, 33           # Name pointer
    lui     $t7, 0x8001
    ori     $t7, $t7, 0x4000       # We'll store compare string here
    # Actually, compare inline
    # "SYSTEM.CNF;1" in ASCII
    lbu     $t8, 0($t6)            # 'S'
    nop
    li      $t9, 0x53              # 'S'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 1($t6)            # 'Y'
    nop
    li      $t9, 0x59              # 'Y'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 2($t6)            # 'S'
    nop
    li      $t9, 0x53              # 'S'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 3($t6)            # 'T'
    nop
    li      $t9, 0x54              # 'T'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 4($t6)            # 'E'
    nop
    li      $t9, 0x45              # 'E'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 5($t6)            # 'M'
    nop
    li      $t9, 0x4D              # 'M'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 6($t6)            # '.'
    nop
    li      $t9, 0x2E              # '.'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 7($t6)            # 'C'
    nop
    li      $t9, 0x43              # 'C'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 8($t6)            # 'N'
    nop
    li      $t9, 0x4E              # 'N'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 9($t6)            # 'F'
    nop
    li      $t9, 0x46              # 'F'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 10($t6)           # ';'
    nop
    li      $t9, 0x3B              # ';'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 11($t6)           # '1'
    nop
    li      $t9, 0x31              # '1'
    bne     $t8, $t9, find_file_next
    nop

    # Found! Extract LBA (offset 2, 4 bytes LE) and size (offset 10, 4 bytes LE)
    lw      $v0, 2($t0)            # LBA (offset 2 in dir record)
    nop
    lw      $v1, 10($t0)           # File size (offset 10 in dir record)
    nop
    jr      $ra
    nop

find_file_next:
    # Move to next record
    add     $t0, $t0, $t1          # Skip by record length
    j       find_file_loop
    nop

find_file_next_sector:
    # Zero record length — padding at end of current sector
    # Check if we're already at a sector boundary (means end of dir)
    subu    $t1, $t0, $a0           # Offset from buffer start
    andi    $t2, $t1, 0x7FF         # Offset within current sector
    beq     $t2, $zero, find_file_not_found  # At boundary = end of dir
    nop
    # Advance to next 2048-byte boundary
    addiu   $t1, $t1, 2048
    srl     $t1, $t1, 11            # Round up to next sector index
    sll     $t1, $t1, 11            # Byte offset
    addu    $t0, $a0, $t1           # New position
    # Check if we've exceeded scan range
    subu    $t5, $t0, $a0
    sltu    $t5, $t5, $t3           # offset < max?
    bne     $t5, $zero, find_file_loop
    nop
find_file_not_found:
    li      $v0, 0
    li      $v1, 0
    jr      $ra
    nop

# =============================================================================
# Parse SYSTEM.CNF Boot Line
# $a0 = buffer pointer to SYSTEM.CNF content
# Looks for "BOOT" or "boot" followed by "=" and a filename
# Then looks up that filename in root directory
# Returns: $v0 = EXE LBA (0 if not found), $v1 = EXE size
# =============================================================================
Parse_Boot_Line:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    move    $t0, $a0               # Buffer pointer
    li      $t6, 2048              # Max scan

parse_boot_loop:
    # Look for 'B' or 'b' (start of "BOOT")
    lbu     $t1, 0($t0)
    nop
    li      $t2, 0x42              # 'B'
    beq     $t1, $t2, parse_boot_found_b
    nop
    li      $t2, 0x62              # 'b'
    beq     $t1, $t2, parse_boot_found_b
    nop
    addiu   $t0, $t0, 1
    addiu   $t6, $t6, -1
    bne     $t6, $zero, parse_boot_loop
    nop
    # Not found
    li      $v0, 0
    li      $v1, 0
    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

parse_boot_found_b:
    # Check "BOOT" prefix (case-insensitive)
    lbu     $t1, 1($t0)
    nop
    li      $t2, 0x4F              # 'O'
    bne     $t1, $t2, parse_boot_no_o1
    nop
    j       parse_boot_check_o2
    nop
parse_boot_no_o1:
    li      $t2, 0x6F              # 'o'
    bne     $t1, $t2, parse_boot_next
    nop
parse_boot_check_o2:
    lbu     $t1, 2($t0)
    nop
    li      $t2, 0x4F              # 'O'
    beq     $t1, $t2, parse_boot_check_t
    nop
    li      $t2, 0x6F              # 'o'
    bne     $t1, $t2, parse_boot_next
    nop
parse_boot_check_t:
    lbu     $t1, 3($t0)
    nop
    li      $t2, 0x54              # 'T'
    beq     $t1, $t2, parse_boot_after_boot
    nop
    li      $t2, 0x74              # 't'
    bne     $t1, $t2, parse_boot_next
    nop

parse_boot_after_boot:
    # Skip whitespace and '='
    addiu   $t0, $t0, 4            # Skip "BOOT"
parse_boot_skip_ws:
    lbu     $t1, 0($t0)
    nop
    li      $t2, 0x20              # Space
    beq     $t1, $t2, parse_boot_skip_ws_inc
    nop
    li      $t2, 0x09              # Tab
    beq     $t1, $t2, parse_boot_skip_ws_inc
    nop
    li      $t2, 0x3D              # '='
    beq     $t1, $t2, parse_boot_skip_eq
    nop
    li      $t2, 0x3A              # ':'
    beq     $t1, $t2, parse_boot_skip_eq
    nop
    j       parse_boot_copy_name
    nop
parse_boot_skip_ws_inc:
    addiu   $t0, $t0, 1
    j       parse_boot_skip_ws
    nop
parse_boot_skip_eq:
    addiu   $t0, $t0, 1
    j       parse_boot_skip_ws
    nop

parse_boot_copy_name:
    # Skip "cdrom:" prefix if present (case-insensitive)
    lbu     $t1, 0($t0)
    nop
    li      $t2, 0x63              # 'c'
    beq     $t1, $t2, parse_boot_check_d
    nop
    li      $t2, 0x43              # 'C'
    bne     $t1, $t2, parse_boot_no_cdrom
    nop
parse_boot_check_d:
    lbu     $t1, 1($t0)
    nop
    li      $t2, 0x64              # 'd'
    beq     $t1, $t2, parse_boot_check_cdrom2
    nop
    li      $t2, 0x44              # 'D'
    bne     $t1, $t2, parse_boot_no_cdrom
    nop
parse_boot_check_cdrom2:
    # Skip to after "cdrom:" (6 chars) then skip '\' or '/'
    addiu   $t0, $t0, 6
    lbu     $t1, 0($t0)
    nop
    li      $t2, 0x5C              # '\'
    beq     $t1, $t2, parse_boot_skip_slash
    nop
    li      $t2, 0x2F              # '/'
    beq     $t1, $t2, parse_boot_skip_slash
    nop
    j       parse_boot_copy_start
    nop
parse_boot_skip_slash:
    addiu   $t0, $t0, 1
    j       parse_boot_copy_start
    nop
parse_boot_no_cdrom:
    # Also skip leading '\' or '/' if present
    lbu     $t1, 0($t0)
    nop
    li      $t2, 0x5C              # '\'
    beq     $t1, $t2, parse_boot_skip_slash
    nop
    li      $t2, 0x2F              # '/'
    beq     $t1, $t2, parse_boot_skip_slash
    nop
parse_boot_copy_start:
    # Copy filename to 0x80014000 (temp buffer for filename)
    lui     $t3, 0x8001
    ori     $t3, $t3, 0x4000
    li      $t4, 0                 # Length counter
parse_boot_copy_loop:
    lbu     $t1, 0($t0)
    nop
    # Stop at CR, LF, or end
    li      $t2, 0x0D              # CR
    beq     $t1, $t2, parse_boot_copy_done
    nop
    li      $t2, 0x0A              # LF
    beq     $t1, $t2, parse_boot_copy_done
    nop
    beq     $t1, $zero, parse_boot_copy_done
    nop
    # Skip leading spaces
    li      $t2, 0x20
    beq     $t1, $t2, parse_boot_copy_skip_space
    nop
    sb      $t1, 0($t3)
    addiu   $t3, $t3, 1
    addiu   $t4, $t4, 1
    addiu   $t0, $t0, 1
    j       parse_boot_copy_loop
    nop
parse_boot_copy_skip_space:
    addiu   $t0, $t0, 1
    j       parse_boot_copy_loop
    nop

parse_boot_copy_done:
    # Null-terminate
    sb      $zero, 0($t3)

    # Now search root directory for this filename
    # Re-read root dir (already at 0x80012000 from earlier)
    lui     $a0, 0x8001
    ori     $a0, $a0, 0x2000
    jal     Find_File_By_Name
    nop

    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

parse_boot_next:
    addiu   $t0, $t0, 1
    addiu   $t6, $t6, -1
    bne     $t6, $zero, parse_boot_loop
    nop
    li      $v0, 0
    li      $v1, 0
    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# =============================================================================
# Find File By Name in Directory
# $a0 = directory buffer
# Name to find is at 0x80014000 (null-terminated)
# Returns: $v0 = LBA, $v1 = size
# =============================================================================
Find_File_By_Name:
    move    $t0, $a0               # Dir buffer
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x4000       # Name to find

find_by_name_loop:
    lbu     $t2, 0($t0)            # Record length
    nop
    beq     $t2, $zero, find_by_name_not_found
    nop

    # Get name length at offset 32
    lbu     $t3, 32($t0)
    nop
    beq     $t3, $zero, find_by_name_next
    nop

    # Compare name byte by byte
    addiu   $t4, $t0, 33           # Dir entry name
    move    $t5, $t1               # Search name
    li      $t6, 0                 # Index
find_by_name_cmp:
    lbu     $t7, 0($t5)            # Search name byte
    nop
    beq     $t7, $zero, find_by_name_match
    nop
    lbu     $t8, 0($t4)            # Dir entry name byte
    nop
    bne     $t7, $t8, find_by_name_next
    nop
    addiu   $t5, $t5, 1
    addiu   $t4, $t4, 1
    addiu   $t6, $t6, 1
    j       find_by_name_cmp
    nop

find_by_name_match:
    # Found! Extract LBA and size
    lw      $v0, 2($t0)            # LBA
    nop
    lw      $v1, 10($t0)           # Size
    nop
    jr      $ra
    nop

find_by_name_next:
    add     $t0, $t0, $t2
    j       find_by_name_loop
    nop

find_by_name_not_found:
    li      $v0, 0
    li      $v1, 0
    jr      $ra
    nop

# =============================================================================
# Find HBD File in ISO 9660 Directory
# $a0 = directory buffer pointer
# Searches for any file with "HBD" in the name (case-insensitive)
# Returns: $v0 = LBA (0 if not found), $v1 = file size
# =============================================================================
Find_HBD:
    move    $t0, $a0               # Dir buffer pointer
    li      $t3, 2048              # Max scan range

find_hbd_loop:
    lbu     $t1, 0($t0)            # Record length
    nop
    beq     $t1, $zero, find_hbd_not_found
    nop

    # Get file name length at offset 32
    lbu     $t4, 32($t0)
    nop
    # Need at least 3 chars for "HBD"
    li      $t5, 3
    sltu    $t5, $t5, $t4          # t5 = (3 < name_len)
    beq     $t5, $zero, find_hbd_next
    nop

    # Scan name for "HBD" substring (case-insensitive)
    addiu   $t6, $t0, 33           # Name pointer
    move    $t7, $zero             # Char index
find_hbd_scan:
    # Check if we have 3 chars left
    subu    $t8, $t4, $t7          # Remaining chars
    li      $t9, 3
    sltu    $t9, $t9, $t8          # t9 = (3 <= remaining)
    beq     $t9, $zero, find_hbd_next
    nop

    # Check 'H' at t6+t7
    addu    $t8, $t6, $t7
    lbu     $t9, 0($t8)
    nop
    li      $t2, 0x48              # 'H'
    beq     $t9, $t2, find_hbd_check_b
    nop
    li      $t2, 0x68              # 'h'
    bne     $t9, $t2, find_hbd_inc
    nop
find_hbd_check_b:
    lbu     $t9, 1($t8)
    nop
    li      $t2, 0x42              # 'B'
    beq     $t9, $t2, find_hbd_check_d
    nop
    li      $t2, 0x62              # 'b'
    bne     $t9, $t2, find_hbd_inc
    nop
find_hbd_check_d:
    lbu     $t9, 2($t8)
    nop
    li      $t2, 0x44              # 'D'
    beq     $t9, $t2, find_hbd_found
    nop
    li      $t2, 0x64              # 'd'
    bne     $t9, $t2, find_hbd_inc
    nop
    j       find_hbd_found
    nop
find_hbd_inc:
    addiu   $t7, $t7, 1
    j       find_hbd_scan
    nop

find_hbd_found:
    # Found! Extract LBA (offset 2, 4 bytes LE) and size (offset 10, 4 bytes LE)
    lw      $v0, 2($t0)            # LBA
    nop
    lw      $v1, 10($t0)           # File size
    nop
    jr      $ra
    nop

find_hbd_next:
    add     $t0, $t0, $t1          # Skip by record length
    j       find_hbd_loop
    nop

find_hbd_not_found:
    li      $v0, 0
    li      $v1, 0
    jr      $ra
    nop

# =============================================================================
# VBlank Interrupt Handler
# Installed at 0x80000080 (RAM exception vector for interrupt when BEV=0)
# Sets display flags at 0x800B5312 and 0x800B679C
# Delivers VBlank events to registered event callbacks
# =============================================================================
VBlank_Handler:
    # Save working registers
    addiu   $sp, $sp, -32
    sw      $t0, 0($sp)
    sw      $t1, 4($sp)
    sw      $t2, 8($sp)
    sw      $t3, 12($sp)
    sw      $t4, 16($sp)
    sw      $ra, 20($sp)

    # Read CP0 Cause register to confirm hardware interrupt
    # On PSX, ALL hardware interrupts (VBlank, GPU, CD-ROM, DMA, timers)
    # come through IP2 (Cause bit 12). Must read ISTAT to distinguish.
    mfc0    $t0, 13                # Cause register
    nop

    # Check IP2 (PSX hardware interrupt) — Cause bit 12
    # On PSX, ALL hardware interrupts come through IP2 (ISTAT → IP2)
    andi    $t1, $t0, 0x1000       # IP2 bit (bit 12)
    beq     $t1, $zero, vblank_handler_return  # Not a hardware interrupt
    nop

    # Read ISTAT (0x1F801070) to determine which interrupt(s) fired
    lui     $t1, 0x1f80
    ori     $t1, $t1, 0x1000
    lw      $t2, 0x70($t1)         # Read ISTAT
    nop

    # Check ISTAT bit 0 (VBlank)
    andi    $t3, $t2, 0x01
    bne     $t3, $zero, vblank_irq0_handler
    nop

    # Check ISTAT bit 2 (CD-ROM IRQ2)
    andi    $t3, $t2, 0x04
    bne     $t3, $zero, vblank_cdrom_irq2_handler
    nop

    # Other hardware interrupt — ack all ISTAT and return
    li      $t3, 0x000000FF
    sw      $t3, 0x70($t1)         # Clear all ISTAT bits
    nop
    j       vblank_handler_return
    nop

vblank_irq0_handler:
    # Acknowledge VBlank interrupt at ISTAT (bit 0)
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t1, 0x00000001        # VBlank bit
    sw      $t1, 0x70($t0)         # Clear ISTAT bit 0
    nop

    # Set display flag at 0x800B5312 (DW7 VBlank counter)
    lui     $t1, 0x800B
    ori     $t1, $t1, 0x5312
    lhu     $t2, 0($t1)            # Read current value
    nop
    addiu   $t2, $t2, 1            # Increment
    sh      $t2, 0($t1)            # Store back
    nop

    # Increment VBlank counter at 0x800B63D8 (game VSync wait loop polls this)
    lui     $t1, 0x800B
    ori     $t1, $t1, 0x63D8
    lw      $t2, 0($t1)            # Read current value
    nop
    addiu   $t2, $t2, 1            # Increment
    sw      $t2, 0($t1)            # Store back
    nop

    # Set 0x800B679C = 5 (CD command complete)
    lui     $t1, 0x800B
    ori     $t1, $t1, 0x679C
    li      $t2, 5
    sh      $t2, 0($t1)
    nop

    # Deliver VBlank AND CD-ROM events (VBlank fallback delivery for CD-ROM)
    # Event table at 0x80010B00, 16 entries, 16 bytes each
    # Event struct: [class(0), spec(4), mode(8), flag(12)]
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00       # Event table base
    li      $t1, 16                # Event count
    move    $t2, $zero             # Index
vblank_event_loop:
    beq     $t2, $t1, vblank_event_done
    nop
    # Check event class (offset 0): match VBlank (0xF2000001) OR CD-ROM (0xF0000009)
    lw      $t3, 0($t0)            # class
    nop
    li      $t4, 0xF2000001        # VBlank event class
    beq     $t3, $t4, vblank_event_active
    nop
    li      $t4, 0xF0000009        # CD-ROM event class
    beq     $t3, $t4, vblank_event_active
    nop
    j       vblank_event_next
    nop
vblank_event_active:
    # Check event status (offset 8): active = 1
    lw      $t3, 8($t0)            # mode/status
    nop
    li      $t4, 1                 # Active
    bne     $t3, $t4, vblank_event_next
    nop
    # Set event flag (offset 12) to 1 (triggered)
    li      $t3, 1
    sw      $t3, 12($t0)
    nop
vblank_event_next:
    addiu   $t0, $t0, 16           # Next event entry
    addiu   $t2, $t2, 1
    beq     $zero, $zero, vblank_event_loop
    nop
vblank_event_done:
    j       vblank_handler_return
    nop

vblank_cdrom_irq2_handler:
    # Acknowledge CD-ROM interrupt at CD-ROM controller
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # CD-ROM regs
    li      $t1, 0x01
    sb      $t1, 0x00($t0)         # Index = 1
    nop
    li      $t1, 0x07
    sb      $t1, 0x03($t0)         # Ack CD-ROM IRQ
    nop
    li      $t1, 0x00
    sb      $t1, 0x00($t0)         # Index = 0 (restore)
    nop

    # Clear ISTAT bit 2 (CD-ROM IRQ2)
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t1, 0x00000004
    sw      $t1, 0x70($t0)         # Clear ISTAT bit 2
    nop

    # Deliver CD-ROM events (class 0xF0000009 only)
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00       # Event table base
    li      $t1, 16                # Event count
    move    $t2, $zero             # Index
cdrom_event_loop:
    beq     $t2, $t1, cdrom_event_done
    nop
    lw      $t3, 0($t0)            # class
    nop
    li      $t4, 0xF0000009        # CD-ROM event class
    bne     $t3, $t4, cdrom_event_next
    nop
    lw      $t3, 8($t0)            # mode/status
    nop
    li      $t4, 1                 # Active
    bne     $t3, $t4, cdrom_event_next
    nop
    li      $t3, 1
    sw      $t3, 12($t0)           # Set flag = 1 (triggered)
    nop
cdrom_event_next:
    addiu   $t0, $t0, 16           # Next event entry
    addiu   $t2, $t2, 1
    j       cdrom_event_loop
    nop
cdrom_event_done:
    # Fall through to return

vblank_handler_return:
    # Restore registers
    lw      $t0, 0($sp)
    lw      $t1, 4($sp)
    lw      $t2, 8($sp)
    lw      $t3, 12($sp)
    lw      $t4, 16($sp)
    lw      $ra, 20($sp)
    addiu   $sp, $sp, 32

    # Return from exception
    mfc0    $t0, 14                # EPC
    nop
    jr      $t0
    .word 0x42000010               # rfe instruction

# =============================================================================
# Install VBlank Handler
# Copies the VBlank handler code to 0x80000080
# =============================================================================
Install_VBlank_Handler:
    la      $t0, VBlank_Handler    # Source
    lui     $t1, 0x8000            # Dest = 0x80000080
    ori     $t1, $t1, 0x0080
    li      $t2, 512               # Copy 512 bytes (128 instructions max)
vblank_copy_loop:
    beq     $t2, $zero, vblank_copy_done
    nop
    lbu     $t3, 0($t0)
    nop
    sb      $t3, 0($t1)
    addiu   $t0, $t0, 1
    addiu   $t1, $t1, 1
    addiu   $t2, $t2, -1
    j       vblank_copy_loop
    nop
vblank_copy_done:
    jr      $ra
    nop

# =============================================================================
# Flush Cache
# =============================================================================
Flush_Cache:
    # TagHi (reg 3) write is silently ignored by StarPSX
    mtc0    $zero, 3               # TagHi = 0
    nop
    # TagLo (reg 2) write not supported by StarPSX — skip
    # Cache instruction not supported by StarPSX — skip
    # Most emulators handle cache coherency automatically
    jr      $ra
    nop

# =============================================================================
# Syscall Vector Stubs
# Each vector is 4 instructions (16 bytes) installed at 0xA0, 0xB0, 0xC0
# The calling convention: $t1 = function number, vector jumps to table[$t1]
# =============================================================================

# A0 Vector: dispatches to A0 table at 0x80010000
A0_Vector_Stub:
    sll     $t0, $t1, 2              # t0 = t1 * 4 (byte offset)
    lui     $t2, 0x8001              # t2 = 0x80010000 (A0 table base)
    addu    $t2, $t2, $t0            # t2 = &A0table[t1]
    lw      $t3, 0($t2)             # t3 = handler address
    jr      $t3                      # jump to handler
    nop

# B0 Vector: dispatches to B0 table at 0x80010300
B0_Vector_Stub:
    sll     $t0, $t1, 2
    lui     $t2, 0x8001
    ori     $t2, $t2, 0x0300        # B0 table base = 0x80010300
    addu    $t2, $t2, $t0
    lw      $t3, 0($t2)
    jr      $t3
    nop

# C0 Vector: dispatches to C0 table at 0x80010480
C0_Vector_Stub:
    sll     $t0, $t1, 2
    lui     $t2, 0x8001
    ori     $t2, $t2, 0x0480        # C0 table base = 0x80010480
    addu    $t2, $t2, $t0
    lw      $t3, 0($t2)
    jr      $t3
    nop

# =============================================================================
# Install Syscall Vectors
# Copies 4-word stubs to RAM addresses 0xA0, 0xB0, 0xC0
# =============================================================================
Install_Syscall_Vectors:
    # A0 vector -> 0x000000A0
    lui     $t0, 0x0000
    ori     $t0, $t0, 0x00A0
    la      $t1, A0_Vector_Stub
    lw      $t2, 0($t1)
    sw      $t2, 0($t0)
    lw      $t2, 4($t1)
    sw      $t2, 4($t0)
    lw      $t2, 8($t1)
    sw      $t2, 8($t0)
    lw      $t2, 12($t1)
    sw      $t2, 12($t0)

    # B0 vector -> 0x000000B0
    ori     $t0, $t0, 0x0010        # 0xA0 + 0x10 = 0xB0
    la      $t1, B0_Vector_Stub
    lw      $t2, 0($t1)
    sw      $t2, 0($t0)
    lw      $t2, 4($t1)
    sw      $t2, 4($t0)
    lw      $t2, 8($t1)
    sw      $t2, 8($t0)
    lw      $t2, 12($t1)
    sw      $t2, 12($t0)

    # C0 vector -> 0x000000C0
    ori     $t0, $t0, 0x0010        # 0xB0 + 0x10 = 0xC0
    la      $t1, C0_Vector_Stub
    lw      $t2, 0($t1)
    sw      $t2, 0($t0)
    lw      $t2, 4($t1)
    sw      $t2, 4($t0)
    lw      $t2, 8($t1)
    sw      $t2, 8($t0)
    lw      $t2, 12($t1)
    sw      $t2, 12($t0)

    jr      $ra
    nop

# =============================================================================
# Copy Syscall Tables to RAM
# A0 table: 0xC0 entries -> 0x80010000 (0x300 bytes)
# B0 table: 0x60 entries -> 0x80010300 (0x180 bytes)
# C0 table: 0x20 entries -> 0x80010480 (0x80 bytes)
# =============================================================================
Copy_Syscall_Tables:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    # Copy A0 table
    la      $t0, A0_Table            # Source
    lui     $t1, 0x8001              # Dest = 0x80010000
    li      $t2, 0x300               # 0xC0 * 4 bytes
    jal     Memcopy
    nop

    # Copy B0 table
    la      $t0, B0_Table
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0300
    li      $t2, 0x180               # 0x60 * 4
    jal     Memcopy
    nop

    # Copy C0 table
    la      $t0, C0_Table
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0480
    li      $t2, 0x80                # 0x20 * 4
    jal     Memcopy
    nop

    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# =============================================================================
# Memcopy: $t0=src, $t1=dst, $t2=count (bytes)
# =============================================================================
Memcopy:
    beq     $t2, $zero, memcopy_done
    nop
memcopy_loop:
    lbu     $t3, 0($t0)
    nop
    sb      $t3, 0($t1)
    addiu   $t0, $t0, 1
    addiu   $t1, $t1, 1
    addiu   $t2, $t2, -1
    bne     $t2, $zero, memcopy_loop
    nop
memcopy_done:
    jr      $ra
    nop

# =============================================================================
# Init Interrupt Controller
# =============================================================================
Init_Interrupt_Controller:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000

    # ISTAT (0x1F801070): clear all interrupt flags
    li      $t1, 0x0000
    sw      $t1, 0x70($t0)          # Clear ISTAT
    nop

    # IMASK (0x1F801074): enable VBlank(0x01), GPU(0x40), CDROM(0x04), DMA(0x80)
    li      $t1, 0x000000C5         # VBlank + GPU + CDROM + DMA
    sw      $t1, 0x74($t0)          # Set IMASK
    nop

    jr      $ra
    nop

# =============================================================================
# Init Heap
# Simple heap allocator: heap starts at 0x80018000, size 0x8000 (32KB)
# Globals at 0x80010A00: heap_ptr, heap_size
# =============================================================================
Init_Heap:
    # Set heap base pointer
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00       # 0x80010A00 = globals area
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x8000       # Heap base = 0x80018000
    sw      $t1, 0($t0)            # heap_ptr = 0x80018000
    nop
    li      $t1, 0x00008000        # Heap size = 32KB
    sw      $t1, 4($t0)            # heap_size = 0x8000
    nop
    jr      $ra
    nop

# =============================================================================
# Init Events
# $a0 = event count
# Allocates EvCB array at 0x80010B00, each entry 16 bytes
# =============================================================================
Init_Events:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00       # Event array base = 0x80010B00
    move    $t1, $zero             # Counter
init_events_loop:
    slt     $t2, $t1, $a0
    beq     $t2, $zero, init_events_done
    nop
    # Clear 16 bytes per event slot
    sw      $zero, 0($t0)
    sw      $zero, 4($t0)
    sw      $zero, 8($t0)
    sw      $zero, 12($t0)
    addiu   $t0, $t0, 16
    addiu   $t1, $t1, 1
    j       init_events_loop
    nop
init_events_done:
    # Store event count in globals
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00
    sw      $a0, 8($t0)            # globals[2] = event_count
    nop
    jr      $ra
    nop

# =============================================================================
# Init Threads
# $a0 = thread count
# Allocates TCB array at 0x80010C00, each entry 128 bytes (oversized for regs)
# =============================================================================
Init_Threads:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0C00       # Thread array base = 0x80010C00
    move    $t1, $zero             # Counter
init_threads_loop:
    slt     $t2, $t1, $a0
    beq     $t2, $zero, init_threads_done
    nop
    # Clear first 32 bytes of TCB (flags + key registers)
    sw      $zero, 0($t0)
    sw      $zero, 4($t0)
    sw      $zero, 8($t0)
    sw      $zero, 12($t0)
    sw      $zero, 16($t0)
    sw      $zero, 20($t0)
    sw      $zero, 24($t0)
    sw      $zero, 28($t0)
    addiu   $t0, $t0, 128          # Next TCB (128-byte stride)
    addiu   $t1, $t1, 1
    j       init_threads_loop
    nop
init_threads_done:
    # Store thread count in globals
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00
    sw      $a0, 12($t0)           # globals[3] = thread_count
    nop
    jr      $ra
    nop

# =============================================================================
# Unimplemented Syscall Handler
# Logs the call and returns 0 (graceful degradation)
# =============================================================================
Sys_Unimplemented:
    # Write a marker to 0x801FFFF0 so we can detect unimplemented calls
    lui     $t0, 0x801F
    ori     $t0, $t0, 0xFFF0
    sw      $t1, 0($t0)            # Store function number
    nop
    # Return 0
    li      $v0, 0
    jr      $ra
    nop

# =============================================================================
# Syscall Stubs — A0 Table Functions
# =============================================================================

# A0(0x00): open
Sys_open:
    li      $v0, 0xFFFFFFFF        # Return -1 (no file system yet)
    jr      $ra
    nop

# A0(0x02): read
Sys_read:
    li      $v0, 0
    jr      $ra
    nop

# A0(0x03): write
Sys_write:
    li      $v0, 0
    jr      $ra
    nop

# A0(0x04): close
Sys_close:
    li      $v0, 0
    jr      $ra
    nop

# A0(0x0E): abs
Sys_abs:
    sra     $v0, $a0, 31           # v0 = sign bit
    xor     $v1, $a0, $v0          # flip bits if negative
    subu    $v0, $v1, $v0          # add 1 if negative
    jr      $ra
    nop

# A0(0x0F): labs
Sys_labs:
    sra     $v0, $a0, 31
    xor     $v1, $a0, $v0
    subu    $v0, $v1, $v0
    jr      $ra
    nop

# A0(0x10): atoi
Sys_atoi:
    move    $v0, $zero
    li      $t0, 10
atoi_loop:
    lbu     $t1, 0($a0)
    nop
    beq     $t1, $zero, atoi_done
    nop
    li      $t2, 0x30              # '0'
    sltu    $t3, $t2, $t1          # t3 = (0x30 < char) — excludes '0' itself
    bne     $t3, $zero, atoi_check_high  # if char > '0', check upper bound
    nop
    # char == '0'? still valid digit
    li      $t2, 0x30
    beq     $t1, $t2, atoi_is_digit
    nop
    j       atoi_skip
    nop
atoi_check_high:
    li      $t2, 0x3A              # one past '9'
    sltu    $t3, $t1, $t2          # t3 = (char < 0x3A) — includes '9'
    beq     $t3, $zero, atoi_skip
    nop
atoi_is_digit:
    mult    $v0, $t0               # v0 = v0 * 10 (2-operand form)
    nop
    mflo    $v0                    # result in LO
    addiu   $t1, $t1, -0x30
    addu    $v0, $v0, $t1
atoi_skip:
    addiu   $a0, $a0, 1
    j       atoi_loop
    nop
atoi_done:
    jr      $ra
    nop

# A0(0x17): strcmp
Sys_strcmp:
    move    $v0, $zero
strcmp_loop:
    lbu     $t0, 0($a0)
    nop
    lbu     $t1, 0($a1)
    nop
    beq     $t0, $zero, strcmp_end
    nop
    bne     $t0, $t1, strcmp_end
    nop
    addiu   $a0, $a0, 1
    addiu   $a1, $a1, 1
    j       strcmp_loop
    nop
strcmp_end:
    subu    $v0, $t0, $t1
    jr      $ra
    nop

# A0(0x19): strcpy
Sys_strcpy:
    move    $v0, $a0               # Return dest
strcpy_loop:
    lbu     $t0, 0($a1)
    nop
    sb      $t0, 0($a0)
    beq     $t0, $zero, strcpy_done
    nop
    addiu   $a0, $a0, 1
    addiu   $a1, $a1, 1
    j       strcpy_loop
    nop
strcpy_done:
    jr      $ra
    nop

# A0(0x1B): strlen
Sys_strlen:
    move    $v0, $zero
strlen_loop:
    addu    $t0, $a0, $v0
    lbu     $t1, 0($t0)
    nop
    beq     $t1, $zero, strlen_done
    nop
    addiu   $v0, $v0, 1
    j       strlen_loop
    nop
strlen_done:
    jr      $ra
    nop

# A0(0x2A): memcpy
Sys_memcpy:
    beq     $a2, $zero, memcpy_done2
    nop
    move    $v0, $a0               # Return dest
memcpy_loop2:
    lbu     $t0, 0($a1)
    nop
    sb      $t0, 0($a0)
    addiu   $a0, $a0, 1
    addiu   $a1, $a1, 1
    addiu   $a2, $a2, -1
    bne     $a2, $zero, memcpy_loop2
    nop
memcpy_done2:
    jr      $ra
    nop

# A0(0x2B): memset
Sys_memset:
    beq     $a2, $zero, memset_done
    nop
    move    $v0, $a0               # Return dest
memset_loop:
    sb      $a1, 0($a0)
    addiu   $a0, $a0, 1
    addiu   $a2, $a2, -1
    bne     $a2, $zero, memset_loop
    nop
memset_done:
    jr      $ra
    nop

# A0(0x33): malloc
Sys_malloc:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00       # Globals area
    lw      $t1, 0($t0)            # heap_ptr
    nop
    # Simple bump allocator: return current heap_ptr, advance by size
    move    $v0, $t1               # Return current heap ptr
    addu    $t1, $t1, $a0          # Advance by requested size
    # Round up to 4-byte alignment
    addiu   $t1, $t1, 3
    srl     $t1, $t1, 2
    sll     $t1, $t1, 2
    sw      $t1, 0($t0)            # Update heap_ptr
    nop
    jr      $ra
    nop

# A0(0x34): free
Sys_free:
    # No-op for bump allocator
    jr      $ra
    nop

# A0(0x37): calloc
Sys_calloc:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    # malloc(nitems * size) then memset to 0
    mult    $a0, $a1               # a0 = nitems * size (2-operand)
    nop
    mflo    $a0                    # result in LO
    jal     Sys_malloc
    nop
    # v0 = ptr, clear it
    beq     $v0, $zero, calloc_done
    nop
    move    $a0, $v0
    li      $a1, 0
    # a2 already has size from mult... actually we need to recalculate
    # For simplicity, just return the malloc'd ptr (bump allocator returns zeroed RAM)
calloc_done:
    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# A0(0x38): realloc
Sys_realloc:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    # Simple: malloc new, copy old, free old
    # For now just malloc new size
    move    $a0, $a1               # size = a1
    jal     Sys_malloc
    nop
    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# A0(0x39): InitHeap
Sys_InitHeap:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00
    sw      $a0, 0($t0)            # heap_ptr = a0
    nop
    sw      $a1, 4($t0)            # heap_size = a1
    nop
    jr      $ra
    nop

# A0(0x3F): printf
Sys_printf:
    # No-op (no TTY yet)
    li      $v0, 0
    jr      $ra
    nop

# A0(0x44): FlushCache
Sys_FlushCache:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    jal     Flush_Cache
    nop
    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# A0(0x46): GPU_dw (drawing area)
Sys_GPU_dw:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # GPU regs at 0x1F801810
    li      $t1, 0xA0000000        # GP0 command: fill VRAM
    sw      $t1, 0x10($t0)         # Write to GP0
    nop
    sw      $a0, 0x10($t0)         # x,y
    nop
    sw      $a1, 0x10($t0)         # w,h
    nop
    jr      $ra
    nop

# A0(0x47): mem2vram
Sys_GPU_mem2vram:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # GPU regs at 0x1F801810
    li      $t1, 0xA0000000
    sw      $t1, 0x10($t0)
    nop
    sw      $a0, 0x10($t0)
    nop
    sw      $a1, 0x10($t0)
    nop
    jr      $ra
    nop

# A0(0x48): SendGPU
Sys_GPU_send:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # GPU regs at 0x1F801810
    sw      $a0, 0x10($t0)         # Write to GP0
    nop
    jr      $ra
    nop

# =============================================================================
# Syscall Stubs — B0 Table Functions
# =============================================================================

# B0(0x00): malloc (kernel)
Sys_kmalloc:
    j       Sys_malloc
    nop

# B0(0x01): free (kernel)
Sys_kfree:
    j       Sys_free
    nop

# B0(0x07): deliverEvent
# $a0 = event class, $a1 = event spec
# Sets the flag for the matching event in the event table
Sys_deliverEvent:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00       # Event table base
    li      $t1, 16                # Event count
    move    $t2, $zero             # Index
deliver_event_loop:
    beq     $t2, $t1, deliver_event_not_found
    nop
    lw      $t3, 0($t0)           # class
    nop
    bne     $t3, $a0, deliver_event_next
    nop
    lw      $t3, 4($t0)           # spec
    nop
    bne     $t3, $a1, deliver_event_next
    nop
    # Found matching event — set flag
    li      $t3, 1
    sw      $t3, 12($t0)          # flag = 1 (triggered)
    nop
    li      $v0, 1                # Success
    jr      $ra
    nop
deliver_event_next:
    addiu   $t0, $t0, 16
    addiu   $t2, $t2, 1
    j       deliver_event_loop
    nop
deliver_event_not_found:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x08): openEvent
# $a0 = class, $a1 = spec, $a2 = mode, $a3 = callback
# Allocates an event slot, returns event handle (slot index + 1)
Sys_openEvent:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00       # Event table base
    li      $t1, 16                # Event count
    move    $t2, $zero             # Index
open_event_loop:
    beq     $t2, $t1, open_event_full
    nop
    lw      $t3, 0($t0)           # class
    nop
    bne     $t3, $zero, open_event_next   # Slot in use?
    nop
    # Free slot found — fill it
    sw      $a0, 0($t0)           # class
    nop
    sw      $a1, 4($t0)           # spec
    nop
    sw      $a2, 8($t0)           # mode (active=1 when enabled)
    nop
    sw      $zero, 12($t0)        # flag = 0 (not triggered yet)
    nop
    # Return handle = index + 1 (so 0 = invalid)
    addiu   $v0, $t2, 1
    jr      $ra
    nop
open_event_next:
    addiu   $t0, $t0, 16
    addiu   $t2, $t2, 1
    j       open_event_loop
    nop
open_event_full:
    li      $v0, 0                 # No free slots
    jr      $ra
    nop

# B0(0x09): closeEvent
# $a0 = event handle
# Clears the event slot
Sys_closeEvent:
    # Handle = index + 1, so index = handle - 1
    addiu   $t0, $a0, -1
    # Bounds check
    sltu    $t1, $t0, 16           # t1 = (index < 16)
    beq     $t1, $zero, close_event_fail
    nop
    # Clear slot
    sll     $t0, $t0, 4            # index * 16
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0B00
    addu    $t1, $t1, $t0
    sw      $zero, 0($t1)          # class = 0 (free)
    nop
    sw      $zero, 4($t1)          # spec = 0
    nop
    sw      $zero, 8($t1)          # mode = 0
    nop
    sw      $zero, 12($t1)         # flag = 0
    nop
    li      $v0, 1                 # Success
    jr      $ra
    nop
close_event_fail:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x0A): waitEvent
# $a0 = event handle
# Polls until the event flag is set, then clears it
Sys_waitEvent:
    addiu   $t0, $a0, -1
    sltu    $t1, $t0, 16
    beq     $t1, $zero, wait_event_fail
    nop
    sll     $t0, $t0, 4
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0B00
    addu    $t1, $t1, $t0
wait_event_poll:
    lw      $t2, 12($t1)          # flag
    nop
    beq     $t2, $zero, wait_event_poll
    nop
    # Clear flag
    sw      $zero, 12($t1)
    nop
    li      $v0, 1                # Success
    jr      $ra
    nop
wait_event_fail:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x0B): testEvent
# $a0 = event handle
# Returns 1 if event flag is set, 0 otherwise (does not clear)
Sys_testEvent:
    addiu   $t0, $a0, -1
    sltu    $t1, $t0, 16
    beq     $t1, $zero, test_event_fail
    nop
    sll     $t0, $t0, 4
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0B00
    addu    $t1, $t1, $t0
    lw      $v0, 12($t1)          # Return flag value
    nop
    jr      $ra
    nop
test_event_fail:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x0C): enableEvent
# $a0 = event handle
# Sets mode to 1 (active)
Sys_enableEvent:
    addiu   $t0, $a0, -1
    sltu    $t1, $t0, 16
    beq     $t1, $zero, enable_event_fail
    nop
    sll     $t0, $t0, 4
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0B00
    addu    $t1, $t1, $t0
    li      $t2, 1
    sw      $t2, 8($t1)           # mode = 1 (active)
    nop
    li      $v0, 1
    jr      $ra
    nop
enable_event_fail:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x0D): disableEvent
# $a0 = event handle
# Sets mode to 0 (inactive)
Sys_disableEvent:
    addiu   $t0, $a0, -1
    sltu    $t1, $t0, 16
    beq     $t1, $zero, disable_event_fail
    nop
    sll     $t0, $t0, 4
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0B00
    addu    $t1, $t1, $t0
    sw      $zero, 8($t1)         # mode = 0 (inactive)
    nop
    li      $v0, 1
    jr      $ra
    nop
disable_event_fail:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x0E): openThread
Sys_openThread:
    li      $v0, 0xFF000000        # Return fake thread handle
    jr      $ra
    nop

# B0(0x0F): closeThread
Sys_closeThread:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x10): changeThread
Sys_changeThread:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x14): returnFromException
Sys_returnFromException:
    # Restore EPC and return
    mfc0    $t0, 14                # EPC
    nop
    jr      $t0
    nop

# B0(0x32): open
Sys_B0_open:
    li      $v0, 0xFFFFFFFF
    jr      $ra
    nop

# B0(0x33): lseek
Sys_lseek:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x34): read
Sys_B0_read:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x35): write
Sys_B0_write:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x36): close
Sys_B0_close:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x39): exit
Sys_exit:
    j       boot_fail
    nop

# B0(0x3F): puts
Sys_puts:
    li      $v0, 0
    jr      $ra
    nop

# =============================================================================
# CD-ROM Syscall Implementations (B0 table)
# =============================================================================

# B0(0x4B): CD_Init — initialize CD-ROM subsystem
Sys_CD_init:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    jal     CDROM_Init
    nop
    li      $v0, 1
    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# B0(0x4C): CD_Read — start async CD read
# $a0 = read mode (0=raw, 1=cooked), $a1 = start sector, $a2 = count, $a3 = dest
# Returns 1 on success, 0 on failure
Sys_CD_read:
    addiu   $sp, $sp, -24
    sw      $ra, 20($sp)
    sw      $s5, 16($sp)
    sw      $s6, 12($sp)
    sw      $s7, 8($sp)
    # Save args
    move    $s6, $a1               # Start LBA
    move    $s7, $a3               # Dest
    move    $s5, $a2               # Count
    jal     CDROM_ReadSectors
    nop
    # v0 already set by CDROM_ReadSectors
    lw      $ra, 20($sp)
    lw      $s5, 16($sp)
    lw      $s6, 12($sp)
    lw      $s7, 8($sp)
    addiu   $sp, $sp, 24
    jr      $ra
    nop

# B0(0x4D): CD_ReadSync — wait for CD read to complete
# Returns 0 when complete
Sys_CD_readSync:
    # Since CD_read is synchronous, always return 0 (complete)
    li      $v0, 0
    jr      $ra
    nop

# B0(0x4E): CD_GetStat — get CD-ROM status
# Returns status byte in $v0
Sys_CD_getstat:
    addiu   $sp, $sp, -8
    sw      $ra, 4($sp)
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1f801800 (CD-ROM regs)
    # Send command 0x01 (Getstat)
    li      $t1, 0x01
    sb      $t1, 0x01($t0)         # Command: Getstat
    nop
    jal     CDROM_Wait_Response
    nop
    # $v0 = response byte
    lw      $ra, 4($sp)
    addiu   $sp, $sp, 8
    jr      $ra
    nop

# B0(0x4F): CD_Seek — seek to position
# $a0 = LBA to seek to
Sys_CD_seek:
    addiu   $sp, $sp, -24
    sw      $ra, 20($sp)
    sw      $s0, 16($sp)
    sw      $s1, 12($sp)
    sw      $s2, 8($sp)
    # Convert LBA to MSF (binary) then BCD, send Setloc command
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # $t0 = 0x1F801800 (CD-ROM regs)
    addiu   $t1, $a0, 150          # LBA + 150
    li      $t9, 4500
    div     $t1, $t9
    nop
    mflo    $t2                    # minute (binary)
    mfhi    $t3                    # remainder
    li      $t9, 75
    div     $t3, $t9
    nop
    mflo    $t4                    # second (binary)
    mfhi    $t5                    # frame (binary)
    # Convert to BCD
    li      $t9, 10
    div     $t2, $t9
    nop
    mflo    $s0
    mfhi    $t1
    sll     $s0, $s0, 4
    or      $s0, $s0, $t1         # s0 = minute BCD
    div     $t4, $t9
    nop
    mflo    $s1
    mfhi    $t1
    sll     $s1, $s1, 4
    or      $s1, $s1, $t1         # s1 = second BCD
    div     $t5, $t9
    nop
    mflo    $s2
    mfhi    $t1
    sll     $s2, $s2, 4
    or      $s2, $s2, $t1         # s2 = frame BCD
    # Write params to FIFO first, then send command
    sb      $s0, 0x02($t0)         # Param: minute (BCD)
    nop
    sb      $s1, 0x02($t0)         # Param: second (BCD)
    nop
    sb      $s2, 0x02($t0)         # Param: frame (BCD)
    nop
    li      $t1, 0x02
    sb      $t1, 0x01($t0)         # Command: Setloc
    nop
    jal     CDROM_Wait_Response
    nop
    li      $v0, 1
    lw      $ra, 20($sp)
    lw      $s0, 16($sp)
    lw      $s1, 12($sp)
    lw      $s2, 8($sp)
    addiu   $sp, $sp, 24
    jr      $ra
    nop

# =============================================================================
# Syscall Stubs — C0 Table Functions
# =============================================================================

# C0(0x05): getFreeTCBslot
Sys_getFreeTCB:
    li      $v0, 0
    jr      $ra
    nop

# C0(0x06): exceptionHandler
Sys_exceptionHandler:
    jr      $ra
    nop

# C0(0x07): installExceptionHandler
Sys_installExceptionHandler:
    jr      $ra
    nop

# C0(0x08): initheap (kernel)
Sys_kinitheap:
    j       Sys_InitHeap
    nop

# C0(0x10): setupFileIO
Sys_setupFileIO:
    jr      $ra
    nop

# C0(0x11): reopenStdio
Sys_reopenStdio:
    jr      $ra
    nop

# =============================================================================
# A0 Function Table (0xC0 entries = 192 words)
# =============================================================================
.align 4
A0_Table:
    .word Sys_open, Sys_Unimplemented, Sys_read, Sys_write    # 00-03
    .word Sys_close, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 04-07
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 08-0B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_abs, Sys_labs    # 0C-0F
    .word Sys_atoi, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 10-13
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_strcmp  # 14-17
    .word Sys_Unimplemented, Sys_strcpy, Sys_Unimplemented, Sys_strlen  # 18-1B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 1C-1F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 20-23
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 24-27
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_memcpy, Sys_memset  # 28-2B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 2C-2F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_malloc  # 30-33
    .word Sys_free, Sys_Unimplemented, Sys_Unimplemented, Sys_calloc  # 34-37
    .word Sys_realloc, Sys_InitHeap, Sys_Unimplemented, Sys_Unimplemented  # 38-3B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_printf  # 3C-3F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 40-43
    .word Sys_FlushCache, Sys_Unimplemented, Sys_GPU_dw, Sys_GPU_mem2vram  # 44-47
    .word Sys_GPU_send, Sys_Unimplemented, Sys_Unimplemented, Sys_CD_init  # 48-4B
    .word Sys_CD_read, Sys_CD_readSync, Sys_CD_getstat, Sys_CD_seek  # 4C-4F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 50-53
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 54-57
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 58-5B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 5C-5F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 60-63
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 64-67
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 68-6B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 6C-6F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 70-73
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 74-77
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 78-7B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 7C-7F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 80-83
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 84-87
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 88-8B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 8C-8F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 90-93
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 94-97
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 98-9B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 9C-9F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # A0-A3
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # A4-A7
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # A8-AB
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # AC-AF
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # B0-B3
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # B4-B7
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # B8-BB
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # BC-BF

# =============================================================================
# B0 Function Table (0x60 entries = 96 words)
# =============================================================================
.align 4
B0_Table:
    .word Sys_kmalloc, Sys_kfree, Sys_Unimplemented, Sys_Unimplemented  # 00-03
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_deliverEvent  # 04-07
    .word Sys_openEvent, Sys_closeEvent, Sys_waitEvent, Sys_testEvent  # 08-0B
    .word Sys_enableEvent, Sys_disableEvent, Sys_openThread, Sys_closeThread  # 0C-0F
    .word Sys_changeThread, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 10-13
    .word Sys_returnFromException, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 14-17
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 18-1B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 1C-1F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 20-23
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 24-27
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 28-2B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 2C-2F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_B0_open, Sys_lseek  # 30-33
    .word Sys_B0_read, Sys_B0_write, Sys_B0_close, Sys_Unimplemented  # 34-37
    .word Sys_exit, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 38-3B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_puts  # 3C-3F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 40-43
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 44-47
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_CD_init  # 48-4B
    .word Sys_CD_read, Sys_CD_readSync, Sys_CD_getstat, Sys_CD_seek  # 4C-4F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 50-53
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 54-57
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 58-5B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 5C-5F

# =============================================================================
# C0 Function Table (0x20 entries = 32 words)
# =============================================================================
.align 4
C0_Table:
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 00-03
    .word Sys_Unimplemented, Sys_getFreeTCB, Sys_exceptionHandler, Sys_installExceptionHandler  # 04-07
    .word Sys_kinitheap, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 08-0B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 0C-0F
    .word Sys_setupFileIO, Sys_reopenStdio, Sys_Unimplemented, Sys_Unimplemented  # 10-13
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 14-17
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 18-1B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 1C-1F

# =============================================================================
# General Exception Handler (at 0xBFC00180)
# =============================================================================
.org 0xbfc00180
exception_handler:
    # Check if this is an interrupt (Cause ExcCode = 0)
    mfc0    $t0, 13                # Cause register
    nop
    srl     $t1, $t0, 2            # Shift ExcCode to bits 2-6
    andi    $t1, $t1, 0x1F         # Mask ExcCode
    bne     $t1, $zero, exception_non_int  # Not an interrupt?
    nop

    # It's an interrupt — check which IRQ
    # When BEV=0, interrupt handler is at 0x80000080
    # But we're at 0xBFC00180 (BEV=1 fallback), so we need to
    # check if VBlank handler is installed at 0x80000080
    # If BEV is still 1 (boot phase), handle VBlank inline
    # Check IP2 (PSX hardware interrupt) — Cause bit 12
    # On PSX, ALL hardware interrupts come through IP2 (ISTAT → IP2)
    andi    $t1, $t0, 0x00001000   # IP2 bit (bit 12)
    beq     $t1, $zero, exception_check_other  # Not a hardware interrupt
    nop

    # Read ISTAT to determine which interrupt fired
    lui     $t1, 0x1f80
    ori     $t1, $t1, 0x1000
    lw      $t2, 0x70($t1)         # Read ISTAT
    nop

    # Check ISTAT bit 0 (VBlank)
    andi    $t3, $t2, 0x01
    bne     $t3, $zero, exception_vblank_handler
    nop

    # Check ISTAT bit 2 (CD-ROM IRQ2)
    andi    $t3, $t2, 0x04
    bne     $t3, $zero, exception_cdrom_handler
    nop

    # Other hardware interrupt
    j       exception_check_other
    nop

exception_vblank_handler:

    # VBlank interrupt — handle inline
    # Acknowledge VBlank at ISTAT
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t1, 0x00000001
    sw      $t1, 0x70($t0)         # Clear ISTAT bit 0
    nop

    # Set display flags
    lui     $t1, 0x800B
    ori     $t1, $t1, 0x5312
    lhu     $t2, 0($t1)
    nop
    addiu   $t2, $t2, 1
    sh      $t2, 0($t1)
    nop

    # Increment VBlank counter at 0x800B63D8 (game VSync wait loop polls this)
    lui     $t1, 0x800B
    ori     $t1, $t1, 0x63D8
    lw      $t2, 0($t1)
    nop
    addiu   $t2, $t2, 1
    sw      $t2, 0($t1)
    nop

    # Set 0x800B679C = 5 (CD command complete)
    lui     $t1, 0x800B
    ori     $t1, $t1, 0x679C
    li      $t2, 5
    sh      $t2, 0($t1)
    nop

    # Deliver VBlank AND CD-ROM events
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00
    li      $t1, 16
    move    $t2, $zero
exc_vblank_event_loop:
    beq     $t2, $t1, exc_vblank_event_done
    nop
    lw      $t3, 0($t0)
    nop
    li      $t4, 0xF2000001
    beq     $t3, $t4, exc_vblank_active
    nop
    li      $t4, 0xF0000009        # CD-ROM event class
    beq     $t3, $t4, exc_vblank_active
    nop
    j       exc_vblank_next
    nop
exc_vblank_active:
    lw      $t3, 8($t0)
    nop
    li      $t4, 1
    bne     $t3, $t4, exc_vblank_next
    nop
    li      $t3, 1
    sw      $t3, 12($t0)
    nop
exc_vblank_next:
    addiu   $t0, $t0, 16
    addiu   $t2, $t2, 1
    j       exc_vblank_event_loop
    nop
exc_vblank_event_done:

    # Return from exception
    mfc0    $t0, 14                # EPC
    nop
    jr      $t0
    .word 0x42000010               # rfe

exception_cdrom_handler:
    # CD-ROM IRQ2 interrupt — acknowledge and deliver CD-ROM events
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1800       # CD-ROM regs
    # Acknowledge CD-ROM interrupt
    li      $t1, 0x01
    sb      $t1, 0x00($t0)         # Index = 1
    nop
    li      $t1, 0x07
    sb      $t1, 0x03($t0)         # Ack CD-ROM IRQ
    nop
    li      $t1, 0x00
    sb      $t1, 0x00($t0)         # Index = 0
    nop
    # Clear ISTAT bit 2 (CD-ROM IRQ2)
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t1, 0x00000004
    sw      $t1, 0x70($t0)         # Clear ISTAT bit 2
    nop
    # Deliver CD-ROM events (class 0xF0000009)
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00
    li      $t1, 16
    move    $t2, $zero
exc_cdrom_event_loop:
    beq     $t2, $t1, exc_cdrom_event_done
    nop
    lw      $t3, 0($t0)
    nop
    li      $t4, 0xF0000009
    bne     $t3, $t4, exc_cdrom_next
    nop
    lw      $t3, 8($t0)
    nop
    li      $t4, 1
    bne     $t3, $t4, exc_cdrom_next
    nop
    li      $t3, 1
    sw      $t3, 12($t0)
    nop
exc_cdrom_next:
    addiu   $t0, $t0, 16
    addiu   $t2, $t2, 1
    j       exc_cdrom_event_loop
    nop
exc_cdrom_event_done:
    mfc0    $t0, 14
    nop
    jr      $t0
    .word 0x42000010               # rfe

exception_check_other:
    # Other interrupt — just acknowledge and return
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t1, 0x000000FF        # Ack all interrupts
    sw      $t1, 0x70($t0)
    nop
    mfc0    $t0, 14
    nop
    jr      $t0
    .word 0x42000010               # rfe

exception_non_int:
    # Save registers for debugging
    lui     $k0, 0x801F
    ori     $k0, $k0, 0xFF00
    sw      $at, 0x00($k0)
    sw      $v0, 0x04($k0)
    sw      $v1, 0x08($k0)
    sw      $a0, 0x0C($k0)
    sw      $a1, 0x10($k0)
    sw      $a2, 0x14($k0)
    sw      $a3, 0x18($k0)
    sw      $t0, 0x1C($k0)
    sw      $t1, 0x20($k0)
    sw      $t2, 0x24($k0)
    sw      $t3, 0x28($k0)
    sw      $t4, 0x2C($k0)
    sw      $t5, 0x30($k0)
    sw      $t6, 0x34($k0)
    sw      $t7, 0x38($k0)
    mfc0    $t0, 14
    nop
    sw      $t0, 0x3C($k0)
    mfc0    $t0, 13
    nop
    sw      $t0, 0x40($k0)
    mfc0    $t0, 8
    nop
    sw      $t0, 0x44($k0)
    mfc0    $t0, 12
    nop
    sw      $t0, 0x48($k0)
    lui     $t0, 0xDEAD
    ori     $t0, $t0, 0xCAFE
    sw      $t0, 0x4C($k0)
    j       exception_halt
    nop
exception_halt:
    j       exception_halt
    nop

# =============================================================================
# Signature Block (injected by build_frankenstein_bios.py)
# =============================================================================
.org 0xbfc07FE0
# OpenBIOS at 0x78 and VHB-SUPER-BIOS at 0x7FE0 injected by build script

// =============================================================================
// vhb_core.h — Virtual Hypervisor BIOS (VHB) Core
//
// Universal multi-console abstraction layer for running custom ROM hacks.
// Supports PSX (MIPS R3000A), SNES (65816), and Saturn (SH-2) target profiles.
//
// The VHB acts as an intelligent abstraction layer that:
//   1. Loads and inspects ROM/ISO images
//   2. Parses executable headers (PS-X EXE, SNES ROM, Saturn header)
//   3. Sets up virtual memory with Soft-MMU translation
//   4. Registers custom vector/trap handlers for ROM hack freedom
//   5. Dispatches payload execution to the correct target runtime
//
// Integration with existing project:
//   - PSX: uses psx_exe.py / frankenstein_driver for EXE parsing and MIPS codegen
//   - SNES: hooks into SFX-100 bus probe from frankenstein_bios.s
//   - Saturn: stub for future SH-2 support
// =============================================================================

#pragma once

#include <cstdint>
#include <cstring>
#include <vector>
#include <string>
#include <unordered_map>
#include <memory>
#include <functional>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <algorithm>

// ============================================================================
// Target System Profiles
// ============================================================================

enum class TargetSystem {
    // Legacy (kept for backward compatibility)
    SNES_Extended,    // Tile-16 (WDC 65C816)
    PSX_Hybrid,       // CD-24/CD-32 (MIPS R3000A) — primary target
    Saturn_Flexible,  // CD-32X (Dual SH-2 + VDP)

    // Multi-bit-depth expansion (clean-room naming)
    Tile8,            // 8-bit (MOS 6502) — cartridge
    Tile8Z,           // 8-bit (Z80) — cartridge
    Handheld8,        // 8-bit (Sharp LR35902) — cartridge
    Tile16,           // 16-bit (WDC 65C816) — cartridge
    Cd16,             // 16-bit (Motorola 68000) — cartridge + CD
    Handheld32,       // 32-bit (ARM7TDMI) — cartridge
    Cd32x,            // 32-bit (Dual SH-2) — CD
    PortableMedia32,  // 32-bit (MIPS R4000 Allegrex) — UMD
    Cart64,           // 64-bit (MIPS R4300) — cartridge
};

struct TargetProfile {
    TargetSystem system;
    const char* name;
    uint32_t default_ram_size;       // Base RAM for this target
    uint32_t extended_ram_size;      // Extended RAM for ROM hacks
    uint32_t payload_entry;          // Default payload entry point
    uint32_t vector_table_base;      // Exception vector table base
    uint32_t sector_size;            // CD sector size (0 for cartridge)
    uint32_t data_offset;            // Data offset in sector (0 for cartridge)
    const char* exe_magic;           // Magic bytes for EXE identification (nullptr if none)
    uint32_t ram_ceiling;            // P3: Maximum addressable RAM (for descriptor clamping)
    uint32_t desc_publish_addr;      // P3: Descriptor publish instruction address (0 if N/A)
    uint32_t desc_safe_base;         // P3: Safe fallback descriptor base address
};

// ============================================================================
// Virtual Hardware Context
// ============================================================================

struct MemoryRegion {
    uint32_t start;
    uint32_t end;
    const char* name;
    bool writable;
    bool executable;
};

class VirtualHardwareContext {
public:
    uint32_t extended_ram_size;
    bool freedom_mode_enabled;
    std::vector<MemoryRegion> memory_map;

    VirtualHardwareContext(uint32_t ram_size)
        : extended_ram_size(ram_size), freedom_mode_enabled(true) {}

    void register_region(uint32_t start, uint32_t end, const char* name,
                         bool writable = true, bool executable = true) {
        memory_map.push_back({start, end, name, writable, executable});
    }

    bool is_address_valid(uint32_t addr) const {
        for (const auto& r : memory_map) {
            if (addr >= r.start && addr < r.end) return true;
        }
        return false;
    }

    const MemoryRegion* find_region(uint32_t addr) const {
        for (const auto& r : memory_map) {
            if (addr >= r.start && addr < r.end) return &r;
        }
        return nullptr;
    }
};

// ============================================================================
// Soft-MMU: Dynamic Memory Translation
// ============================================================================

struct MMUMapping {
    uint32_t virtual_addr;
    uint32_t physical_addr;
    uint32_t size;
    const char* name;
};

class SoftMMU {
    std::vector<MMUMapping> mappings;
    std::vector<uint8_t> unified_memory;

public:
    SoftMMU(uint32_t pool_size = 64 * 1024 * 1024)
        : unified_memory(pool_size, 0) {}

    void map(uint32_t virt, uint32_t phys, uint32_t size, const char* name) {
        mappings.push_back({virt, phys, size, name});
    }

    uint32_t translate(uint32_t virt_addr) const {
        for (const auto& m : mappings) {
            if (virt_addr >= m.virtual_addr && virt_addr < m.virtual_addr + m.size) {
                return m.physical_addr + (virt_addr - m.virtual_addr);
            }
        }
        return virt_addr;  // Identity mapping if no translation found
    }

    uint8_t* physical_base() { return unified_memory.data(); }
    uint32_t pool_size() const { return (uint32_t)unified_memory.size(); }

    bool read(uint32_t virt_addr, void* dest, size_t len) {
        uint32_t phys = translate(virt_addr);
        if (phys + len > unified_memory.size()) return false;
        memcpy(dest, unified_memory.data() + phys, len);
        return true;
    }

    bool write(uint32_t virt_addr, const void* src, size_t len) {
        uint32_t phys = translate(virt_addr);
        if (phys + len > unified_memory.size()) return false;
        memcpy(unified_memory.data() + phys, src, len);
        return true;
    }

    uint32_t read32(uint32_t virt_addr) {
        uint32_t val = 0;
        read(virt_addr, &val, 4);
        return val;
    }

    void write32(uint32_t virt_addr, uint32_t val) {
        write(virt_addr, &val, 4);
    }
};

// ============================================================================
// Vector & Trap Dispatcher
// ============================================================================

using TrapHandler = std::function<void(uint32_t vector, uint32_t* registers)>;

struct VectorEntry {
    uint32_t vector_id;
    uint32_t original_target;
    uint32_t custom_target;
    TrapHandler handler;
    const char* name;
};

class VectorDispatcher {
    std::unordered_map<uint32_t, VectorEntry> vectors;

public:
    void register_vector(uint32_t id, uint32_t original_target,
                         TrapHandler handler, const char* name) {
        vectors[id] = {id, original_target, 0, handler, name};
    }

    void override_vector(uint32_t id, uint32_t custom_target) {
        if (vectors.count(id)) {
            vectors[id].custom_target = custom_target;
        }
    }

    bool dispatch(uint32_t vector_id, uint32_t* registers) {
        auto it = vectors.find(vector_id);
        if (it == vectors.end()) return false;

        if (it->second.handler) {
            it->second.handler(vector_id, registers);
            return true;
        }
        return false;
    }

    size_t count() const { return vectors.size(); }

    void list_vectors() const {
        for (const auto& [id, entry] : vectors) {
            printf("  Vector 0x%08X: %s (orig=0x%08X, custom=0x%08X)\n",
                   id, entry.name, entry.original_target, entry.custom_target);
        }
    }
};

// ============================================================================
// VFS: Virtual File System for Unified Asset Streaming
// ============================================================================

struct VFSFile {
    std::string name;
    uint32_t offset;
    uint32_t size;
    std::vector<uint8_t> data;
};

class VirtualFileSystem {
    std::unordered_map<std::string, VFSFile> files;

public:
    void mount(const std::string& name, const uint8_t* data, uint32_t size, uint32_t offset = 0) {
        VFSFile f;
        f.name = name;
        f.offset = offset;
        f.size = size;
        f.data.assign(data + offset, data + offset + size);
        files[name] = std::move(f);
    }

    const VFSFile* open(const std::string& name) const {
        auto it = files.find(name);
        if (it == files.end()) return nullptr;
        return &it->second;
    }

    bool read(const std::string& name, uint32_t offset, void* dest, size_t len) const {
        auto it = files.find(name);
        if (it == files.end()) return false;
        const auto& f = it->second;
        if (offset + len > f.data.size()) return false;
        memcpy(dest, f.data.data() + offset, len);
        return true;
    }

    void list_files() const {
        for (const auto& [name, f] : files) {
            printf("  %s: %u bytes (offset 0x%X)\n", name.c_str(), f.size, f.offset);
        }
    }
};

// ============================================================================
// ROM Image Info (parsed from loaded ROM/ISO)
// ============================================================================

struct RomImageInfo {
    TargetSystem system;
    std::string file_path;
    uint32_t file_size;
    std::string format;           // "PS-X EXE", "ISO 9660", "SNES ROM", "Saturn"
    std::string volume_id;        // Volume identifier (e.g., "SLUS_012.06")

    // EXE/entry info
    uint32_t entry_pc;            // Initial PC
    uint32_t load_addr;           // Load address in RAM
    uint32_t text_size;           // Text section size
    uint32_t gp_value;            // Global pointer value
    uint32_t sp_value;            // Stack pointer value

    // ISO-specific
    uint32_t exe_lba;             // LBA of EXE in ISO (0 if standalone)
    uint32_t hbd_lba;             // LBA of HBD data (0 if none)
    uint32_t sector_size;         // 2352 for MODE2, 2048 for MODE1

    bool valid;
};

// ============================================================================
// Super BIOS Hypervisor (VHB Core)
// ============================================================================

class SuperBIOSHypervisor {
private:
    TargetSystem current_target;
    TargetProfile profile;
    uint32_t configured_ram_mb;      // P3: Configured RAM size in MB
    std::unique_ptr<VirtualHardwareContext> context;
    SoftMMU mmu;
    VectorDispatcher vectors;
    VirtualFileSystem vfs;

    std::vector<uint8_t> rom_data;
    RomImageInfo rom_info;

public:
    SuperBIOSHypervisor(TargetSystem target, uint32_t ram_mb = 8);

    // Load a ROM/ISO image and parse its header
    bool load_rom(const std::string& path);

    // Load a standalone PS-X EXE file
    bool load_exe(const std::string& path);

    // Load EXE from an ISO image at a given LBA
    bool load_exe_from_iso(const std::string& iso_path, uint32_t exe_lba = 24);

    // Register ROM hack vectors (override legacy BIOS jump tables)
    void register_rom_hack_vectors();

    // Mount a file in the VFS
    void vfs_mount(const std::string& name, const uint8_t* data, uint32_t size, uint32_t offset = 0);

    // Execute payload at a given entry point
    void execute_payload(uint32_t entry_point);

    // Get the ROM image info
    const RomImageInfo& rom_info_get() const { return rom_info; }

    // Get the target profile
    const TargetProfile& get_profile() const { return profile; }

    // Get the Soft-MMU
    SoftMMU& get_mmu() { return mmu; }

    // Get the vector dispatcher
    VectorDispatcher& get_vectors() { return vectors; }

    // Get the VFS
    VirtualFileSystem& get_vfs() { return vfs; }

    // P3: Get RAM ceiling for descriptor clamping
    uint32_t get_ram_ceiling() const { return profile.ram_ceiling; }

    // P3: Get safe descriptor base
    uint32_t get_desc_safe_base() const { return profile.desc_safe_base; }

    // P3: Get configured RAM size
    uint32_t get_configured_ram_mb() const { return configured_ram_mb; }

    // Print system status
    void print_status() const;

    // List all registered vectors
    void list_vectors() const { vectors.list_vectors(); }

    // List all mounted VFS files
    void list_vfs() const { vfs.list_files(); }

private:
    // Parse PS-X EXE header from raw bytes
    bool parse_psx_exe(const uint8_t* data, size_t size);

    // Parse ISO 9660 to find EXE LBA
    bool parse_iso(const std::string& path);

    // Initialize memory map for the target system
    void init_memory_map();

    // Read a sector from an ISO file
    static std::vector<uint8_t> read_iso_sector(std::ifstream& f, uint32_t lba,
                                                  uint32_t sector_size, uint32_t data_offset);
};

// ============================================================================
// Target Profile Registry
// ============================================================================

namespace TargetProfiles {
    inline TargetProfile get(TargetSystem sys, uint32_t ram_mb = 8) {
        uint32_t ram_bytes = ram_mb * 1024 * 1024;
        switch (sys) {
            case TargetSystem::PSX_Hybrid:
                return {
                    TargetSystem::PSX_Hybrid,
                    "PSX Hybrid (MIPS R3000A)",
                    0x00200000,    // 2MB base RAM (hardware default)
                    ram_bytes,     // Extended RAM (configurable: 2/8/16MB)
                    0x80100000,    // Payload entry
                    0xBFC00000,    // Vector table base (BIOS)
                    2352,         // MODE2 sector
                    24,           // Data offset in sector
                    "PS-X EXE",   // EXE magic
                    0x80000000 + ram_bytes,  // P3: RAM ceiling (e.g. 0x80800000 for 8MB)
                    0x8007AD74,   // P3: Descriptor publish instruction address
                    0x80100000,   // P3: Safe fallback descriptor base
                };
            case TargetSystem::SNES_Extended:
                return {
                    TargetSystem::SNES_Extended,
                    "SNES Extended (65816 + SFX)",
                    0x00020000,    // 128KB base RAM
                    0x00400000,    // 4MB extended (GSU)
                    0x008000,      // Payload entry (ROM base)
                    0x000000,      // Vector table (65816 vectors in ROM)
                    0,            // Cartridge — no sectors
                    0,            // No data offset
                    nullptr,      // No EXE magic
                    0x00400000,   // RAM ceiling
                    0,            // No descriptor publish (SNES)
                    0,            // No descriptor base (SNES)
                };
            case TargetSystem::Saturn_Flexible:
            case TargetSystem::Cd32x:
                return {
                    TargetSystem::Saturn_Flexible,
                    "CD-32X (Dual SH-2)",
                    0x00200000,    // 2MB base RAM
                    0x00800000,    // 8MB extended
                    0x06004000,    // Payload entry (SH-2 cache)
                    0x06000000,    // Vector table base
                    2352,         // MODE2 sector
                    24,           // Data offset
                    "SEGA SEGASATURN",  // Saturn disc magic
                    0x06200000,   // RAM ceiling
                    0,            // No descriptor publish
                    0,            // No descriptor base
                };
            case TargetSystem::Tile8:
                return {
                    TargetSystem::Tile8,
                    "Tile-8 (MOS 6502)",
                    0x00000800,    // 2KB base RAM
                    0x00000800,    // 2KB extended (no expansion)
                    0x0000C000,   // Payload entry (PRG ROM upper bank)
                    0x00000000,   // Vector table (NMI/RESET/IRQ in ROM)
                    0,            // Cartridge — no sectors
                    0,            // No data offset
                    nullptr,      // No EXE magic (iNES header instead)
                    0x00010000,   // RAM ceiling (64KB address space)
                    0,            // No descriptor publish
                    0,            // No descriptor base
                };
            case TargetSystem::Tile8Z:
                return {
                    TargetSystem::Tile8Z,
                    "Tile-8Z (Zilog Z80)",
                    0x00002000,    // 8KB base RAM
                    0x00002000,    // 8KB extended
                    0x00000000,   // Payload entry (ROM base)
                    0x00000000,   // Vector table (RST 0-38 in ROM)
                    0,            // Cartridge — no sectors
                    0,            // No data offset
                    nullptr,      // No EXE magic
                    0x00010000,   // RAM ceiling (64KB address space)
                    0, 0,
                };
            case TargetSystem::Handheld8:
                return {
                    TargetSystem::Handheld8,
                    "Handheld-8 (Sharp LR35902)",
                    0x00002000,    // 8KB base RAM
                    0x00002000,    // 8KB extended
                    0x00000100,   // Payload entry (ROM entry point)
                    0x00000040,   // Vector table (RST addresses)
                    0,            // Cartridge — no sectors
                    0,            // No data offset
                    nullptr,      // No EXE magic
                    0x00010000,   // RAM ceiling (64KB address space)
                    0, 0,
                };
            case TargetSystem::Tile16:
                return {
                    TargetSystem::Tile16,
                    "Tile-16 (WDC 65C816)",
                    0x00020000,    // 128KB base RAM
                    0x00400000,    // 4MB extended (coprocessor)
                    0x008000,     // Payload entry (ROM base)
                    0x000000,     // Vector table (65C816 vectors in ROM)
                    0,            // Cartridge — no sectors
                    0,            // No data offset
                    nullptr,      // No EXE magic
                    0x00400000,   // RAM ceiling
                    0, 0,
                };
            case TargetSystem::Cd16:
                return {
                    TargetSystem::Cd16,
                    "CD-16 (Motorola 68000)",
                    0x00010000,    // 64KB base RAM
                    0x00010000,    // 64KB extended
                    0x00000000,   // Payload entry (68k reset vector)
                    0x00000000,   // Vector table (68k exception table)
                    2352,         // MODE2 sector
                    24,           // Data offset
                    "SEGA",       // CD-16 disc magic
                    0x00400000,   // RAM ceiling (4MB address space)
                    0, 0,
                };
            case TargetSystem::Handheld32:
                return {
                    TargetSystem::Handheld32,
                    "Handheld-32 (ARM7TDMI)",
                    0x00040000,    // 256KB base RAM
                    0x00040000,    // 256KB extended
                    0x08000000,   // Payload entry (ROM base, mirror)
                    0x00000000,   // Vector table (ARM exception vectors)
                    0,            // Cartridge — no sectors
                    0,            // No data offset
                    nullptr,      // No EXE magic (GBA header)
                    0x02000000,   // RAM ceiling (32MB address space)
                    0, 0,
                };
            case TargetSystem::PortableMedia32:
                return {
                    TargetSystem::PortableMedia32,
                    "Portable-Media-32 (MIPS R4000 Allegrex)",
                    0x02000000,    // 32MB base RAM
                    0x02000000,    // 32MB extended
                    0x08800000,   // Payload entry (user mode entry)
                    0xBFC00000,   // Vector table base (BIOS)
                    2048,         // MODE1 sector (UMD)
                    0,            // No data offset (MODE1)
                    "PSP_GAME",   // UMD magic (volume ID)
                    0x04000000,   // RAM ceiling (64MB address space)
                    0, 0,
                };
            case TargetSystem::Cart64:
                return {
                    TargetSystem::Cart64,
                    "Cart-64 (MIPS R4300)",
                    0x00400000,    // 4MB base RAM
                    0x00800000,    // 8MB extended
                    0x80000400,   // Payload entry (ROM header + IPL)
                    0xBFC00000,   // Vector table base (NMI/TLB miss)
                    0,            // Cartridge — no sectors
                    0,            // No data offset
                    nullptr,      // No EXE magic (N64 header)
                    0x01000000,   // RAM ceiling (16MB address space)
                    0, 0,
                };
        }
        return {};
    }
}

// =============================================================================
// psx_core.cpp — Standalone PSX Emulator Implementation
//
// MIPS R3000A CPU core with memory, CD-ROM, GPU, SIO0, IRQ, VBlank.
// Designed for VHB Super BIOS boot testing.
// =============================================================================

#include "psx_core.h"
#include <cstdarg>
#include <algorithm>

// ============================================================================
// Constructor / Destructor
// ============================================================================

PSXEmulator::PSXEmulator() {
    reset();
}

PSXEmulator::~PSXEmulator() {
    if (disc_file.is_open())
        disc_file.close();
}

// ============================================================================
// Reset
// ============================================================================

void PSXEmulator::reset() {
    memset(regs, 0, sizeof(regs));
    ram.assign(RAM_SIZE, 0);
    bios.assign(BIOS_SIZE, 0);
    hw_regs.assign(HW_REG_SIZE / 4, 0);
    hi = lo = 0;
    pc = 0xBFC00000;
    next_pc = 0xBFC00004;
    in_branch_delay = false;
    branch_target = 0;
    cp0_status = 0x00400000;  // BEV=1
    cp0_cause = 0;
    cp0_epc = 0;
    cp0_count = 0;
    cp0_compare = 0;
    irq_stat = 0;
    irq_mask = 0;
    vblank_timer = 0;

    // CD-ROM initial state
    cdrom = CDROMState{};

    // SIO0 — simulate connected digital controller
    sio0 = SIO0State{};

    // GPU
    gpu = GPUState{};

    telemetry = Telemetry{};
}

// ============================================================================
// Load BIOS / Disc
// ============================================================================

bool PSXEmulator::load_bios(const std::string& path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) return false;
    size_t sz = (size_t)f.tellg();
    if (sz != BIOS_SIZE) {
        printf("[PSX] WARNING: BIOS size %zu != %u\n", sz, BIOS_SIZE);
    }
    f.seekg(0);
    f.read((char*)bios.data(), std::min(sz, (size_t)BIOS_SIZE));
    printf("[PSX] BIOS loaded: %s (%zu bytes)\n", path.c_str(), sz);
    return true;
}

bool PSXEmulator::load_disc(const std::string& path) {
    disc_file.open(path, std::ios::binary | std::ios::ate);
    if (!disc_file) return false;
    size_t sz = (size_t)disc_file.tellg();
    disc_file.seekg(0);
    disc_sectors = (uint32_t)(sz / RAW_SECTOR_SIZE);
    if (disc_sectors == 0) {
        // Try 2048-byte sectors
        disc_sectors = (uint32_t)(sz / SECTOR_DATA_SIZE);
    }
    disc_loaded = true;
    printf("[PSX] Disc loaded: %s (%zu bytes, %u sectors)\n", path.c_str(), sz, disc_sectors);
    return true;
}

// ============================================================================
// Memory Access
// ============================================================================

uint8_t PSXEmulator::read8(uint32_t addr) {
    uint32_t paddr = phys_addr(addr);

    if (is_ram(paddr))
        return ram.data()[paddr];
    if (is_bios(paddr))
        return bios.data()[paddr - 0x1FC00000];
    if (is_cdrom(paddr))
        return hw_read8(paddr);
    if (is_sio0(paddr))
        return hw_read8(paddr);
    if (is_hw_reg(paddr))
        return hw_read8(paddr);

    // Unmapped — return 0
    return 0;
}

uint16_t PSXEmulator::read16(uint32_t addr) {
    uint32_t paddr = phys_addr(addr);
    if (is_ram(paddr))
        return ram.data()[paddr] | (ram.data()[paddr + 1] << 8);
    return read8(addr) | (read8(addr + 1) << 8);
}

uint32_t PSXEmulator::read32(uint32_t addr) {
    uint32_t paddr = phys_addr(addr);

    if (is_ram(paddr))
        return ram.data()[paddr] | (ram.data()[paddr+1] << 8) | (ram.data()[paddr+2] << 16) | (ram.data()[paddr+3] << 24);
    if (is_bios(paddr))
        return bios.data()[paddr - 0x1FC00000] | (bios.data()[paddr - 0x1FC00000 + 1] << 8) |
               (bios.data()[paddr - 0x1FC00000 + 2] << 16) | (bios.data()[paddr - 0x1FC00000 + 3] << 24);
    if (is_hw_reg(paddr))
        return hw_read32(paddr);

    return read8(addr) | (read8(addr+1) << 8) | (read8(addr+2) << 16) | (read8(addr+3) << 24);
}

void PSXEmulator::write8(uint32_t addr, uint8_t val) {
    uint32_t paddr = phys_addr(addr);
    if (is_ram(paddr)) {
        ram.data()[paddr] = val;
        return;
    }
    if (is_cdrom(paddr) || is_sio0(paddr) || is_hw_reg(paddr)) {
        hw_write8(paddr, val);
        return;
    }
    // Ignore writes to ROM / unmapped
}

void PSXEmulator::write16(uint32_t addr, uint16_t val) {
    write8(addr, val & 0xFF);
    write8(addr + 1, (val >> 8) & 0xFF);
}

void PSXEmulator::write32(uint32_t addr, uint32_t val) {
    uint32_t paddr = phys_addr(addr);
    if (is_ram(paddr)) {
        ram.data()[paddr] = val & 0xFF;
        ram.data()[paddr+1] = (val >> 8) & 0xFF;
        ram.data()[paddr+2] = (val >> 16) & 0xFF;
        ram.data()[paddr+3] = (val >> 24) & 0xFF;
        return;
    }
    if (is_hw_reg(paddr)) {
        hw_write32(paddr, val);
        return;
    }
    write8(addr, val & 0xFF);
    write8(addr+1, (val >> 8) & 0xFF);
    write8(addr+2, (val >> 16) & 0xFF);
    write8(addr+3, (val >> 24) & 0xFF);
}

// ============================================================================
// Hardware Register Access
// ============================================================================

uint32_t PSXEmulator::hw_read32(uint32_t addr) {
    if (addr == IRQ_STAT) return irq_stat;
    if (addr == IRQ_MASK) return irq_mask;
    if (addr == RAM_SIZE_REG) return 0x00000F88;  // 8MB
    if (addr == GPU_REG_BASE) return gpu.status;     // GP0 read
    if (addr == GPU_REG_BASE + 4) return gpu.status; // GP1 read

    // SIO0 32-bit read
    if (addr >= SIO0_REG_BASE && addr < SIO0_REG_BASE + 0x10) {
        uint32_t offset = addr - SIO0_REG_BASE;
        if (offset == 0x00) return sio0.data;
        if (offset == 0x04) return sio0.status;
        if (offset == 0x08) return sio0.control;
        if (offset == 0x0C) return sio0.baud;
    }

    // DMA registers — return 0 for now
    if (addr >= DMA_BASE && addr < DMA_BASE + 0x80)
        return 0;

    // Timers
    if (addr >= TIMER_BASE && addr < TIMER_BASE + 0x30)
        return 0;

    // Memory control registers
    return hw_regs.data()[(addr - HW_REG_BASE) / 4];
}

uint8_t PSXEmulator::hw_read8(uint32_t addr) {
    // CD-ROM registers (0x1F801800-0x1F801803)
    if (is_cdrom(addr)) {
        uint32_t offset = addr - CDROM_REG_BASE;
        switch (offset) {
        case 0x00: return cdrom_read_status();
        case 0x01: return cdrom_read_response();
        case 0x02: return cdrom_read_data();
        case 0x03: return cdrom.int_flag;
        }
    }

    // SIO0 registers (0x1F801040-0x1F801043)
    if (is_sio0(addr)) {
        uint32_t offset = addr - SIO0_REG_BASE;
        telemetry.sio0_reads++;
        switch (offset) {
        case 0x00: {
            // Return next RX byte
            if (sio0.rx_pos < sio0.rx_count) {
                uint8_t val = sio0.rx_buf[sio0.rx_pos++];
                if (sio0.rx_pos >= sio0.rx_count) {
                    sio0.status &= ~0x02;  // Clear RX ready
                }
                return val;
            }
            return 0xFF;
        }
        case 0x01: return sio0.status;
        case 0x02: return sio0.status;
        case 0x03: return sio0.control;
        }
    }

    // GPU registers
    if (is_gpu(addr)) {
        uint32_t offset = addr - GPU_REG_BASE;
        if (offset == 0x00 || offset == 0x04)
            return (uint8_t)(gpu.status >> 24);  // Return high byte
    }

    // IRQ status (byte access)
    if (addr == IRQ_STAT) return (uint8_t)irq_stat;
    if (addr == IRQ_STAT + 1) return (uint8_t)(irq_stat >> 8);
    if (addr == IRQ_STAT + 2) return (uint8_t)(irq_stat >> 16);
    if (addr == IRQ_STAT + 3) return (uint8_t)(irq_stat >> 24);

    return (uint8_t)hw_read32(addr & ~3);
}

void PSXEmulator::hw_write32(uint32_t addr, uint32_t val) {
    if (addr == IRQ_STAT) { irq_stat &= val; return; }  // Write 1 to clear
    if (addr == IRQ_MASK) { irq_mask = val; return; }
    if (addr == RAM_SIZE_REG) { return; }  // Ignore RAM size writes
    if (addr == GPU_REG_BASE) { gpu.gp0 = val; telemetry.gpu_writes++; return; }
    if (addr == GPU_REG_BASE + 4) {
        gpu.gp1 = val;
        telemetry.gpu_writes++;
        if ((val >> 24) == 0x03) gpu.display_on = (val & 1);
        return;
    }

    // SIO0 32-bit write
    if (addr >= SIO0_REG_BASE && addr < SIO0_REG_BASE + 0x10) {
        uint32_t offset = addr - SIO0_REG_BASE;
        if (offset == 0x00) {
            sio0.data = val & 0xFF;
            // Controller poll: when data 0x01 is written, prepare response
            if (val == 0x01) {
                sio0.rx_pos = 0;
                sio0.rx_count = 6;
                sio0.status |= 0x02;  // RX ready
            }
            return;
        }
        if (offset == 0x04) { sio0.status = val & 0xFF; return; }
        if (offset == 0x08) { sio0.control = val & 0xFF; return; }
        if (offset == 0x0C) { sio0.baud = val & 0xFFFF; return; }
    }

    // DMA registers
    if (addr >= DMA_BASE && addr < DMA_BASE + 0x80) {
        hw_regs.data()[(addr - HW_REG_BASE) / 4] = val;
        return;
    }

    // Timers
    if (addr >= TIMER_BASE && addr < TIMER_BASE + 0x30) {
        hw_regs.data()[(addr - HW_REG_BASE) / 4] = val;
        return;
    }

    // Memory control
    hw_regs.data()[(addr - HW_REG_BASE) / 4] = val;
}

void PSXEmulator::hw_write8(uint32_t addr, uint8_t val) {
    // CD-ROM registers
    if (is_cdrom(addr)) {
        uint32_t offset = addr - CDROM_REG_BASE;
        switch (offset) {
        case 0x00:
            cdrom.index = val & 0x03;
            break;
        case 0x01:
            // Command write (index 0) or response read (index 1)
            if (cdrom.index == 0) {
                cdrom_send_command(val);
            }
            break;
        case 0x02:
            // Parameter write (index 0) or data read (index 1)
            if (cdrom.index == 0) {
                if (cdrom.param_count < 16)
                    cdrom.param_fifo[cdrom.param_count++] = val;
            }
            break;
        case 0x03:
            // Interrupt flag/enable
            if (cdrom.index == 1) {
                if (val & 0x07) {
                    cdrom_ack_interrupt();
                }
            }
            break;
        }
        return;
    }

    // SIO0 registers
    if (is_sio0(addr)) {
        uint32_t offset = addr - SIO0_REG_BASE;
        switch (offset) {
        case 0x00:
            sio0.data = val;
            if (val == 0x01) {
                sio0.rx_pos = 0;
                sio0.rx_count = 6;
                sio0.status |= 0x02;
            }
            break;
        case 0x01: sio0.status = val; break;
        case 0x02: sio0.status = val; break;
        case 0x03: sio0.control = val; break;
        }
        return;
    }

    // GPU registers
    if (is_gpu(addr)) {
        uint32_t offset = addr - GPU_REG_BASE;
        if (offset == 0x00) { telemetry.gpu_writes++; return; }
        if (offset == 0x04) {
            telemetry.gpu_writes++;
            if ((val >> 4) == 0x03) gpu.display_on = val & 1;
            return;
        }
    }

    // IRQ
    if (addr == IRQ_STAT) { irq_stat &= ~(uint32_t)val; return; }
    if (addr == IRQ_STAT + 1) { irq_stat &= ~((uint32_t)val << 8); return; }
    if (addr == IRQ_STAT + 2) { irq_stat &= ~((uint32_t)val << 16); return; }
    if (addr == IRQ_STAT + 3) { irq_stat &= ~((uint32_t)val << 24); return; }
    if (addr == IRQ_MASK) { irq_mask = (irq_mask & 0xFFFFFF00) | val; return; }
    if (addr == IRQ_MASK + 1) { irq_mask = (irq_mask & 0xFFFF00FF) | ((uint32_t)val << 8); return; }
    if (addr == IRQ_MASK + 2) { irq_mask = (irq_mask & 0xFF00FFFF) | ((uint32_t)val << 16); return; }
    if (addr == IRQ_MASK + 3) { irq_mask = (irq_mask & 0x00FFFFFF) | ((uint32_t)val << 24); return; }

    // Fall through to 32-bit
    hw_write32(addr & ~3, val);
}

// ============================================================================
// CD-ROM State Machine
// ============================================================================

void PSXEmulator::cdrom_send_command(uint8_t cmd) {
    cdrom.cmd_pending = cmd;
    cdrom.response_count = 0;
    cdrom.response_pos = 0;
    telemetry.cdrom_commands_sent++;

    if (verbose) printf("[CDROM] Command 0x%02X (params: %d)\n", cmd, cdrom.param_count);

    switch (cmd) {
    case CMD_GETSTAT:
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;  // INT3
        break;

    case CMD_SETLOC:
        // Params: minute(BCD), second(BCD), frame(BCD)
        if (cdrom.param_count >= 3) {
            uint8_t min_bcd = cdrom.param_fifo[0];
            uint8_t sec_bcd = cdrom.param_fifo[1];
            uint8_t frm_bcd = cdrom.param_fifo[2];
            // Convert BCD to binary
            cdrom.read_lba = ((min_bcd >> 4) * 10 + (min_bcd & 0xF)) * 60 * 75
                           + ((sec_bcd >> 4) * 10 + (sec_bcd & 0xF)) * 75
                           + ((frm_bcd >> 4) * 10 + (frm_bcd & 0xF)) - 150;
            if (verbose) printf("[CDROM] Setloc: LBA=%u\n", cdrom.read_lba);
        }
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;
        break;

    case CMD_READN:
        cdrom.reading = true;
        cdrom.data_ready = false;
        cdrom.data_pos = 0;
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;
        // Immediately prepare data for BIOS mode (synchronous)
        cdrom_read_sector_data();
        break;

    case CMD_PAUSE:
        cdrom.reading = false;
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;
        break;

    case CMD_SETMODE:
        if (cdrom.param_count >= 1) {
            cdrom.mode = cdrom.param_fifo[0];
            if (verbose) printf("[CDROM] Setmode: 0x%02X\n", cdrom.mode);
        }
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;
        break;

    case CMD_INIT:
        cdrom.status |= CD_STAT_MOTOR_ON;
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;
        break;

    case CMD_READTOC:
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;
        break;

    default:
        if (verbose) printf("[CDROM] Unknown command 0x%02X\n", cmd);
        cdrom_push_response(cdrom.status);
        cdrom.int_flag = 0x03;
        break;
    }

    // Clear param FIFO
    cdrom.param_count = 0;

    // Raise CD-ROM interrupt
    if (cdrom.int_flag) {
        raise_interrupt(IRQ_CDROM);
    }
}

void PSXEmulator::cdrom_push_response(uint8_t val) {
    if (cdrom.response_count < 16) {
        cdrom.response_fifo[cdrom.response_count++] = val;
    }
    cdrom.status |= CD_STAT_RESPONSE_READY;
}

uint8_t PSXEmulator::cdrom_read_status() {
    return (cdrom.index & 0x03) | (cdrom.status & 0xE0);
    // Status bits: bit 5 = response ready, bit 6 = data ready, bit 7 = busy
    // Bits 0-1 = index
}

uint8_t PSXEmulator::cdrom_read_response() {
    if (cdrom.response_pos < cdrom.response_count) {
        uint8_t val = cdrom.response_fifo[cdrom.response_pos++];
        if (cdrom.response_pos >= cdrom.response_count) {
            cdrom.status &= ~CD_STAT_RESPONSE_READY;
            cdrom.response_count = 0;
            cdrom.response_pos = 0;
        }
        return val;
    }
    return 0xFF;
}

uint8_t PSXEmulator::cdrom_read_data() {
    if (cdrom.data_ready && cdrom.data_pos < SECTOR_DATA_SIZE) {
        uint8_t val = cdrom.data_fifo[cdrom.data_pos++];
        if (cdrom.data_pos >= SECTOR_DATA_SIZE) {
            cdrom.data_ready = false;
            cdrom.status &= ~CD_STAT_DATA_READY;
            telemetry.cdrom_sectors_read++;
        }
        return val;
    }
    return 0xFF;
}

void PSXEmulator::cdrom_ack_interrupt() {
    cdrom.int_flag = 0;
    // Clear CD-ROM IRQ
    irq_stat &= ~IRQ_CDROM;
}

bool PSXEmulator::cdrom_read_sector_data() {
    if (!disc_loaded || cdrom.read_lba >= disc_sectors) {
        if (verbose) printf("[CDROM] Read failed: LBA=%u, sectors=%u\n", cdrom.read_lba, disc_sectors);
        return false;
    }

    // Read sector from disc
    uint32_t offset = cdrom.read_lba * RAW_SECTOR_SIZE;
    if (offset >= disc_file.tellg() || !disc_file.good()) {
        disc_file.clear();
    }
    disc_file.seekg(offset, std::ios::beg);

    // Try raw sector first (2352 bytes), skip 24-byte header + 4-byte subheader
    uint8_t raw_buf[RAW_SECTOR_SIZE];
    disc_file.read((char*)raw_buf, RAW_SECTOR_SIZE);
    if (disc_file.gcount() >= RAW_SECTOR_SIZE) {
        // Mode 2 Form 1: data at offset 24
        memcpy(cdrom.data_fifo, raw_buf + 24, SECTOR_DATA_SIZE);
    } else {
        // Try 2048-byte cooked sectors
        disc_file.clear();
        disc_file.seekg(cdrom.read_lba * SECTOR_DATA_SIZE, std::ios::beg);
        disc_file.read((char*)cdrom.data_fifo, SECTOR_DATA_SIZE);
        if (disc_file.gcount() < (std::streamsize)SECTOR_DATA_SIZE) {
            memset(cdrom.data_fifo, 0, SECTOR_DATA_SIZE);
        }
    }

    cdrom.data_ready = true;
    cdrom.data_pos = 0;
    cdrom.status |= CD_STAT_DATA_READY;

    if (verbose) printf("[CDROM] Sector read: LBA=%u, first bytes: %02X %02X %02X %02X\n",
        cdrom.read_lba, cdrom.data_fifo[0], cdrom.data_fifo[1],
        cdrom.data_fifo[2], cdrom.data_fifo[3]);

    return true;
}

// ============================================================================
// Interrupts
// ============================================================================

void PSXEmulator::raise_interrupt(uint32_t irq_bit) {
    irq_stat |= irq_bit;
    check_interrupts();
}

void PSXEmulator::check_interrupts() {
    // If any unmasked interrupt is pending and IE is set
    if ((cp0_status & 0x01) && (irq_stat & irq_mask)) {
        // Trigger exception
        trigger_exception(0, pc);
    }
}

void PSXEmulator::trigger_exception(uint32_t cause_code, uint32_t epc) {
    // General exception vector at 0x80000080 (when BEV=0)
    // Or 0xBFC00180 (when BEV=1)
    uint32_t vector = (cp0_status & 0x00400000) ? 0xBFC00180 : 0x80000080;

    cp0_epc = epc;
    cp0_cause = (cause_code << 2);

    // Save previous interrupt state, disable interrupts, keep BEV
    uint32_t old_status = cp0_status;
    cp0_status = (cp0_status & ~0x0F) | ((old_status << 2) & 0x0F);  // Shift KU/IE bits

    // If in branch delay, set EPC to previous instruction and set BD bit
    if (in_branch_delay) {
        cp0_epc = pc - 4;
        cp0_cause |= 0x80000000;  // BD bit
    }

    pc = vector;
    next_pc = vector + 4;
    in_branch_delay = false;
}

void PSXEmulator::update_vblank() {
    vblank_timer++;
    if (vblank_timer >= VBLANK_INTERVAL) {
        vblank_timer = 0;
        telemetry.vblank_count++;
        raise_interrupt(IRQ_VBLANK);

        // Check if 0x80000080 has a handler (non-zero)
        uint32_t handler = read32(0x80000080);
        if (handler != 0 && (cp0_status & 0x01) && (irq_stat & irq_mask & IRQ_VBLANK)) {
            // VBlank handler is installed — exception will be triggered
        }
    }

    // CP0 Count register
    cp0_count = (uint32_t)(telemetry.instruction_count >> 1);
}

// ============================================================================
// Instruction Execution
// ============================================================================

void PSXEmulator::execute_special(uint32_t word) {
    uint32_t rs = (word >> 21) & 0x1F;
    uint32_t rt = (word >> 16) & 0x1F;
    uint32_t rd = (word >> 11) & 0x1F;
    uint32_t sa = (word >> 6) & 0x1F;
    uint32_t fn = word & 0x3F;

    switch (fn) {
    case 0x00:  // SLL
        regs[rd] = regs[rt] << sa;
        break;
    case 0x02:  // SRL
        regs[rd] = regs[rt] >> sa;
        break;
    case 0x03:  // SRA
        regs[rd] = (int32_t)regs[rt] >> sa;
        break;
    case 0x04:  // SLLV
        regs[rd] = regs[rt] << (regs[rs] & 0x1F);
        break;
    case 0x06:  // SRLV
        regs[rd] = regs[rt] >> (regs[rs] & 0x1F);
        break;
    case 0x07:  // SRAV
        regs[rd] = (int32_t)regs[rt] >> (regs[rs] & 0x1F);
        break;
    case 0x08:  // JR
        branch_target = regs[rs];
        in_branch_delay = true;
        break;
    case 0x09:  // JALR
        regs[rd] = pc + 4;  // cur_pc + 8
        branch_target = regs[rs];
        in_branch_delay = true;
        break;
    case 0x0C:  // SYSCALL
        trigger_exception(8, pc - 4);  // EPC = cur_pc (pc is cur_pc + 4)
        return;
    case 0x0D:  // BREAK
        trigger_exception(9, pc - 4);  // EPC = cur_pc
        return;
    case 0x10:  // MFHI
        regs[rd] = hi;
        break;
    case 0x11:  // MTHI
        hi = regs[rs];
        break;
    case 0x12:  // MFLO
        regs[rd] = lo;
        break;
    case 0x13:  // MTLO
        lo = regs[rs];
        break;
    case 0x18: {  // MULT
        int64_t result = (int64_t)(int32_t)regs[rs] * (int64_t)(int32_t)regs[rt];
        lo = (uint32_t)result;
        hi = (uint32_t)(result >> 32);
        break;
    }
    case 0x19: {  // MULTU
        uint64_t result = (uint64_t)regs[rs] * (uint64_t)regs[rt];
        lo = (uint32_t)result;
        hi = (uint32_t)(result >> 32);
        break;
    }
    case 0x1A: {  // DIV
        if (regs[rt] != 0) {
            lo = (uint32_t)((int32_t)regs[rs] / (int32_t)regs[rt]);
            hi = (uint32_t)((int32_t)regs[rs] % (int32_t)regs[rt]);
        }
        break;
    }
    case 0x1B: {  // DIVU
        if (regs[rt] != 0) {
            lo = regs[rs] / regs[rt];
            hi = regs[rs] % regs[rt];
        }
        break;
    }
    case 0x20:  // ADD (treat as ADDU, no overflow trap)
        regs[rd] = regs[rs] + regs[rt];
        break;
    case 0x21:  // ADDU
        regs[rd] = regs[rs] + regs[rt];
        break;
    case 0x22:  // SUB
        regs[rd] = regs[rs] - regs[rt];
        break;
    case 0x23:  // SUBU
        regs[rd] = regs[rs] - regs[rt];
        break;
    case 0x24:  // AND
        regs[rd] = regs[rs] & regs[rt];
        break;
    case 0x25:  // OR
        regs[rd] = regs[rs] | regs[rt];
        break;
    case 0x26:  // XOR
        regs[rd] = regs[rs] ^ regs[rt];
        break;
    case 0x27:  // NOR
        regs[rd] = ~(regs[rs] | regs[rt]);
        break;
    case 0x2A:  // SLT
        regs[rd] = ((int32_t)regs[rs] < (int32_t)regs[rt]) ? 1 : 0;
        break;
    case 0x2B:  // SLTU
        regs[rd] = (regs[rs] < regs[rt]) ? 1 : 0;
        break;
    default:
        if (verbose) printf("[CPU] Unknown SPECIAL fn=0x%02X at PC=0x%08X\n", fn, pc);
        break;
    }
    regs[0] = 0;  // $zero always 0
}

void PSXEmulator::execute_regimm(uint32_t word) {
    uint32_t rs = (word >> 21) & 0x1F;
    uint32_t rt_code = (word >> 16) & 0x1F;
    int16_t imm = (int16_t)(word & 0xFFFF);
    uint32_t target = pc + (imm << 2);  // pc is already cur_pc + 4

    switch (rt_code) {
    case 0x00:  // BLTZ
        if ((int32_t)regs[rs] < 0) { branch_target = target; in_branch_delay = true; }
        break;
    case 0x01:  // BGEZ
        if ((int32_t)regs[rs] >= 0) { branch_target = target; in_branch_delay = true; }
        break;
    case 0x10:  // BLTZAL
        regs[31] = pc + 4;  // cur_pc + 8
        if ((int32_t)regs[rs] < 0) { branch_target = target; in_branch_delay = true; }
        break;
    case 0x11:  // BGEZAL
        regs[31] = pc + 4;  // cur_pc + 8
        if ((int32_t)regs[rs] >= 0) { branch_target = target; in_branch_delay = true; }
        break;
    default:
        if (verbose) printf("[CPU] Unknown REGIMM rt=0x%02X at PC=0x%08X\n", rt_code, pc);
        break;
    }
    regs[0] = 0;
}

void PSXEmulator::execute_cop0(uint32_t word) {
    uint32_t rs_code = (word >> 21) & 0x1F;
    uint32_t rt = (word >> 16) & 0x1F;
    uint32_t rd = (word >> 11) & 0x1F;

    switch (rs_code) {
    case 0x00:  // MFC0
        switch (rd) {
        case 12: regs[rt] = cp0_status; break;
        case 13: regs[rt] = cp0_cause; break;
        case 14: regs[rt] = cp0_epc; break;
        case 9:  regs[rt] = cp0_count; break;
        case 11: regs[rt] = cp0_compare; break;
        default: regs[rt] = 0; break;
        }
        break;
    case 0x04:  // MTC0
        switch (rd) {
        case 12: cp0_status = regs[rt]; break;
        case 13: cp0_cause = regs[rt]; break;
        case 9:  cp0_count = regs[rt]; break;
        case 11: cp0_compare = regs[rt]; break;
        default: break;
        }
        break;
    case 0x10: {  // RFE (bits 25-21 = 0x10)
        // Restore interrupt state from previous bits
        cp0_status = (cp0_status & ~0x0F) | ((cp0_status >> 2) & 0x0F);
        break;
    }
    case 0x18: {  // ERET (bits 25-21 = 0x18)
        pc = cp0_epc;
        next_pc = cp0_epc + 4;
        in_branch_delay = false;
        cp0_status &= ~0x02;  // Clear ERL
        return;
    }
    default:
        if (verbose) printf("[CPU] Unknown COP0 rs=0x%02X at PC=0x%08X\n", rs_code, pc);
        break;
    }
    regs[0] = 0;
}

void PSXEmulator::execute_instruction(uint32_t word) {
    uint32_t op = (word >> 26) & 0x3F;
    uint32_t rs = (word >> 21) & 0x1F;
    uint32_t rt = (word >> 16) & 0x1F;
    uint16_t imm = word & 0xFFFF;
    int16_t simm = (int16_t)imm;
    uint32_t target26 = word & 0x03FFFFFF;

    switch (op) {
    case 0x00:  // SPECIAL
        execute_special(word);
        break;
    case 0x01:  // REGIMM
        execute_regimm(word);
        break;
    case 0x02:  // J
        branch_target = (pc & 0xF0000000) | (target26 << 2);
        in_branch_delay = true;
        break;
    case 0x03:  // JAL
        regs[31] = pc + 4;  // cur_pc + 8 (pc is already cur_pc + 4)
        branch_target = (pc & 0xF0000000) | (target26 << 2);
        in_branch_delay = true;
        break;
    case 0x04:  // BEQ
        if (regs[rs] == regs[rt]) { branch_target = pc + (simm << 2); in_branch_delay = true; }
        break;
    case 0x05:  // BNE
        if (regs[rs] != regs[rt]) { branch_target = pc + (simm << 2); in_branch_delay = true; }
        break;
    case 0x06:  // BLEZ
        if ((int32_t)regs[rs] <= 0) { branch_target = pc + (simm << 2); in_branch_delay = true; }
        break;
    case 0x07:  // BGTZ
        if ((int32_t)regs[rs] > 0) { branch_target = pc + (simm << 2); in_branch_delay = true; }
        break;
    case 0x08:  // ADDI (treat as ADDIU)
        regs[rt] = regs[rs] + simm;
        break;
    case 0x09:  // ADDIU
        regs[rt] = regs[rs] + simm;
        break;
    case 0x0A:  // SLTI
        regs[rt] = ((int32_t)regs[rs] < simm) ? 1 : 0;
        break;
    case 0x0B:  // SLTIU
        regs[rt] = (regs[rs] < (uint32_t)simm) ? 1 : 0;
        break;
    case 0x0C:  // ANDI
        regs[rt] = regs[rs] & imm;
        break;
    case 0x0D:  // ORI
        regs[rt] = regs[rs] | imm;
        break;
    case 0x0E:  // XORI
        regs[rt] = regs[rs] ^ imm;
        break;
    case 0x0F:  // LUI
        regs[rt] = (uint32_t)imm << 16;
        break;
    case 0x10:  // COP0
        execute_cop0(word);
        break;
    case 0x20:  // LB
        regs[rt] = (int32_t)(int8_t)read8(regs[rs] + simm);
        break;
    case 0x21:  // LH
        regs[rt] = (int32_t)(int16_t)read16(regs[rs] + simm);
        break;
    case 0x23:  // LW
        regs[rt] = read32(regs[rs] + simm);
        break;
    case 0x24:  // LBU
        regs[rt] = read8(regs[rs] + simm);
        break;
    case 0x25:  // LHU
        regs[rt] = read16(regs[rs] + simm);
        break;
    case 0x28:  // SB
        write8(regs[rs] + simm, (uint8_t)regs[rt]);
        break;
    case 0x29:  // SH
        write16(regs[rs] + simm, (uint16_t)regs[rt]);
        break;
    case 0x2B:  // SW
        write32(regs[rs] + simm, regs[rt]);
        break;
    default:
        if (verbose) printf("[CPU] Unknown opcode 0x%02X at PC=0x%08X (word=0x%08X)\n", op, pc, word);
        break;
    }
    regs[0] = 0;  // $zero always 0
}

// ============================================================================
// Step / Run
// ============================================================================

int PSXEmulator::step() {
    uint32_t cur_pc = pc;

    // Fetch instruction
    uint32_t paddr = phys_addr(cur_pc);
    uint32_t word;

    if (is_ram(paddr)) {
        word = ram.data()[paddr] | (ram.data()[paddr+1] << 8) | (ram.data()[paddr+2] << 16) | (ram.data()[paddr+3] << 24);
    } else if (is_bios(paddr)) {
        word = bios.data()[paddr - 0x1FC00000] | (bios.data()[paddr - 0x1FC00000 + 1] << 8) |
               (bios.data()[paddr - 0x1FC00000 + 2] << 16) | (bios.data()[paddr - 0x1FC00000 + 3] << 24);
    } else {
        // Instruction fetch from unmapped memory
        telemetry.crashed = true;
        telemetry.crash_reason = "Instruction fetch from unmapped address 0x" +
            std::to_string(cur_pc);
        if (verbose) printf("[CPU] FATAL: Instruction fetch from unmapped 0x%08X\n", cur_pc);
        return -1;
    }

    // Update PC — branch delay slot handling
    // After executing the delay slot instruction, jump to branch target
    if (in_branch_delay) {
        pc = branch_target;
        next_pc = branch_target + 4;
        in_branch_delay = false;
    } else {
        pc = next_pc;
        next_pc = pc + 4;
    }

    // Execute
    execute_instruction(word);

    // Telemetry
    telemetry.instruction_count++;
    telemetry.last_pc = telemetry.pc;
    telemetry.pc = cur_pc;

    // Track PC range in RAM
    if (cur_pc >= 0x80000000 && cur_pc < 0x80800000) {
        if (cur_pc > telemetry.max_pc) telemetry.max_pc = cur_pc;
        if (cur_pc < telemetry.min_pc) telemetry.min_pc = cur_pc;
    }

    // Detect BIOS progress
    if (!telemetry.bios_past_cdrom_init && cur_pc > 0xBFC00378) {
        telemetry.bios_past_cdrom_init = true;
        if (verbose) printf("[BIOS] Passed 0xBFC00378 at instr #%llu\n", telemetry.instruction_count);
    }
    if (!telemetry.reached_exe && cur_pc >= 0x80010000 && cur_pc < 0x80200000) {
        telemetry.reached_exe = true;
        telemetry.entry_pc = cur_pc;
        if (verbose) printf("[BIOS] Reached EXE at PC=0x%08X at instr #%llu\n", cur_pc, telemetry.instruction_count);
    }

    // PC trace (keep last 64 entries)
    telemetry.pc_trace.push_back(cur_pc);
    if (telemetry.pc_trace.size() > 64) telemetry.pc_trace.pop_front();

    // Watch PC
    if (watch_pc_enabled && cur_pc == watch_pc) {
        if (verbose) printf("[WATCH] PC hit 0x%08X at instr #%llu\n", cur_pc, telemetry.instruction_count);
    }

    // VBlank timer
    update_vblank();

    // Check for crash conditions
    if (cur_pc == 0x00000000 || cur_pc == 0x80000000) {
        // Null pointer — likely a crash
        if (telemetry.instruction_count > 1000) {
            telemetry.crashed = true;
            telemetry.crash_reason = "Null pointer execution at 0x" + std::to_string(cur_pc);
            return -1;
        }
    }

    // Infinite loop detection (same PC for too long)
    if (telemetry.pc_trace.size() >= 4) {
        size_t n = telemetry.pc_trace.size();
        if (telemetry.pc_trace[n-1] == telemetry.pc_trace[n-3] &&
            telemetry.pc_trace[n-2] == telemetry.pc_trace[n-4] &&
            telemetry.pc_trace[n-1] == telemetry.pc_trace[n-2]) {
            // Tight 2-instruction loop — check if it's a wait loop
            // Only flag if stuck for many iterations
        }
    }

    return 0;
}

void PSXEmulator::run(uint64_t max_instructions) {
    printf("[PSX] Starting execution (max %llu instructions)\n", max_instructions);

    for (uint64_t i = 0; i < max_instructions; i++) {
        if (step() != 0) break;

        // Periodic progress
        if ((i + 1) % 10000000 == 0) {
            printf("[PSX] Progress: %lluM instructions, PC=0x%08X, VBlank=%llu, CD sectors=%u\n",
                (i + 1) / 1000000, pc, telemetry.vblank_count, telemetry.cdrom_sectors_read);
        }
    }

    printf("[PSX] Execution complete: %llu instructions, PC=0x%08X\n",
        telemetry.instruction_count, pc);
    printf("[PSX] VBlanks: %llu, CD sectors read: %u, GPU writes: %u, SIO0 reads: %u\n",
        telemetry.vblank_count, telemetry.cdrom_sectors_read, telemetry.gpu_writes, telemetry.sio0_reads);
    printf("[PSX] PC range: 0x%08X - 0x%08X\n", telemetry.min_pc, telemetry.max_pc);
    printf("[PSX] Past CDROM_Init: %s, Reached EXE: %s, Crashed: %s\n",
        telemetry.bios_past_cdrom_init ? "YES" : "NO",
        telemetry.reached_exe ? "YES" : "NO",
        telemetry.crashed ? "YES" : "NO");
    if (telemetry.crashed) {
        printf("[PSX] Crash: %s\n", telemetry.crash_reason.c_str());
    }
}

// ============================================================================
// Telemetry Save
// ============================================================================

void PSXEmulator::save_telemetry(const std::string& path) {
    FILE* f = fopen(path.c_str(), "w");
    if (!f) return;

    fprintf(f, "{\n");
    fprintf(f, "  \"instruction_count\": %llu,\n", telemetry.instruction_count);
    fprintf(f, "  \"vblank_count\": %llu,\n", telemetry.vblank_count);
    fprintf(f, "  \"pc\": \"0x%08X\",\n", telemetry.pc);
    fprintf(f, "  \"last_pc\": \"0x%08X\",\n", telemetry.last_pc);
    fprintf(f, "  \"entry_pc\": \"0x%08X\",\n", telemetry.entry_pc);
    fprintf(f, "  \"crashed\": %s,\n", telemetry.crashed ? "true" : "false");
    fprintf(f, "  \"reached_exe\": %s,\n", telemetry.reached_exe ? "true" : "false");
    fprintf(f, "  \"cdrom_sectors_read\": %u,\n", telemetry.cdrom_sectors_read);
    fprintf(f, "  \"cdrom_commands_sent\": %u,\n", telemetry.cdrom_commands_sent);
    fprintf(f, "  \"gpu_writes\": %u,\n", telemetry.gpu_writes);
    fprintf(f, "  \"sio0_reads\": %u,\n", telemetry.sio0_reads);
    fprintf(f, "  \"max_pc\": \"0x%08X\",\n", telemetry.max_pc);
    fprintf(f, "  \"min_pc\": \"0x%08X\",\n", telemetry.min_pc);
    fprintf(f, "  \"bios_past_cdrom_init\": %s,\n", telemetry.bios_past_cdrom_init ? "true" : "false");
    fprintf(f, "  \"bios_past_exe_load\": %s,\n", telemetry.bios_past_exe_load ? "true" : "false");
    fprintf(f, "  \"bios_past_syscall_install\": %s,\n", telemetry.bios_past_syscall_install ? "true" : "false");
    fprintf(f, "  \"crash_reason\": \"%s\",\n", telemetry.crash_reason.c_str());
    fprintf(f, "  \"pc_trace\": [\n");
    for (size_t i = 0; i < telemetry.pc_trace.size(); i++) {
        fprintf(f, "    \"0x%08X\"%s\n", telemetry.pc_trace[i],
            (i < telemetry.pc_trace.size() - 1) ? "," : "");
    }
    fprintf(f, "  ]\n");
    fprintf(f, "}\n");
    fclose(f);
    printf("[PSX] Telemetry saved to %s\n", path.c_str());
}

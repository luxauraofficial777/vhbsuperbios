# VHB Super BIOS v0.2 — Clean-Room PSX BIOS
# Built with cybergrime/mips/assembler.py (zero external dependencies)
#
# Memory Map:
#   0xBFC00000 - BIOS ROM base (512KB)
#   0x1F801000 - Hardware registers
#   0x1F801020 - GPU registers
#   0x1F801060 - RAM size register
#   0x1F801080 - DMA channel 0 (MDEC)
#   0x1F8010A0 - DMA channel 2 (GPU)
#   0x1F8010B0 - DMA channel 3 (CD-ROM)
#   0x1F8010F0 - DMA interrupt status
#   0x80010000 - Scratchpad / boot buffer
#   0x80100000 - EXE load address
#
# CD-ROM Registers (offset from 0x1f801000):
#   0x00 - Status/Response (read)
#   0x01 - Command (write)
#   0x02 - Data (read)
#   0x03 - Interrupt flag/enable (write)

.set noreorder
.global _start
.org 0xbfc00000

# =============================================================================
# Boot Entry Point (0xBFC00000)
# =============================================================================
_start:
    # CP0 Status: kernel mode, BEV=1, disable interrupts
    li      $t0, 0x00400000
    mtc0    $t0, 12
    nop
    mtc0    $zero, 13
    nop

    # Memory controller init
    lui     $t1, 0x1f80
    li      $t3, 0x00070707
    sw      $t3, 0x1000($t1)
    nop

    # RAM size: 8MB default (patchable by build script)
    # RAM_SIZE_PATCH_MARKER
    li      $t3, 0x00000F88
    sw      $t3, 0x1060($t1)
    nop

    # Clear 8KB of RAM at 0x80000000 for boot workspace
    lui     $t0, 0x8000
    li      $t1, 0x00002000
clear_loop:
    sw      $zero, 0($t0)
    addiu   $t0, $t0, 4
    sltu    $t2, $t0, $t1
    bne     $t2, $zero, clear_loop
    nop

    # Set up stack pointer
    lui     $sp, 0x801F
    ori     $sp, $sp, 0xFF00

    # VHB: Preinit descriptors
    jal     Preinit_Descriptors
    nop

    # Init GPU (minimal — turn on display)
    jal     GPU_Init
    nop

    # Init CD-ROM
    jal     CDROM_Init
    nop

    # Read PVD at LBA 16 to find root directory
    # Buffer at 0x80010000
    li      $a0, 16
    lui     $a1, 0x8001
    jal     CDROM_ReadSector
    nop

    # Parse PVD: root dir record at offset 0x9C (156)
    # PVD type=1 at offset 0, root dir record at offset 156
    lui     $t0, 0x8001
    lbu     $t1, 0x9C($t0)       # Root dir record length
    nop
    # Root dir LBA is at offset 0x9C+2 = 0x9E (4 bytes LE)
    lw      $s0, 0xA0($t0)       # Root dir LBA (offset 2+0=0x9E, but LBA at +4)
    nop
    # Root dir size at offset 0xA8 (10 bytes, we use first 4)
    lw      $s1, 0xAA($t0)       # Root dir size
    nop

    # Read root directory sector
    move    $a0, $s0
    lui     $a1, 0x8001
    ori     $a1, $a1, 0x2000
    jal     CDROM_ReadSector
    nop

    # Search root dir for "SYSTEM.CNF;1"
    lui     $a0, 0x8001
    ori     $a0, $a0, 0x2000
    jal     Find_File
    nop
    beq     $v0, $zero, boot_fail
    nop

    # $v0 = LBA of SYSTEM.CNF, $v1 = size
    move    $s2, $v0
    move    $s3, $v1

    # Read SYSTEM.CNF to 0x80011000
    move    $a0, $s2
    lui     $a1, 0x8001
    ori     $a1, $a1, 0x1000
    jal     CDROM_ReadSector
    nop

    # Parse SYSTEM.CNF for "BOOT = " line
    lui     $a0, 0x8001
    ori     $a0, $a0, 0x1000
    jal     Parse_Boot_Line
    nop
    beq     $v0, $zero, boot_fail
    nop

    # $v0 = LBA of EXE, $v1 = size
    move    $s4, $v0
    move    $s5, $v1

    # Read EXE header (first sector) to get load address and entry point
    move    $a0, $s4
    lui     $a1, 0x8001
    ori     $a1, $a1, 0x3000
    jal     CDROM_ReadSector
    nop

    # PS-EXE header: load_addr at offset 0x10, entry at 0x10, t_size at 0x1C
    # Actually: PC0 at 0x10, text_start (load) at 0x18, t_size at 0x1C
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x3000
    lw      $s6, 0x18($t0)       # Load address (text_start)
    nop
    lw      $s7, 0x10($t0)       # Entry point (PC0)
    nop

    # Load EXE body: skip 0x800-byte header, read rest to load address
    # Calculate sectors to read
    addiu   $t1, $s5, -0x800     # Body size = file_size - header
    srl     $t2, $t1, 11         # Sectors = body_size / 2048
    andi    $t3, $t1, 0x7FF      # Remainder
    bne     $t3, $zero, has_remainder
    nop
    j       no_remainder
    nop
has_remainder:
    addiu   $t2, $t2, 1          # Round up
no_remainder:

    # Read EXE body sectors via DMA to load address
    addiu   $a0, $s4, 1          # Start at sector after header
    move    $a1, $s6             # Dest = load address
    move    $a2, $t2             # Count
    jal     CDROM_ReadSectors
    nop

    # Flush cache before jumping
    jal     Flush_Cache
    nop

    # Install syscall vectors at 0xA0, 0xB0, 0xC0
    jal     Install_Syscall_Vectors
    nop

    # Copy A0/B0/C0 function tables to RAM
    jal     Copy_Syscall_Tables
    nop

    # Initialize interrupt controller
    jal     Init_Interrupt_Controller
    nop

    # Initialize kernel heap
    jal     Init_Heap
    nop

    # Initialize event control blocks (16 events)
    li      $a0, 16
    jal     Init_Events
    nop

    # Initialize thread control blocks (4 threads)
    li      $a0, 4
    jal     Init_Threads
    nop

    # Set BEV=0 (normal exception vector mode) so EXE exceptions go to RAM
    li      $t0, 0x00000000
    mtc0    $t0, 12
    nop

    # Flush cache again after all setup
    jal     Flush_Cache
    nop

    # Jump to EXE entry point
    jr      $s7
    nop

boot_fail:
    # Boot failed — infinite loop
    j       boot_fail
    nop

# =============================================================================
# VHB: Descriptor Pre-Initialization
# =============================================================================
Preinit_Descriptors:
    lui     $t0, 0x8010             # Safe descriptor base = 0x80100000
    lui     $t1, 0x800F
    ori     $t1, $t1, 0x2228
    sw      $t0, 0($t1)            # *0x800F2228 = 0x80100000
    nop
    lui     $t1, 0x800D
    ori     $t1, $t1, 0x9A40
    sw      $t0, 0($t1)            # *0x800D9A40 = 0x80100000
    nop
    lui     $t1, 0x800F
    ori     $t1, $t1, 0x2238
    sw      $zero, 0($t1)          # *0x800F2238 = 0
    nop
    jr      $ra
    nop

# =============================================================================
# GPU Initialization (minimal)
# =============================================================================
GPU_Init:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000       # $t0 = 0x1f801000 (base for GPU regs)

    # Reset GPU command: write 0x00 to GP1 command register (0x1f801014)
    sw      $zero, 0x14($t0)       # GP1(00h) = reset
    nop

    # Set display mode: 256x240 NTSC
    li      $t1, 0x08000000        # GP1(08h) = display mode
    sw      $t1, 0x14($t0)
    nop

    # Set horizontal display range
    li      $t1, 0x0C020608        # GP1(06h) = horizontal range
    sw      $t1, 0x14($t0)
    nop

    # Set vertical display range
    li      $t1, 0x0C001810        # GP1(07h) = vertical range
    sw      $t1, 0x14($t0)
    nop

    # Enable display: GP1(03h) = display on
    li      $t1, 0x03000000
    sw      $t1, 0x14($t0)
    nop

    # Set drawing mode: GP0(0xE1h) = draw mode
    li      $t1, 0xE1000400
    sw      $t1, 0x10($t0)         # GP0 register at 0x1f801010
    nop

    # Set texture window: GP0(0xE2h)
    li      $t1, 0xE2000000
    sw      $t1, 0x10($t0)
    nop

    # Clear drawing area: GP0(0xE3h) = drawing area top-left
    li      $t1, 0xE3000000
    sw      $t1, 0x10($t0)
    nop

    # Drawing area bottom-right: GP0(0xE4h)
    li      $t1, 0xE403C0F0
    sw      $t1, 0x10($t0)
    nop

    # Drawing offset: GP0(0xE5h)
    li      $t1, 0xE5000000
    sw      $t1, 0x10($t0)
    nop

    jr      $ra
    nop

# =============================================================================
# CD-ROM Initialization
# =============================================================================
CDROM_Init:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000       # $t0 = 0x1f801000

    # Reset CD-ROM: write 0x01 to 0x1f801001 (command: reset)
    # Actually use the CD-ROM reset via port 0x1f801083 (CDROM reg 3)
    # Write 0x01 to reset controller
    li      $t1, 0x01
    sb      $t1, 0x03($t0)         # Write to CDROM reg 3 (reset)
    nop

    # Wait for CD-ROM to settle (busy wait ~1ms)
    li      $t2, 0x00001000
cd_init_wait:
    addiu   $t2, $t2, -1
    bne     $t2, $zero, cd_init_wait
    nop

    # Send CDROM command 0x00 (Sync) — just acknowledge
    # Write command to reg 1
    li      $t1, 0x00
    sb      $t1, 0x01($t0)         # Command: Sync
    nop

    # Wait for response
    jal     CDROM_Wait_Response
    nop

    # Send command 0x02 (Read TOC)
    li      $t1, 0x02
    sb      $t1, 0x01($t0)         # Command: ReadTOC
    nop

    # Wait for response (TOC read takes longer)
    li      $a0, 0x00100000        # Longer timeout for TOC
    jal     CDROM_Wait_Response_Long
    nop

    jr      $ra
    nop

# =============================================================================
# CD-ROM Wait for Response
# Polls status register until response is ready
# =============================================================================
CDROM_Wait_Response:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t2, 0x00010000        # Timeout
cd_wait_resp_loop:
    lbu     $t1, 0x00($t0)         # Read status register
    nop
    andi    $t3, $t1, 0x20         # Check bit 5 (response ready)
    bne     $t3, $zero, cd_wait_resp_done
    nop
    addiu   $t2, $t2, -1
    bne     $t2, $zero, cd_wait_resp_loop
    nop
cd_wait_resp_done:
    # Read response byte
    lbu     $v0, 0x00($t0)         # Read response
    nop
    # Acknowledge interrupt
    li      $t1, 0x07
    sb      $t1, 0x03($t0)         # Write 0x07 to reg 3 (ack all)
    nop
    jr      $ra
    nop

# =============================================================================
# CD-ROM Wait for Response (long timeout for TOC etc)
# $a0 = timeout value
# =============================================================================
CDROM_Wait_Response_Long:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    move    $t2, $a0
cd_wait_resp_long_loop:
    lbu     $t1, 0x00($t0)
    nop
    andi    $t3, $t1, 0x20
    bne     $t3, $zero, cd_wait_resp_long_done
    nop
    addiu   $t2, $t2, -1
    bne     $t2, $zero, cd_wait_resp_long_loop
    nop
cd_wait_resp_long_done:
    lbu     $v0, 0x00($t0)
    nop
    li      $t1, 0x07
    sb      $t1, 0x03($t0)
    nop
    jr      $ra
    nop

# =============================================================================
# CD-ROM Read Single Sector
# $a0 = LBA, $a1 = dest buffer (must be 0x80xxxxxx)
# Uses CD-ROM command 0x06 (ReadN) with parameters
# =============================================================================
CDROM_ReadSector:
    # Save args
    move    $s6, $a0               # LBA
    move    $s7, $a1               # Dest

    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000

    # Set CD-ROM mode: command 0x0E (Setmode) with param
    # Mode: 0x80 = double speed, 0x00 = raw data
    li      $t1, 0x0E
    sb      $t1, 0x01($t0)         # Command: Setmode
    nop
    # Wait for parameter ready
    jal     CDROM_Wait_Param
    nop
    li      $t1, 0x80              # Double speed, data mode
    sb      $t1, 0x02($t0)         # Write parameter
    nop
    jal     CDROM_Wait_Response
    nop

    # Convert LBA to minute:second:frame (MSF)
    # minute = (LBA+150) / 4500
    # second = remainder / 75
    # frame = remainder % 75
    addiu   $t1, $s6, 150          # t1 = LBA + 150
    li      $t9, 4500
    div     $t1, $t9               # LO = minute, HI = remainder
    nop
    mflo    $t2                    # t2 = minute
    mfhi    $t3                    # t3 = remainder
    li      $t9, 75
    div     $t3, $t9               # LO = second, HI = frame
    nop
    mflo    $t4                    # t4 = second
    mfhi    $t5                    # t5 = frame

    # Send ReadN command (0x06) with 3 params: minute, second, frame
    li      $t1, 0x06
    sb      $t1, 0x01($t0)         # Command: ReadN
    nop
    jal     CDROM_Wait_Param
    nop
    sb      $t2, 0x02($t0)         # Param: minute
    nop
    jal     CDROM_Wait_Param
    nop
    sb      $t4, 0x02($t0)         # Param: second
    nop
    jal     CDROM_Wait_Param
    nop
    sb      $t5, 0x02($t0)         # Param: frame
    nop

    # Wait for data ready (poll status bit 7 = data ready)
    li      $t6, 0x01000000        # Timeout for data ready
cd_read_data_wait:
    lbu     $t1, 0x00($t0)
    nop
    andi    $t3, $t1, 0x80         # Bit 7 = data ready
    bne     $t3, $zero, cd_read_data_ready
    nop
    andi    $t3, $t1, 0x20         # Bit 5 = response ready (error?)
    bne     $t3, $zero, cd_read_error
    nop
    addiu   $t6, $t6, -1
    bne     $t6, $zero, cd_read_data_wait
    nop
    j       cd_read_error          # Timeout
    nop

cd_read_data_ready:
    # Read 2048 bytes from CD-ROM data port (0x1f801002)
    # Use manual copy since CD-ROM data port is 8-bit
    move    $t7, $zero             # Counter
    move    $t8, $s7               # Dest pointer
cd_read_copy:
    lbu     $t9, 0x02($t0)         # Read data byte
    nop
    sb      $t9, 0($t8)            # Store to dest
    addiu   $t8, $t8, 1
    addiu   $t7, $t7, 1
    li      $t9, 2048
    sltu    $t9, $t7, $t9
    bne     $t9, $zero, cd_read_copy
    nop

    # Acknowledge interrupt
    li      $t1, 0x07
    sb      $t1, 0x03($t0)
    nop

    # Pause CD-ROM (command 0x09)
    li      $t1, 0x09
    sb      $t1, 0x01($t0)
    nop
    jal     CDROM_Wait_Response
    nop

    li      $v0, 1                 # Success
    jr      $ra
    nop

cd_read_error:
    li      $v0, 0                 # Failure
    jr      $ra
    nop

# =============================================================================
# CD-ROM Wait for Parameter Ready
# Polls status bit 3 (parameter FIFO ready)
# =============================================================================
CDROM_Wait_Param:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t2, 0x00001000
cd_wait_param_loop:
    lbu     $t1, 0x00($t0)
    nop
    andi    $t3, $t1, 0x08         # Bit 3 = parameter ready
    beq     $t3, $zero, cd_wait_param_done
    nop
    addiu   $t2, $t2, -1
    bne     $t2, $zero, cd_wait_param_loop
    nop
cd_wait_param_done:
    jr      $ra
    nop

# =============================================================================
# CD-ROM Read Multiple Sectors (DMA)
# $a0 = start LBA, $a1 = dest, $a2 = count
# =============================================================================
CDROM_ReadSectors:
    move    $s6, $a0               # Start LBA
    move    $s7, $a1               # Dest
    move    $s5, $a2               # Count

cd_read_multi_loop:
    beq     $s5, $zero, cd_read_multi_done
    nop

    move    $a0, $s6
    move    $a1, $s7
    jal     CDROM_ReadSector
    nop

    beq     $v0, $zero, cd_read_multi_fail
    nop

    addiu   $s6, $s6, 1            # Next sector
    addiu   $s7, $s7, 2048         # Next dest
    addiu   $s5, $s5, -1           # Decrement count
    j       cd_read_multi_loop
    nop

cd_read_multi_done:
    li      $v0, 1
    jr      $ra
    nop

cd_read_multi_fail:
    li      $v0, 0
    jr      $ra
    nop

# =============================================================================
# Find File in ISO 9660 Directory
# $a0 = directory buffer pointer
# Searches for "SYSTEM.CNF;1" (case-insensitive)
# Returns: $v0 = LBA (0 if not found), $v1 = file size
# =============================================================================
Find_File:
    move    $t0, $a0               # Dir buffer pointer
    li      $t3, 2048              # Max scan range

find_file_loop:
    lbu     $t1, 0($t0)            # Record length
    nop
    beq     $t1, $zero, find_file_next_sector
    nop

    # Get file name length at offset 32
    lbu     $t4, 32($t0)
    nop

    # Compare name: "SYSTEM.CNF;1" = 12 chars
    li      $t5, 12
    bne     $t4, $t5, find_file_next
    nop

    # Compare string at offset 33
    addiu   $t6, $t0, 33           # Name pointer
    lui     $t7, 0x8001
    ori     $t7, $t7, 0x4000       # We'll store compare string here
    # Actually, compare inline
    # "SYSTEM.CNF;1" in ASCII
    lbu     $t8, 0($t6)            # 'S'
    nop
    li      $t9, 0x53              # 'S'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 1($t6)            # 'Y'
    nop
    li      $t9, 0x59              # 'Y'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 2($t6)            # 'S'
    nop
    li      $t9, 0x53              # 'S'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 3($t6)            # 'T'
    nop
    li      $t9, 0x54              # 'T'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 4($t6)            # 'E'
    nop
    li      $t9, 0x45              # 'E'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 5($t6)            # 'M'
    nop
    li      $t9, 0x4D              # 'M'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 6($t6)            # '.'
    nop
    li      $t9, 0x2E              # '.'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 7($t6)            # 'C'
    nop
    li      $t9, 0x43              # 'C'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 8($t6)            # 'N'
    nop
    li      $t9, 0x4E              # 'N'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 9($t6)            # 'F'
    nop
    li      $t9, 0x46              # 'F'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 10($t6)           # ';'
    nop
    li      $t9, 0x3B              # ';'
    bne     $t8, $t9, find_file_next
    nop
    lbu     $t8, 11($t6)           # '1'
    nop
    li      $t9, 0x31              # '1'
    bne     $t8, $t9, find_file_next
    nop

    # Found! Extract LBA (offset 2, 4 bytes LE) and size (offset 10, 4 bytes LE)
    lw      $v0, 2($t0)            # LBA (offset 2 in dir record)
    nop
    lw      $v1, 10($t0)           # File size (offset 10 in dir record)
    nop
    jr      $ra
    nop

find_file_next:
    # Move to next record
    add     $t0, $t0, $t1          # Skip by record length
    j       find_file_loop
    nop

find_file_next_sector:
    # Not found in this sector
    li      $v0, 0
    li      $v1, 0
    jr      $ra
    nop

# =============================================================================
# Parse SYSTEM.CNF Boot Line
# $a0 = buffer pointer to SYSTEM.CNF content
# Looks for "BOOT" or "boot" followed by "=" and a filename
# Then looks up that filename in root directory
# Returns: $v0 = EXE LBA (0 if not found), $v1 = EXE size
# =============================================================================
Parse_Boot_Line:
    move    $t0, $a0               # Buffer pointer
    li      $t6, 2048              # Max scan

parse_boot_loop:
    # Look for 'B' or 'b' (start of "BOOT")
    lbu     $t1, 0($t0)
    nop
    li      $t2, 0x42              # 'B'
    beq     $t1, $t2, parse_boot_found_b
    nop
    li      $t2, 0x62              # 'b'
    beq     $t1, $t2, parse_boot_found_b
    nop
    addiu   $t0, $t0, 1
    addiu   $t6, $t6, -1
    bne     $t6, $zero, parse_boot_loop
    nop
    # Not found
    li      $v0, 0
    li      $v1, 0
    jr      $ra
    nop

parse_boot_found_b:
    # Check "BOOT" prefix (case-insensitive)
    lbu     $t1, 1($t0)
    nop
    li      $t2, 0x4F              # 'O'
    bne     $t1, $t2, parse_boot_no_o1
    nop
    j       parse_boot_check_o2
    nop
parse_boot_no_o1:
    li      $t2, 0x6F              # 'o'
    bne     $t1, $t2, parse_boot_next
    nop
parse_boot_check_o2:
    lbu     $t1, 2($t0)
    nop
    li      $t2, 0x4F              # 'O'
    beq     $t1, $t2, parse_boot_check_t
    nop
    li      $t2, 0x6F              # 'o'
    bne     $t1, $t2, parse_boot_next
    nop
parse_boot_check_t:
    lbu     $t1, 3($t0)
    nop
    li      $t2, 0x54              # 'T'
    beq     $t1, $t2, parse_boot_after_boot
    nop
    li      $t2, 0x74              # 't'
    bne     $t1, $t2, parse_boot_next
    nop

parse_boot_after_boot:
    # Skip whitespace and '='
    addiu   $t0, $t0, 4            # Skip "BOOT"
parse_boot_skip_ws:
    lbu     $t1, 0($t0)
    nop
    li      $t2, 0x20              # Space
    beq     $t1, $t2, parse_boot_skip_ws_inc
    nop
    li      $t2, 0x09              # Tab
    beq     $t1, $t2, parse_boot_skip_ws_inc
    nop
    li      $t2, 0x3D              # '='
    beq     $t1, $t2, parse_boot_skip_eq
    nop
    li      $t2, 0x3A              # ':'
    beq     $t1, $t2, parse_boot_skip_eq
    nop
    j       parse_boot_copy_name
    nop
parse_boot_skip_ws_inc:
    addiu   $t0, $t0, 1
    j       parse_boot_skip_ws
    nop
parse_boot_skip_eq:
    addiu   $t0, $t0, 1
    j       parse_boot_skip_ws
    nop

parse_boot_copy_name:
    # Copy filename to 0x80014000 (temp buffer for filename)
    lui     $t3, 0x8001
    ori     $t3, $t3, 0x4000
    li      $t4, 0                 # Length counter
parse_boot_copy_loop:
    lbu     $t1, 0($t0)
    nop
    # Stop at CR, LF, or end
    li      $t2, 0x0D              # CR
    beq     $t1, $t2, parse_boot_copy_done
    nop
    li      $t2, 0x0A              # LF
    beq     $t1, $t2, parse_boot_copy_done
    nop
    beq     $t1, $zero, parse_boot_copy_done
    nop
    # Skip leading spaces
    li      $t2, 0x20
    beq     $t1, $t2, parse_boot_copy_skip_space
    nop
    sb      $t1, 0($t3)
    addiu   $t3, $t3, 1
    addiu   $t4, $t4, 1
    addiu   $t0, $t0, 1
    j       parse_boot_copy_loop
    nop
parse_boot_copy_skip_space:
    addiu   $t0, $t0, 1
    j       parse_boot_copy_loop
    nop

parse_boot_copy_done:
    # Null-terminate
    sb      $zero, 0($t3)

    # Now search root directory for this filename
    # Re-read root dir (already at 0x80012000 from earlier)
    lui     $a0, 0x8001
    ori     $a0, $a0, 0x2000
    jal     Find_File_By_Name
    nop

    jr      $ra
    nop

parse_boot_next:
    addiu   $t0, $t0, 1
    addiu   $t6, $t6, -1
    bne     $t6, $zero, parse_boot_loop
    nop
    li      $v0, 0
    li      $v1, 0
    jr      $ra
    nop

# =============================================================================
# Find File By Name in Directory
# $a0 = directory buffer
# Name to find is at 0x80014000 (null-terminated)
# Returns: $v0 = LBA, $v1 = size
# =============================================================================
Find_File_By_Name:
    move    $t0, $a0               # Dir buffer
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x4000       # Name to find

find_by_name_loop:
    lbu     $t2, 0($t0)            # Record length
    nop
    beq     $t2, $zero, find_by_name_not_found
    nop

    # Get name length at offset 32
    lbu     $t3, 32($t0)
    nop
    beq     $t3, $zero, find_by_name_next
    nop

    # Compare name byte by byte
    addiu   $t4, $t0, 33           # Dir entry name
    move    $t5, $t1               # Search name
    li      $t6, 0                 # Index
find_by_name_cmp:
    lbu     $t7, 0($t5)            # Search name byte
    nop
    beq     $t7, $zero, find_by_name_match
    nop
    lbu     $t8, 0($t4)            # Dir entry name byte
    nop
    bne     $t7, $t8, find_by_name_next
    nop
    addiu   $t5, $t5, 1
    addiu   $t4, $t4, 1
    addiu   $t6, $t6, 1
    j       find_by_name_cmp
    nop

find_by_name_match:
    # Found! Extract LBA and size
    lw      $v0, 2($t0)            # LBA
    nop
    lw      $v1, 10($t0)           # Size
    nop
    jr      $ra
    nop

find_by_name_next:
    add     $t0, $t0, $t2
    j       find_by_name_loop
    nop

find_by_name_not_found:
    li      $v0, 0
    li      $v1, 0
    jr      $ra
    nop

# =============================================================================
# Flush Cache
# =============================================================================
Flush_Cache:
    # Write to CP0 TagLo/TagHi then invalidate I-cache
    mtc0    $zero, 2               # TagLo = 0
    nop
    mtc0    $zero, 3               # TagHi = 0
    nop
    # Cache instruction: invalidate all I-cache
    # cache 0x00, 0($zero) — but our assembler may not support cache
    # Use a NOP-heavy approach: just ensure stores complete
    nop
    nop
    nop
    nop
    nop
    jr      $ra
    nop

# =============================================================================
# Syscall Vector Stubs
# Each vector is 4 instructions (16 bytes) installed at 0xA0, 0xB0, 0xC0
# The calling convention: $t1 = function number, vector jumps to table[$t1]
# =============================================================================

# A0 Vector: dispatches to A0 table at 0x80010000
A0_Vector_Stub:
    sll     $t0, $t1, 2              # t0 = t1 * 4 (byte offset)
    lui     $t2, 0x8001              # t2 = 0x80010000 (A0 table base)
    addu    $t2, $t2, $t0            # t2 = &A0table[t1]
    lw      $t3, 0($t2)             # t3 = handler address
    jr      $t3                      # jump to handler
    nop

# B0 Vector: dispatches to B0 table at 0x80010300
B0_Vector_Stub:
    sll     $t0, $t1, 2
    lui     $t2, 0x8001
    ori     $t2, $t2, 0x0300        # B0 table base = 0x80010300
    addu    $t2, $t2, $t0
    lw      $t3, 0($t2)
    jr      $t3
    nop

# C0 Vector: dispatches to C0 table at 0x80010480
C0_Vector_Stub:
    sll     $t0, $t1, 2
    lui     $t2, 0x8001
    ori     $t2, $t2, 0x0480        # C0 table base = 0x80010480
    addu    $t2, $t2, $t0
    lw      $t3, 0($t2)
    jr      $t3
    nop

# =============================================================================
# Install Syscall Vectors
# Copies 4-word stubs to RAM addresses 0xA0, 0xB0, 0xC0
# =============================================================================
Install_Syscall_Vectors:
    # A0 vector -> 0x000000A0
    lui     $t0, 0x0000
    ori     $t0, $t0, 0x00A0
    la      $t1, A0_Vector_Stub
    lw      $t2, 0($t1)
    sw      $t2, 0($t0)
    lw      $t2, 4($t1)
    sw      $t2, 4($t0)
    lw      $t2, 8($t1)
    sw      $t2, 8($t0)
    lw      $t2, 12($t1)
    sw      $t2, 12($t0)

    # B0 vector -> 0x000000B0
    ori     $t0, $t0, 0x0010        # 0xA0 + 0x10 = 0xB0
    la      $t1, B0_Vector_Stub
    lw      $t2, 0($t1)
    sw      $t2, 0($t0)
    lw      $t2, 4($t1)
    sw      $t2, 4($t0)
    lw      $t2, 8($t1)
    sw      $t2, 8($t0)
    lw      $t2, 12($t1)
    sw      $t2, 12($t0)

    # C0 vector -> 0x000000C0
    ori     $t0, $t0, 0x0010        # 0xB0 + 0x10 = 0xC0
    la      $t1, C0_Vector_Stub
    lw      $t2, 0($t1)
    sw      $t2, 0($t0)
    lw      $t2, 4($t1)
    sw      $t2, 4($t0)
    lw      $t2, 8($t1)
    sw      $t2, 8($t0)
    lw      $t2, 12($t1)
    sw      $t2, 12($t0)

    jr      $ra
    nop

# =============================================================================
# Copy Syscall Tables to RAM
# A0 table: 0xC0 entries -> 0x80010000 (0x300 bytes)
# B0 table: 0x60 entries -> 0x80010300 (0x180 bytes)
# C0 table: 0x20 entries -> 0x80010480 (0x80 bytes)
# =============================================================================
Copy_Syscall_Tables:
    # Copy A0 table
    la      $t0, A0_Table            # Source
    lui     $t1, 0x8001              # Dest = 0x80010000
    li      $t2, 0x300               # 0xC0 * 4 bytes
    jal     Memcopy
    nop

    # Copy B0 table
    la      $t0, B0_Table
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0300
    li      $t2, 0x180               # 0x60 * 4
    jal     Memcopy
    nop

    # Copy C0 table
    la      $t0, C0_Table
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x0480
    li      $t2, 0x80                # 0x20 * 4
    jal     Memcopy
    nop

    jr      $ra
    nop

# =============================================================================
# Memcopy: $t0=src, $t1=dst, $t2=count (bytes)
# =============================================================================
Memcopy:
    beq     $t2, $zero, memcopy_done
    nop
memcopy_loop:
    lbu     $t3, 0($t0)
    nop
    sb      $t3, 0($t1)
    addiu   $t0, $t0, 1
    addiu   $t1, $t1, 1
    addiu   $t2, $t2, -1
    bne     $t2, $zero, memcopy_loop
    nop
memcopy_done:
    jr      $ra
    nop

# =============================================================================
# Init Interrupt Controller
# =============================================================================
Init_Interrupt_Controller:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000

    # ISTAT (0x1F801070): clear all interrupt flags
    li      $t1, 0x0000
    sw      $t1, 0x70($t0)          # Clear ISTAT
    nop

    # IMASK (0x1F801074): enable VBlank(0x01), GPU(0x40), CDROM(0x04), DMA(0x80)
    li      $t1, 0x000000C5         # VBlank + GPU + CDROM + DMA
    sw      $t1, 0x74($t0)          # Set IMASK
    nop

    jr      $ra
    nop

# =============================================================================
# Init Heap
# Simple heap allocator: heap starts at 0x80018000, size 0x8000 (32KB)
# Globals at 0x80010A00: heap_ptr, heap_size
# =============================================================================
Init_Heap:
    # Set heap base pointer
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00       # 0x80010A00 = globals area
    lui     $t1, 0x8001
    ori     $t1, $t1, 0x8000       # Heap base = 0x80018000
    sw      $t1, 0($t0)            # heap_ptr = 0x80018000
    nop
    li      $t1, 0x00008000        # Heap size = 32KB
    sw      $t1, 4($t0)            # heap_size = 0x8000
    nop
    jr      $ra
    nop

# =============================================================================
# Init Events
# $a0 = event count
# Allocates EvCB array at 0x80010B00, each entry 16 bytes
# =============================================================================
Init_Events:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0B00       # Event array base = 0x80010B00
    move    $t1, $zero             # Counter
init_events_loop:
    slt     $t2, $t1, $a0
    beq     $t2, $zero, init_events_done
    nop
    # Clear 16 bytes per event slot
    sw      $zero, 0($t0)
    sw      $zero, 4($t0)
    sw      $zero, 8($t0)
    sw      $zero, 12($t0)
    addiu   $t0, $t0, 16
    addiu   $t1, $t1, 1
    j       init_events_loop
    nop
init_events_done:
    # Store event count in globals
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00
    sw      $a0, 8($t0)            # globals[2] = event_count
    nop
    jr      $ra
    nop

# =============================================================================
# Init Threads
# $a0 = thread count
# Allocates TCB array at 0x80010C00, each entry 128 bytes (oversized for regs)
# =============================================================================
Init_Threads:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0C00       # Thread array base = 0x80010C00
    move    $t1, $zero             # Counter
init_threads_loop:
    slt     $t2, $t1, $a0
    beq     $t2, $zero, init_threads_done
    nop
    # Clear first 32 bytes of TCB (flags + key registers)
    sw      $zero, 0($t0)
    sw      $zero, 4($t0)
    sw      $zero, 8($t0)
    sw      $zero, 12($t0)
    sw      $zero, 16($t0)
    sw      $zero, 20($t0)
    sw      $zero, 24($t0)
    sw      $zero, 28($t0)
    addiu   $t0, $t0, 128          # Next TCB (128-byte stride)
    addiu   $t1, $t1, 1
    j       init_threads_loop
    nop
init_threads_done:
    # Store thread count in globals
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00
    sw      $a0, 12($t0)           # globals[3] = thread_count
    nop
    jr      $ra
    nop

# =============================================================================
# Unimplemented Syscall Handler
# Logs the call and returns 0 (graceful degradation)
# =============================================================================
Sys_Unimplemented:
    # Write a marker to 0x801FFFF0 so we can detect unimplemented calls
    lui     $t0, 0x801F
    ori     $t0, $t0, 0xFFF0
    sw      $t1, 0($t0)            # Store function number
    nop
    # Return 0
    li      $v0, 0
    jr      $ra
    nop

# =============================================================================
# Syscall Stubs — A0 Table Functions
# =============================================================================

# A0(0x00): open
Sys_open:
    li      $v0, 0xFFFFFFFF        # Return -1 (no file system yet)
    jr      $ra
    nop

# A0(0x02): read
Sys_read:
    li      $v0, 0
    jr      $ra
    nop

# A0(0x03): write
Sys_write:
    li      $v0, 0
    jr      $ra
    nop

# A0(0x04): close
Sys_close:
    li      $v0, 0
    jr      $ra
    nop

# A0(0x0E): abs
Sys_abs:
    sra     $v0, $a0, 31           # v0 = sign bit
    xor     $v1, $a0, $v0          # flip bits if negative
    subu    $v0, $v1, $v0          # add 1 if negative
    jr      $ra
    nop

# A0(0x0F): labs
Sys_labs:
    sra     $v0, $a0, 31
    xor     $v1, $a0, $v0
    subu    $v0, $v1, $v0
    jr      $ra
    nop

# A0(0x10): atoi
Sys_atoi:
    move    $v0, $zero
    li      $t0, 10
atoi_loop:
    lbu     $t1, 0($a0)
    nop
    beq     $t1, $zero, atoi_done
    nop
    li      $t2, 0x30              # '0'
    sltu    $t3, $t2, $t1          # t3 = (0x30 < char) — excludes '0' itself
    bne     $t3, $zero, atoi_check_high  # if char > '0', check upper bound
    nop
    # char == '0'? still valid digit
    li      $t2, 0x30
    beq     $t1, $t2, atoi_is_digit
    nop
    j       atoi_skip
    nop
atoi_check_high:
    li      $t2, 0x3A              # one past '9'
    sltu    $t3, $t1, $t2          # t3 = (char < 0x3A) — includes '9'
    beq     $t3, $zero, atoi_skip
    nop
atoi_is_digit:
    mult    $v0, $t0               # v0 = v0 * 10 (2-operand form)
    nop
    mflo    $v0                    # result in LO
    addiu   $t1, $t1, -0x30
    addu    $v0, $v0, $t1
atoi_skip:
    addiu   $a0, $a0, 1
    j       atoi_loop
    nop
atoi_done:
    jr      $ra
    nop

# A0(0x17): strcmp
Sys_strcmp:
    move    $v0, $zero
strcmp_loop:
    lbu     $t0, 0($a0)
    nop
    lbu     $t1, 0($a1)
    nop
    beq     $t0, $zero, strcmp_end
    nop
    bne     $t0, $t1, strcmp_end
    nop
    addiu   $a0, $a0, 1
    addiu   $a1, $a1, 1
    j       strcmp_loop
    nop
strcmp_end:
    subu    $v0, $t0, $t1
    jr      $ra
    nop

# A0(0x19): strcpy
Sys_strcpy:
    move    $v0, $a0               # Return dest
strcpy_loop:
    lbu     $t0, 0($a1)
    nop
    sb      $t0, 0($a0)
    beq     $t0, $zero, strcpy_done
    nop
    addiu   $a0, $a0, 1
    addiu   $a1, $a1, 1
    j       strcpy_loop
    nop
strcpy_done:
    jr      $ra
    nop

# A0(0x1B): strlen
Sys_strlen:
    move    $v0, $zero
strlen_loop:
    addu    $t0, $a0, $v0
    lbu     $t1, 0($t0)
    nop
    beq     $t1, $zero, strlen_done
    nop
    addiu   $v0, $v0, 1
    j       strlen_loop
    nop
strlen_done:
    jr      $ra
    nop

# A0(0x2A): memcpy
Sys_memcpy:
    beq     $a2, $zero, memcpy_done2
    nop
    move    $v0, $a0               # Return dest
memcpy_loop2:
    lbu     $t0, 0($a1)
    nop
    sb      $t0, 0($a0)
    addiu   $a0, $a0, 1
    addiu   $a1, $a1, 1
    addiu   $a2, $a2, -1
    bne     $a2, $zero, memcpy_loop2
    nop
memcpy_done2:
    jr      $ra
    nop

# A0(0x2B): memset
Sys_memset:
    beq     $a2, $zero, memset_done
    nop
    move    $v0, $a0               # Return dest
memset_loop:
    sb      $a1, 0($a0)
    addiu   $a0, $a0, 1
    addiu   $a2, $a2, -1
    bne     $a2, $zero, memset_loop
    nop
memset_done:
    jr      $ra
    nop

# A0(0x33): malloc
Sys_malloc:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00       # Globals area
    lw      $t1, 0($t0)            # heap_ptr
    nop
    # Simple bump allocator: return current heap_ptr, advance by size
    move    $v0, $t1               # Return current heap ptr
    addu    $t1, $t1, $a0          # Advance by requested size
    # Round up to 4-byte alignment
    addiu   $t1, $t1, 3
    srl     $t1, $t1, 2
    sll     $t1, $t1, 2
    sw      $t1, 0($t0)            # Update heap_ptr
    nop
    jr      $ra
    nop

# A0(0x34): free
Sys_free:
    # No-op for bump allocator
    jr      $ra
    nop

# A0(0x37): calloc
Sys_calloc:
    # malloc(nitems * size) then memset to 0
    mult    $a0, $a1               # a0 = nitems * size (2-operand)
    nop
    mflo    $a0                    # result in LO
    jal     Sys_malloc
    nop
    # v0 = ptr, clear it
    beq     $v0, $zero, calloc_done
    nop
    move    $a0, $v0
    li      $a1, 0
    # a2 already has size from mult... actually we need to recalculate
    # For simplicity, just return the malloc'd ptr (bump allocator returns zeroed RAM)
calloc_done:
    jr      $ra
    nop

# A0(0x38): realloc
Sys_realloc:
    # Simple: malloc new, copy old, free old
    # For now just malloc new size
    move    $a0, $a1               # size = a1
    jal     Sys_malloc
    nop
    jr      $ra
    nop

# A0(0x39): InitHeap
Sys_InitHeap:
    lui     $t0, 0x8001
    ori     $t0, $t0, 0x0A00
    sw      $a0, 0($t0)            # heap_ptr = a0
    nop
    sw      $a1, 4($t0)            # heap_size = a1
    nop
    jr      $ra
    nop

# A0(0x3F): printf
Sys_printf:
    # No-op (no TTY yet)
    li      $v0, 0
    jr      $ra
    nop

# A0(0x44): FlushCache
Sys_FlushCache:
    jal     Flush_Cache
    nop
    jr      $ra
    nop

# A0(0x46): GPU_dw (drawing area)
Sys_GPU_dw:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t1, 0xA0000000        # GP0 command: fill VRAM
    sw      $t1, 0x10($t0)         # Write to GP0
    nop
    sw      $a0, 0x10($t0)         # x,y
    nop
    sw      $a1, 0x10($t0)         # w,h
    nop
    jr      $ra
    nop

# A0(0x47): mem2vram
Sys_GPU_mem2vram:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    li      $t1, 0xA0000000
    sw      $t1, 0x10($t0)
    nop
    sw      $a0, 0x10($t0)
    nop
    sw      $a1, 0x10($t0)
    nop
    jr      $ra
    nop

# A0(0x48): SendGPU
Sys_GPU_send:
    lui     $t0, 0x1f80
    ori     $t0, $t0, 0x1000
    sw      $a0, 0x10($t0)         # Write to GP0
    nop
    jr      $ra
    nop

# =============================================================================
# Syscall Stubs — B0 Table Functions
# =============================================================================

# B0(0x00): malloc (kernel)
Sys_kmalloc:
    j       Sys_malloc
    nop

# B0(0x01): free (kernel)
Sys_kfree:
    j       Sys_free
    nop

# B0(0x07): deliverEvent
Sys_deliverEvent:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x08): openEvent
Sys_openEvent:
    li      $v0, 0xF1000000        # Return fake event handle
    jr      $ra
    nop

# B0(0x09): closeEvent
Sys_closeEvent:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x0A): waitEvent
Sys_waitEvent:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x0B): testEvent
Sys_testEvent:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x0C): enableEvent
Sys_enableEvent:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x0D): disableEvent
Sys_disableEvent:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x0E): openThread
Sys_openThread:
    li      $v0, 0xFF000000        # Return fake thread handle
    jr      $ra
    nop

# B0(0x0F): closeThread
Sys_closeThread:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x10): changeThread
Sys_changeThread:
    li      $v0, 1
    jr      $ra
    nop

# B0(0x14): returnFromException
Sys_returnFromException:
    # Restore EPC and return
    mfc0    $t0, 14                # EPC
    nop
    jr      $t0
    nop

# B0(0x32): open
Sys_B0_open:
    li      $v0, 0xFFFFFFFF
    jr      $ra
    nop

# B0(0x33): lseek
Sys_lseek:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x34): read
Sys_B0_read:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x35): write
Sys_B0_write:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x36): close
Sys_B0_close:
    li      $v0, 0
    jr      $ra
    nop

# B0(0x39): exit
Sys_exit:
    j       boot_fail
    nop

# B0(0x3F): puts
Sys_puts:
    li      $v0, 0
    jr      $ra
    nop

# =============================================================================
# Syscall Stubs — C0 Table Functions
# =============================================================================

# C0(0x05): getFreeTCBslot
Sys_getFreeTCB:
    li      $v0, 0
    jr      $ra
    nop

# C0(0x06): exceptionHandler
Sys_exceptionHandler:
    jr      $ra
    nop

# C0(0x07): installExceptionHandler
Sys_installExceptionHandler:
    jr      $ra
    nop

# C0(0x08): initheap (kernel)
Sys_kinitheap:
    j       Sys_InitHeap
    nop

# C0(0x10): setupFileIO
Sys_setupFileIO:
    jr      $ra
    nop

# C0(0x11): reopenStdio
Sys_reopenStdio:
    jr      $ra
    nop

# =============================================================================
# A0 Function Table (0xC0 entries = 192 words)
# =============================================================================
.align 4
A0_Table:
    .word Sys_open, Sys_Unimplemented, Sys_read, Sys_write    # 00-03
    .word Sys_close, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 04-07
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 08-0B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_abs, Sys_labs    # 0C-0F
    .word Sys_atoi, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 10-13
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_strcmp  # 14-17
    .word Sys_Unimplemented, Sys_strcpy, Sys_Unimplemented, Sys_strlen  # 18-1B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 1C-1F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 20-23
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 24-27
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_memcpy, Sys_memset  # 28-2B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 2C-2F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_malloc  # 30-33
    .word Sys_free, Sys_Unimplemented, Sys_Unimplemented, Sys_calloc  # 34-37
    .word Sys_realloc, Sys_InitHeap, Sys_Unimplemented, Sys_Unimplemented  # 38-3B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_printf  # 3C-3F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 40-43
    .word Sys_FlushCache, Sys_Unimplemented, Sys_GPU_dw, Sys_GPU_mem2vram  # 44-47
    .word Sys_GPU_send, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 48-4B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 4C-4F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 50-53
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 54-57
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 58-5B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 5C-5F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 60-63
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 64-67
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 68-6B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 6C-6F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 70-73
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 74-77
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 78-7B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 7C-7F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 80-83
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 84-87
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 88-8B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 8C-8F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 90-93
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 94-97
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 98-9B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 9C-9F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # A0-A3
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # A4-A7
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # A8-AB
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # AC-AF
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # B0-B3
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # B4-B7
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # B8-BB
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # BC-BF

# =============================================================================
# B0 Function Table (0x60 entries = 96 words)
# =============================================================================
.align 4
B0_Table:
    .word Sys_kmalloc, Sys_kfree, Sys_Unimplemented, Sys_Unimplemented  # 00-03
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_deliverEvent  # 04-07
    .word Sys_openEvent, Sys_closeEvent, Sys_waitEvent, Sys_testEvent  # 08-0B
    .word Sys_enableEvent, Sys_disableEvent, Sys_openThread, Sys_closeThread  # 0C-0F
    .word Sys_changeThread, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 10-13
    .word Sys_returnFromException, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 14-17
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 18-1B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 1C-1F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 20-23
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 24-27
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 28-2B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 2C-2F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_B0_open, Sys_lseek  # 30-33
    .word Sys_B0_read, Sys_B0_write, Sys_B0_close, Sys_Unimplemented  # 34-37
    .word Sys_exit, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 38-3B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_puts  # 3C-3F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 40-43
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 44-47
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 48-4B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 4C-4F
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 50-53
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 54-57
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 58-5B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 5C-5F

# =============================================================================
# C0 Function Table (0x20 entries = 32 words)
# =============================================================================
.align 4
C0_Table:
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 00-03
    .word Sys_Unimplemented, Sys_getFreeTCB, Sys_exceptionHandler, Sys_installExceptionHandler  # 04-07
    .word Sys_kinitheap, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 08-0B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 0C-0F
    .word Sys_setupFileIO, Sys_reopenStdio, Sys_Unimplemented, Sys_Unimplemented  # 10-13
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 14-17
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 18-1B
    .word Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented, Sys_Unimplemented  # 1C-1F

# =============================================================================
# General Exception Handler (at 0xBFC00180)
# =============================================================================
.org 0xbfc00180
exception_handler:
    lui     $k0, 0x801F
    ori     $k0, $k0, 0xFF00
    sw      $at, 0x00($k0)
    sw      $v0, 0x04($k0)
    sw      $v1, 0x08($k0)
    sw      $a0, 0x0C($k0)
    sw      $a1, 0x10($k0)
    sw      $a2, 0x14($k0)
    sw      $a3, 0x18($k0)
    sw      $t0, 0x1C($k0)
    sw      $t1, 0x20($k0)
    sw      $t2, 0x24($k0)
    sw      $t3, 0x28($k0)
    sw      $t4, 0x2C($k0)
    sw      $t5, 0x30($k0)
    sw      $t6, 0x34($k0)
    sw      $t7, 0x38($k0)
    mfc0    $t0, 14
    nop
    sw      $t0, 0x3C($k0)
    mfc0    $t0, 13
    nop
    sw      $t0, 0x40($k0)
    mfc0    $t0, 8
    nop
    sw      $t0, 0x44($k0)
    mfc0    $t0, 12
    nop
    sw      $t0, 0x48($k0)
    lui     $t0, 0xDEAD
    ori     $t0, $t0, 0xCAFE
    sw      $t0, 0x4C($k0)
    j       exception_halt
    nop
exception_halt:
    j       exception_halt
    nop

# =============================================================================
# Signature Block (injected by build_frankenstein_bios.py)
# =============================================================================
.org 0xbfc07FE0
# OpenBIOS at 0x78 and VHB-SUPER-BIOS at 0x7FE0 injected by build script

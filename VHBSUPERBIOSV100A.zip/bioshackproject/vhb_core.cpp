// =============================================================================
// vhb_core.cpp — Virtual Hypervisor BIOS (VHB) Core Implementation
//
// Implements the VHB: loads ROM/ISO images, parses PS-X EXE headers,
// sets up virtual memory with Soft-MMU, registers vector handlers,
// and dispatches payload execution.
//
// Build:
//   g++ -O2 -std=c++17 -c vhb_core.cpp -o vhb_core.o
//   g++ -O2 -std=c++17 -o vhb_launch.exe vhb_core.cpp vhb_launch.cpp
// =============================================================================

#include "vhb_core.h"
#include <cstdio>
#include <sys/stat.h>

// ============================================================================
// File helpers
// ============================================================================

static std::vector<uint8_t> read_file(const char* path) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) return {};
    size_t sz = (size_t)f.tellg();
    f.seekg(0);
    std::vector<uint8_t> data(sz);
    f.read((char*)data.data(), sz);
    return data;
}

static uint32_t file_size(const std::string& path) {
    struct stat st;
    if (stat(path.c_str(), &st) != 0) return 0;
    return (uint32_t)st.st_size;
}

static uint32_t rd32(const uint8_t* p) {
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
}

// ============================================================================
// SuperBIOSHypervisor Constructor
// ============================================================================

SuperBIOSHypervisor::SuperBIOSHypervisor(TargetSystem target, uint32_t ram_mb)
    : current_target(target), configured_ram_mb(ram_mb),
      profile(TargetProfiles::get(target, ram_mb))
{
    // Allocate unified memory pool (64MB, bypassing legacy 2MB/8MB ceilings)
    // MMU constructor already allocates the pool
    context = std::make_unique<VirtualHardwareContext>(profile.extended_ram_size);
    init_memory_map();

    printf("[VHB] Super BIOS Hypervisor initialized.\n");
    printf("  Target: %s\n", profile.name);
    printf("  Base RAM: 0x%08X (%u MB)\n", profile.default_ram_size, profile.default_ram_size / (1024*1024));
    printf("  Extended RAM: 0x%08X (%u MB)\n", profile.extended_ram_size, profile.extended_ram_size / (1024*1024));
    printf("  RAM ceiling: 0x%08X\n", profile.ram_ceiling);
    printf("  Payload entry: 0x%08X\n", profile.payload_entry);
    printf("  MMU pool: %u MB\n", mmu.pool_size() / (1024*1024));
}

// ============================================================================
// Memory Map Initialization
// ============================================================================

void SuperBIOSHypervisor::init_memory_map() {
    switch (current_target) {
        case TargetSystem::PSX_Hybrid: {
            // Standard PSX memory regions (publicly documented)
            context->register_region(0x00000000, 0x00200000, "Main RAM (2MB)", true, true);
            context->register_region(0x1F000000, 0x1F800000, "Expansion Region 1", true, false);
            context->register_region(0x1F000000, 0x1F010000, "Expansion 1 (SFX-100)", false, false);
            context->register_region(0x1F801000, 0x1F802000, "Memory Control Registers", true, false);
            context->register_region(0x1F801000, 0x1F801100, "I/O Ports", true, false);
            context->register_region(0x1F801100, 0x1F801200, "GPU Registers", true, false);
            context->register_region(0x1F801800, 0x1F801900, "CD-ROM Registers", true, false);
            context->register_region(0x1F801C00, 0x1F801D00, "SPU Registers", true, false);
            context->register_region(0x1F802000, 0x1F804000, "Expansion Region 2", true, false);
            context->register_region(0x1FA00000, 0x1FB00000, "Expansion Region 3", true, false);
            context->register_region(0xBFC00000, 0xBFC80000, "BIOS ROM (512KB)", false, true);

            // P3: Configurable RAM — map full configured range as cached KSEG0
            uint32_t ram_top = 0x80000000 + profile.extended_ram_size;
            context->register_region(0x80000000, ram_top, "Kernel/User RAM (cached)", true, true);
            context->register_region(0xA0000000, 0xA0000000 + profile.extended_ram_size,
                "Kernel/User RAM (uncached)", true, true);

            // Extended RAM for ROM hacks (beyond configured size, up to 8MB)
            if (profile.extended_ram_size < 0x00800000) {
                context->register_region(ram_top, 0x80800000,
                    "Extended RAM (hack pool)", true, true);
            }
            context->register_region(0x1F400000, 0x1F500000, "SFX-100 Cartridge Bus", false, false);

            // MMU mappings: virtual → physical
            // Map full configured RAM at 0x80000000 to start of pool
            mmu.map(0x80000000, 0x00000000, profile.extended_ram_size, "Main RAM");
            // Map extended RAM beyond configured size
            if (profile.extended_ram_size < 0x00800000) {
                mmu.map(ram_top, profile.extended_ram_size,
                        0x00800000 - profile.extended_ram_size, "Extended RAM (hack pool)");
            }
            // Map BIOS ROM at 0xBFC00000 to offset 8MB in pool (read-only)
            mmu.map(0xBFC00000, 0x00800000, 0x00080000, "BIOS ROM");
            break;
        }

        case TargetSystem::SNES_Extended:
            context->register_region(0x000000, 0x040000, "SNES RAM (128KB+banks)", true, true);
            context->register_region(0x000000, 0x008000, "LoROM bank 0", false, true);
            context->register_region(0x1F400000, 0x1F500000, "SFX-100 Bus", false, false);
            // Extended: GSU SuperFX can address up to 8MB
            context->register_region(0x000000, 0x800000, "Extended ROM (8MB GSU)", false, true);

            mmu.map(0x000000, 0x00000000, 0x008000, "SNES Bank 0");
            mmu.map(0x1F400000, 0x008000, 0x00100000, "SFX-100 Bus");
            break;

        case TargetSystem::Saturn_Flexible:
            context->register_region(0x06000000, 0x06200000, "Saturn Work RAM (2MB)", true, true);
            context->register_region(0x00200000, 0x00300000, "Saturn VDP1 RAM", true, false);
            context->register_region(0x05C00000, 0x05C80000, "VDP2 VRAM", true, false);
            context->register_region(0x05800000, 0x05A00000, "Saturn Sound RAM", true, false);

            mmu.map(0x06000000, 0x00000000, 0x00200000, "Work RAM");
            mmu.map(0x00200000, 0x00200000, 0x00100000, "VDP1 RAM");
            break;
    }
}

// ============================================================================
// ROM Loading
// ============================================================================

bool SuperBIOSHypervisor::load_rom(const std::string& path) {
    printf("[VHB] Loading ROM: %s\n", path.c_str());

    rom_data = read_file(path.c_str());
    if (rom_data.empty()) {
        printf("  ERROR: Cannot read file or file is empty.\n");
        return false;
    }

    uint32_t fsize = (uint32_t)rom_data.size();
    printf("  File size: %u bytes (%.2f MB)\n", fsize, (double)fsize / (1024*1024));

    // Detect format by checking magic bytes
    if (fsize >= 8 && memcmp(rom_data.data(), "PS-X EXE", 8) == 0) {
        printf("  Format: PS-X EXE (standalone)\n");
        return parse_psx_exe(rom_data.data(), rom_data.size());
    }

    // Check for ISO 9660 (PSX MODE2)
    if (fsize > 0x8000 + 0x9320) {
        // Check for CD001 at sector 16 (LBA 16, offset 16*2352+24+1 = 0x9320+1)
        uint32_t iso_check = 16 * 2352 + 24 + 1;
        if (iso_check + 5 <= fsize && memcmp(rom_data.data() + iso_check, "CD001", 5) == 0) {
            printf("  Format: ISO 9660 (MODE2)\n");
            return load_exe_from_iso(path, 24);
        }
        // Also check MODE1 (2048 sector)
        uint32_t iso_check1 = 16 * 2048 + 1;
        if (iso_check1 + 5 <= fsize && memcmp(rom_data.data() + iso_check1, "CD001", 5) == 0) {
            printf("  Format: ISO 9660 (MODE1)\n");
            return load_exe_from_iso(path, 24);
        }
    }

    // Check for SNES ROM (no standard magic, but check for SMC header)
    if (fsize >= 0x8000 && fsize <= 0x800000) {
        // Could be SNES — check for Nintendo header at 0xFFC0 (with or without 512-byte SMC header)
        uint32_t header_off = (fsize & 0x7FFF) == 512 ? 512 : 0;
        if (header_off + 0xFFD5 <= fsize) {
            uint8_t check = rom_data[header_off + 0xFFD5];
            // SNES ROMs often have 0x33 or 0x23 at this offset (game code)
            if (check == 0x33 || check == 0x23) {
                printf("  Format: SNES ROM (possible)\n");
                rom_info.system = TargetSystem::SNES_Extended;
                rom_info.file_path = path;
                rom_info.file_size = fsize;
                rom_info.format = "SNES ROM";
                rom_info.entry_pc = 0x008000;  // SNES reset vector
                rom_info.load_addr = 0x000000;
                rom_info.text_size = fsize;
                rom_info.valid = true;
                rom_info.sector_size = 0;
                return true;
            }
        }
    }

    // Unknown format — try as raw binary
    printf("  Format: Unknown (treating as raw binary payload)\n");
    rom_info.system = current_target;
    rom_info.file_path = path;
    rom_info.file_size = fsize;
    rom_info.format = "Raw Binary";
    rom_info.entry_pc = profile.payload_entry;
    rom_info.load_addr = 0;
    rom_info.text_size = fsize;
    rom_info.valid = true;
    rom_info.sector_size = 0;
    return true;
}

// ============================================================================
// Standalone EXE Loading
// ============================================================================

bool SuperBIOSHypervisor::load_exe(const std::string& path) {
    printf("[VHB] Loading EXE: %s\n", path.c_str());
    rom_data = read_file(path.c_str());
    if (rom_data.empty()) {
        printf("  ERROR: Cannot read file.\n");
        return false;
    }
    printf("  File size: %u bytes\n", (uint32_t)rom_data.size());
    return parse_psx_exe(rom_data.data(), rom_data.size());
}

// ============================================================================
// EXE from ISO
// ============================================================================

bool SuperBIOSHypervisor::load_exe_from_iso(const std::string& iso_path, uint32_t exe_lba) {
    printf("[VHB] Loading EXE from ISO: %s (LBA %u)\n", iso_path.c_str(), exe_lba);

    // Detect sector size
    std::ifstream f(iso_path, std::ios::binary);
    if (!f) {
        printf("  ERROR: Cannot open ISO.\n");
        return false;
    }

    // Check if MODE2 (2352) or MODE1 (2048) by file size divisibility
    f.seekg(0, std::ios::end);
    uint64_t fsize = f.tellg();
    f.seekg(0);

    uint32_t sector_size = 2352;
    uint32_t data_offset = 24;
    uint32_t user_size = 2048;

    // If file size is divisible by 2048 but not 2352, it's MODE1
    if (fsize % 2048 == 0 && fsize % 2352 != 0) {
        sector_size = 2048;
        data_offset = 0;
        user_size = 2048;
        printf("  Sector: MODE1 (2048 bytes)\n");
    } else {
        printf("  Sector: MODE2 (2352 bytes)\n");
    }

    // Read EXE header (first sector of EXE)
    auto header_sector = read_iso_sector(f, exe_lba, sector_size, data_offset);
    if (header_sector.empty()) {
        printf("  ERROR: Cannot read EXE header sector.\n");
        return false;
    }

    if (!parse_psx_exe(header_sector.data(), header_sector.size())) {
        printf("  ERROR: EXE header parse failed.\n");
        return false;
    }

    // Read full EXE text
    uint32_t read_size = rom_info.text_size;
    std::vector<uint8_t> exe_text;
    uint32_t remaining = read_size;
    uint32_t sector = exe_lba + 1;  // Text starts in next sector (after 0x800 header)

    while (remaining > 0) {
        auto chunk = read_iso_sector(f, sector, sector_size, data_offset);
        if (chunk.empty()) break;
        uint32_t take = (uint32_t)std::min((size_t)remaining, chunk.size());
        exe_text.insert(exe_text.end(), chunk.begin(), chunk.begin() + take);
        remaining -= take;
        sector++;
    }

    // Combine header + text into rom_data
    rom_data.clear();
    rom_data.insert(rom_data.end(), header_sector.begin(), header_sector.begin() + 0x800);
    rom_data.insert(rom_data.end(), exe_text.begin(), exe_text.end());

    rom_info.file_path = iso_path;
    rom_info.exe_lba = exe_lba;
    rom_info.sector_size = sector_size;
    rom_info.file_size = (uint32_t)rom_data.size();

    printf("  EXE loaded: %u bytes (header + text)\n", rom_info.file_size);
    printf("  Entry PC: 0x%08X\n", rom_info.entry_pc);
    printf("  Load addr: 0x%08X\n", rom_info.load_addr);
    printf("  Text size: 0x%X (%u bytes)\n", rom_info.text_size, rom_info.text_size);

    return true;
}

// ============================================================================
// PS-X EXE Header Parser
// ============================================================================

bool SuperBIOSHypervisor::parse_psx_exe(const uint8_t* data, size_t size) {
    if (size < 0x38) {
        printf("  ERROR: Data too small for PS-X EXE header.\n");
        return false;
    }

    if (memcmp(data, "PS-X EXE", 8) != 0) {
        printf("  ERROR: Invalid PS-X EXE magic.\n");
        return false;
    }

    rom_info.system = TargetSystem::PSX_Hybrid;
    rom_info.format = "PS-X EXE";
    rom_info.entry_pc = rd32(data + 0x10);
    rom_info.gp_value = rd32(data + 0x14);
    rom_info.load_addr = rd32(data + 0x18);
    rom_info.text_size = rd32(data + 0x1C);
    uint32_t s_addr = rd32(data + 0x20);
    uint32_t s_size = rd32(data + 0x24);
    rom_info.sp_value = s_addr + s_size;  // Stack top = base + size

    // Extract volume ID from ISO directory if available (set externally)
    rom_info.valid = true;

    printf("  PS-X EXE Header:\n");
    printf("    PC0:       0x%08X\n", rom_info.entry_pc);
    printf("    GP0:       0x%08X\n", rom_info.gp_value);
    printf("    Load addr: 0x%08X\n", rom_info.load_addr);
    printf("    Text size: 0x%X (%u bytes)\n", rom_info.text_size, rom_info.text_size);
    printf("    Stack:     0x%08X (base=0x%X size=0x%X)\n", rom_info.sp_value, s_addr, s_size);

    // Validate entry PC is within text region
    if (rom_info.entry_pc < rom_info.load_addr ||
        rom_info.entry_pc >= rom_info.load_addr + rom_info.text_size) {
        printf("  WARNING: Entry PC 0x%08X is outside text region [0x%08X, 0x%08X)\n",
               rom_info.entry_pc, rom_info.load_addr, rom_info.load_addr + rom_info.text_size);
    }

    return true;
}

// ============================================================================
// ROM Hack Vector Registration
// ============================================================================

void SuperBIOSHypervisor::register_rom_hack_vectors() {
    printf("[VHB] Registering ROM hack vectors...\n");

    switch (current_target) {
        case TargetSystem::PSX_Hybrid:
            // Override legacy BIOS vectors for unconstrained execution
            // These intercept the standard PSX BIOS call tables (A/B/C)
            // and redirect to our custom handlers

            vectors.register_vector(0xA0, 0x000000A0, [](uint32_t, uint32_t* regs) {
                printf("[VHB] Intercepted A-table syscall (vector 0xA0)\n");
                // In a real hypervisor, we'd dispatch to our extended handler
            }, "A-table dispatch");

            vectors.register_vector(0xB0, 0x000000B0, [](uint32_t, uint32_t* regs) {
                printf("[VHB] Intercepted B-table syscall (vector 0xB0)\n");
            }, "B-table dispatch");

            vectors.register_vector(0xC0, 0x000000C0, [](uint32_t, uint32_t* regs) {
                printf("[VHB] Intercepted C-table syscall (vector 0xC0)\n");
            }, "C-table dispatch");

            // P3: Descriptor intercept vector — catches descriptor publish calls
            // When the DW7 EXE writes the descriptor base to 0x800F2228,
            // this vector intercepts and clamps the value to the RAM ceiling.
            // This works in concert with the P1 EXE trampoline patch.
            vectors.register_vector(
                0x8007AD74,  // descriptor publish instruction address
                0x8007AD74,  // original target (same — intercept in-place)
                [ceiling = profile.ram_ceiling, safe = profile.desc_safe_base]
                (uint32_t, uint32_t* regs) {
                    if (regs) {
                        // $a2 is register 6 — descriptor base being published
                        uint32_t desc_base = regs[6];
                        if (desc_base >= ceiling) {
                            printf("[VHB] Descriptor intercept: clamping 0x%08X -> 0x%08X (ceiling=0x%08X)\n",
                                   desc_base, safe, ceiling);
                            regs[6] = safe;
                        }
                    }
                },
                "Descriptor publish intercept (P3)"
            );

            // Memory ceiling bypass: intercept allocation requests that would
            // exceed the legacy 2MB limit and redirect to extended pool
            vectors.register_vector(0x80000000, 0x80000000, [](uint32_t, uint32_t* regs) {
                printf("[VHB] Memory ceiling intercept: redirecting allocation to extended pool\n");
                if (regs) {
                    // Translate high address through Soft-MMU
                    // This is where the 2MB→8MB ceiling bypass happens
                }
            }, "Memory ceiling bypass");

            // Disc check bypass: intercept region/anti-piracy checks
            vectors.register_vector(0xBFC07FE0, 0xBFC07FE0, [](uint32_t, uint32_t* regs) {
                printf("[VHB] Disc check bypass: returning FRANK-PSX identity\n");
            }, "Disc check bypass");

            // P4: Exception handler vector — crash logger at 0xBFC00180
            vectors.register_vector(0xBFC00180, 0xBFC00180, [](uint32_t, uint32_t* regs) {
                printf("[VHB] Exception handler triggered (vector 0xBFC00180)\n");
                if (regs) {
                    printf("[VHB] Crash dump: $at=0x%08X $v0=0x%08X $v1=0x%08X $a0=0x%08X\n",
                           regs[1], regs[2], regs[3], regs[4]);
                    printf("[VHB] Crash dump: $a1=0x%08X $a2=0x%08X $a3=0x%08X\n",
                           regs[5], regs[6], regs[7]);
                }
            }, "Exception handler (P4)");

            break;

        case TargetSystem::SNES_Extended:
            // SNES NMI/IRQ vector override
            vectors.register_vector(0xFFEA, 0xFFEA, [](uint32_t, uint32_t* regs) {
                printf("[VHB] SNES NMI vector intercepted\n");
            }, "SNES NMI");
            vectors.register_vector(0xFFEE, 0xFFEE, [](uint32_t, uint32_t* regs) {
                printf("[VHB] SNES IRQ vector intercepted\n");
            }, "SNES IRQ");
            break;

        case TargetSystem::Saturn_Flexible:
            // Saturn SH-2 exception vectors
            vectors.register_vector(0x06000000, 0x06000000, [](uint32_t, uint32_t* regs) {
                printf("[VHB] Saturn SH-2 master vector intercepted\n");
            }, "Saturn SH-2 master");
            break;
    }

    printf("  Registered %u vectors.\n", (uint32_t)vectors.count());
}

// ============================================================================
// VFS Mount
// ============================================================================

void SuperBIOSHypervisor::vfs_mount(const std::string& name, const uint8_t* data, uint32_t size, uint32_t offset) {
    vfs.mount(name, data, size, offset);
    printf("[VHB] VFS mounted: %s (%u bytes)\n", name.c_str(), size);
}

// ============================================================================
// Payload Execution
// ============================================================================

void SuperBIOSHypervisor::execute_payload(uint32_t entry_point) {
    printf("[VHB] Executing payload at 0x%08X\n", entry_point);

    // Validate address through MMU
    uint32_t phys = mmu.translate(entry_point);
    printf("  MMU translation: 0x%08X -> 0x%08X\n", entry_point, phys);

    if (phys >= mmu.pool_size()) {
        printf("  ERROR: Segmentation fault — payload exceeds virtual memory pool.\n");
        printf("  Attempting Soft-MMU redirect...\n");

        // Auto-map to extended pool
        uint32_t ext_offset = profile.default_ram_size;
        if (ext_offset + 0x1000 <= mmu.pool_size()) {
            mmu.map(entry_point, ext_offset, 0x100000, "Auto-extended payload");
            printf("  Redirected to extended pool at physical 0x%08X\n", ext_offset);
        } else {
            printf("  FATAL: Extended pool exhausted.\n");
            return;
        }
    }

    // Load ROM data into virtual memory at the load address
    if (!rom_data.empty() && rom_info.valid) {
        uint32_t load_phys = mmu.translate(rom_info.load_addr);
        uint32_t copy_size = (uint32_t)std::min((size_t)rom_info.text_size, rom_data.size() - 0x800);

        if (load_phys + copy_size <= mmu.pool_size()) {
            // Copy text section (skip 0x800 EXE header) into virtual memory
            memcpy(mmu.physical_base() + load_phys, rom_data.data() + 0x800, copy_size);
            printf("  Loaded %u bytes of text at virtual 0x%08X (physical 0x%08X)\n",
                   copy_size, rom_info.load_addr, load_phys);
        } else {
            printf("  WARNING: Text section exceeds mapped memory — partial load\n");
            uint32_t avail = mmu.pool_size() - load_phys;
            memcpy(mmu.physical_base() + load_phys, rom_data.data() + 0x800, avail);
            printf("  Loaded %u bytes (truncated from %u)\n", avail, copy_size);
        }

        // Set up stack
        if (rom_info.sp_value > 0) {
            uint32_t sp_phys = mmu.translate(rom_info.sp_value);
            if (sp_phys < mmu.pool_size()) {
                printf("  Stack pointer: 0x%08X (physical 0x%08X)\n",
                       rom_info.sp_value, sp_phys);
            }
        }

        // Set up GP
        if (rom_info.gp_value > 0) {
            printf("  Global pointer: 0x%08X\n", rom_info.gp_value);
        }
    }

    // Verify entry point has valid code
    uint32_t entry_phys = mmu.translate(entry_point);
    if (entry_phys + 4 <= mmu.pool_size()) {
        uint32_t first_insn = mmu.read32(entry_point);
        uint32_t op = (first_insn >> 26) & 0x3F;
        printf("  Entry instruction: 0x%08X (opcode 0x%02X)\n", first_insn, op);

        if (op == 0x0F) printf("    -> LUI (load upper immediate)\n");
        else if (op == 0x10) printf("    -> COP0 (co-processor 0)\n");
        else if (op == 0x08) printf("    -> J (jump)\n");
        else if (op == 0x0C) printf("    -> JAL (jump and link)\n");
        else if (op == 0x00) printf("    -> SPECIAL (R-type)\n");
        else printf("    -> Other\n");
    }

    printf("[VHB] Payload ready for execution.\n");
    printf("  In a live emulator environment, the VHB would now transfer control\n");
    printf("  to 0x%08X with the following state:\n", entry_point);
    printf("    PC=0x%08X  GP=0x%08X  SP=0x%08X\n",
           entry_point, rom_info.gp_value, rom_info.sp_value);
    printf("    MMU active, %u vectors registered, %u VFS files mounted\n",
           (uint32_t)vectors.count(), 0);
}

// ============================================================================
// Status Print
// ============================================================================

void SuperBIOSHypervisor::print_status() const {
    printf("\n=== VHB Status ===\n");
    printf("  Target: %s\n", profile.name);
    printf("  ROM: %s\n", rom_info.file_path.c_str());
    printf("  Format: %s\n", rom_info.format.c_str());
    printf("  Valid: %s\n", rom_info.valid ? "YES" : "NO");
    if (rom_info.valid) {
        printf("  Entry PC: 0x%08X\n", rom_info.entry_pc);
        printf("  Load addr: 0x%08X\n", rom_info.load_addr);
        printf("  Text size: 0x%X (%u bytes)\n", rom_info.text_size, rom_info.text_size);
        printf("  GP: 0x%08X  SP: 0x%08X\n", rom_info.gp_value, rom_info.sp_value);
        if (rom_info.exe_lba > 0) {
            printf("  EXE LBA: %u  Sector: %u bytes\n", rom_info.exe_lba, rom_info.sector_size);
        }
    }
    printf("  Memory regions: %u\n", (uint32_t)context->memory_map.size());
    printf("  MMU pool: %u MB\n", mmu.pool_size() / (1024*1024));
    printf("  RAM ceiling: 0x%08X\n", profile.ram_ceiling);
    printf("  Descriptor safe base: 0x%08X\n", profile.desc_safe_base);
    printf("==================\n");
}

// ============================================================================
// ISO Sector Reader
// ============================================================================

std::vector<uint8_t> SuperBIOSHypervisor::read_iso_sector(std::ifstream& f, uint32_t lba,
                                                            uint32_t sector_size, uint32_t data_offset) {
    uint32_t user_size = sector_size - data_offset - (sector_size == 2352 ? 280 : 0);
    f.seekg((uint64_t)lba * sector_size + data_offset);
    std::vector<uint8_t> buf(user_size);
    f.read((char*)buf.data(), user_size);
    if (!f) {
        buf.resize(f.gcount());
    }
    return buf;
}

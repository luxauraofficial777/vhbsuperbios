// =============================================================================
// vhb_launch.cpp — VHB Launcher CLI
//
// Command-line tool to load, inspect, and launch custom ROMs through the
// Virtual Hypervisor BIOS. Supports PSX EXEs, ISO images, and raw binaries.
//
// Build:
//   g++ -O2 -std=c++17 -o vhb_launch.exe vhb_core.cpp vhb_launch.cpp
//
// Usage:
//   vhb_launch <rom_path> [--target psx|snes|saturn] [--entry 0xADDR]
//              [--inspect] [--vectors] [--vfs <name>:<path>]
//
// Examples:
//   vhb_launch dq4_frankenstein_v34.bin --target psx --inspect
//   vhb_launch SLUS_012.06 --target psx --entry 0x800BCCF0
//   vhb_launch FRANKENSTEIN.BIOS --target psx --inspect
// =============================================================================

#include "vhb_core.h"
#include <cstdio>
#include <cstring>
#include <cstdlib>

static void usage() {
    printf("Usage: vhb_launch <rom_path> [options]\n\n");
    printf("Options:\n");
    printf("  --target psx|snes|saturn  Target system (default: psx)\n");
    printf("  --entry 0xADDR             Override entry point\n");
    printf("  --inspect                   Print ROM info and exit (no execution)\n");
    printf("  --vectors                   List registered VHB vectors\n");
    printf("  --vfs NAME:PATH             Mount a file in VFS\n");
    printf("  --load-addr 0xADDR          Override load address\n");
    printf("  --exe-lba N                 EXE LBA in ISO (default: 24)\n");
    printf("  --help                      Show this help\n");
    printf("\n");
    printf("Supported formats:\n");
    printf("  PS-X EXE (standalone .EXE files)\n");
    printf("  ISO 9660 (MODE1/MODE2, auto-detected)\n");
    printf("  Raw binary (fallback)\n");
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        usage();
        return 1;
    }

    std::string rom_path = argv[1];
    TargetSystem target = TargetSystem::PSX_Hybrid;
    uint32_t entry_override = 0;
    bool inspect_only = false;
    bool show_vectors = false;
    uint32_t exe_lba = 24;
    uint32_t load_addr_override = 0;
    bool has_load_override = false;

    // VFS mounts: pairs of (name, path)
    std::vector<std::pair<std::string, std::string>> vfs_mounts;

    // Parse arguments
    for (int i = 2; i < argc; i++) {
        std::string arg = argv[i];

        if (arg == "--help" || arg == "-h") {
            usage();
            return 0;
        } else if (arg == "--target") {
            if (++i >= argc) { printf("ERROR: --target needs a value\n"); return 1; }
            std::string t = argv[i];
            if (t == "psx") target = TargetSystem::PSX_Hybrid;
            else if (t == "snes") target = TargetSystem::SNES_Extended;
            else if (t == "saturn") target = TargetSystem::Saturn_Flexible;
            else { printf("ERROR: Unknown target '%s'\n", t.c_str()); return 1; }
        } else if (arg == "--entry") {
            if (++i >= argc) { printf("ERROR: --entry needs a value\n"); return 1; }
            entry_override = (uint32_t)strtoul(argv[i], nullptr, 0);
        } else if (arg == "--inspect") {
            inspect_only = true;
        } else if (arg == "--vectors") {
            show_vectors = true;
        } else if (arg == "--vfs") {
            if (++i >= argc) { printf("ERROR: --vfs needs NAME:PATH\n"); return 1; }
            std::string vfs_arg = argv[i];
            size_t colon = vfs_arg.find(':');
            if (colon == std::string::npos) {
                printf("ERROR: --vfs format is NAME:PATH\n");
                return 1;
            }
            vfs_mounts.push_back({vfs_arg.substr(0, colon), vfs_arg.substr(colon + 1)});
        } else if (arg == "--load-addr") {
            if (++i >= argc) { printf("ERROR: --load-addr needs a value\n"); return 1; }
            load_addr_override = (uint32_t)strtoul(argv[i], nullptr, 0);
            has_load_override = true;
        } else if (arg == "--exe-lba") {
            if (++i >= argc) { printf("ERROR: --exe-lba needs a value\n"); return 1; }
            exe_lba = (uint32_t)strtoul(argv[i], nullptr, 0);
        } else {
            printf("WARNING: Unknown option '%s'\n", arg.c_str());
        }
    }

    // Initialize VHB
    SuperBIOSHypervisor bios(target);

    // Load ROM
    if (!bios.load_rom(rom_path)) {
        printf("ERROR: Failed to load ROM.\n");
        return 1;
    }

    // Mount VFS files
    for (const auto& [name, path] : vfs_mounts) {
        std::ifstream f(path, std::ios::binary | std::ios::ate);
        if (!f) {
            printf("WARNING: Cannot open VFS file '%s'\n", path.c_str());
            continue;
        }
        size_t sz = f.tellg();
        f.seekg(0);
        std::vector<uint8_t> data(sz);
        f.read((char*)data.data(), sz);
        bios.vfs_mount(name, data.data(), (uint32_t)sz);
    }

    // Register ROM hack vectors
    bios.register_rom_hack_vectors();

    // Print status
    bios.print_status();

    if (show_vectors) {
        printf("\n=== Registered Vectors ===\n");
        bios.list_vectors();
    }

    if (inspect_only) {
        printf("\n[VHB] Inspection complete. Exiting (--inspect mode).\n");
        return 0;
    }

    // Determine entry point
    uint32_t entry = entry_override;
    if (entry == 0) {
        entry = bios.rom_info_get().entry_pc;
    }
    if (entry == 0) {
        entry = bios.get_profile().payload_entry;
    }

    // Override load address if specified
    if (has_load_override) {
        printf("[VHB] Load address override: 0x%08X\n", load_addr_override);
    }

    // Execute payload
    printf("\n");
    bios.execute_payload(entry);

    printf("\n[VHB] Launch sequence complete.\n");
    printf("  To run this ROM in an emulator, use the clean-room FRANKENSTEIN.BIOS\n");
    printf("  and point the emulator's CD drive to the ROM's ISO image.\n");

    return 0;
}

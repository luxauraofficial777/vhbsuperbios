# =============================================================================
# Project Frankenstein: Clean-Room Compliant Super BIOS Bootstrap
#
# LEGAL NOTICE:
#   This file contains 100% original MIPS assembly code. It does NOT
#   contain, reference, or link to any copyrighted Sony, Nintendo, or
#   other proprietary firmware code. No proprietary BIOS dumps are
#   merged into the output. The resulting binary is built entirely
#   from this source file.
#
# Architecture:
#   - MIPS R3000A ISA (publicly documented instruction set)
#   - SFX-100 cartridge bus probe (hypothetical expansion)
#   - Multi-region initialization (NA/JP/EU) via public hardware registers
#   - PSX2 IOP bridge stubs for extended I/O
#
# Memory Map (publicly documented hardware addresses):
#   0xBFC00000 - BIOS ROM base (512KB)
#   0x1F000000 - Hardware registers (CPU control)
#   0x1F801000 - Memory control registers (public datasheet)
#   0x1F400000 - SFX-100 expansion bus (hypothetical)
#   0x80100000 - RAM payload entry (Frankenstein ROM)
#   0xB8000000 - Kanji ROM mapping (JP region, public spec)
#
# Build:
#   python build_frankenstein_bios.py
#   (Uses cybergrime/mips/assembler.py — no external toolchain needed)
# =============================================================================

.set noreorder
.global _start
.org 0xbfc00000

# =============================================================================
# Boot Entry Point
# =============================================================================
_start:
    # Step 1: Safe Hardware State Initialization
    # CP0 Status Register: kernel mode, disable interrupts, BEV=1
    li      $t0, 0x00400000         # Kernel mode, clear interrupts
    mtc0    $t0, 12                 # Write to Status Register (CP0 $12)
    nop                             # CP0 write hazard
    mtc0    $zero, 13               # Clear Cause Register (CP0 $13)
    nop

    # Step 2: Initialize Open Memory Controllers via Standard Bus Mapping
    lui     $t1, 0x1f80             # Base I/O address (public hardware register)
    ori     $t2, $t1, 0x1000        # Memory Control Register offset
    li      $t3, 0x00070707         # Generic open-bus timing parameters
    sw      $t3, 0($t2)
    nop

    # Step 3: Configure RAM Size Register (public spec: 2MB)
    li      $t3, 0x00000B88         # 2MB RAM configuration
    sw      $t3, 0x1060($t1)        # RAM_SIZE register at 0x1F801060
    nop

    # Step 4: Clear RAM (first 64KB sanity check region)
    li      $t0, 0x00000000         # Start of RAM (KUSEG)
    li      $t1, 0x0000FFFF         # End of clear region (64KB)
clear_ram_loop:
    sw      $zero, 0($t0)
    addiu   $t0, $t0, 4
    sltu    $t2, $t0, $t1
    bne     $t2, $zero, clear_ram_loop
    nop

    # Step 5: Probe SFX-100 / SNES-CD Cartridge Bus Interface
    jal     Probe_SFX100_Bus
    nop
    bne     $v0, $zero, sfx_boot_mode
    nop

    # Default: Standard Boot Path
    jal     Init_Region_Profile     # Determine NA/JP/EU via hardware config
    nop
    j       Launch_Frankenstein_Rom
    nop

sfx_boot_mode:
    # Initialize SNES-CD / SFX-100 shared memory registers
    jal     Init_SFX100_Bridge
    nop
    j       Launch_Frankenstein_Rom
    nop

# =============================================================================
# Frankenstein ROM Launch
# =============================================================================
Launch_Frankenstein_Rom:
    # Direct handshake to Frankenstein Application Layer
    lui     $k0, 0x8010             # Target RAM Vector
    ori     $k0, $k0, 0x0000
    jr      $k0                     # Jump to Frankenstein payload
    nop

# =============================================================================
# SFX-100 Cartridge Bus Probe
# =============================================================================
Probe_SFX100_Bus:
    # Hardware handshake probe for the unreleased expansion slot
    lui     $t4, 0x1f40             # Hypothetical SFX expansion register space
    lw      $v0, 0($t4)            # Read expansion ID register
    nop                             # Load delay slot
    lui     $t5, 0x5346             # 'SF' magic word check (0x53460000)
    bne     $v0, $t5, probe_fail
    nop
    li      $v0, 1                  # Success: SFX-100 hardware present
    jr      $ra
    nop

probe_fail:
    li      $v0, 0                  # Standard mode fallback
    jr      $ra
    nop

# =============================================================================
# Region Profile Initialization
# =============================================================================
Init_Region_Profile:
    # Read region from hardware configuration area (public register spec)
    # Region codes: 0=JP, 1=NA, 2=AUS, 3=UK, 4=EU, 5=Korea, 6=HK, 7=TW, 8=RUS

    lui     $t0, 0x1f80             # Hardware register base
    lbu     $t1, 0x1060($t0)        # Read region byte from RAM_SIZE config
    nop

    # Branch to region-specific init
    beq     $t1, $zero, region_jp   # Region 0 = Japan
    nop
    li      $t2, 1
    beq     $t1, $t2, region_na     # Region 1 = North America
    nop
    li      $t2, 4
    beq     $t1, $t2, region_eu     # Region 4 = Europe
    nop
    j       region_default          # Unknown region — use NA defaults
    nop

region_jp:
    # Japan: Kanji ROM mapping at 0xB8000000 (public hardware spec)
    lui     $t3, 0xB800             # Kanji ROM base
    li      $t4, 0x00000001         # Enable Kanji ROM
    sw      $t4, 0($t3)
    nop
    # Set NTSC timing (60Hz VSync)
    li      $t5, 0x00000000         # NTSC mode
    j       region_done
    nop

region_na:
    # North America: NTSC timing / CD Audio Sync
    li      $t5, 0x00000000         # NTSC mode
    j       region_done
    nop

region_eu:
    # Europe: PAL interlace / 50Hz VSync handlers
    li      $t5, 0x00000001         # PAL mode
    j       region_done
    nop

region_default:
    # Default to NA/NTSC
    li      $t5, 0x00000000

region_done:
    # Store region mode in a global config location
    lui     $t6, 0x8010             # RAM config area
    ori     $t6, $t6, 0xFFC0       # Offset 0xFFC0 (config page)
    sw      $t5, 0($t6)            # Store region mode
    nop

    jr      $ra
    nop

# =============================================================================
# SFX-100 Bridge Initialization
# =============================================================================
Init_SFX100_Bridge:
    # Map 65816 co-processor communication buffers
    lui     $t0, 0x1f40             # SFX expansion space
    nop

    # Initialize communication buffer descriptors
    li      $t1, 0x00000001         # Enable bridge
    sw      $t1, 0x0100($t0)       # Bridge control register
    nop

    # Set up 65816 I/O buffer at expansion RAM
    lui     $t2, 0x1f41             # Expansion RAM base
    li      $t3, 0x0000FFFF         # Buffer size mask
    sw      $t3, 0($t2)            # Initialize buffer header
    nop

    # Enable SFX-100 interrupt routing
    li      $t4, 0x00000002         # IRQ enable for cartridge bus
    sw      $t4, 0x0200($t0)       # IRQ mask register
    nop

    jr      $ra
    nop

# =============================================================================
# Open-Source Signature Block (NOT a proprietary identifier)
# =============================================================================
.org 0xbfc07FE0
# 32-byte open-source signature at end of 512KB BIOS image
# Identifies this as a Frankenstein-PSX clean-room build
# Format: "FRANK-PSX\0" + "OPEN-BIOS\0\0\0\0\0\0\0"
# These are injected by build_frankenstein_bios.py

#!/usr/bin/env python3
"""
Project Frankenstein: Clean-Room Build Orchestrator

Hybrid pipeline: Python orchestrator invokes external MIPS toolchain when
available, falls back to internal Python assembler, then invokes C++ bios_tool
for binary post-processing (pad, signature inject, checksum, verify).

No proprietary BIOS dumps are used. The output is built entirely from
original assembly source code.

Usage:
    python build_frankenstein_bios.py [--region NA|JP|EU] [--output PATH]

External toolchain (optional):
    mipsel-linux-gnu-as  — MIPS assembler
    mipsel-linux-gnu-ld  — MIPS linker

Fallback:
    cybergrime/mips/assembler.py — pure Python MIPS I assembler

C++ utility:
    bios_tool — pad, signature inject, checksum, clean-room verify
    (auto-compiled from bios_tool.cpp if bios_tool.exe is missing)
"""

import argparse
import hashlib
import os
import shutil
import struct
import subprocess
import sys

# Paths
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)
CYBERGRIME_DIR = os.path.join(PROJECT_ROOT, "cybergrime")
sys.path.insert(0, CYBERGRIME_DIR)

ASSEMBLY_SOURCE = os.path.join(SCRIPT_DIR, "frankenstein_bios.s")
BIOS_TOOL_SRC = os.path.join(SCRIPT_DIR, "bios_tool.cpp")
BIOS_TOOL_EXE = os.path.join(SCRIPT_DIR, "bios_tool.exe")
DEFAULT_OUTPUT = os.path.join(SCRIPT_DIR, "FRANKENSTEIN.BIOS")
BUILD_DIR = os.path.join(SCRIPT_DIR, "build")

# External toolchain names to probe for
EXTERNAL_ASSEMBLERS = ["mipsel-linux-gnu-as", "mips-linux-gnu-as"]
EXTERNAL_LINKERS = ["mipsel-linux-gnu-ld", "mips-linux-gnu-ld"]


def find_tool(names):
    """Find an executable in PATH from a list of candidate names."""
    for name in names:
        path = shutil.which(name)
        if path:
            return path
    return None


def ensure_bios_tool():
    """Ensure bios_tool.exe is compiled. Compile if missing or source is newer."""
    need_compile = False
    if not os.path.exists(BIOS_TOOL_EXE):
        need_compile = True
    elif os.path.exists(BIOS_TOOL_SRC):
        src_mtime = os.path.getmtime(BIOS_TOOL_SRC)
        exe_mtime = os.path.getmtime(BIOS_TOOL_EXE)
        if src_mtime > exe_mtime:
            need_compile = True

    if need_compile:
        print("[0/5] Compiling bios_tool.cpp (C++ utility)...")
        gcc = shutil.which("g++") or shutil.which("gcc")
        if not gcc:
            print("  WARNING: No C++ compiler found. Using Python fallback for binary ops.")
            return False
        cmd = [gcc, "-O2", "-std=c++17", "-o", BIOS_TOOL_EXE, BIOS_TOOL_SRC]
        print(f"  Executing: {' '.join(cmd)}")
        result = subprocess.run(cmd)
        if result.returncode != 0:
            print("  WARNING: C++ compilation failed. Using Python fallback.")
            return False
        print("  bios_tool compiled successfully.")
    return True


def try_external_toolchain():
    """Try to assemble + link using external MIPS toolchain. Returns raw binary path or None."""
    as_path = find_tool(EXTERNAL_ASSEMBLERS)
    ld_path = find_tool(EXTERNAL_LINKERS)

    if not as_path or not ld_path:
        return None

    print(f"[1/5] External toolchain found: {as_path}")
    os.makedirs(BUILD_DIR, exist_ok=True)

    obj_path = os.path.join(BUILD_DIR, "frankenstein_bios.o")
    raw_path = os.path.join(BUILD_DIR, "frankenstein_bios.raw")

    # Step 1: Assemble
    print(f"[1/5] Assembling with external toolchain...")
    cmd = [as_path, "-march=r3000", "-mabi=32", ASSEMBLY_SOURCE, "-o", obj_path]
    print(f"  Executing: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print("  External assembler failed. Falling back to Python assembler.")
        return None

    # Step 2: Link as raw binary
    print(f"[2/5] Linking raw binary...")
    cmd = [ld_path, "-Ttext", "0xbfc00000", "--oformat", "binary",
           obj_path, "-o", raw_path]
    print(f"  Executing: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print("  External linker failed. Falling back to Python assembler.")
        return None

    print(f"  Raw binary: {raw_path}")
    return raw_path


def assemble_with_python():
    """Assemble using the internal Python MIPS assembler. Returns raw binary bytes."""
    print("[1/5] Assembling with Python MIPS assembler (fallback)...")
    from mips import assemble

    with open(ASSEMBLY_SOURCE, "r", encoding="utf-8") as f:
        source = f.read()

    words, labels = assemble(source, 0xBFC00000)
    machine_code = b"".join(struct.pack("<I", w) for w in words)

    print(f"  Machine code: {len(machine_code)} bytes ({len(words)} instructions)")
    print(f"  Labels: {', '.join(sorted(labels.keys()))}")

    # Write raw binary to build dir
    os.makedirs(BUILD_DIR, exist_ok=True)
    raw_path = os.path.join(BUILD_DIR, "frankenstein_bios.raw")
    with open(raw_path, "wb") as f:
        f.write(machine_code)

    return raw_path


def pack_with_cpp(raw_path, output_path, region):
    """Use C++ bios_tool to pad, inject signatures, and write final BIOS."""
    print(f"[3/5] Packing with bios_tool (C++ utility)...")
    cmd = [BIOS_TOOL_EXE, "pack", raw_path, output_path, "--region", region]
    print(f"  Executing: {' '.join(cmd)}")
    result = subprocess.run(cmd)
    return result.returncode == 0


def pack_with_python(raw_path, output_path, region):
    """Python fallback for binary packing (when bios_tool is unavailable)."""
    print(f"[3/5] Packing with Python fallback...")
    from mips import assemble  # already imported, but keep consistent

    BIOS_SIZE = 524288
    SIG_OFFSET = 0x7FE0

    with open(raw_path, "rb") as f:
        raw = f.read()

    bios = bytearray(BIOS_SIZE)
    for i in range(min(len(raw), BIOS_SIZE)):
        bios[i] = raw[i]

    # Inject signatures
    sig = b"FRANK-PSX\x00\x00\x00\x00\x00\x00\x00"
    tag = b"OPEN-BIOS\x00\x00\x00\x00\x00\x00\x00"
    for i in range(16):
        bios[SIG_OFFSET + i] = sig[i]
        bios[SIG_OFFSET + 16 + i] = tag[i]

    with open(output_path, "wb") as f:
        f.write(bios)

    sha = hashlib.sha256(bios).hexdigest()
    print(f"  Code: {len(raw)} bytes")
    print(f"  Zero-fill: {BIOS_SIZE - len(raw)} bytes")
    print(f"  SHA-256: {sha}")
    return True


def verify_bios(output_path, use_cpp):
    """Verify the built BIOS."""
    print("[4/5] Verifying...")

    if use_cpp:
        cmd = [BIOS_TOOL_EXE, "verify", output_path]
        result = subprocess.run(cmd)
        return result.returncode == 0
    else:
        # Python fallback verification
        BIOS_SIZE = 524288
        SIG_OFFSET = 0x7FE0

        with open(output_path, "rb") as f:
            data = f.read()

        passed = 0
        total = 0

        # Size
        total += 1
        if len(data) == BIOS_SIZE:
            print("  [PASS] Size")
            passed += 1
        else:
            print(f"  [FAIL] Size: {len(data)} != {BIOS_SIZE}")

        # Entry opcode
        total += 1
        entry = struct.unpack_from("<I", data, 0)[0]
        op = (entry >> 26) & 0x3F
        if op in (0x0F, 0x10):
            print(f"  [PASS] Entry opcode: 0x{op:02X}")
            passed += 1
        else:
            print(f"  [WARN] Entry opcode: 0x{op:02X}")

        # Signatures
        total += 1
        if data[SIG_OFFSET:SIG_OFFSET+8] == b"FRANK-PS":
            print("  [PASS] FRANK-PSX signature")
            passed += 1
        else:
            print("  [FAIL] No FRANK-PSX signature")

        total += 1
        if data[SIG_OFFSET+16:SIG_OFFSET+24] == b"OPEN-BIO":
            print("  [PASS] OPEN-BIOS tag")
            passed += 1
        else:
            print("  [FAIL] No OPEN-BIOS tag")

        # No proprietary strings
        total += 1
        if b"SCPH" not in data and b"Sony" not in data and b"SONY" not in data:
            print("  [PASS] No proprietary strings")
            passed += 1
        else:
            print("  [FAIL] Proprietary strings found")

        # Clean kernel area
        total += 1
        code_end = 0
        for i in range(0, SIG_OFFSET, 4):
            if struct.unpack_from("<I", data, i)[0] != 0:
                code_end = i + 4
        if all(b == 0 for b in data[code_end:SIG_OFFSET]):
            print(f"  [PASS] Clean-room: zeros 0x{code_end:04X}-0x{SIG_OFFSET:04X}")
            passed += 1
        else:
            print("  [FAIL] Non-zero in kernel area")

        print(f"\n  Result: {passed}/{total} checks passed")
        return passed == total


def main():
    parser = argparse.ArgumentParser(
        description="Build Project Frankenstein Clean-Room Super BIOS"
    )
    parser.add_argument(
        "--region", choices=["NA", "JP", "EU"], default="NA",
        help="Region profile (default: NA)",
    )
    parser.add_argument(
        "--output", default=DEFAULT_OUTPUT,
        help=f"Output BIOS path (default: {DEFAULT_OUTPUT})",
    )
    parser.add_argument(
        "--verify-only", action="store_true",
        help="Only verify an existing BIOS file",
    )
    parser.add_argument(
        "--force-python", action="store_true",
        help="Force Python assembler even if external toolchain exists",
    )
    args = parser.parse_args()

    if args.verify_only:
        has_cpp = ensure_bios_tool()
        ok = verify_bios(args.output, has_cpp)
        return 0 if ok else 1

    if not os.path.exists(ASSEMBLY_SOURCE):
        print(f"ERROR: Assembly source not found: {ASSEMBLY_SOURCE}")
        return 1

    # Step 0: Ensure C++ bios_tool is available
    has_cpp = ensure_bios_tool()

    # Step 1-2: Assemble (external toolchain or Python fallback)
    raw_path = None
    if not args.force_python:
        raw_path = try_external_toolchain()

    if raw_path is None:
        raw_path = assemble_with_python()

    # Step 3: Pack (C++ bios_tool or Python fallback)
    if has_cpp:
        ok = pack_with_cpp(raw_path, args.output, args.region)
    else:
        ok = pack_with_python(raw_path, args.output, args.region)

    if not ok:
        print("ERROR: Packing failed.")
        return 1

    # Step 4: Verify
    ok = verify_bios(args.output, has_cpp)

    # Step 5: Summary
    print("\n[5/5] Build Summary")
    print(f"  Source:     {ASSEMBLY_SOURCE}")
    print(f"  Region:     {args.region}")
    print(f"  Output:     {args.output}")
    print(f"  Toolchain:  {'external' if not args.force_python and find_tool(EXTERNAL_ASSEMBLERS) else 'Python fallback'}")
    print(f"  Binary ops: {'C++ bios_tool' if has_cpp else 'Python fallback'}")
    print(f"  Verify:     {'PASS' if ok else 'FAIL'}")
    print(f"  Clean-room: {'YES — zero proprietary code' if ok else 'NO — violations found'}")

    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
